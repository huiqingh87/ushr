from PyQt5 import QtCore, uic
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QBrush, QColor, QIcon
import os, sys
import pyperclip as clipboard
from .resources import *
from .render import *



class client_db_win(QMainWindow):
    def __init__(self,mainwin=None):
        super().__init__()
        self.setWindowTitle("Client Database Configuration")
        self.setWindowIcon(QIcon(":/plugin/happy_ansi/db.png"))
        self.main = mainwin
        self.layouts = {}
        self.num_of_layer = 0

        rfdb_layout = QVBoxLayout()
        rfdb_ctl_layout = QHBoxLayout()         
        self.rfdb_cbox  = QCheckBox('RFDB')
        self.rfdb_down  = QToolButton()
        self.rfdb_down.setFixedSize(QSize(20,20))
        self.rfdb_down.setIcon(QIcon(':/plugin/happy_ansi/down'))
        self.rfdb_down.setIconSize(QSize(16,16))
        self.rfdb_down.setStyleSheet("border:1")
        rfdb_ctl_layout.addWidget(self.rfdb_cbox)
        rfdb_ctl_layout.addStretch()
        rfdb_ctl_layout.addWidget(self.rfdb_down)
        self.rfdb_list  = QListWidget()           
        self.rfdb_list.setStyleSheet("QListView {padding-top:5px;}")
        rfdb_num_layer = 0
        for lyr, lyr_name in client_layers['RFDB'].items():
            rfdb_num_layer += len(lyr_name)
            if lyr:
                item = QListWidgetItem(lyr)
                # could be Qt.Unchecked; setting it makes the check appear
                if lyr in self.main.rfdb_layers:
                    item.setCheckState(Qt.Checked)
                else:
                    item.setCheckState(Qt.Unchecked)
                self.rfdb_list.addItem(item)              
        self.num_of_layer = max(self.num_of_layer,rfdb_num_layer)
        rfdb_layout.addLayout(rfdb_ctl_layout)
        rfdb_layout.addWidget(self.rfdb_list)

        win_width = 200
        if self.main.ansi_database!='RFDB':
            client_layout = QVBoxLayout()
            client_ctl_layout = QHBoxLayout()         
            self.client_cbox  = QCheckBox(self.main.ansi_database)
            self.client_down  = QToolButton()
            self.client_down.setFixedSize(QSize(20,20))
            self.client_down.setIcon(QIcon(':/plugin/happy_ansi/down'))
            self.client_down.setIconSize(QSize(16,16))
            self.client_down.setStyleSheet("border:1")

            client_ctl_layout.addWidget(self.client_cbox)
            client_ctl_layout.addStretch()
            client_ctl_layout.addWidget(self.client_down)
            self.client_list  = QListWidget()           
            self.client_list.setStyleSheet("QListView {padding-top:5px;}")
            if self.main.ansi_database.startswith('CR'):
                self.num_of_layer = max(self.num_of_layer,len(client_layers['GM'].keys()))
            else:
                self.num_of_layer = max(self.num_of_layer,len(client_layers[self.main.ansi_database].keys()))
            for lyr, lyr_name in client_layers[self.main.ansi_database].items():  
                if lyr:
                    item = QListWidgetItem(lyr)
                    if lyr in self.main.client_layers:
                        item.setCheckState(Qt.Checked)
                    else:
                        item.setCheckState(Qt.Unchecked)
                    # could be Qt.Unchecked; setting it makes the check appear
                    self.client_list.addItem(item)            
            client_layout.addLayout(client_ctl_layout)
            client_layout.addWidget(self.client_list)

            self.client_list.itemClicked.connect(self.client_clicked)
            self.client_cbox.stateChanged.connect(self.toggle_client)
            self.rfdb_cbox.stateChanged.connect(self.toggle_rfdb)    
            self.client_down.clicked.connect(self.down_client)
            self.rfdb_down.clicked.connect(self.down_rfdb)        
            merged_layout = QHBoxLayout()
            merged_layout.addStretch()

            for l in rfdb_layout, client_layout:
                merged_layout.addLayout(l)
            merged_layout.addStretch()   
            win_width += 200 
        else:
            win_width = 300
            merged_layout = rfdb_layout
            self.rfdb_cbox.stateChanged.connect(self.toggle_rfdb) 
            self.rfdb_down.clicked.connect(self.down_rfdb)    
        
        self.rfdb_list.itemClicked.connect(self.rfdb_clicked)
        self.setFixedSize(QSize(win_width, self.num_of_layer * 20+10))
        widget = QWidget()
        widget.setLayout(merged_layout)
        self.setCentralWidget(widget)

    def rfdb_clicked(self,item):
        lyr = item.text()
        if item.checkState()==Qt.Checked:
            if lyr not in self.main.rfdb_layers:
                self.main.rfdb_layers.append(lyr)
        else:
            if lyr in self.main.rfdb_layers:
                self.main.rfdb_layers.remove(lyr)
        #print(','.join(self.main.rfdb_layers))

    def client_clicked(self,item):
        lyr = item.text()
        if item.checkState()==Qt.Checked:
            if lyr not in self.main.client_layers:
                self.main.client_layers.update({lyr:client_layers[self.main.ansi_database][lyr]})
        else:
            if lyr in self.main.client_layers:
                self.main.client_layers.pop(lyr)
        #print(','.join(self.main.client_layers))

    def toggle_client(self):       
        if self.client_cbox.isChecked():
            for i in range(self.client_list.count()):
                self.client_list.item(i).setCheckState(Qt.Checked)
        else:
            for i in range(self.client_list.count()):
                self.client_list.item(i).setCheckState(Qt.Unchecked)
    def toggle_rfdb(self):        
        if self.rfdb_cbox.isChecked():
            for i in range(self.rfdb_list.count()):
                self.rfdb_list.item(i).setCheckState(Qt.Checked)
        else:
            for i in range(self.rfdb_list.count()):
                self.rfdb_list.item(i).setCheckState(Qt.Unchecked)

    def down_client(self):        
        if self.main.ansi_database=='GM':
            self.main.show_gm()
        if self.main.ansi_database=='UDBX':
            self.main.show_udbx()
        if self.main.ansi_database=='UDBX3':
            self.main.show_udbx3()
        if self.main.ansi_database.find('CR')!=-1:
            self.main.show_gm(db=self.ansi_database)

    def down_rfdb(self):
        if self.main.ansi_database=='UDBX3':
            self.main.show_rfdb(dbname="JPRFDB")
        else:
            self.main.show_rfdb()

if __name__=='__main__':       
    app = QApplication(sys.argv)
    window = db_manager()
    window.show()
    app.exec_()