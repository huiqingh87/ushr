menus = {
        'File':[['Open','Save','Exit'],['self.load_data','self.save','self.closePlugin'],['open','save','exit']],
        'Setting':[['DB','Rules','Layer','Data Table'],['self.set_db','self.set_rules','self.set_lyrs', 'self.show_table'],['db','rules','layers','table']], 
        'QC':[['GM','Rivian','Nissan'],['','',''],['','','']],
        'GM':[['ANSI','Toll','Ramp','Tunnel','Bidirectional'],['','','','',''],['','','','','']],
        'Rivian':[['ANSI','Toll','Ramp','Tunnel','Bidirectional'],['','','','',''],['','','','','']],
        'Nissan':[['ANSI','Toll','Ramp','Tunnel','Bidirectional'],['','','','',''],['','','','','']],
        'Evaluation':[['Daily','Engineer','Overall'],['self.sum_daily','self.sum_tech','self.sum_overall'],['daily','qc','pie']],
        'Help':[['Version','About','Contact'],['self.load_data','self.show_about','self.set_lyrs'],['','info','']]
        }

tools = ['Open','Save','','Layer','DB','Rules','Data Table','','Daily','Engineer','Overall','','About','Exit']
ctools = ['DB','Rules','Daily','Engineer','Overall',]

current_dir =r'C:\Users\hhuang\Downloads\happyAnsi_ver0'


def autolabel(rects):
    """Attach a text label above each bar in *rects*, displaying its height."""
    for rect in rects:
        height = rect.get_height()
        ax.annotate('{}'.format(height),
                    xy=(rect.get_x() + rect.get_width() / 2, height),
                    xytext=(0, 3),  # 3 points vertical offset
                    textcoords="offset points",
                    ha='center', va='bottom')

    # or p in ax.patches:
    #     ax.annotate(str(p.get_height()), (p.get_x() * 1.005, p.get_height() * 1.005))

class MplCanvas(FigureCanvasQTAgg):
    def __init__(self, parent=None, width=10, height=8, dpi=100,subplot=111):
        self.fig = Figure(figsize=(width, height), dpi=dpi)
        self.axes = self.fig.add_subplot(subplot)
        super().__init__(self.fig)
    def addSubplot(self,subplot):
        self.splot = self.fig.add_subplot(subplot)
        return self.splot
class PlotWindow(QMainWindow):
    def __init__(self,title="USHR Happy ANSI Helper - Summary",win_width=450, win_height =  300, ltx = 50, lty=50,subplot=111):
        super().__init__()
        # Create the maptlotlib FigureCanvas object,
        # which defines a single set of axes as self.axes.
        self.setWindowTitle(title)
        self.setWindowIcon(QIcon(":/plugin/happy_ansi/table.png"))
        self.setMinimumSize(QSize(win_width, win_height))
        self.move(ltx,lty)
        self.sc = MplCanvas(self, width=6, height=4, dpi=80,subplot=subplot)
        plt.tight_layout()
        self.setCentralWidget(self.sc)

class HMessageBox(QDialog):
    def __init__(self, parent=None,title='MessageBox',win_width=280, win_height =  120,message='MessageBox Text',png='warning.png'):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.setFixedSize(win_width,win_height)
        QBtn = QDialogButtonBox.Ok | QDialogButtonBox.Cancel
        self.buttonBox = QDialogButtonBox(QBtn)
        self.buttonBox.accepted.connect(self.accept)
        self.buttonBox.rejected.connect(self.reject)
        self.layout = QVBoxLayout()
        self.blayout = QHBoxLayout()
        icon = QLabel()
        pixmap = QPixmap(png)
        icon.setPixmap(pixmap)
        msgLabel = QLabel(message)
        self.blayout.addWidget(icon)
        self.blayout.addWidget(msgLabel)
        self.layout.addLayout(self.blayout)
        self.layout.addWidget(self.buttonBox)
        self.setLayout(self.layout)

        qss = """QLabel {
                    margin-left:5px;margin-right:5px;
                };
                """
        self.setStyleSheet(qss)

    def setIcon(self):
        print('icon')