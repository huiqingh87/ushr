# -*- coding: utf-8 -*-

from PyQt5.QtCore import *
from PyQt5.QtGui import *
from PyQt5.QtWidgets import QDialog
from datetime import datetime
from .ui.ui_about import Ui_DlgAbout
#from __init__ import name, description, version
import platform
def name():
    return "Happy ANSI Helper"

def description():
    return "it is a handy tool aims to promote the efficiency and happiness within QGis"

def version():
    return "0.1.0"

def qgisMinimumVersion():
    return "3.10.0"

def icon():
    return "icons/green_globe.png"

def authorName():
    return "Huiqing Huang"

from .resources import *


class DlgAbout(QDialog, Ui_DlgAbout):

	def __init__(self, parent=None):
		QDialog.__init__(self, parent)
		self.setupUi(self)
		self.setWindowTitle('About the Plugin')
		self.setFixedSize(QSize(500,380))
		self.logo.setPixmap( QPixmap( ":/plugin/happy_ansi/icon1.png" ) )
		self.title.setText( name() )

		self.description.setText( description() )
		text = self.txt.toHtml()
		text = text.replace( "$PLUGIN_NAME$", name() )

		subject = "Help: %s" % name()
		body = """\n\n
--------------------------------------------------
Plugin name: %s
Plugin version: %s
Python version: %s
Platform: %s - %s
Date: %s
--------------------------------------------------


""" % ( name(), version(), platform.python_version(), platform.system(), platform.version(), datetime.now().strftime('%Y-%m-%d') )

		mail = QUrl( "mailto:hhuang@ushrauto.com" )
		query = QUrlQuery()
		query.addQueryItem( "subject", subject )
		query.addQueryItem( "body", body )
		mail.setQuery(query)


		text = text.replace( "$MAIL_SUBJECT$", query.queryItemValue("subject", QUrl.FullyDecoded))  #unicode(mail.encodedQueryItemValue( "subject" )) )
		text = text.replace( "$MAIL_BODY$", query.queryItemValue("body", QUrl.FullyDecoded))     #unicode(mail.encodedQueryItemValue( "body" )) )

		self.txt.setHtml(text)



def email(subject, body):
    """Opens the e-mail composer with the given subject and body, with version information added to it."""
    subject = "[{0} {1}] {2}".format(appinfo.appname, appinfo.version, subject)
    body = "{0}\n\n{1}\n\n".format(debuginfo.version_info_string(' -- '), body)
    url = QUrl("mailto:" + appinfo.maintainer_email)
    query = QUrlQuery()
    query.addQueryItem("subject", subject)
    query.addQueryItem("body", body)
    url.setQuery(query)
    helpers.openUrl(url, "email")