from .db_conn import make_query


def query_subcountry_list(conn):
    query = '''select subcountry
               from work_units.work_unit
               group by subcountry
               order by subcountry'''
    response = make_query(conn, query, None)
    subcountry_list = []
    for row in response:
        subcountry = row[0]
        subcountry_list.append(subcountry)
    return subcountry_list


def query_extra_subcountry_list(conn):
    query = '''select subcountry
               from work_units.extra_subcountries
               group by subcountry
               order by subcountry'''
    response = make_query(conn, query, None)
    extra_subcountry_list = []
    for row in response:
        subcountry = row[0]
        extra_subcountry_list.append(subcountry)
    return extra_subcountry_list


def query_sign_types(conn):
    query = '''SELECT name, super_type FROM signs.sign_types order by name'''
    response = make_query(conn, query, None)
    sign_type_dict = {}
    for row in response:
        sign_type, sign_super_type = row
        sign_type_dict[sign_type] = sign_super_type
    return sign_type_dict


def query_pm_types(conn):
    query = '''SELECT road_object_type_name 
               FROM road_object.road_object_type_descriptions where road_object_type_name like 'RO_PM_%%'
               ORDER BY road_object_type_name
                '''
    response = make_query(conn, query, None)
    pm_type_list = []
    for row in response:
        pm_type = row[0]
        pm_type_list.append(pm_type)
    return pm_type_list


def query_crossing_types(conn):
    query = '''SELECT crossing_type_name FROM crossing.crossing_type_descriptions
                ORDER BY crossing_type_name 
                '''
    response = make_query(conn, query, None)
    crossing_type_list = []
    for row in response:
        crossing_type = row[0]
        crossing_type_list.append(crossing_type)
    return crossing_type_list


def query_feature_type_enums(conn, feature_dict):
    feature_type_enums = {}
    for feature in feature_dict:
        enums = []
        if feature == 'crossing':
            enums = query_crossing_types(conn)
        feature_type_enums[feature] = enums
    return feature_type_enums
