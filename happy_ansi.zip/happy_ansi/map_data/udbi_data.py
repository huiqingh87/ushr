from map_data.db_conn import *
from map_data.utils import *
from map_data.rfdb_enums import *


class UDBIMapData:
    def __init__(self, mainwin):
        self.main_win = mainwin
        self.conn = mainwin.customer_conn
        self.extent = mainwin.extent
        self.srid = 4326

    def is_udbi_db(self):
        query = '''SELECT * 
                   FROM INFORMATION_SCHEMA.TABLES 
                   WHERE TABLE_SCHEMA = %s
                   AND  TABLE_NAME = %s
                   '''
        response = make_query(self.conn, query, ('udbi', 'path_attributes'))
        if len(response) == 0:
            return False
        else:
            return True

    def query_road_segment_in_extent(self):
        query = f'''select *
                    from udbi.road_segment
                    where st_within(road_segment_geometry, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                    {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    '''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('number_of_lanes', QVariant.Int),
                      QgsField('number_of_driving_lanes', QVariant.Int), QgsField('road_type', QVariant.String),
                      QgsField('subcountry', QVariant.String), QgsField('region_id', QVariant.Int),
                      QgsField('road_name', QVariant.String), QgsField('road_id', QVariant.Int),
                      QgsField('created_at', QVariant.DateTime), QgsField('has_left_shoulder', QVariant.Bool),
                      QgsField('sub_country', QVariant.String), QgsField('osm_way_id', QVariant.Int),
                      QgsField('osm_way_type', QVariant.String), QgsField('wu_id', QVariant.Int)]
        feature_list = []
        road_type_set = set([])
        for row in response:
            road_segment_id, number_of_lanes, number_of_driving_lanes, road_type, subcountry, region_id, \
                road_name, road_id, created_at, has_left_shoulder, sub_country, osm_way_id, osm_way_type, wu_id, \
                geom = row[0:15]
            road_type = rfdb_road_type_df[rfdb_road_type_df['id'] == road_type]['road_type'].values[0]
            road_type_set.add(road_type)
            polygon = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            f.setAttributes([road_segment_id, number_of_lanes, number_of_driving_lanes, road_type, subcountry,
                             region_id, road_name, road_id, created_at, has_left_shoulder, sub_country,
                             osm_way_id, osm_way_type, wu_id])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', f'udbi_road_segment',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for road_type in road_type_set:
            actual_width = 1
            label = road_type
            exp = f'''road_type = \'{label}\''''
            line_style = 'solid'
            color = rfdb_road_type_df[rfdb_road_type_df['road_type'] == road_type]['color'].values[0]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer
