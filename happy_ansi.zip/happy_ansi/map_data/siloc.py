"""
    sign_id
    shape
    name
    type
    camera_imagery_id
    lidar_bbox
    camera_bbox
    pointcloud_id
    s3_bucket
    s3_key
    geom
    azimuth
    elevation

    functions:

    query signs in extent

"""

from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
from .db_conn import *
from ..ushr_image.ushr_image import UshrImage
from ..mapillary.mapillary import *


class Siloc:
    def __init__(self, mainwin,client='RFDB'):
        self.mainwin = mainwin
        self.client  = client
        self.id_ = None
        self.shape = None
        self.type = None
        self.value = None
        self.is_digital = None
        self.is_hanging = None
        self.width = None
        self.height = None
        self.azimuth = None
        self.elevation = None
        self.centroid_geom = None
        self.polygon_geom = None

        self.camera_imagery_id = None
        self.camera_bbox = None
        self.ushr_image = None
        self.is_ushr_image = True

        self.pointcloud_id = None
        self.lidar_bbox = None
        self.s3_location = None
        self.s3_bucket = None
        self.s3_key = None

        self.mapillary = None

        self.conn = None

    def get_mapillary_imagery(self):
        if self.mapillary is None:
            self.mapillary = Mapillary()
        captured_at, camera_image = self.mapillary.query_image(self.camera_imagery_id)
        return captured_at, camera_image

    # input: sign_id, output: image with attributes
    def get_sign_image(self, sign_id):
        self.id_ = sign_id
        self.query_siloc_data()
        if self.mainwin.ushr_image is None:
            self.mainwin.ushr_image = UshrImage(self)
        camera_imagery_captured_at, lidar_imagey_captured_at, camera_image, lidar_image = None, None, None, None
        if self.camera_imagery_id is None:
            self.mainwin.push_message(f'No camera image for rfdb sign {sign_id}!')
        else:
            # camera imagery can be from ushr-image or ushr-gen2 bucket or mapillary
            # camera image
            if '/' in self.camera_imagery_id:
                camera_image_s3_bucket, camera_image_s3_key = parse_s3_url(f's3://{self.camera_imagery_id}.jpg')
                camera_image = self.mainwin.ushr_image.query_image(camera_image_s3_bucket, camera_image_s3_key)
                camera_imagery_captured_at = f'{camera_image_s3_bucket}_{camera_image_s3_key}'
            else:
                camera_imagery_captured_at, camera_image = self.get_mapillary_imagery()
                camera_imagery_captured_at = f'Mapillary - {camera_imagery_captured_at}'
                self.is_ushr_image = False
            # LiDAR image
            if self.s3_bucket is not None:
                lidar_image = self.mainwin.ushr_image.query_image(self.s3_bucket, self.s3_key)
                lidar_imagey_captured_at = f'{self.s3_bucket}_{self.s3_key}'
        if camera_image is None:
            self.mainwin.push_message(f'No camera image found for camera_imagery_id: {self.camera_imagery_id}')
        return camera_imagery_captured_at, lidar_imagey_captured_at, lidar_image, camera_image, \
               self.lidar_bbox, self.camera_bbox, self.type, self.value, \
               self.shape, self.is_digital, self.is_hanging, self.centroid_geom

    def get_camera_image_date(self, s3_key):
        query = '''select date(datetime)
                   from datalake.camera_image
                   where s3_key = %'''
        response = make_query(self.conn, query, (s3_key,))
        if len(response) == 0:
            return None
        else:
            date_ = response[0][0]
            return date_

    def query_siloc_data(self):
        if self.client=='UDBX3':
            self.mainwin.update_current_conn("JPRFDB",verbal=0)
            self.mainwin.update_current_conn("UDBX3",verbal=0)
        elif self.client=='RFDB':
            print('testing')
            self.mainwin.update_current_conn("RFDB",verbal=0)
            print('testing over')
        else:
            self.mainwin.update_current_conn("RFDB",verbal=0)
            self.mainwin.update_current_conn(self.client,verbal=0)
        self.conn = self.mainwin.rfdb_conn        
        query = f'''SELECT st_astext(centroid) as centroid,
                    st_astext(st_polygon(st_linefrommultipoint(
                    st_collect(array[bl_corner, tl_corner, tr_corner, br_corner, bl_corner])), 4326)) as sign_geom,
                    width, height, azimuth, elevation, sign_shapes.name, sign_types.name, is_digital, camera_imagery_id, 
                    lidar_bbox, camera_bbox, asset.name, s3_location, is_hanging, value
                    FROM signs.signs
                    join signs.sign_types on sign_types.id = type_id
                    join signs.sign_shapes on sign_shapes.id = shape_id
                    join datalake.asset on asset.id = signs.asset_id
                    join datalake.intensity_lidar_image on intensity_lidar_image.asset_id = signs.asset_id
                    where signs.id = %s
                    and intensity_lidar_image.processing_index = signs.processing_index'''

        response = make_query(self.conn, query, (self.id_,))
        for row in response:
            self.centroid_geom, self.polygon_geom, self.width, self.height, self.azimuth, self.elevation, self.shape, \
                self.type, self.is_digital, self.camera_imagery_id, self.lidar_bbox, self.camera_bbox, \
                self.pointcloud_id, self.s3_location, self.is_hanging, self.value = row

            self.s3_bucket, self.s3_key = parse_s3_url(self.s3_location)

    def query_signs_in_extent(self, extent):
        xmin, ymin, xmax, ymax = extent
        query = f'''SELECT st_astext(centroid) as centroid,
                    st_astext(st_polygon(st_linefrommultipoint(
                    st_collect(array[bl_corner, tl_corner, tr_corner, br_corner, bl_corner])), 4326)) as sign_geom,
                    width, height, azimuth, elevation, shape, type, is_digital, camera_imagery_id, 
                    lidar_bbox, camera_bbox, asset.name, s3_location
                    FROM signs.signs
                    join datalake.asset on asset.id = signs.asset_id
                    join datalake.intensity_lidar_image on intensity_lidar_image.asset_id = signs.asset_id
                    where st_intersects(ST_MakeEnvelope({xmin}, {ymin}, {xmax}, {ymax}, 4326), centroid)
                    and intensity_lidar_image.processing_index = signs.processing_index'''

        response = make_query(self.conn, query, (None,))

        g = QgsGeometry()
        qgs_fields = [QgsField('sign_id', QVariant.Int), QgsField('type', QVariant.String),
                      QgsField('is_digital', QVariant.String), QgsField('shape', QVariant.String),
                      QgsField('height', QVariant.Double), QgsField('width', QVariant.Double),
                      QgsField('face_azimuth', QVariant.Double), QgsField('face_elevation', QVariant.Double),
                      QgsField('pointcloud_id', QVariant.String), QgsField('lidar_bbox', QVariant.String),
                      QgsField('camera_imagery_id', QVariant.String), QgsField('camera_bbox', QVariant.String),
                      QgsField('s3_bucket', QVariant.String), QgsField('s3_key', QVariant.String)
                      ]
        feature_list = []
        sign_type_list = []

        for row in response:
            sign_id = row[0]
            centroid = row[1]
            polygon_geom = row[2]
            width = row[3]
            height = row[4]
            azimuth = row[5]
            elevation = row[6]
            shape = row[7]
            sign_type = row[8]
            is_digital = row[9]
            camera_imagery_id = row[10]
            lidar_bbox = row[11]
            camera_bbox = row[12]
            pointcloud_id = row[13]  # without scanner, e.g. H_190316_160844
            s3_location = row[14]  # e.g. ushr-siloc-image
            s3_bucket, s3_key = parse_s3_url(s3_location)

            if sign_type not in sign_type_list:
                sign_type_list.append(sign_type)

            sign_qgsgeom = g.fromWkt(polygon_geom)

            f = QgsFeature()
            f.setGeometry(sign_qgsgeom)
            f.setAttributes([sign_id, sign_type, f'{is_digital}', shape, height, width, azimuth, elevation,
                             pointcloud_id, lidar_bbox, camera_imagery_id, camera_bbox, s3_bucket, s3_key])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', 'siloc_sign',
                                      feature_list, qgs_fields)

        # make rules
        rules = ()
        sign_color_selector = ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'purple']
        for i, sign_type in enumerate(sign_type_list):
            actual_width = 1

            label = f'{sign_type}'
            exp = f'''type = \'{sign_type}\''''
            line_style = 'solid'
            if i > 6:
                index = i % 6
            else:
                index = i
            color = sign_color_selector[index]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)

        return v_layer

