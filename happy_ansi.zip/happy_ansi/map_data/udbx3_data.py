from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
from .utils import *
from .db_conn import *
from shapely.geometry import LineString
from shapely.wkt import loads
from .udbx_enums import *
from .udbx3_enums import *
from .udbx3_query import query_driving_side
import os
import pathlib
import configparser
from dataclasses import dataclass
import seaborn as sns


class UDBX3MapData:
    def __init__(self, mainwin):
        self.main_win = mainwin
        self.conn = mainwin.customer_conn
        self.extent = mainwin.extent
        self.driving_side = None

    def is_udbx3_db(self):
        query = '''SELECT *
                           FROM pg_catalog.pg_namespace
                           WHERE nspname = %s'''
        response = make_query(self.conn, query, ('ushr_format',))
        if len(response) == 0:
            return False
        else:
            return True

    def get_srid(self):
        query = '''select st_srid(position)
                    from ushr_format.road_edge_points
                    limit 1'''
        response = make_query(self.conn, query, None)
        for row in response:
            srid = row[0]
            return srid
        return None

    def get_driving_side(self):
        self.driving_side = query_driving_side(self.conn)

    def query_road_segment_in_extent(self):
        query = f'''with segments_in_extent as (
                    select road_segment_id
                        from ushr_format.road_edge_points            						
                        where road_edge_point_sequence_index = 0 
                        and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   
                    left_edge as (
                    select road_segment.road_segment_id, road_type, number_of_lanes, road_division,
                    motorway_flag, functional_road_class,
                    st_makeline(array_agg(left_edge_pts.position 
                                            order by road_edge_point_sequence_index)) as left_edge_line,
                    max(road_edge_point_sequence_index) as max_index
                    from segments_in_extent
                    join ushr_format.road_segment 
                        on road_segment.road_segment_id = segments_in_extent.road_segment_id
                    join ushr_format.road_edge_points left_edge_pts 
                        on left_edge_pts.road_segment_id = segments_in_extent.road_segment_id 
                    where left_edge_pts.road_edge_side = false										
                    group by road_segment.road_segment_id
                        ),
                    road_edge as (									
                    select left_edge.road_segment_id, road_type, number_of_lanes, max_index, 
                    left_edge_line, road_division, motorway_flag, functional_road_class,
                    st_makeline(array_agg(right_edge_pts.position   
                                            order by road_edge_point_sequence_index desc)) as right_edge_line
                    from left_edge
                    join ushr_format.road_edge_points right_edge_pts 
                        on right_edge_pts.road_segment_id = left_edge.road_segment_id
                    where right_edge_pts.road_edge_side = true
                    group by left_edge.road_segment_id, road_type, number_of_lanes, max_index, 
                        left_edge_line, road_division, motorway_flag, functional_road_class
                    ),
                    segment_boundary_lines as (									
                    select *, 
                    st_makeline(array[ST_PointN(right_edge_line, -1), 
                                        ST_PointN(left_edge_line, 1)]) as start_boundary_line, 
                    st_makeline(array[ST_PointN(left_edge_line, -1), 
                                        ST_PointN(right_edge_line, 1)]) as end_boundary_line 
                    from road_edge
                    )
                    select road_segment_id, road_type, number_of_lanes, road_division, 
                    motorway_flag, functional_road_class,
                    st_astext(st_makepolygon(st_makeline(array[left_edge_line, end_boundary_line, 
                                            right_edge_line, start_boundary_line]))) as boundary_line
                    from segment_boundary_lines'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('road_type', QVariant.String),
                      QgsField('number_of_lanes', QVariant.Int), QgsField('motorway_flag', QVariant.Bool),
                      QgsField('functional_road_class', QVariant.String)]
        feature_list = []
        road_type_division_list = []
        for row in response:
            segment_id, road_type_id, number_of_lanes, road_division_boolean, \
                motorway_flag, functional_road_class, geom = row
            if [road_type_id, road_division_boolean] not in road_type_division_list:
                road_type_division_list.append([road_type_id, road_division_boolean])
            polygon = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            road_type = udbx3_road_type_df[udbx3_road_type_df['id'] == road_type_id]['type'].values[0]
            road_division = \
                udbx3_road_division_df[udbx3_road_division_df['boolean'] == road_division_boolean]['division'].values[0]
            frc_description = FunctionalRoadClass(functional_road_class).name
            frc_osm_ref = FunctionalRoadClassOSM[frc_description].value
            functional_road_class = f'{frc_description}_{frc_osm_ref}'
            f.setAttributes([segment_id, f'{road_type}_{road_division}', number_of_lanes,
                             motorway_flag, functional_road_class])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer(f'PolygonZ?crs=epsg:{self.main_win.srid}', f'udbx3_road_segment',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for road_type_division in road_type_division_list:
            actual_width = 1
            road_type_id = road_type_division[0]
            road_division_boolean = road_type_division[1]
            road_type = udbx3_road_type_df[udbx3_road_type_df['id'] == road_type_id]['type'].values[0]
            road_division = \
                udbx3_road_division_df[udbx3_road_division_df['boolean'] == road_division_boolean]['division'].values[0]
            label = f'{road_type}_{road_division}'
            exp = f'''road_type = \'{label}\''''
            line_style = 'solid'
            road_type_color = udbx3_road_type_df[udbx3_road_type_df['id'] == road_type_id]['draw_color'].values[0]
            division_color = \
                udbx3_road_division_df[udbx3_road_division_df['boolean']
                                       == road_division_boolean]['draw_color'].values[0]
            color = blend_colors([road_type_color, division_color])
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    def query_coverage_in_extent(self):
        query = f'''select road_segment.road_segment_id, road_type, road_division, number_of_lanes,
                    count(lane_line_point_sequence_index),
                    st_astext(ST_SimplifyVW(st_makeline(position order by lane_line_point_sequence_index), 0.000003))
                    from ushr_format.lane_line_points
                    join ushr_format.road_segment on road_segment.road_segment_id = lane_line_points.road_segment_id
                    where lane_line_ordinal_id = 2                    
                    and st_intersects(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    group by road_segment.road_segment_id
                    '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('road_type', QVariant.String),
                      QgsField('number_of_lanes', QVariant.Int), QgsField('approximate_length', QVariant.Int)]
        feature_list = []
        road_type_division_list = []
        for row in response:
            segment_id, road_type_id, road_division, number_of_lanes, index_count, geom = row
            if [road_type_id, road_division] not in road_type_division_list:
                road_type_division_list.append([road_type_id, road_division])
            polygon = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            road_type = udbx3_road_type_df[udbx3_road_type_df['id'] == road_type_id]['type'].values[0]
            road_division = \
                udbx3_road_division_df[udbx3_road_division_df['boolean'] == road_division]['division'].values[0]
            f.setAttributes([segment_id, f'{road_type}_{road_division}', number_of_lanes, index_count])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', f'udbx3_coverage',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for road_type_division in road_type_division_list:
            actual_width = 1
            road_type_id = road_type_division[0]
            road_division_boolean = road_type_division[1]
            road_type = udbx3_road_type_df[udbx3_road_type_df['id'] == road_type_id]['type'].values[0]
            road_division = \
                udbx3_road_division_df[udbx3_road_division_df['boolean'] == road_division_boolean]['division'].values[0]
            label = f'{road_type}_{road_division}'
            exp = f'''road_type = \'{label}\''''
            line_style = 'solid'
            road_type_color = udbx3_road_type_df[udbx3_road_type_df['id'] == road_type_id]['draw_color'].values[0]
            division_color = \
                udbx3_road_division_df[udbx3_road_division_df['boolean'] == road_division_boolean]['draw_color'].values[
                    0]
            color = blend_colors([road_type_color, division_color])
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    def query_lane_lines_in_extent(self):
        # line_type, line_color, line_width
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_intersects(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	                    
                    line_start_att as (
                    	select lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id, 
						lane_line_type_attribute, lane_line_color_attribute, lane_line_width_attribute, 
						reflective_markings_attribute, pavement_striping_present_attribute,						
                    	array_agg(st_astext(position) order by lane_line_point_sequence_index) as geoms,
                    	max(lane_line_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.lane_line_points on lane_line_points.road_segment_id = segments_in_extent.road_segment_id
                    	join ushr_format.lane_lines on lane_lines.road_segment_id = lane_line_points.road_segment_id
                    	where lane_line_points.lane_line_ordinal_id = lane_lines.lane_line_ordinal_id
                        and segments_in_extent.road_segment_id <> 0
                    	group by lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id
                    )
                    select line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, 
                    max_index, geoms, lane_line_type_attribute, lane_line_color_attribute, lane_line_width_attribute,
                    array_agg(lane_line_attributes.lane_line_point_sequence_index order by lane_line_point_sequence_index) as inds, 
					array_agg(lane_line_attribute_type order by lane_line_point_sequence_index) as attr_types,
                    array_agg(lane_line_attribute_value order by lane_line_point_sequence_index) as attr_vals
                    from line_start_att
                    left join ushr_format.lane_line_attributes on line_start_att.road_segment_id = lane_line_attributes.road_segment_id
                    	and line_start_att.lane_line_ordinal_id = lane_line_attributes.lane_line_ordinal_id    
                    	and lane_line_attribute_type in (0, 1, 2, 3)                	
                    group by line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, max_index, geoms, 
					lane_line_type_attribute, lane_line_color_attribute, lane_line_width_attribute 					
    				'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('lane_line_ordinal_id', QVariant.Int),
                      QgsField('type', QVariant.String), QgsField('color', QVariant.String),
                      QgsField('width', QVariant.String), QgsField('index_range', QVariant.String)
                      ]
        feature_list = []
        line_attr_list = []
        for row in response:
            segment_id, lane_line_ordinal_id, max_index, point_geoms, initial_line_type_id, initial_line_color_id, \
                initial_line_width_id, attr_inds, attr_types, attr_vals = row
            line_attr_dict = {}
            seq_ind = 0
            line_attr_dict[seq_ind] = {'line_type_id': initial_line_type_id, 'line_color_id': initial_line_color_id,
                                       'line_width_id': initial_line_width_id}
            # maintain the attributes until there is a change
            line_type_id, line_color_id, line_width_id = initial_line_type_id, initial_line_color_id, initial_line_width_id
            # there is change
            if attr_inds[0] is not None:
                for i, seq_ind in enumerate(attr_inds):
                    attr_type = attr_types[i]
                    attr_val = attr_vals[i]
                    line_att_type = \
                        udbx_line_att_type_df[udbx_line_att_type_df['id'] == attr_type]['line_att_type'].values[0]
                    if line_att_type == 'line_type':
                        line_type_id = attr_val
                    if line_att_type == 'line_color':
                        line_color_id = attr_val
                    if line_att_type == 'line_width':
                        line_width_id = attr_val
                    line_attr_dict[seq_ind] = {'line_type_id': line_type_id, 'line_color_id': line_color_id,
                                               'line_width_id': line_width_id}
            for seq_ind in line_attr_dict:
                if line_attr_dict[seq_ind] not in line_attr_list:
                    line_attr_list.append(line_attr_dict[seq_ind])
            ind_list = []
            point_geom_list = []
            line_type_id = line_attr_dict[0]['line_type_id']
            line_color_id = line_attr_dict[0]['line_color_id']
            line_width_id = line_attr_dict[0]['line_width_id']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in line_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'[{min(ind_list)}, {max(ind_list)})'
                    point_geom_list.append(loads(point_geom_wkt))
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    line_geom = LineString(point_geom_list).wkt
                    line_qgsgeom = g.fromWkt(line_geom)
                    f = QgsFeature()
                    f.setGeometry(line_qgsgeom)
                    f.setAttributes([segment_id, lane_line_ordinal_id,
                                     udbx_line_type_df[udbx_line_type_df['id'] == line_type_id]['type'].values[0],
                                     udbx_line_color_df[udbx_line_color_df['id'] == line_color_id]['name'].values[0],
                                     udbx_line_width_df[udbx_line_width_df['id'] == line_width_id]['name'].values[0],
                                     index_range])
                    feature_list.append(f)
                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    line_type_id = line_attr_dict[i]['line_type_id']
                    line_color_id = line_attr_dict[i]['line_color_id']
                    line_width_id = line_attr_dict[i]['line_width_id']
            max_change_ind = max(line_attr_dict)
            index_range = f'[{max_change_ind}, {max_index})'
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            line_type_id = line_attr_dict[max_change_ind]['line_type_id']
            line_color_id = line_attr_dict[max_change_ind]['line_color_id']
            line_width_id = line_attr_dict[max_change_ind]['line_width_id']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            line_geom = LineString(point_geom_list).wkt
            line_qgsgeom = g.fromWkt(line_geom)
            f = QgsFeature()
            f.setGeometry(line_qgsgeom)
            f.setAttributes([segment_id, lane_line_ordinal_id,
                             udbx_line_type_df[udbx_line_type_df['id'] == line_type_id]['type'].values[0],
                             udbx_line_color_df[udbx_line_color_df['id'] == line_color_id]['name'].values[0],
                             udbx_line_width_df[udbx_line_width_df['id'] == line_width_id]['name'].values[0],
                             index_range])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', 'udbx3_lane_line',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for line_attr in line_attr_list:
            line_type_id = line_attr['line_type_id']
            line_color_id = line_attr['line_color_id']
            line_width_id = line_attr['line_width_id']
            layer_width = udbx_line_width_df[udbx_line_width_df['id'] == line_width_id]['draw_width'].values[0] * 5
            line_type = udbx_line_type_df[udbx_line_type_df['id'] == line_type_id]['type'].values[0]
            line_color = udbx_line_color_df[udbx_line_color_df['id'] == line_color_id]['name'].values[0]
            line_width = udbx_line_width_df[udbx_line_width_df['id'] == line_width_id]['name'].values[0]
            label = f'{line_type}'
            exp = f'''type = \'{line_type}\' 
                      and color = \'{line_color}\' 
                      and width = \'{line_width}\''''
            stroke_style = udbx_line_type_df[udbx_line_type_df['id'] == line_type_id]['stroke_style'].values[0]
            color = udbx_line_color_df[udbx_line_color_df['id'] == line_color_id]['draw_color'].values[0]
            rules += ((label, exp, stroke_style, color, layer_width),)
        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    # reflective marking, pavement_striping_present, deceleration_marking_present, lane_line_geometry_centered
    def query_lane_line_attributes_in_extent(self, line_att_type_id):
        lane_line_attribute = LaneLineAttrType(line_att_type_id).name
        lane_line_attribute_init = get_lane_line_attr_type_init(lane_line_attribute)
        lane_line_attribute_change_init = get_lane_line_attr_type_change_init(lane_line_attribute)
        if lane_line_attribute == 'REFLECTIVE_MARKINGS_ATTRIBUTE':
            sel_type_df = udbx_reflective_markings_df
        elif lane_line_attribute == 'PAVEMENT_STRIPING_PRESENT_ATTRIBUTE':
            sel_type_df = udbx_pavement_striping_present_df
        elif lane_line_attribute == 'DECELERATION_MARKING_PRESENT':
            sel_type_df = udbx_deceleration_marking_present_df
        elif lane_line_attribute == 'LANE_LINE_GEOMETRY_CENTERED':
            sel_type_df = udbx_lane_line_geometry_centered_df
        else:
            return
        query = \
            f'''with segments_w_attr as (
                select ll.road_segment_id
                    from ushr_format.lane_lines ll
                    left join ushr_format.lane_line_attributes lla on lla.road_segment_id = ll.road_segment_id
                        and lla.lane_line_ordinal_id = ll.lane_line_ordinal_id
                        and lane_line_attribute_type = {line_att_type_id}
                    where ({lane_line_attribute} != {lane_line_attribute_init} 
                            or lane_line_attribute_value != {lane_line_attribute_change_init})
                    group by ll.road_segment_id
                ),
                segments_in_extent as (select distinct road_edge_points.road_segment_id
                    from ushr_format.road_edge_points  
                    join ushr_format.lanes on lanes.road_segment_id = road_edge_points.road_segment_id
                    join segments_w_attr on segments_w_attr.road_segment_id = road_edge_points.road_segment_id
                    where lane_number = 1
                    and (road_edge_point_sequence_index = 0 or road_edge_point_sequence_index = lane_length)
                    and road_edge_side = false
                    and st_within(position, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                    {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                ),	   	
                line_start_att as (
                    select lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id, {lane_line_attribute},
                    array_agg(st_astext(position) order by lane_line_point_sequence_index) as geoms,
                    max(lane_line_point_sequence_index) as max_index
                    from segments_in_extent
                    join ushr_format.lane_line_points 
                        on lane_line_points.road_segment_id = segments_in_extent.road_segment_id
                    join ushr_format.lane_lines on lane_lines.road_segment_id = segments_in_extent.road_segment_id
                    where lane_line_points.lane_line_ordinal_id = lane_lines.lane_line_ordinal_id
                    group by lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id
                )
                select line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, 
                {lane_line_attribute}, max_index, geoms,
                array_agg(lane_line_attributes.lane_line_point_sequence_index order 
                            by lane_line_point_sequence_index) as inds, 
                array_agg(lane_line_attribute_value order by lane_line_point_sequence_index) as vals
                from line_start_att
                left join ushr_format.lane_line_attributes 
                    on line_start_att.road_segment_id = lane_line_attributes.road_segment_id
                    and line_start_att.lane_line_ordinal_id = lane_line_attributes.lane_line_ordinal_id
                    and lane_line_attributes.lane_line_attribute_type = {line_att_type_id}
                group by line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, 
                    {lane_line_attribute}, max_index, geoms
                        '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_line_ordinal_id', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('index_range', QVariant.String),
                      QgsField(lane_line_attribute, QVariant.String)
                      ]
        feature_list = []
        type_list = []
        for row in response:
            segment_id, lane_line_ordinal_id, initial_attr_val, max_index, point_geoms, attr_inds, attr_vals = row
            if type(initial_attr_val) == bool:
                if initial_attr_val:
                    initial_attr_val = 1
                else:
                    initial_attr_val = 0
            line_attr_dict = {}
            seq_ind = 0
            line_attr_dict[seq_ind] = {'line_attr_val': initial_attr_val}

            # there is change
            if attr_inds[0] is not None:
                for i, seq_ind in enumerate(attr_inds):
                    attr_val = attr_vals[i]
                    line_attr_dict[seq_ind] = {'line_attr_val': attr_val}

            for seq_ind in line_attr_dict:
                if line_attr_dict[seq_ind]['line_attr_val'] != lane_line_attribute_change_init \
                        and line_attr_dict[seq_ind]['line_attr_val'] is not None \
                        and line_attr_dict[seq_ind]['line_attr_val'] not in type_list:
                    type_list.append(line_attr_dict[seq_ind]['line_attr_val'])

            ind_list = []
            point_geom_list = []
            line_attr_val = line_attr_dict[0]['line_attr_val']

            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in line_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    point_geom_list.append(loads(point_geom_wkt))
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'[{min(ind_list)}, {max(ind_list)})'
                    length = max(ind_list) - min(ind_list)
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])

                    # start of the section with 0 (except lane line centered) or 1 for lane line centered
                    if line_attr_val == lane_line_attribute_change_init:
                        ind_list = [i]
                        point_geom_list = [loads(point_geom_wkt)]
                        line_attr_val = line_attr_dict[i]['line_attr_val']
                        continue
                    line_attr = sel_type_df[sel_type_df['id'] == line_attr_val]['type'].values[0]

                    # complete the geometry for the current type duration
                    line_geom = LineString(point_geom_list).wkt
                    line_qgsgeom = g.fromWkt(line_geom)
                    f = QgsFeature()
                    f.setGeometry(line_qgsgeom)
                    f.setAttributes([segment_id, lane_line_ordinal_id, length, index_range, line_attr])
                    feature_list.append(f)
                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    line_attr_val = line_attr_dict[i]['line_attr_val']

            max_change_ind = max(list(line_attr_dict.keys()))
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            line_attr_val = line_attr_dict[max_change_ind]['line_attr_val']
            index_range = f'[{max_change_ind}, {max_index})'
            length = max_index - max_change_ind
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            if line_attr_val == lane_line_attribute_change_init or line_attr_val is None:
                continue
            line_attr = sel_type_df[sel_type_df['id'] == line_attr_val]['type'].values[0]
            line_geom = LineString(point_geom_list).wkt
            line_qgsgeom = g.fromWkt(line_geom)
            f = QgsFeature()
            f.setGeometry(line_qgsgeom)
            f.setAttributes([segment_id, lane_line_ordinal_id, length, index_range, line_attr])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}',
                                      f'udbx3_line_attr_{lane_line_attribute}',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for type_i in type_list:
            label = sel_type_df[sel_type_df['id'] == type_i]['type'].values[0]
            color = sel_type_df[sel_type_df['id'] == type_i]['draw_color'].values[0]
            feature_dict[label] = (color, label)
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field=lane_line_attribute, width=2)
        return v_layer

    def query_lanes_in_extent(self):
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   	
                            lane_start_att as (
                            	select lanes.road_segment_id, lanes.lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id, 
        						lane_add_remove_type, accelerating_lane, decelerating_lane, lane_type_attribute, lane_length,						
                            	array_agg(st_astext(position) order by lane_point_sequence_index) as geoms,
                            	max(lane_point_sequence_index) as max_index
                            	from segments_in_extent
                            	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.road_segment_id
                            	join ushr_format.lanes on lanes.road_segment_id = lane_center_points.road_segment_id
                            	where lane_center_points.lane_number = lanes.lane_number
								and segments_in_extent.road_segment_id <> 0
                            	group by lanes.road_segment_id, lanes.lane_number
                            )
                            select lane_start_att.road_segment_id, lane_start_att.lane_number, 
        					left_lane_line_ordinal_id, right_lane_line_ordinal_id, 
        					lane_type_attribute, lane_length,
                            max_index, geoms, 
                            array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
        					array_agg(lane_attributes.lane_attribute_type order by lane_point_sequence_index) as attr_types,
        					array_agg(lane_attributes.lane_attribute_value order by lane_point_sequence_index) as attr_vals
                            from lane_start_att
                            left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                            	and lane_start_att.lane_number = lane_attributes.lane_number       	
                            	and lane_attributes.lane_attribute_type = 0			
                            group by lane_start_att.road_segment_id, lane_start_att.lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id, 
        				    lane_type_attribute, lane_length,
                            max_index, geoms							
							'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('lane_number', QVariant.Int), QgsField('length', QVariant.Int),
                      QgsField('lane_type', QVariant.String), QgsField('index_range', QVariant.String),
                      QgsField('left_lane_line_ordinal_id', QVariant.Int),
                      QgsField('right_lane_line_ordinal_id', QVariant.Int)
                      ]
        feature_list = []
        lane_type_ids_list = []
        for row in response:
            segment_id, lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id, lane_type_id, \
                lane_length, max_index, point_geoms, change_inds, change_attr_types, change_attr_vals = row

            # generate a list of all the bit-masks that a value contains, i.e. 5 -> 1 + 4
            # 5/16=0, 5/8=0, 5/4=1, 1/2=0, 1/1=1 ----> 4, 1
            # lane type
            lane_type_bitmasks = get_bitmask_array(lane_type_id)
            lane_type_list = []
            for item in lane_type_bitmasks:
                lane_type_list.append(udbx_lane_type_df[udbx_lane_type_df['id'] == item]['type'].values[0])

            if lane_type_bitmasks not in lane_type_ids_list:
                lane_type_ids_list.append(lane_type_bitmasks)

            lane_attr_dict = {}
            seq_ind = 0
            lane_attr_dict[seq_ind] = {'lane_type': lane_type_list}

            if change_inds[0] is not None:
                for i, seq_ind in enumerate(change_inds):
                    change_attr_type = change_attr_types[i]
                    change_attr_val = change_attr_vals[i]
                    if \
                            udbx_lane_attr_type_df[udbx_lane_attr_type_df['id'] == change_attr_type][
                                'lane_attr_type'].values[
                                0] == 'lane_type_attribute':
                        lane_type_list = []
                        lane_type_code = change_attr_val
                        lane_type_bitmasks = get_bitmask_array(lane_type_code)
                        for item in lane_type_bitmasks:
                            lane_type = udbx_lane_type_df[udbx_lane_type_df['id'] == item]['type'].values[0]
                            lane_type_list.append(lane_type)
                        if lane_type_bitmasks not in lane_type_ids_list:
                            lane_type_ids_list.append(lane_type_bitmasks)
                    lane_attr_dict[seq_ind] = {'lane_type': lane_type_list}

            ind_list = []
            point_geom_list = []
            lane_type = lane_attr_dict[0]['lane_type']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in lane_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'[{min(ind_list)}, {max(ind_list)})'
                    point_geom_list.append(loads(point_geom_wkt))
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    lane_geom = LineString(point_geom_list).wkt
                    lane_qgsgeom = g.fromWkt(lane_geom)
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    f.setAttributes([segment_id, lane_number, lane_length, f'{lane_type}', index_range,
                                     left_lane_line_ordinal_id, right_lane_line_ordinal_id])
                    feature_list.append(f)
                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    lane_type = lane_attr_dict[i]['lane_type']

            max_change_ind = max(lane_attr_dict)
            index_range = f'[{max_change_ind}, {max_index})'
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            lane_type = lane_attr_dict[max_change_ind]['lane_type']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            lane_geom = LineString(point_geom_list).wkt
            lane_qgsgeom = g.fromWkt(lane_geom)
            f = QgsFeature()
            f.setGeometry(lane_qgsgeom)
            f.setAttributes([segment_id, lane_number, lane_length, f'{lane_type}', index_range,
                             left_lane_line_ordinal_id, right_lane_line_ordinal_id])
            feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', 'udbx3_lane',
                                            feature_list, qgs_fields)
        feature_dict = {}

        for lane_type_ids in lane_type_ids_list:
            # blend colors
            color_list = []
            lane_types = []
            for lane_type_id in lane_type_ids:
                color_list.append(udbx_lane_type_df[udbx_lane_type_df['id'] == lane_type_id]['draw_color'].values[0])
                lane_types.append(udbx_lane_type_df[udbx_lane_type_df['id'] == lane_type_id]['type'].values[0])
            color = blend_colors(color_list)
            feature_dict[f'{lane_types}'] = (color, f'{lane_types}')
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='lane_type', width=1.5)
        return v_layer

    def query_lane_category_in_extent(self, lane_category_id):
        if lane_category_id == 0:
            category_df = udbx_lane_add_remove_type_df
            layer_name = 'udbx3_lane_add_remove_type'
        else:
            category_df = udbx_acc_dec_type_df
            layer_name = 'udbx3_lane_accelerating_decelerating'

        category_field = udbx_lane_category_df[udbx_lane_category_df['id'] == lane_category_id]['category'].values[0]

        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   
                            lane_category as (
                            	select lanes.road_segment_id, lanes.lane_number, lane_add_remove_type, accelerating_lane, decelerating_lane,                            	
								st_makeline(array_agg(position order by lane_point_sequence_index)) as geom                            	
                            	from segments_in_extent
                            	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.road_segment_id
                            	join ushr_format.lanes on lanes.road_segment_id = segments_in_extent.road_segment_id
                            	where lane_center_points.lane_number = lanes.lane_number
								and (lane_add_remove_type != 0 or accelerating_lane = true or decelerating_lane = true)
                            	group by lanes.road_segment_id, lanes.lane_number
                            )
                            select lane_category.road_segment_id, lane_category.lane_number, 
							lane_add_remove_type, accelerating_lane, decelerating_lane, st_astext(geom)              
                            from lane_category
                            '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('lane_number', QVariant.Int), QgsField(category_field, QVariant.String)
                      ]
        feature_list = []
        lane_category_type_id_set = set([])
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            lane_add_remove_type_id = row[2]
            acc_lane = row[3]
            dec_lane = row[4]
            lane_geom = row[5]

            # add_remove_type
            if lane_category_id == 0:
                lane_category_type_id = lane_add_remove_type_id
                if lane_category_type_id != 0:
                    lane_category_type_id_set.add(lane_category_type_id)
            # acc, dec
            else:
                lane_category_type_id = 0
                if acc_lane:
                    lane_category_type_id += 1
                if dec_lane:
                    lane_category_type_id -= 1

                if not acc_lane and lane_category_type_id == 0:
                    lane_category_type_id = 999
                if lane_category_type_id != 999:
                    lane_category_type_id_set.add(lane_category_type_id)

            if lane_category_type_id == 999:
                continue
            lane_category_type = category_df[category_df['id'] == lane_category_type_id]['type'].values[0]

            lane_qgsgeom = g.fromWkt(lane_geom)
            f = QgsFeature()
            f.setGeometry(lane_qgsgeom)
            f.setAttributes([segment_id, lane_number, lane_category_type])
            feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', layer_name,
                                            feature_list, qgs_fields)

        feature_dict = {}
        for lane_category_type_id in lane_category_type_id_set:
            label = category_df[category_df['id'] == lane_category_type_id]['type'].values[0]
            color = category_df[category_df['id'] == lane_category_type_id]['draw_color'].values[0]
            feature_dict[label] = (color, label)

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field=category_field, width=1.5)
        return v_layer

    # Current implementation: segment level resolution
    def query_functional_authority_in_extent(self):
        query = f'''with segments_in_extent as (
	select road_segment_id
    from ushr_format.road_edge_points            						
	where road_edge_point_sequence_index = 0 
	and road_edge_side = false
    and st_within(position, 
     ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, 
    {self.extent.y_max}, {self.main_win.srid}))
),
fa_segment as (
	select distinct fa.road_segment_id, functional_authority_attribute as fa_value
	from segments_in_extent
	join ushr_format.functional_authority fa on fa.road_segment_id = segments_in_extent.road_segment_id
	and functional_authority_attribute != 0
),
left_edge as (
                                select road_segment.road_segment_id, road_type, number_of_lanes, road_division, 
                               	st_makeline(array_agg(left_edge_pts.position order by road_edge_point_sequence_index)) as left_edge_line,
								max(road_edge_point_sequence_index) as max_index, fa_value
                                from fa_segment
                                join ushr_format.road_segment on road_segment.road_segment_id = fa_segment.road_segment_id
                                join ushr_format.road_edge_points left_edge_pts on left_edge_pts.road_segment_id = fa_segment.road_segment_id 
								where left_edge_pts.road_edge_side = false										
                                group by road_segment.road_segment_id, fa_value
                            ),
					road_edge as (									
                    select left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line, road_division,
					st_makeline(array_agg(right_edge_pts.position order by road_edge_point_sequence_index desc)) as right_edge_line, 
					fa_value
                    from left_edge
					join ushr_format.road_edge_points right_edge_pts on right_edge_pts.road_segment_id = left_edge.road_segment_id
					where right_edge_pts.road_edge_side = true
					group by left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line, road_division, fa_value
					),
					segment_boundary_lines as (									
					select *, 
					st_makeline(array[ST_PointN(right_edge_line, -1), ST_PointN(left_edge_line, 1)]) as start_boundary_line, 
					st_makeline(array[ST_PointN(left_edge_line, -1), ST_PointN(right_edge_line, 1)]) as end_boundary_line 
					from road_edge
					)
					select road_segment_id, road_type, number_of_lanes, road_division, fa_value,
					st_astext(st_makepolygon(st_makeline(array[left_edge_line, end_boundary_line, right_edge_line, start_boundary_line]))) as boundary_line
					from segment_boundary_lines
					'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('road_type', QVariant.String),
                      QgsField('number_of_lanes', QVariant.Int), QgsField('fa_type', QVariant.String)]
        feature_list = []
        fa_value_set = set([])
        for row in response:
            segment_id, road_type_id, number_of_lanes, road_division_boolean, fa_value, geom = row
            fa_value_set.add(fa_value)
            polygon = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            road_type = RoadType(road_type_id).name
            road_division = RoadDivision(road_division_boolean).name
            f.setAttributes([segment_id, f'{road_type}_{road_division}', number_of_lanes,
                             FunctionalAuthority(fa_value).name])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer(f'PolygonZ?crs=epsg:{self.main_win.srid}', f'udbx3_functional_authority',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for fa_value in fa_value_set:
            actual_width = 1
            fa_type = FunctionalAuthority(fa_value).name
            label = f'{FunctionalAuthority(fa_value).name}'
            exp = f'''fa_type = \'{label}\''''
            line_style = 'solid'
            color = FunctionalAuthorityColor[fa_type].value
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        v_layer.setDisplayExpression('fa_type')
        return v_layer

    def query_lane_attributes_in_extent(self, lane_attr_type_id):
        lane_attribute = \
            udbx_lane_attr_type_df[udbx_lane_attr_type_df['id'] == lane_attr_type_id]['lane_attr_type'].values[0]
        bitmask_type = \
            udbx_lane_attr_type_df[udbx_lane_attr_type_df['id'] == lane_attr_type_id]['bitmask_type'].values[0]
        bitmask_df_dict = {4: udbx_crossing_type_df, 5: udbx_rtd_type_df}
        if lane_attr_type_id in (4, 5):
            bitmask_df = bitmask_df_dict[lane_attr_type_id]
        else:
            bitmask_df = None
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   
                            lane_start_att as (
                            	select lanes.road_segment_id, lanes.lane_number, {lane_attribute},
                            	array_agg(st_astext(position) order by lane_point_sequence_index) as geoms,
                            	max(lane_point_sequence_index) as max_index
                            	from segments_in_extent
                            	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.road_segment_id
                            	join ushr_format.lanes on lanes.road_segment_id = segments_in_extent.road_segment_id
                            	where lane_center_points.lane_number = lanes.lane_number
                            	group by lanes.road_segment_id, lanes.lane_number
                            )
                            select lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}, max_index, geoms,
                            array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
                            array_agg(lane_attribute_value order by lane_point_sequence_index) as vals
                            from lane_start_att
                            left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                            	and lane_start_att.lane_number = lane_attributes.lane_number
                            	and lane_attributes.lane_attribute_type = {lane_attr_type_id}
                            group by lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}, max_index, geoms'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        if lane_attr_type_id == 1:
            value_type = QVariant.Int
        else:
            value_type = QVariant.String
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('index_range', QVariant.String),
                      QgsField(lane_attribute, value_type)
                      ]
        feature_list = []
        lane_attr_val_set = set([])
        for row in response:
            segment_id, lane_number, initial_attr_val, max_index, point_geoms, change_inds, change_attr_vals = row

            lane_attr_dict = {}
            seq_ind = 0

            # generate a list of all the bit-masks that a value contains, i.e. 5 -> 1 + 4
            # 5/16=0, 5/8=0, 5/4=1, 1/2=0, 1/1=1 ----> 4, 1
            # crossing type
            if bitmask_type:
                lane_attr_val_bitmasks = get_bitmask_array(initial_attr_val)
                lane_attr_val_list = []
                for val in lane_attr_val_bitmasks:
                    lane_attr_val_list.append(val)
                    lane_attr_val_set.add(val)
                lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val_list}
            else:
                lane_attr_val = initial_attr_val
                if lane_attr_val is None:
                    lane_attr_val = 0
                lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val}
                lane_attr_val_set.add(lane_attr_val)

            if change_inds[0] is not None:
                for i, seq_ind in enumerate(change_inds):
                    change_attr_val = change_attr_vals[i]
                    if bitmask_type:
                        lane_attr_val_bitmasks = get_bitmask_array(change_attr_val)
                        lane_attr_val_list = []
                        for val in lane_attr_val_bitmasks:
                            lane_attr_val_list.append(val)
                            lane_attr_val_set.add(val)
                        lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val_list}
                    else:
                        # for left_change_allowed and right_change_allowed, the initial value is stored as Boolean,
                        # the change value is stored as integer, 0 = False, 1 = True
                        if lane_attribute in ('left_change_allowed_attribute', 'right_change_allowed_attribute'):
                            if change_attr_val == 0:
                                change_attr_val = False
                            else:
                                change_attr_val = True
                        lane_attr_val = change_attr_val
                        lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val}
                        lane_attr_val_set.add(lane_attr_val)

            # for crossing, if there are multiple crossings at one place, plot them separately
            ind_list = []
            point_geom_list = []
            lane_attr_val = lane_attr_dict[0]['lane_attr_val']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in lane_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    point_geom_list.append(loads(point_geom_wkt))
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'[{min(ind_list)}, {max(ind_list)})'
                    length = max(ind_list) - min(ind_list)
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    lane_geom = LineString(point_geom_list).wkt
                    lane_qgsgeom = g.fromWkt(lane_geom)
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    if bitmask_type:
                        for val in lane_attr_val:
                            f = QgsFeature()
                            f.setGeometry(lane_qgsgeom)
                            f.setAttributes([segment_id, lane_number, length, index_range,
                                             bitmask_df[bitmask_df['id'] == val]['type'].values[0]])
                            feature_list.append(f)
                    else:
                        if lane_attribute in ('left_change_allowed_attribute', 'right_change_allowed_attribute'):
                            lane_attr_val = \
                                udbx_lane_change_allowed_df[udbx_lane_change_allowed_df['id'] == lane_attr_val][
                                    'type'].values[0]
                        f.setAttributes([segment_id, lane_number, length, index_range, lane_attr_val])
                        feature_list.append(f)

                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    lane_attr_val = lane_attr_dict[i]['lane_attr_val']

            max_change_ind = max(list(lane_attr_dict.keys()))
            index_range = f'[{max_change_ind}, {max_index})'
            length = max_index - max_change_ind
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            lane_attr_val = lane_attr_dict[max_change_ind]['lane_attr_val']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            lane_geom = LineString(point_geom_list).wkt
            lane_qgsgeom = g.fromWkt(lane_geom)
            f = QgsFeature()
            f.setGeometry(lane_qgsgeom)
            if bitmask_type:
                for val in lane_attr_val:
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    f.setAttributes([segment_id, lane_number, length, index_range,
                                     bitmask_df[bitmask_df['id'] == val]['type'].values[0]])
                    feature_list.append(f)
            else:
                if lane_attribute in ('left_change_allowed_attribute', 'right_change_allowed_attribute'):
                    lane_attr_val = \
                        udbx_lane_change_allowed_df[udbx_lane_change_allowed_df['id'] == lane_attr_val]['type'].values[
                            0]
                f.setAttributes([segment_id, lane_number, length, index_range, lane_attr_val])
                feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}',
                                            f'udbx3_lane_att_{lane_attribute}',
                                            feature_list, qgs_fields)

        feature_dict = {}
        color_selector = get_colors(len(lane_attr_val_set))
        sel_type_df = None
        hsv = False
        color_ramp = False
        if lane_attribute in ('left_change_allowed_attribute', 'right_change_allowed_attribute'):
            sel_type_df = udbx_lane_change_allowed_df
        elif lane_attribute == 'crossing_type_attribute':
            sel_type_df = udbx_crossing_type_df
        elif lane_attribute == 'regulatory_traffic_device_attribute':
            sel_type_df = udbx_rtd_type_df
        else:
            hsv = True
            color_ramp = True
        for i, lane_attr_val in enumerate(sorted(lane_attr_val_set)):
            if lane_attribute == 'speed_limit_attribute':
                label = f'{lane_attr_val}'
                color = QColor(color_selector[i])
            else:
                label = sel_type_df[sel_type_df['id'] == lane_attr_val]['type'].values[0]
                color = sel_type_df[sel_type_df['id'] == lane_attr_val]['draw_color'].values[0]
            feature_dict[label] = (color, label)

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field=lane_attribute, width=1.5, hsv=hsv,apply_color_ramp=color_ramp)

        return v_layer

    def query_lane_change_allowed_in_extent(self):
        # left change allow value: + 1
        # right change allow value: + 2
        # => left & right = 3
        # => no left no right = 0
        # => left only = 1
        # => right only = 2
        g = QgsGeometry()

        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('index_range', QVariant.String),
                      QgsField('lane_change_allowed', QVariant.String)
                      ]

        lane_attr_type_id = 2  # left change allowed
        lane_attribute = \
            udbx_lane_attr_type_df[udbx_lane_attr_type_df['id'] == lane_attr_type_id]['lane_attr_type'].values[0]
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
        		    	where road_edge_point_sequence_index = 0 
        		    	and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   
                    lane_start_att as (
                    	select lanes.road_segment_id, lanes.lane_number, {lane_attribute},
                    	array_agg(st_astext(position) order by lane_point_sequence_index) as geoms,
                    	max(lane_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.road_segment_id
                    	join ushr_format.lanes on lanes.road_segment_id = segments_in_extent.road_segment_id
                    	where lane_center_points.lane_number = lanes.lane_number
                    	group by lanes.road_segment_id, lanes.lane_number
                    )
                    select lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}, max_index, geoms,
                    array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
                    array_agg(lane_attribute_value order by lane_point_sequence_index) as vals
                    from lane_start_att
                    left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                    	and lane_start_att.lane_number = lane_attributes.lane_number
                    	and lane_attributes.lane_attribute_type = {lane_attr_type_id}
                    group by lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}, max_index, geoms'''
        response = make_query(self.conn, query, None)
        left_change_allowed_dict = {}
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            initial_attr_val = row[2]
            if initial_attr_val:
                initial_attr_val = 1
            else:
                initial_attr_val = 0
            max_index = row[3]
            point_geoms = row[4]
            change_inds = row[5]
            change_attr_vals = row[6]
            left_change_allowed_dict[segment_id, lane_number] = {'initial_attr_val': initial_attr_val,
                                                                 'max_index': max_index, 'point_geoms': point_geoms,
                                                                 'change_inds': change_inds,
                                                                 'change_attr_vals': change_attr_vals}

        lane_attr_type_id = 3  # right change allowed
        lane_attribute = \
            udbx_lane_attr_type_df[udbx_lane_attr_type_df['id'] == lane_attr_type_id]['lane_attr_type'].values[0]
        query = f'''with segments_in_extent as (select road_segment_id
                                from ushr_format.road_edge_points            						
                        		where road_edge_point_sequence_index = 0 
                        		and road_edge_side = false
                                and st_within(position, 
                                ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                            ),	   
                            lane_start_att as (
                            	select lanes.road_segment_id, lanes.lane_number, {lane_attribute}
                            	from segments_in_extent
                            	join ushr_format.lanes on lanes.road_segment_id = segments_in_extent.road_segment_id                                            	
                            )
                            select lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute},
                            array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
                            array_agg(lane_attribute_value order by lane_point_sequence_index) as vals
                            from lane_start_att
                            left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                            	and lane_start_att.lane_number = lane_attributes.lane_number
                            	and lane_attributes.lane_attribute_type = {lane_attr_type_id}
                            group by lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}'''
        response = make_query(self.conn, query, None)
        right_change_allowed_dict = {}
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            initial_attr_val = row[2]
            if initial_attr_val:
                initial_attr_val = 1
            else:
                initial_attr_val = 0
            change_inds = row[3]
            change_attr_vals = row[4]
            right_change_allowed_dict[segment_id, lane_number] = {'initial_attr_val': initial_attr_val,
                                                                  'change_inds': change_inds,
                                                                  'change_attr_vals': change_attr_vals}

        feature_list = []
        lane_attr_val_set = set([])
        for (segment_id, lane_number) in left_change_allowed_dict:
            max_index = left_change_allowed_dict[segment_id, lane_number]['max_index']
            point_geoms = left_change_allowed_dict[segment_id, lane_number]['point_geoms']

            left_change_allowed_initial_val = left_change_allowed_dict[segment_id, lane_number]['initial_attr_val']
            left_change_allowed_change_inds = left_change_allowed_dict[segment_id, lane_number]['change_inds']
            left_change_allowed_change_vals = left_change_allowed_dict[segment_id, lane_number]['change_attr_vals']
            right_change_allowed_initial_val = right_change_allowed_dict[segment_id, lane_number]['initial_attr_val']
            right_change_allowed_change_inds = right_change_allowed_dict[segment_id, lane_number]['change_inds']
            right_change_allowed_change_vals = right_change_allowed_dict[segment_id, lane_number]['change_attr_vals']

            if right_change_allowed_initial_val == 1:
                right_change_allowed_initial_val = 2

            left_change_allowed_val = left_change_allowed_initial_val
            right_change_allowed_val = right_change_allowed_initial_val
            lane_change_allowed_change_dict = {}
            for seq_ind in range(0, max_index + 1):
                if seq_ind == 0:
                    lane_change_allowed_val = left_change_allowed_initial_val + right_change_allowed_initial_val
                elif seq_ind in left_change_allowed_change_inds + right_change_allowed_change_inds:
                    if seq_ind in left_change_allowed_change_inds:
                        i = left_change_allowed_change_inds.index(seq_ind)
                        left_change_allowed_val = left_change_allowed_change_vals[i]
                    if seq_ind in right_change_allowed_change_inds:
                        i = right_change_allowed_change_inds.index(seq_ind)
                        if right_change_allowed_change_vals[i] == 1:
                            right_change_allowed_val = 2
                        else:
                            right_change_allowed_val = 0
                    lane_change_allowed_val = left_change_allowed_val + right_change_allowed_val
                else:
                    continue
                lane_change_allowed_change_dict[seq_ind] = lane_change_allowed_val
                lane_attr_val_set.add(lane_change_allowed_val)

            ind_list = []
            point_geom_list = []
            lane_attr_val = lane_change_allowed_change_dict[0]
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in lane_change_allowed_change_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    point_geom_list.append(loads(point_geom_wkt))
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'[{min(ind_list)}, {max(ind_list)})'
                    length = max(ind_list) - min(ind_list)
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    lane_geom = LineString(point_geom_list).wkt
                    lane_qgsgeom = g.fromWkt(lane_geom)
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    lane_attr_val = \
                        udbx_lane_change_allowed_df[udbx_lane_change_allowed_df['id'] == lane_attr_val]['type'].values[
                            0]
                    f.setAttributes([segment_id, lane_number, length, index_range, lane_attr_val])
                    feature_list.append(f)

                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    lane_attr_val = lane_change_allowed_change_dict[i]

            max_change_ind = max(lane_change_allowed_change_dict)
            index_range = f'[{max_change_ind}, {max_index})'
            length = max_index - max_change_ind
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            lane_attr_val = lane_change_allowed_change_dict[max_change_ind]
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            lane_geom = LineString(point_geom_list).wkt
            lane_qgsgeom = g.fromWkt(lane_geom)
            f = QgsFeature()
            f.setGeometry(lane_qgsgeom)
            lane_attr_val = \
                udbx_lane_change_allowed_df[udbx_lane_change_allowed_df['id'] == lane_attr_val]['type'].values[0]
            f.setAttributes([segment_id, lane_number, length, index_range, lane_attr_val])
            feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}',
                                            f'udbx3_lane_att_lane_change_allowed',
                                            feature_list, qgs_fields)

        feature_dict = {}
        sel_type_df = udbx_lane_change_allowed_df
        for lane_attr_val in lane_attr_val_set:
            label = sel_type_df[sel_type_df['id'] == lane_attr_val]['type'].values[0]
            color = sel_type_df[sel_type_df['id'] == lane_attr_val]['draw_color'].values[0]
            feature_dict[label] = (color, label)
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='lane_change_allowed',
                                           width=1.5)
        return v_layer

    def query_lane_connection_in_extent(self):
        query = f'''with segment_connections_in_extent as (select road_segment_id, incident_road_segment_id, emergent_road_segment_id
                        from ushr_format.road_edge_points            
						join ushr_format.lane_connections on lane_connections.incident_road_segment_id = road_segment_id 
							or lane_connections.emergent_road_segment_id = road_segment_id
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ), 
					segments_in_extent as (
						select road_segment_id from segment_connections_in_extent
						union
						select incident_road_segment_id from segment_connections_in_extent
						union
						select emergent_road_segment_id from segment_connections_in_extent						
					),
					lane_conn as (					
                    select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
                    curvature, heading, along_slope
					from segments_in_extent
					join ushr_format.lane_connections on incident_road_segment_id = road_segment_id 
						or emergent_road_segment_id = road_segment_id
					where road_segment_id <> 0
						),
					incident_lane as (
        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, -- node_position, 
        max(lcp_incident.lane_point_sequence_index) - 1 as incident_lane_last_to_second_index, 
        lane_conn.curvature, lane_conn.heading, lane_conn.along_slope
        from lane_conn
        join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
        where lcp_incident.lane_number = incident_lane_number
        group by incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
            lane_conn.curvature, lane_conn.heading, lane_conn.along_slope
        ),
        incident_emergent_pts as (
        select incident_lane.*, lcp_emergent_1.position as emergent_second_pt, lcp_incident.position as incident_lane_last_to_second_pt, 
			lcp_emergent_0.position as node_position
        from incident_lane
        join ushr_format.lane_center_points lcp_emergent_1 on lcp_emergent_1.road_segment_id = emergent_road_segment_id
		join ushr_format.lane_center_points lcp_emergent_0 on lcp_emergent_0.road_segment_id = emergent_road_segment_id
        join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
        where lcp_incident.lane_number = incident_lane_number
        and lcp_emergent_1.lane_number = emergent_lane_number
        and lcp_emergent_1.lane_point_sequence_index = 1
		and lcp_emergent_0.lane_number = emergent_lane_number
        and lcp_emergent_0.lane_point_sequence_index = 0
        and lcp_incident.lane_point_sequence_index = incident_lane_last_to_second_index
        )
        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
        curvature, heading, along_slope, st_astext(node_position),
        st_astext(st_makeline(array[incident_lane_last_to_second_pt, node_position, emergent_second_pt]))
        from incident_emergent_pts
        '''
        response_connection = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('incident_road_segment_id', QVariant.Int),
                      QgsField('incident_lane_number', QVariant.Int),
                      QgsField('emergent_road_segment_id', QVariant.Int),
                      QgsField('emergent_lane_number', QVariant.Int),
                      QgsField('node_type', QVariant.String),
                      QgsField('curvature', QVariant.Double),
                      QgsField('heading', QVariant.Double),
                      QgsField('along_slope', QVariant.Double)
                      ]

        node_feature_list = []
        line_feature_list = []

        query = f'''with segment_connections_end_in_extent as (
                        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
                        curvature, heading, along_slope
                        from ushr_format.road_edge_points            
						join ushr_format.lane_connections on lane_connections.incident_road_segment_id = road_segment_id 
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
						and emergent_road_segment_id = 0										   
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ), 
        incident_lane as (
        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number,
        max(lcp_incident.lane_point_sequence_index) - 1 as incident_lane_last_to_second_index, 
        segment_connections_end_in_extent.curvature, segment_connections_end_in_extent.heading, segment_connections_end_in_extent.along_slope
        from segment_connections_end_in_extent
        join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
        where lcp_incident.lane_number = incident_lane_number
        group by incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
            segment_connections_end_in_extent.curvature, segment_connections_end_in_extent.heading, 
            segment_connections_end_in_extent.along_slope
        ),
        incident_pts as (
        select incident_lane.*, lcp_incident_b1.position as incident_lane_last_to_second_pt, 
			lcp_incident_b0.position as node_position
        from incident_lane
        join ushr_format.lane_center_points lcp_incident_b1 on lcp_incident_b1.road_segment_id = incident_road_segment_id
		join ushr_format.lane_center_points lcp_incident_b0 on lcp_incident_b0.road_segment_id = incident_road_segment_id
        where lcp_incident_b1.lane_number = incident_lane_number
        and lcp_incident_b1.lane_point_sequence_index = incident_lane_last_to_second_index
		and lcp_incident_b0.lane_number = incident_lane_number
		and lcp_incident_b0.lane_point_sequence_index = incident_lane_last_to_second_index + 1
        )
        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
        curvature, heading, along_slope, st_astext(node_position),
        st_astext(st_makeline(array[incident_lane_last_to_second_pt, node_position]))
        from incident_pts
		'''
        response_end_node = make_query(self.conn, query, None)

        query = f'''with segment_connections_start_in_extent as (
                        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
                        curvature, heading, along_slope
                        from ushr_format.road_edge_points            
						join ushr_format.lane_connections on lane_connections.emergent_road_segment_id = road_segment_id 
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
						and incident_road_segment_id = 0										   
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ), 
        emergent_pts as (
        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
        segment_connections_start_in_extent.curvature, segment_connections_start_in_extent.heading, 
        segment_connections_start_in_extent.along_slope,
		lcp_emergent_0.position as node_position, 
		lcp_emergent_1.position as emergent_second_pt
        from segment_connections_start_in_extent
        join ushr_format.lane_center_points lcp_emergent_1 on lcp_emergent_1.road_segment_id = emergent_road_segment_id
		join ushr_format.lane_center_points lcp_emergent_0 on lcp_emergent_0.road_segment_id = emergent_road_segment_id
        where lcp_emergent_1.lane_number = emergent_lane_number
        and lcp_emergent_1.lane_point_sequence_index = 1
		and lcp_emergent_0.lane_number = emergent_lane_number
        and lcp_emergent_0.lane_point_sequence_index = 0
        )
        select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, 
        curvature, heading, along_slope, st_astext(node_position),
        st_astext(st_makeline(array[node_position, emergent_second_pt]))
        from emergent_pts
		
		'''

        response_start_node = make_query(self.conn, query, None)

        node_type_list = []
        for row in response_connection + response_end_node + response_start_node:
            incident_road_segment_id = row[0]
            incident_lane_number = row[1]
            emergent_road_segment_id = row[2]
            emergent_lane_number = row[3]
            curvature = row[4]
            heading = row[5]
            along_slope = row[6]
            node_geom = row[7]
            # arrow_geom is a line formed by: last-to-second point of the incident lane,
            # connection node and second point of the emergent lane
            line_geom = row[8]

            if incident_road_segment_id == 0:
                node_type = 'start'
            elif emergent_road_segment_id == 0:
                node_type = 'end'
            else:
                node_type = 'transition'

            if node_type not in node_type_list:
                node_type_list.append(node_type)

            qgs_node_geom = g.fromWkt(node_geom)
            qgs_line_geom = g.fromWkt(line_geom)

            f_node = QgsFeature()
            f_node.setGeometry(qgs_node_geom)
            f_node.setAttributes([incident_road_segment_id, incident_lane_number,
                                  emergent_road_segment_id, emergent_lane_number, node_type,
                                  curvature, heading, along_slope])
            node_feature_list.append(f_node)

            f_line = QgsFeature()
            f_line.setGeometry(qgs_line_geom)
            f_line.setAttributes([incident_road_segment_id, incident_lane_number,
                                  emergent_road_segment_id, emergent_lane_number, node_type,
                                  curvature, heading, along_slope])
            line_feature_list.append(f_line)

        # start_node: green
        # end_node: red
        # transition_node: yellow
        rules = ()
        colors = {'start': 'lime', 'end': 'red', 'transition': 'yellow'}
        for node_type in node_type_list:
            actual_width = 0.5
            label = f'{node_type}'
            exp = f'''node_type = \'{node_type}\''''
            line_style = 'solid'
            color = colors[node_type]
            rules += ((label, exp, line_style, color, actual_width),)

        node_v_layer = buildSimpleQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_lane_connection_node',
                                                 node_feature_list, qgs_fields)

        feature_dict = {}
        for node_type in node_type_list:
            feature_dict[node_type] = (colors[node_type], node_type)
        node_v_layer = apply_categorized_symbol(feature_dict, node_v_layer, field='node_type', point=True)

        arrow_v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', 'udbx3_lane_connection',
                                                  line_feature_list, qgs_fields)
        arrow_v_layer = setLineLayerStyleToArrow(arrow_v_layer)

        return node_v_layer, arrow_v_layer

    def query_road_edge_in_extent(self):
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
                        where road_edge_point_sequence_index = 0 
                        and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   
                    edge_start_att as (
                    	select road_edges.road_segment_id, road_edges.road_edge_side, road_edge_type, 
						array_agg(shoulder_width) as shoulder_widths,
                    	array_agg(st_astext(position) order by road_edge_point_sequence_index) as geoms,
                    	max(road_edge_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.road_edge_points 
                            on road_edge_points.road_segment_id = segments_in_extent.road_segment_id
                    	join ushr_format.road_edges on road_edges.road_segment_id = road_edge_points.road_segment_id
                    	where road_edge_points.road_edge_side = road_edges.road_edge_side
                    	group by road_edges.road_segment_id, road_edges.road_edge_side
                    )
                    select edge_start_att.road_segment_id, edge_start_att.road_edge_side, edge_start_att.road_edge_type,					
                    max_index, shoulder_widths, geoms, 
                    array_agg(road_edge_attributes.road_edge_point_sequence_index 
                                    order by road_edge_point_sequence_index) as inds, 
					array_agg(road_edge_attributes.road_edge_type 
                                order by road_edge_point_sequence_index) as road_edge_types                    
                    from edge_start_att
                    left join ushr_format.road_edge_attributes 
                        on edge_start_att.road_segment_id = road_edge_attributes.road_segment_id
                        and edge_start_att.road_edge_side = road_edge_attributes.road_edge_side       						
                    group by edge_start_att.road_segment_id, edge_start_att.road_edge_side, 
                        edge_start_att.road_edge_type, max_index, geoms, shoulder_widths
					'''
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('road_edge_side', QVariant.String),
                      QgsField('road_edge_type', QVariant.String),
                      QgsField('index_range', QVariant.String),
                      QgsField('shoulder_widths', QVariant.String)
                      ]
        feature_list = []
        edge_type_list = []
        response = make_query(self.conn, query, None)
        for row in response:
            segment_id, road_edge_side_boolean, initial_road_edge_type_code, max_index, shoulder_widths, point_geoms, \
                change_inds, change_types = row

            edge_type_dict = {}
            seq_ind = 0
            edge_type_dict[seq_ind] = {'road_edge_side_boolean': road_edge_side_boolean,
                                       'road_edge_type_code': initial_road_edge_type_code}
            # maintain the attributes until there is a change
            # road_edge_type_code = initial_road_edge_type_code

            # there is change
            if change_inds[0] is not None:
                for i, seq_ind in enumerate(change_inds):
                    change_type = change_types[i]
                    edge_type_dict[seq_ind] = {'road_edge_side_boolean': road_edge_side_boolean,
                                               'road_edge_type_code': change_type}
            for seq_ind in edge_type_dict:
                if edge_type_dict[seq_ind]['road_edge_type_code'] not in edge_type_list:
                    edge_type_list.append(edge_type_dict[seq_ind]['road_edge_type_code'])

            ind_list = []
            point_geom_list = []
            road_edge_type_code = edge_type_dict[0]['road_edge_type_code']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in edge_type_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    point_geom_list.append(loads(point_geom_wkt))
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'[{min(ind_list)}, {max(ind_list)})'
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    edge_geom = LineString(point_geom_list).wkt
                    edge_qgsgeom = g.fromWkt(edge_geom)
                    f = QgsFeature()
                    f.setGeometry(edge_qgsgeom)
                    road_edge_side = \
                        udbx_road_edge_side_df[udbx_road_edge_side_df['boolean']
                                               == road_edge_side_boolean]['side'].values[0]
                    road_edge_type = \
                        udbx_road_edge_type_df[udbx_road_edge_type_df['id'] == road_edge_type_code]['type'].values[0]
                    f.setAttributes([segment_id, road_edge_side, road_edge_type, index_range, f'{shoulder_widths}'])
                    feature_list.append(f)
                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    road_edge_type_code = edge_type_dict[i]['road_edge_type_code']

            max_change_ind = max(list(edge_type_dict.keys()))
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            index_range = f'[{max_change_ind}, {max_index})'
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            road_edge_type_code = edge_type_dict[max_change_ind]['road_edge_type_code']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            edge_geom = LineString(point_geom_list).wkt
            edge_qgsgeom = g.fromWkt(edge_geom)
            f = QgsFeature()
            f.setGeometry(edge_qgsgeom)
            road_edge_side = \
                udbx_road_edge_side_df[udbx_road_edge_side_df['boolean'] == road_edge_side_boolean]['side'].values[0]
            road_edge_type = udbx_road_edge_type_df[udbx_road_edge_type_df['id'] == road_edge_type_code]['type'].values[
                0]
            f.setAttributes([segment_id, road_edge_side, road_edge_type, index_range, f'{shoulder_widths}'])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', 'udbx3_road_edge', feature_list,
                                      qgs_fields)

        # make rules
        rules = ()
        for road_edge_type_code in edge_type_list:
            actual_width = 1
            road_edge_type = udbx_road_edge_type_df[udbx_road_edge_type_df['id'] == road_edge_type_code]['type'].values[
                0]
            label = f'{road_edge_type}'
            exp = f'''road_edge_type = \'{road_edge_type}\''''
            line_style = 'solid'
            color = udbx_road_edge_type_df[udbx_road_edge_type_df['id'] == road_edge_type_code]['draw_color'].values[0]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)

        return v_layer

    # obstructed_shoulder, shared_use_shoulder
    def query_special_shoulder_in_extent(self, shoulder_type=None):
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    ),	   
                    shoulder_start as (
                    	select road_edges.road_segment_id, road_edges.road_edge_side, {shoulder_type}, 						
                    	array_agg(st_astext(position) order by road_edge_point_sequence_index) as geoms,
                    	max(road_edge_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.road_edge_points on road_edge_points.road_segment_id = segments_in_extent.road_segment_id
                    	join ushr_format.road_edges on road_edges.road_segment_id = road_edge_points.road_segment_id
                    	where road_edge_points.road_edge_side = road_edges.road_edge_side
                    	group by road_edges.road_segment_id, road_edges.road_edge_side
                    ),
					special_shoulder as (
                    select shoulder_start.road_segment_id, shoulder_start.road_edge_side, shoulder_start.{shoulder_type},					
                    max_index, geoms, 
                    array_agg(road_edge_attributes.road_edge_point_sequence_index order by road_edge_point_sequence_index) as inds, 
					array_agg(road_edge_attributes.{shoulder_type} order by road_edge_point_sequence_index) as {shoulder_type}s                    
                    from shoulder_start
                    left join ushr_format.road_edge_attributes on shoulder_start.road_segment_id = road_edge_attributes.road_segment_id
                    	and shoulder_start.road_edge_side = road_edge_attributes.road_edge_side       						
                    group by shoulder_start.road_segment_id, shoulder_start.road_edge_side, shoulder_start.{shoulder_type}, max_index, geoms
					)
					select *
					from special_shoulder
					where array[True] && {shoulder_type}s or {shoulder_type} = True					
					'''
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('road_edge_side', QVariant.String),
                      QgsField(f'{shoulder_type}', QVariant.String),
                      QgsField(f'range', QVariant.String),
                      QgsField(f'length', QVariant.Int)
                      ]
        feature_list = []
        # edge_type_list = []
        response = make_query(self.conn, query, None)
        for row in response:
            segment_id = row[0]
            road_edge_side_boolean = row[1]
            initial_special_shoulder_boolean = row[2]
            max_index = row[3]
            point_geoms = row[4]
            change_inds = row[5]
            change_special_shoulders = row[6]

            special_shoulder_dict = {}
            seq_ind = 0
            special_shoulder_dict[seq_ind] = {'road_edge_side_boolean': road_edge_side_boolean,
                                              'special_shoulder_boolean': initial_special_shoulder_boolean}
            # maintain the attributes until there is a change
            # there is change
            if change_inds[0] is not None:
                prev_change_special_shoulder = initial_special_shoulder_boolean
                for i, seq_ind in enumerate(change_inds):
                    change_special_shoulder = change_special_shoulders[i]
                    if prev_change_special_shoulder == change_special_shoulder:
                        continue
                    prev_change_special_shoulder = change_special_shoulder
                    special_shoulder_dict[seq_ind] = {'road_edge_side_boolean': road_edge_side_boolean,
                                                      'special_shoulder_boolean': change_special_shoulder}

            ind_list = []
            point_geom_list = []
            special_shoulder_boolean = special_shoulder_dict[0]['special_shoulder_boolean']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                # plot only when boolean changes to False
                if i != 0 and i in special_shoulder_dict:
                    # the last point of the current piece is also the first point of next piece
                    # complete the geometry for the current type duration
                    if special_shoulder_boolean:
                        ind_list.append(i)
                        point_geom_list.append(loads(point_geom_wkt))
                        if len(ind_list) == 1:
                            ind_list.insert(0, 0)
                        index_range = f'[{min(ind_list)}, {max(ind_list)})'
                        length = max(ind_list) - min(ind_list)
                        if len(point_geom_list) == 1:
                            point_geom_list.append(point_geom_list[0])
                        edge_geom = LineString(point_geom_list).wkt
                        edge_qgsgeom = g.fromWkt(edge_geom)
                        f = QgsFeature()
                        f.setGeometry(edge_qgsgeom)
                        road_edge_side = \
                            udbx_road_edge_side_df[udbx_road_edge_side_df['boolean'] == road_edge_side_boolean][
                                'side'].values[0]
                        f.setAttributes(
                            [segment_id, road_edge_side, f'{special_shoulder_boolean}', index_range, length])
                        feature_list.append(f)
                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    special_shoulder_boolean = special_shoulder_dict[i]['special_shoulder_boolean']
            if special_shoulder_boolean:
                max_change_ind = max(list(special_shoulder_dict.keys()))
                index_range = f'[{max_change_ind}, {max_index})'
                length = max_index - max_change_ind
                # complete the last portion of the line, if there is no type change on this line, this is the entire line.
                special_shoulder_boolean = special_shoulder_dict[max_change_ind]['special_shoulder_boolean']
                if len(point_geom_list) == 1:
                    point_geom_list.append(point_geom_list[0])
                edge_geom = LineString(point_geom_list).wkt
                edge_qgsgeom = g.fromWkt(edge_geom)
                f = QgsFeature()
                f.setGeometry(edge_qgsgeom)
                road_edge_side = \
                    udbx_road_edge_side_df[udbx_road_edge_side_df['boolean'] == road_edge_side_boolean]['side'].values[
                        0]
                f.setAttributes([segment_id, road_edge_side, f'{special_shoulder_boolean}', index_range, length])
                feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', f'udbx3_{shoulder_type}',
                                            feature_list, qgs_fields)
        color = special_shoulder_df[special_shoulder_df['type'] == shoulder_type]['draw_color'].values[0]
        v_layer = setLineLayerStyle(v_layer, color=color, width=3)

        return v_layer

    # sign type 1~13: regulatory traffic device: lane mapping correct
    # sign type > 13: regular signs: lane mapping: 0
    def query_signs_in_extent(self):
        query = f'''with signs_in_extent as (
                        select sign_id, sign_face_azimuth, sign_face_elevation, height, width, 
                        shape, type, is_digital, value, centroid_position,
                        st_polygon(st_linefrommultipoint(
                        st_collect(array[bottom_left_corner_position, top_left_corner_position, 
                                         top_right_corner_position, bottom_right_corner_position, 
                                         bottom_left_corner_position])), {self.main_win.srid}) as sign_geom
                        from ushr_format.signs            						
                        where st_within(centroid_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                        order by sign_id
                    ),	     
                    sign_lane_mapping as (
                    select signs_in_extent.*, road_segment_id, lane_number, lane_point_sequence_index
                    from signs_in_extent
                    left join ushr_format.sign_lane_mapping ON sign_lane_mapping.sign_id = signs_in_extent.sign_id
                    )					
                    select sign_id, sign_face_azimuth, sign_face_elevation, height, width, 
                    shape, type, is_digital, value, 
                    sign_lane_mapping.road_segment_id, sign_lane_mapping.lane_number, 
                    sign_lane_mapping.lane_point_sequence_index, st_astext(sign_geom) as sign_geom, 
                    st_astext(st_makeline(centroid_position, position)) as lane_mapping, st_astext(centroid_position)
                    from sign_lane_mapping
                    left join ushr_format.lane_center_points 
                        on lane_center_points.road_segment_id = sign_lane_mapping.road_segment_id
                        and ((type > 13 and type < 196 
                                and lane_center_points.lane_number = sign_lane_mapping.lane_number + 1) 
                            or 
                            ((type <= 13 or type >= 196) 
                                and lane_center_points.lane_number = sign_lane_mapping.lane_number))
                        and lane_center_points.lane_point_sequence_index = sign_lane_mapping.lane_point_sequence_index
                    '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_sign_fields = [QgsField('udbx_sign_id', QVariant.Int), QgsField('rfdb_sign_id', QVariant.Int),
                           QgsField('type', QVariant.String),
                           QgsField('value', QVariant.Int),
                           QgsField('is_digital', QVariant.String), QgsField('shape', QVariant.String),
                           QgsField('height', QVariant.Double), QgsField('width', QVariant.Double),
                           QgsField('face_azimuth', QVariant.Double), QgsField('face_elevation', QVariant.Double),
                           QgsField('arrow_width', QVariant.Int)
                           ]
        qgs_sign_lm_fields = [QgsField('udbx_sign_id', QVariant.Int), QgsField('type', QVariant.String),
                              QgsField('value', QVariant.Int),
                              QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                              QgsField('lane_point_sequence_index', QVariant.Int)
                              ]
        sign_feature_list = []
        sign_centroid_feature_list = []
        sign_lm_feature_list = []
        sign_type_id_list = []
        sign_id_set = set([])

        for row in response:
            # road_segment_id can be None when there is no lane mapping
            sign_id, sign_face_azimuth, sign_face_elevation, height, width, shape_id, sign_type_id, is_digital, value, \
                segment_id, lane_number, lane_point_sequence_index, sign_geom, lane_mapping_geom, \
                sign_centroid_geom = row
            rfdb_sign_id = RFDBSignID(sign_id, self.driving_side)
            sign_shape = SignShape(shape_id).name
            sign_type = SignType(sign_type_id).name

            if sign_type_id not in sign_type_id_list:
                sign_type_id_list.append(sign_type_id)

            sign_qgsgeom = g.fromWkt(sign_geom)
            sign_centroid_qgsgeom = g.fromWkt(sign_centroid_geom)

            lm_qgsgeom = g.fromWkt(lane_mapping_geom)

            if sign_id not in sign_id_set:
                sign_id_set.add(sign_id)
                f = QgsFeature()
                f.setGeometry(sign_qgsgeom)
                f.setAttributes([sign_id, rfdb_sign_id, sign_type, value, f'{is_digital}', sign_shape,
                                 height, width, sign_face_azimuth, sign_face_elevation, 1])
                sign_feature_list.append(f)

                f = QgsFeature()
                f.setGeometry(sign_centroid_qgsgeom)
                f.setAttributes([sign_id, rfdb_sign_id, sign_type, value, f'{is_digital}', sign_shape,
                                 height, width, sign_face_azimuth, sign_face_elevation, 1])
                sign_centroid_feature_list.append(f)

            f = QgsFeature()
            f.setGeometry(lm_qgsgeom)
            f.setAttributes([sign_id, sign_type, value, segment_id, lane_number, lane_point_sequence_index])
            sign_lm_feature_list.append(f)

        v_layer_sign = buildSimpleQgsVectorLayer(f'PolygonZ?crs=epsg:{self.main_win.srid}', 'udbx3_sign',
                                                 sign_feature_list, qgs_sign_fields)
        v_layer_sign_centroid = buildSimpleQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}',
                                                          'udbx3_sign_centroid',
                                                          sign_centroid_feature_list, qgs_sign_fields)
        v_layer_sign_lm = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}',
                                                    'udbx3_sign_lane_mapping',
                                                    sign_lm_feature_list, qgs_sign_lm_fields)
        v_layer_sign_face_azimuth = buildSimpleQgsVectorLayer(
            f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_sign_face_azimuth',
            sign_centroid_feature_list, qgs_sign_fields)
        v_layer_sign_face_azimuth = setVectorFieldTypeStyle(v_layer_sign_face_azimuth, 'arrow_width', 'face_azimuth')

        # make rules
        rules = ()
        sign_color_selector = ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'purple']
        for i, sign_type_id in enumerate(sign_type_id_list):
            actual_width = 0.4
            sign_type = SignType(sign_type_id).name
            label = f'{sign_type}'
            exp = f'''type = \'{sign_type}\''''
            line_style = 'solid'
            if i > 6:
                index = i % 6
            else:
                index = i
            color = sign_color_selector[index]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer_sign = apply_rule_based_symbol(rules, v_layer_sign)
        v_layer_sign_centroid = apply_rule_based_symbol(rules, v_layer_sign_centroid, geometry='point')
        v_layer_sign_lm = apply_rule_based_symbol(rules, v_layer_sign_lm, geometry='arrow')

        return v_layer_sign, v_layer_sign_centroid, v_layer_sign_lm, v_layer_sign_face_azimuth

    def query_rtd_apply_position_in_extent(self):
        query = f'''select road_segment_id, lane_number, lane_point_sequence_index, 
                    lane_point_sequence_index_offset, st_astext(applied_position)
                    from ushr_format.rtd_apply_position            						
                    where st_within(applied_position, 
                                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                    {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_rtd_apply_position_fields = [QgsField('road_segment_id', QVariant.Int),
                                         QgsField('lane_number', QVariant.Int),
                                         QgsField('lane_point_sequence_index', QVariant.Int),
                                         QgsField('lane_point_sequence_index_offset', QVariant.Double)]
        feature_list = []
        for row in response:
            road_segment_id = row[0]
            lane_number = row[1]
            lane_point_sequence_index = row[2]
            lane_point_sequence_index_offset = row[3]
            geom = row[4]
            qgsgeom = g.fromWkt(geom)

            f = QgsFeature()
            f.setGeometry(qgsgeom)
            f.setAttributes([road_segment_id, lane_number, lane_point_sequence_index,
                             lane_point_sequence_index_offset])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_rtd_apply_position',
                                      feature_list, qgs_rtd_apply_position_fields, color='orange')
        return v_layer

    def query_pavement_markings_in_extent(self):
        query = f'''with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
                        where road_edge_point_sequence_index = 0 
                        and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    )
                    select pavement_markings.pavement_marking_id, marking_type, 
                    pavement_marking_lane_mapping.road_segment_id, 
                    array_agg(array[lane_number, lane_point_sequence_index]) as lane_numbers,
                    st_astext(pavement_marking_position) as pavement_marking_geom
                    from ushr_format.pavement_markings
                    left join ushr_format.pavement_marking_lane_mapping 
                        ON pavement_marking_lane_mapping.pavement_marking_id = pavement_markings.pavement_marking_id
                    join segments_in_extent 
                        on segments_in_extent.road_segment_id = pavement_marking_lane_mapping.road_segment_id                                                                                      
                    group by pavement_markings.pavement_marking_id, marking_type, 
                        pavement_marking_lane_mapping.road_segment_id, pavement_marking_position'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('pavement_marking_id', QVariant.Int),
                      QgsField('pavement_marking_type', QVariant.String),
                      QgsField('lane_pt_index', QVariant.String)
                      ]
        feature_list = []
        pm_type_id_set = set([])
        pm_dict = {}
        pm_lane_mapping_dict = {}

        for row in response:
            pavement_marking_id, pavement_marking_type_id, segment_id, lane_pt_index, pm_geom = row
            pavement_marking_type = PavementMarkingType(pavement_marking_type_id).name
            pm_type_id_set.add(pavement_marking_type_id)

            if pavement_marking_id not in pm_dict:
                pm_dict[pavement_marking_id] = {'pavement_marking_type': pavement_marking_type,
                                                'geom': pm_geom}
            if pavement_marking_id not in pm_lane_mapping_dict:
                pm_lane_mapping_dict[pavement_marking_id] = {}
            pm_lane_mapping_dict[pavement_marking_id][segment_id] = lane_pt_index

        for pavement_marking_id in pm_dict:
            pavement_marking_type = pm_dict[pavement_marking_id]['pavement_marking_type']
            pm_geom = pm_dict[pavement_marking_id]['geom']
            pm_qgsgeom = g.fromWkt(pm_geom)

            f = QgsFeature()
            f.setGeometry(pm_qgsgeom)

            f.setAttributes(
                [pavement_marking_id, pavement_marking_type, f'{pm_lane_mapping_dict[pavement_marking_id]}'])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'PolygonZ?crs=epsg:{self.main_win.srid}', 'udbx3_pavement_marking', feature_list,
                                      qgs_fields)

        # make rules
        rules = ()
        pm_color_selector = get_colors(len(pm_type_id_set))
        for i, pm_type_id in enumerate(list(pm_type_id_set)):
            actual_width = 0.5
            pavement_marking_type = PavementMarkingType(pm_type_id).name
            label = f'{pavement_marking_type}'
            exp = f'''pavement_marking_type = \'{pavement_marking_type}\''''
            line_style = 'solid'
            color = QColor(pm_color_selector[i])
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer1 = apply_rule_based_symbol(rules, v_layer, qcolor=True)

        return v_layer1

    def query_intersection_in_extent(self):
        query = f'''SELECT intersection.intersection_id, type, st_astext(centroid), st_astext(geometry), 
                    array_agg(road_segment_id)
                    FROM ushr_format.intersection
                    left join ushr_format.intersection_road_segment_mapping 
                        on intersection_road_segment_mapping.intersection_id = intersection.intersection_id                    
                    where st_within(geometry, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                    {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    group by intersection.intersection_id '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('intersection_id', QVariant.Int), QgsField('type', QVariant.Int),
                      QgsField('segment_id_list', QVariant.String)]
        centroid_feature_list = []
        geom_feature_list = []
        for row in response:
            intersection_id, intersection_type, centroid, geom, segment_id_list = row

            centroid = g.fromWkt(centroid)
            f = QgsFeature()
            f.setGeometry(centroid)
            f.setAttributes([intersection_id, intersection_type, f'{segment_id_list}'])
            centroid_feature_list.append(f)

            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([intersection_id, intersection_type, f'{segment_id_list}'])
            geom_feature_list.append(f)

        centroid_layer = buildQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_intersection_centroid',
                                             centroid_feature_list, qgs_fields)
        geom_layer = buildQgsVectorLayer(f'MULTIPOLYGON?crs=epsg:{self.main_win.srid}', 'udbx3_intersection_geom',
                                         geom_feature_list, qgs_fields, color='pink', fill=True)
        return centroid_layer, geom_layer

    def query_lane_center_points_in_extent(self):
        query = f'''
                    with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
						where road_edge_point_sequence_index = 0 
						and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    )
                            	select lane_center_points.*, st_astext(position), st_z(position)
        						from segments_in_extent
                            	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.road_segment_id'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('xs_id', QVariant.Int), QgsField('curvature', QVariant.Double),
                      QgsField('heading', QVariant.Double), QgsField('cross_slope', QVariant.Double),
                      QgsField('along_slope', QVariant.Double), QgsField('lane_width', QVariant.Double),
                      QgsField('abs_curvature', QVariant.Double), QgsField('elevation', QVariant.Double)]
        feature_list = []
        abs_curvature_list = []
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            xs_id = row[2]
            curvature = row[3]
            heading = row[4]
            cross_slope = row[5]
            along_slope = row[6]
            lane_width = row[7]
            geom = row[9]
            elevation = row[10]
            abs_curvature = abs(curvature)
            abs_curvature_list.append(abs_curvature)

            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, lane_number, xs_id, curvature, heading, cross_slope, along_slope,
                             lane_width, abs_curvature, elevation])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_lane_center_points',
                                      feature_list, qgs_fields)
        if len(abs_curvature_list) > 0:
            v_layer = apply_graduated_symbol(v_layer, 'abs_curvature')
        return v_layer

    def query_lane_line_points_in_extent(self):
        query = f'''
                    with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
        				where road_edge_point_sequence_index = 0 
        				and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    )
                    select lane_line_points.road_segment_id, lane_line_ordinal_id, 
                    lane_line_point_sequence_index, st_astext(position), st_z(position)
                	from segments_in_extent
                    join ushr_format.lane_line_points 
                        on lane_line_points.road_segment_id = segments_in_extent.road_segment_id'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_line_ordinal_id', QVariant.Int),
                      QgsField('xs_id', QVariant.Int), QgsField('elevation', QVariant.Double)]
        feature_list = []
        for row in response:
            segment_id, lane_line_ordinal_id, xs_id, geom, elevation = row
            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, lane_line_ordinal_id, xs_id, elevation])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_lane_line_points',
                                      feature_list, qgs_fields)
        return v_layer

    def query_road_edge_points_in_extent(self):
        query = f'''
                    with segments_in_extent as (select road_segment_id
                        from ushr_format.road_edge_points            						
                        where road_edge_point_sequence_index = 0 
                        and road_edge_side = false
                        and st_within(position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.main_win.srid}))
                    )
                    select road_edge_points.road_segment_id, road_edge_side, 
                    road_edge_point_sequence_index, st_astext(position), st_z(position)
                    from segments_in_extent
                    join ushr_format.road_edge_points 
                        on road_edge_points.road_segment_id = segments_in_extent.road_segment_id'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('road_edge_side', QVariant.String),
                      QgsField('xs_id', QVariant.Int), QgsField('elevation', QVariant.Double)]
        feature_list = []
        for row in response:
            segment_id, road_edge_side, xs_id, geom, elevation = row
            road_edge_side = RoadEdgeSide(road_edge_side)
            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, road_edge_side, xs_id, elevation])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer(f'PointZ?crs=epsg:{self.main_win.srid}', 'udbx3_road_edge_points',
                                      feature_list, qgs_fields)
        return v_layer


def get_colors(n_colors):
    return sns.color_palette(palette='husl', n_colors=n_colors).as_hex()


def RFDBSignID(udbx_sign_id, driving_side):
    if driving_side:
        rfdb_sign_id = int(udbx_sign_id) // 9
    else:
        rfdb_sign_id = udbx_sign_id
    return rfdb_sign_id


@dataclass
class Extent:
    x_min: float
    y_min: float
    x_max: float
    y_max: float


class MainWinTest:
    def __init__(self, conn):
        self.customer_conn = conn
        self.extent = None
        self.srid = None

    def add_layer(self, x, y):
        print(x, y)


if __name__ == '__main__':
    current_dir = pathlib.Path(__file__).parent.parent
    init_file = os.path.join(current_dir, 'user.ini')
    config = configparser.ConfigParser()
    config.read(init_file)
    if 'Customer' in config:
        host = config['Customer']['host']
        port = config['Customer']['port']
        db = config['Customer']['db']
        username = config['Customer']['username']
        password = config['Customer']['password']
    else:
        sys.exit('No connection')
    conn_data = {'host': host, 'db': db, 'port': port, 'username': username, 'password': password}
    conn = connect_to_db(conn_data['host'], conn_data['username'], conn_data['password'], conn_data['db'],
                         conn_data['port'])
    main_win_test = MainWinTest(conn)
    main_win_test.srid = 6697
    main_win_test.extent = Extent(133.79228, 34.62194, 133.80362, 34.63308)
    udbx3_mapdata = UDBX3MapData(main_win_test)
    udbx3_mapdata.query_lane_line_attributes_in_extent(6)
