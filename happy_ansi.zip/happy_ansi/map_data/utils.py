from qgis.core import QgsVectorLayer, QgsSymbol, QgsRendererCategory, \
    QgsCategorizedSymbolRenderer, QgsRuleBasedRenderer, QgsSimpleMarkerSymbolLayerBase, \
    QgsSimpleLineSymbolLayer, QgsMarkerSymbol, QgsArrowSymbolLayer, \
    QgsRasterLayer, QgsCoordinateReferenceSystem, QgsLineSymbol, QgsRendererRange, \
    QgsGraduatedSymbolRenderer, QgsFeatureRequest, QgsFillSymbol, QgsVectorLayerSimpleLabeling, \
    QgsPalLayerSettings, QgsTextFormat, QgsTextBufferSettings, QgsGeometry, QgsCoordinateReferenceSystem, \
    QgsField, QgsFeature, QgsProject, QgsSimpleMarkerSymbolLayer, QgsVectorFileWriter, QgsStyle, \
    QgsRendererRangeLabelFormat, QgsClassificationQuantile, QgsVectorFieldSymbolLayer, QgsSingleSymbolRenderer
from PyQt5.QtGui import QColor, QFont
from qgis.PyQt.QtCore import Qt, QFileInfo, QSettings, QVariant
from PyQt5.QtWidgets import QMessageBox
import os
import seaborn as sns


def construct_layer(layer_name, feature_name, wkt_geom, attributes, geom_type='PolygonZ'):
    g = QgsGeometry()
    qgs_fields = [QgsField(feature_name, QVariant.Int)]
    feature_list = []

    geom = g.fromWkt(wkt_geom)
    f = QgsFeature()
    f.setGeometry(geom)
    f.setAttributes(attributes)
    feature_list.append(f)
    layer = buildSimpleQgsVectorLayer(f'{geom_type}?crs=epsg:4326', layer_name, feature_list, qgs_fields)
    if geom_type == 'PolygonZ':
        layer = setPolygonLayerStyle(layer, stroke_color='orange')
    elif geom_type == 'LinestringZ':
        layer = setLineLayerStyle(layer, color='orange')
    layers = [layer]
    return layers


def build_qgs_layer(field_dict, field_content_lists, location_list, layer_name=None, color='lime',
                    geometry_type='PointZ', epsg=4326):
    qgs_fields = []
    g = QgsGeometry()
    feature_list = []
    for field in field_dict:
        data_type = field_dict[field]
        qgs_fields.append(QgsField(field, data_type))
    for i, location in enumerate(location_list):
        qgsgeom = g.fromWkt(location)
        f = QgsFeature()
        f.setGeometry(qgsgeom)
        field_content = []
        for field_content_list in field_content_lists:
            field_content.append(field_content_list[i])
        f.setAttributes(field_content)
        feature_list.append(f)
    layer = buildSimpleQgsVectorLayer(f'{geometry_type}?crs=epsg:{epsg}', layer_name, feature_list, qgs_fields,
                                      color=color)
    return layer


def show_msgbox(title='', text=''):
    msg = QMessageBox()
    msg.setWindowTitle(title)
    msg.setText(text)
    msg.exec_()


# 5/16=0, 5/8=0, 5/4=1, 1/2=0, 1/1=1 ----> 4, 1
def get_bitmask_array(val):
    value = val
    bitmask_list = []
    for i in range(20, -1, -1):
        bitmask = pow(2, i)
        if value // bitmask == 1:
            bitmask_list.append(bitmask)
            value = value % bitmask
            if value == 0:
                break
    return bitmask_list


pen_style = {
    'solid': Qt.SolidLine,
    'dash': Qt.DashLine,
    'dot': Qt.DotLine
}


# input: color_list is a list of QColor items
def blend_colors(color_list):
    pcnt = 1 / len(color_list)
    blended_color_red = 0
    blended_color_green = 0
    blended_color_blue = 0
    blended_color_alpha = 0
    for color in color_list:
        q_color = QColor(color)
        blended_color_red += pcnt * q_color.red()
        blended_color_green += pcnt * q_color.green()
        blended_color_blue += pcnt * q_color.blue()
        blended_color_alpha += pcnt * q_color.alpha()
    blended_color = QColor(blended_color_red, blended_color_green, blended_color_blue, blended_color_alpha)
    return blended_color


def add_group(group_name):
    # add the layers to group
    root = QgsProject.instance().layerTreeRoot()
    group = None
    child_names = [child.name() for child in root.children()]
    if group_name in child_names:
        for child in root.children():
            if child.name() == group_name:
                group = child
                for group_child in group.children():
                    QgsProject.instance().removeMapLayer(group_child.layerId())
                break
    else:
        group = root.insertGroup(0, group_name)
    return group


def buildQgsVectorLayer(string_geomtype, string_layername, feature_list, list_qgsfield, shape='circle', color='green',
                        fill=False, size=2):
    # create new vector layer from self.crs
    vector_layer = QgsVectorLayer(string_geomtype, string_layername, "memory")

    # set crs from class
    # vector_layer.setCrs(crs)

    # set fields
    provider = vector_layer.dataProvider()
    provider.addAttributes(list_qgsfield)
    vector_layer.updateFields()

    # fill layer with geom and attrs
    vector_layer.startEditing()
    for feat in feature_list:
        vector_layer.addFeature(feat)
    vector_layer.commitChanges()

    if fill:
        symbol = QgsFillSymbol.createSimple({'outline_color': 'black', 'color': f'{color}'})
    else:
        symbol = QgsMarkerSymbol.createSimple({'name': f'{shape}', 'color': f'{color}', 'size': f'{size}'})
    vector_layer.renderer().setSymbol(symbol)
    vector_layer.triggerRepaint()

    return vector_layer


def buildSimpleQgsVectorLayer(string_geomtype, string_layername, feature_list, list_qgsfield, color='lime'):
    # create new vector layer from self.crs
    vector_layer = QgsVectorLayer(string_geomtype, string_layername, "memory")

    # set crs from class
    # vector_layer.setCrs(crs)

    symbol = vector_layer.renderer().symbol()
    # symbol = symbols[0]
    symbol.setColor(QColor(color))

    # set fields
    provider = vector_layer.dataProvider()
    provider.addAttributes(list_qgsfield)
    vector_layer.updateFields()

    # fill layer with geom and attrs
    vector_layer.startEditing()
    for feat in feature_list:
        vector_layer.addFeature(feat)
    vector_layer.commitChanges()

    return vector_layer


def apply_categorized_symbol(features, layer, field, width=1, hsv=False, point=False, apply_color_ramp=False):
    categories = []

    for feature, (color, label) in features.items():
        sym = QgsSymbol.defaultSymbol(layer.geometryType())
        if hsv:
            sym.setColor(color)
        else:
            sym.setColor(QColor(color))
        if width > 0 and not point:
            sym.setWidth(width)
        category = QgsRendererCategory(feature, sym, label)
        categories.append(category)

    sym = QgsSymbol.defaultSymbol(layer.geometryType())
    color = 'red'
    if hsv:
        sym.setColor(color)
    else:
        sym.setColor(QColor(color))
    sym.setWidth(0.5)
    category = QgsRendererCategory(None, sym, 'All Others')
    categories.append(category)
    renderer = QgsCategorizedSymbolRenderer(field, categories)
    if apply_color_ramp:
        ramp_name = 'RdYlGn'
        default_style = QgsStyle().defaultStyle()
        color_ramp = default_style.colorRamp(ramp_name)
        renderer.updateColorRamp(color_ramp)
    layer.setRenderer(renderer)
    return layer


def apply_rule_based_symbol(rules, layer, geometry='line', qcolor=False,opacity=1.0):
    sym = QgsSymbol.defaultSymbol(layer.geometryType())
    renderer = QgsRuleBasedRenderer(sym)
    root_rule = renderer.rootRule()
    for label, exp, style, color, width in rules:
        rule = root_rule.children()[0].clone()
        rule.setLabel(label)
        rule.setFilterExpression(exp)

        rule.symbol().deleteSymbolLayer(0)
        if geometry == 'line':
            symbol_layer = QgsSimpleLineSymbolLayer()
            symbol_layer.setWidth(width)
            symbol_layer.setPenStyle(pen_style[style])
        elif geometry == 'arrow':
            symbol_layer = QgsArrowSymbolLayer()
            symbol_layer.setArrowWidth(width)
            symbol_layer.setHeadThickness(1)
            symbol_layer.setArrowStartWidth(width)
            symbol_layer.setColor(QColor('green'))
            symbol_layer.setIsCurved(False)
            symbol_layer.setIsRepeated(False)
        else:
            symbol_layer = QgsSimpleMarkerSymbolLayer()
        if qcolor:
            color = color
        else:
            color = QColor(color)
        symbol_layer.setColor(color)
        rule.symbol().appendSymbolLayer(symbol_layer)
        root_rule.appendChild(rule)
    root_rule.removeChildAt(0)
    layer.setRenderer(renderer)

    return layer


def apply_graduated_symbol(layer, target_field):
    # Set desired paremeters
    ramp_name = 'Reds'
    num_classes = 10
    classification_method = QgsClassificationQuantile()

    # change format settings as necessary
    label_format = QgsRendererRangeLabelFormat()
    label_format.setFormat("%1 - %2")
    label_format.setPrecision(7)
    label_format.setTrimTrailingZeroes(True)

    symbol = QgsSymbol.defaultSymbol(layer.geometryType())
    symbol.symbolLayer(0).setStrokeColor(QColor('transparent'))

    default_style = QgsStyle().defaultStyle()
    color_ramp = default_style.colorRamp(ramp_name)

    renderer = QgsGraduatedSymbolRenderer()
    renderer.setSourceSymbol(symbol)
    renderer.setClassAttribute(target_field)
    renderer.setClassificationMethod(classification_method)
    renderer.setLabelFormat(label_format)
    renderer.updateClasses(layer, num_classes)
    renderer.updateColorRamp(color_ramp)

    layer.setRenderer(renderer)
    layer.triggerRepaint()

    return layer


def setVectorFieldTypeStyle(layer, length_attribute, angle_attribute, color='blue', width=1):
    symbol = QgsMarkerSymbol.createSimple({})
    symbol.deleteSymbolLayer(0)

    symbol_layer = QgsVectorFieldSymbolLayer()
    symbol_layer.setXAttribute(length_attribute)
    symbol_layer.setYAttribute(angle_attribute)
    symbol_layer.setColor(QColor(color))
    symbol_layer.setScale(6)
    symbol_layer.setVectorFieldType(QgsVectorFieldSymbolLayer.Polar)
    symbol_layer.setAngleUnits(QgsVectorFieldSymbolLayer.Degrees)

    arrow = QgsArrowSymbolLayer.create(
        {
            "arrow_width": f'{width}',
            "head_length": "2",
            "head_thickness": "1",
            "head_type": "0",
            "arrow_type": "0",
            "is_curved": "1",
            "arrow_start_width": f'{width}'
        }
    )

    symbol_layer.subSymbol().changeSymbolLayer(0, arrow)

    symbol.appendSymbolLayer(symbol_layer)

    renderer = QgsSingleSymbolRenderer(symbol)

    layer.setRenderer(renderer)

    # show the changes
    layer.triggerRepaint()
    return layer


def setLineLayerStyle(layer, color='white', width=1):
    symbol = QgsLineSymbol.createSimple({'outline_width': f'{width}', 'color': color})
    layer.renderer().setSymbol(symbol)
    # show the changes
    layer.triggerRepaint()
    return layer


def setPolygonLayerStyle(layer, fill_color='transparent', stroke_color='yellow', width=1,opacity=0.5):
    symbol = QgsFillSymbol.createSimple({'color': fill_color, 'color_border': stroke_color, 'width_border': f'{width}'})
    symbol.setOpacity(opacity)
    layer.renderer().setSymbol(symbol)
    # show the changes
    layer.triggerRepaint()
    return layer


def setLineLayerStyleToArrow(layer, arrow_width=1, arrow_start_width=1, head_thickness=1, color='blue',
                             curved=False, repeated=False):
    sym = layer.renderer().symbol()
    sym_layer = QgsArrowSymbolLayer.create({"arrow_width": f'{arrow_width}'})
    sym_layer.setHeadThickness(head_thickness)
    sym_layer.setArrowStartWidth(arrow_start_width)
    sym_layer.setColor(QColor(color))
    sym_layer.setIsCurved(curved)
    sym_layer.setIsRepeated(repeated)
    sym.changeSymbolLayer(0, sym_layer)
    return layer


def buildQgsRasterLayer(tile_server_url, img_url, layer_name):

    url = tile_server_url + img_url
    qgis_tms_uri = 'type=xyz&zmin=16&zmax=21&url=' + url
    layer = QgsRasterLayer(qgis_tms_uri, layer_name, 'wms')
    layer.setScaleBasedVisibility(True)
    layer.setMinimumScale(6818.0)
    layer.setMaximumScale(1.0)

    return layer


def add_label(layer, field, geom_type='point', is_expression=False, color='black'):
    layer_settings = QgsPalLayerSettings()
    text_format = QgsTextFormat()

    text_format.setFont(QFont("Arial", 8))
    text_format.setColor(QColor(color))

    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(0.10)
    buffer_settings.setColor(QColor('black'))

    text_format.setBuffer(buffer_settings)
    layer_settings.setFormat(text_format)

    if is_expression:
        layer_settings.isExpression = True
    # layer_settings.fieldName = """concat("field_1", ' ', "Field_2")"""
    layer_settings.fieldName = field

    if geom_type == 'point':
        layer_settings.placement = QgsPalLayerSettings.OverPoint
    elif geom_type == 'line':
        layer_settings.placement = QgsPalLayerSettings.Line
    else:
        return

    layer_settings.enabled = True

    layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
    layer.setLabelsEnabled(True)
    layer.setLabeling(layer_settings)
    layer.triggerRepaint()


def build_layer(main_win, feature_dict, qgs_fields, geom_type='Point', layer_name='Zoom_Feature',
                group_name='Group'):
    feature_list = []
    g = QgsGeometry()
    for id_ in feature_dict:
        f = QgsFeature()
        geom = feature_dict[id_]['geom']
        geom = g.fromWkt(geom)
        f.setGeometry(geom)
        attribute_list = feature_dict[id_]['attribute_list']
        f.setAttributes(attribute_list)
        feature_list.append(f)

    v_layer = buildSimpleQgsVectorLayer(f'{geom_type}?crs=epsg:4326', layer_name,
                                        feature_list, qgs_fields)
    if geom_type == 'PolygonZ':
        v_layer = setPolygonLayerStyle(v_layer, stroke_color='orange')
    v_layers = [v_layer]
    root = main_win.qgs_project_instance.layerTreeRoot()
    group = None
    child_names = [child.name() for child in root.children()]
    if group_name in child_names:
        for child in root.children():
            if child.name() == group_name:
                group = child
                break
    else:
        group = root.insertGroup(0, group_name)

    if len(v_layers) > 0:
        for layer in v_layers:
            main_win.qgs_project_instance.addMapLayer(layer, False)
            group.addLayer(layer)
            # main_win.canvas.setExtent(layer.extent())
            # main_win.canvas.refresh()


def zoom_to_feature(main_win, geom, qgs_fields, attribute_list, id_, geom_type='Point', group_name='Zoom_Feature'):
    g = QgsGeometry()
    feature_list = []

    geom = g.fromWkt(geom)
    f = QgsFeature()
    f.setGeometry(geom)
    f.setAttributes(attribute_list)
    feature_list.append(f)
    if geom_type == 'Point':
        layer = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', f'{group_name}_{id_}',
                                          feature_list, qgs_fields)
    elif geom_type == 'Linestring':
        layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', f'{group_name}_{id_}',
                                          feature_list, qgs_fields)
    elif geom_type == 'Polygon':
        layer = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', f'{group_name}_{id_}',
                                          feature_list, qgs_fields)
        layer = setPolygonLayerStyle(layer, stroke_color='orange')
    else:
        return
    v_layers = [layer]
    root = main_win.qgs_project_instance.layerTreeRoot()
    group = None
    child_names = [child.name() for child in root.children()]
    if group_name in child_names:
        for child in root.children():
            if child.name() == group_name:
                group = child
                break
    else:
        group = root.insertGroup(0, group_name)

    if len(v_layers) > 0:
        for layer in v_layers:
            main_win.qgs_project_instance.addMapLayer(layer, False)
            group.addLayer(layer)
            main_win.canvas.setExtent(layer.extent())
            main_win.canvas.refresh()


def highlight_feature(layer, field_name, field_val):
    selection = layer.getFeatures(QgsFeatureRequest().setFilterExpression(f'{field_name} = {field_val}'))
    layer.selectByIds([s.id() for s in selection])


def issame_dict(dict1, dict2):
    for key in dict1:
        if key not in dict2:
            return False
        if dict1[key] != dict2[key]:
            return False
    return True


def load_dict(dict1, dict2):
    for key in dict1:
        dict2[key] = dict1[key]


def load_layer(filepath):
    filename = os.path.basename(filepath)
    layer = QgsVectorLayer(filepath, os.path.splitext(filename)[0], "ogr")
    return layer


def get_colors(n_colors):
    return sns.color_palette(palette='husl', n_colors=n_colors).as_hex()


def write2shp(layer, output_dir, out_filename, crs_wkt):
    if not os.path.exists(output_dir):
        os.mkdir(output_dir)
    out_filepath = os.path.join(output_dir, f'{out_filename}.shp')
    layer.setCrs(QgsCoordinateReferenceSystem(crs_wkt))
    save_options = QgsVectorFileWriter.SaveVectorOptions()
    save_options.driverName = "ESRI Shapefile"
    save_options.fileEncoding = "UTF-8"
    transform_context = QgsProject.instance().transformContext()
    QgsVectorFileWriter.writeAsVectorFormatV2(layer, out_filepath, transform_context, save_options)
    style_out_filepath = os.path.join(output_dir, f'{out_filename}.qml')
    layer.saveNamedStyle(style_out_filepath)


def parse_s3_url(s3_url):
    """Parse an s3 url into a bucket and key form.

    Parameters
    ----------
    s3_url : str
        Location of a s3 object in the form `s3://<bucket>/<key>`. This convention is utilized by various places in the
        code as well as pandas for reading from an s3 object.

    Returns
    -------
    bucket : str
        Bucket portion of the s3 url.

    key : str
        Key portion of the s3 url.

    """
    assert s3_url[:5].lower() == 's3://', 's3_url must start with "s3://"'

    parts = s3_url[5:].split('/')
    assert len(parts) >= 2, f's3_url={s3_url} should be of the form s3://<bucket>/<key>'
    bucket = parts[0]
    key = '/'.join(parts[1:])

    return bucket, key



