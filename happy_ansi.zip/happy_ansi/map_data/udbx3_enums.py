from enum import Enum


class FunctionalAuthority(Enum):
    No_Known_Construction = 0
    Active_Construction = 1
    Construction_Completed_Not_Acquired = 2
    Customer_Requested_Disable = 3
    Temporary_FA_Traffic = 4
    Temporary_FA_Accident = 5
    Compromised_Road_Condition = 6


class FunctionalAuthorityColor(Enum):
    No_Known_Construction = 'green'
    Active_Construction = 'red'
    Construction_Completed_Not_Acquired = 'orange'
    Customer_Requested_Disable = 'blue'
    Temporary_FA_Traffic = 'purple'
    Temporary_FA_Accident = 'brown'
    Compromised_Road_Condition = 'yellow'


class RoadType(Enum):
    CONTROLLED_ACCESS = 0
    NON_CONTROLLED_ACCESS = 1
    INTERCHANGE = 2
    RAMP = 3
    NOT_USED_1 = 4
    NOT_USED_2 = 5
    LOCAL = 6
    NOT_USED_3 = 7
    TURN_MANEUVER = 8
    ROUNDABOUT = 9


class RoadDivision(Enum):
    NON_DIVIDED = False
    DIVIDED = True


class FunctionalRoadClass(Enum):
    Main_Road = 0
    First_Class_Road = 1
    Second_Class_Road = 2
    Third_Class_Road = 3
    Fourth_Class_Road = 4
    Fifth_Class_Road = 5
    Sixth_Class_Road = 6
    Other_Class_Road = 7
    Indeterminate = 8


class FunctionalRoadClassOSM(Enum):
    Main_Road = 'OSM Motorway / Motorway Link'
    First_Class_Road = 'OSM Trunk / Trunk Link'
    Second_Class_Road = 'OSM Primary / Primary Link'
    Third_Class_Road = 'OSM Secondary / Secondary Link'
    Fourth_Class_Road = 'OSM Tertiary / Tertiary Link'
    Fifth_Class_Road = 'OSM Unclassified'
    Sixth_Class_Road = 'OSM Residential'
    Other_Class_Road = 'OSM Living Street, Service, Pedestrian'
    Indeterminate = 'Indeterminate'


class LaneAttrType(Enum):
    LANE_TYPE = 0
    SPEED_LIMIT = 1
    LEFT_CHANGE_ALLOWED = 2
    RIGHT_CHANGE_ALLOWED = 3
    CROSSING_TYPE = 4
    REGULATORY_TRAFFIC_DEVICE = 5
    MINIMUM_SPEED_LIMITS = 6
    PARKING_LANE_TYPE = 7
    TRUCK_SPEED_LIMIT = 8


class LaneType(Enum):
    NOT_USED = 0
    NORMAL_DRIVING_LANE = 1
    HOV_LANE = 2
    BIDIRECTIONAL_LANE = 4
    RESTRICTED_USE_VEHICLE_LANE = 8
    TOLL_BOOTH_LANE = 16
    CONVERTIBLE_TO_SHOULDER = 32
    TURN_ONLY_LANE = 64
    OTHER = 128
    AUTOPAY_TOLL_LANE = 256
    BICYCLE_LANE = 512
    EXPRESS_LANE = 1024
    PARKING_LANE = 2048
    EMERGENCY_LANE = 4096
    STREETCAR_LANE = 8192
    TWO_WAY_CENTER_TURN_LANE = 16384


class LaneLineAttrType(Enum):
    LANE_LINE_TYPE = 0
    LANE_LINE_COLOR = 1
    LANE_LINE_WIDTH = 2
    REFLECTIVE_MARKINGS_ATTRIBUTE = 3
    PAVEMENT_STRIPING_PRESENT_ATTRIBUTE = 4
    DECELERATION_MARKING_PRESENT = 5
    LANE_LINE_GEOMETRY_CENTERED = 6


def get_lane_line_attr_type_init(lane_line_attr_type):
    if lane_line_attr_type in ('LANE_LINE_TYPE', 'LANE_LINE_COLOR', 'LANE_LINE_WIDTH',
                               'PAVEMENT_STRIPING_PRESENT_ATTRIBUTE', 'DECELERATION_MARKING_PRESENT'):
        return 0
    elif lane_line_attr_type == 'REFLECTIVE_MARKINGS_ATTRIBUTE':
        return False
    else:
        return True


def get_lane_line_attr_type_change_init(lane_line_attr_type):
    if lane_line_attr_type in ('LANE_LINE_TYPE', 'LANE_LINE_COLOR', 'LANE_LINE_WIDTH',
                               'PAVEMENT_STRIPING_PRESENT_ATTRIBUTE', 'DECELERATION_MARKING_PRESENT',
                               'REFLECTIVE_MARKINGS_ATTRIBUTE'):
        return 0
    else:
        return 1


class LaneLineType(Enum):
    Virtual = 0
    Single_Solid_Paint_Line = 1
    Single_Dashed_Paint_Line = 2
    Double_Paint_Line_Left_Solid_Right_Solid = 3
    Double_Paint_Line_Left_Dashed_Right_Solid = 4
    Double_Paint_Line_Left_Solid_Right_Dashed = 5
    Double_Paint_Line_Left_Dashed_Right_Dashed = 6
    Triple_Paint_Line_All_Solid = 7
    Other = 8


class LaneLineColor(Enum):
    No_Color = 0
    White = 1
    Yellow = 2
    Not_Used_1 = 3
    Not_Used_2 = 4
    Other = 5


class RoadEdgeSide(Enum):
    Left = False
    Right = True


class CrossingType(Enum):
    NO_CROSSINGS = 0
    OVERHEAD_BRIDGE_OVERPASS = 1
    OVERHEAD_TUNNEL = 2
    OVERHEAD_SIGN_GANTRY = 4
    TOLL_STRUCTURE = 8
    STOP_BAR = 16
    AT_GRADE_ROAD_CROSSING = 32
    AT_GRADE_PEDESTRIAN = 64
    AT_GRADE_MOVABLE_BRIDGE = 128
    AT_GRADE_AUTHORIZED_VEHICLE = 256
    AT_GRADE_ACCESS_ROAD_ONLY = 512
    AT_GRADE_RAILROAD_CROSSING = 1024
    UNDER_GRADE_BRIDGE = 2048
    AT_GRADE_ACCESS_DRIVEWAY = 4096
    NOT_USED_1 = 8192
    NOT_USED_2 = 16384


class LaneAddRemoveType(Enum):
    CONTINUING_LANE = 0
    ADDED_LANE = 1
    ENDING_LANE = 2
    CONTINUING_EQUAL_LANE = 4
    ADDED_EQUAL_LANE = 5
    ENDING_EQUAL_LANE = 6


class LaneAddRemoveTypeColor(Enum):
    CONTINUING_LANE = 'white'
    ADDED_LANE = 'green'
    ENDING_LANE = 'red'
    CONTINUING_EQUAL_LANE = 'blue'
    ADDED_EQUAL_LANE = 'lime'
    ENDING_EQUAL_LANE = 'orange'


class SignType(Enum):
    Stop = 1
    Yield = 2
    Red_Traffic_Light_Excluding_Rail_Crossing = 3
    Yellow_Traffic_Light = 4
    Single_Left_Turn_Light = 5
    Single_Right_Turn_Light = 6
    Single_Straight_Light = 7
    Horizontal_2_Traffic_Light = 8
    Vertical_2_Traffic_Light = 9
    Horizontal_3_Traffic_Light = 10
    Vertical_3_Traffic_Light = 11
    Horizontal_4_Plus_Traffic_Light = 12
    Vertical_4_Plus_Traffic_Light = 13
    Railroad_Crossing_Light = 14
    Railroad_Crossing_Sign = 15
    Interstate_Route = 16
    Overhead_Directions = 17
    Street_Name = 18
    Bridge_Height = 19
    Lane_Ends = 20
    Freeway_Ends = 21
    Rest_Area = 22
    Highway_Exit = 23
    Digital_Sign = 24
    No_Turns = 25
    No_Left_Turn = 26
    No_Right_Turn = 27
    No_Turn_on_Red = 28
    Left_and_Right_Turn_Only = 29
    Left_and_Straight_Only = 30
    Left_Turn_Only = 31
    Left_and_U_Turn_Only = 32
    Left_Straight_and_U_Turn_Only = 33
    Right_and_Straight_Only = 34
    Right_Turn_Only = 35
    Roundabout_Left_and_Straight_Only = 36
    Roundabout_Left_Only = 37
    Roundabout_Left_Straight_and_U_Turn_Only = 38
    Roundabout_Left_Right_and_Straight_Only = 39
    Roundabout_Right_and_Straight_Only = 40
    Roundabout_Straight_Only = 41
    Straight_Only = 42
    U_Turn_Only = 43
    Keep_Left = 44
    Keep_Right = 45
    One_Way_Left = 46
    One_Way_Right = 47
    One_Way_Straight = 48
    Circular_Intersection = 49
    Dead_End = 50
    Wrong_Way = 51
    Authorized_Vehicle = 52
    Incident_Management = 53
    Electronic_Toll = 54
    Other_Turn = 55
    Other_Red = 56
    Other_White = 57
    Other_Black_Warning = 58
    Other_Yellow = 59
    Other_Blue = 60
    Other_Brown = 61
    Other_Green = 62
    Other_Orange = 63
    Other_Complementary = 64
    Unassigned = 65
    Maximum_Speed_Limit = 66
    Minimum_Speed_Limit = 92
    Truck_Speed_Limit = 118
    Night_Speed_Limit = 144
    Warning_Speed_Limit = 170
    Horizontal_4_Traffic_Light = 196
    Vertical_4_Traffic_Light = 197
    Horizontal_5_Traffic_Light = 198
    Vertical_5_Traffic_Light = 199
    Horizontal_6_Plus_Traffic_Light = 200
    Vertical_6_Plus_Traffic_Light = 201
    Single_Other_Traffic_Light = 202
    Other_Traffic_Light = 203
    HOV_Lane = 204
    HOV_Lane_End = 205


class SignSuperType(set, Enum):
    RIGHT_OF_WAY = {SignType.Stop, SignType.Yield,
                    SignType.Red_Traffic_Light_Excluding_Rail_Crossing, SignType.Yellow_Traffic_Light,
                    SignType.Single_Left_Turn_Light, SignType.Single_Right_Turn_Light, SignType.Single_Straight_Light,
                    SignType.Railroad_Crossing_Light, SignType.Railroad_Crossing_Sign,
                    SignType.Single_Other_Traffic_Light, SignType.Other_Traffic_Light,
                    SignType.Horizontal_2_Traffic_Light,  SignType.Vertical_2_Traffic_Light,
                    SignType.Horizontal_3_Traffic_Light, SignType.Vertical_3_Traffic_Light,
                    SignType.Horizontal_4_Traffic_Light, SignType.Vertical_4_Traffic_Light,
                    SignType.Horizontal_4_Plus_Traffic_Light, SignType.Vertical_4_Plus_Traffic_Light,
                    SignType.Horizontal_5_Traffic_Light, SignType.Vertical_5_Traffic_Light,
                    SignType.Horizontal_6_Plus_Traffic_Light, SignType.Vertical_6_Plus_Traffic_Light,
                    }
    INFORMATIONAL = {SignType.Interstate_Route, SignType.Overhead_Directions, SignType.Street_Name,
                     SignType.Rest_Area, SignType.Highway_Exit, SignType.Digital_Sign}
    ADVISORY = {SignType.Bridge_Height, SignType.Lane_Ends, SignType.Freeway_Ends,
                SignType.HOV_Lane, SignType.HOV_Lane_End}
    TURN_RESTRICTION = {SignType.No_Turns, SignType.No_Left_Turn, SignType.No_Right_Turn, SignType.No_Turn_on_Red,
                        SignType.Left_and_Right_Turn_Only, SignType.Left_and_Straight_Only, SignType.Left_Turn_Only,
                        SignType.Left_and_U_Turn_Only, SignType.Left_Straight_and_U_Turn_Only,
                        SignType.Right_and_Straight_Only, SignType.Right_Turn_Only,
                        SignType.Roundabout_Left_and_Straight_Only, SignType.Roundabout_Left_Only,
                        SignType.Roundabout_Left_Right_and_Straight_Only, SignType.Roundabout_Straight_Only,
                        SignType.Roundabout_Left_Straight_and_U_Turn_Only, SignType.Roundabout_Right_and_Straight_Only,
                        SignType.U_Turn_Only, SignType.Keep_Left, SignType.Keep_Right,
                        SignType.One_Way_Left, SignType.One_Way_Right, SignType.One_Way_Straight,
                        SignType.Circular_Intersection, SignType.Dead_End, SignType.Wrong_Way,
                        SignType.Authorized_Vehicle
                        }
    SPEED_LIMIT = {SignType.Maximum_Speed_Limit, SignType.Minimum_Speed_Limit, SignType.Night_Speed_Limit,
                   SignType.Truck_Speed_Limit, SignType.Warning_Speed_Limit}
    OTHER = {SignType.Electronic_Toll, SignType.Other_Traffic_Light, SignType.Other_Black_Warning,
             SignType.Other_Blue, SignType.Other_Brown, SignType.Other_Complementary, SignType.Other_Green,
             SignType.Other_Orange, SignType.Other_Red, SignType.Other_Turn, SignType.Other_White,
             SignType.Other_Yellow}
    UNASSIGNED = {SignType.Unassigned}


class SignShape(Enum):
    Rectangular = 0
    Circular = 1
    Triangle_Point_Up = 2
    Triangle_Point_Down = 3
    Square = 4
    Shield = 5
    Diamond = 6
    Polygonal = 7
    Compound = 8
    Crossbuck = 9
    Other = 10


class SignDigital(Enum):
    NOT_DIGITAL = False
    DIGITAL = True


class PavementMarkingType(Enum):
    Left_and_Right_Arrow = 1
    Left_and_Straight_Arrow = 2
    Left_Arrow = 3
    Left_and_U_Turn_Arrow           = 4
    Left_Right_and_Straight_Arrow = 5
    Left_Straight_and_U_Turn_Arrow = 6
    Merge_Arrow_Left = 7
    Merge_Arrow_Right = 8
    Right_and_Straight_Arrow = 9
    Right_Arrow = 10
    Roundabout_Left_and_Straight_Arrow          = 11
    Roundabout_Left_Arrow = 12
    Roundabout_Left_Right_and_Straight_Arrow = 13
    Roundabout_Left_Straight_and_U_Turn_Arrow = 14
    Roundabout_Right_and_Straight_Arrow = 15
    Roundabout_Straight_Arrow = 16
    Straight_Arrow = 17
    U_Turn_Arrow = 18
    Lane_Number = 19
    Speed_005 = 20
    Speed_010 = 21
    Speed_015 = 22
    Speed_020 = 23
    Speed_025 = 24
    Speed_030 = 25
    Speed_035 = 26
    Speed_040 = 27
    Speed_045 = 28
    Speed_050 = 29
    Speed_055 = 30
    Speed_060 = 31
    Speed_065 = 32
    Speed_070 = 33
    Speed_075 = 34
    Speed_080 = 35
    Speed_085 = 36
    Speed_090 = 37
    Speed_095 = 38
    Speed_100 = 39
    Speed_105 = 40
    Speed_110 = 41
    Speed_115 = 42
    Speed_120 = 43
    Speed_125 = 44
    Speed_130 = 45
    Toll_Speed       = 46
    Bicycle = 47
    Express_Toll = 48
    Diamond = 49
    OK = 50
    Road_Shield = 51
    RXR = 52
    Yield_Triangles = 53
    AHEAD = 54
    BELT = 55
    BIKE = 56
    BR = 57
    BRIDGE = 58
    BUS = 59
    BUSES = 60
    CANADA = 61
    CAR = 62
    CARS = 63
    CASH = 64
    CLEAR = 65
    CRUISE = 66
    EB = 67
    EXIT = 68
    E_Z = 69
    FASTRAK = 70
    FWY = 71
    HWY = 72
    KEEP = 73
    LANE = 74
    LANES = 75
    LOW = 76
    MERGE = 77
    MPH = 78
    NB = 79
    NO = 80
    NORTH = 81
    ONLY = 82
    PASS = 83
    PED = 84
    PKWY = 85
    POOL = 86
    SB = 87
    SCHOOL = 88
    SIGNAL = 89
    SLOW = 90
    SOUTH = 91
    STOP = 92
    SUN = 93
    TO = 94
    TRUCK = 95
    TRUCKS = 96
    WB = 97
    X_ING = 98
    YIELD = 99
    Other = 100
    Stop_Bar = 101
    Pedestrian_Crossing = 102
    Xplus = 103
    Queuing_Bar = 104
    No_Stopping = 105
    Bicycle_No_Entry = 106
    Priority_Road_Ahead = 107
    End_Regulation = 108
    Turn_Method = 109
    Parallel_Parking = 110
    Perpendicular_Parking = 111
    Regular_Car_Lane = 112
    Special_Vehicle_Lane = 113
    Towing_Vehicle_Lane = 114
    Not_Used = 115
    ETC = 116
    Fire_Hydrant = 117


class PavementMarkingSuperType(set, Enum):
    FreeForm = {PavementMarkingType.Stop_Bar, PavementMarkingType.Pedestrian_Crossing}
