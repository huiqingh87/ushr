from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
from .utils import *
from .db_conn import *
from shapely.geometry import LineString
from shapely.wkt import loads


sign_type_enum = {
            1: "Stop",
            2: "Yield",
            3: "Red Traffic Light (excluding RR xing)",
            4: "Yellow Traffic Light",
            5: "Single Left Turn Light",
            6: "Single Right Turn Light",
            7: "Single Straight Light",
            8: "Horizontal Two Traffic Light",
            9: "Vertical Two Traffic Light",
            10: "Horizontal Three Traffic Light",
            11: "Vertical Three Traffic Light",
            12: "4+ Horizontal Traffic Light",
            13: "4+ Vertical Traffic Light",
            14: "Railroad Crossing Light",
            15: "Railroad Crossing Sign",
            16: "Interstate Route",
            17: "Overhead Directions",
            18: "Street Name",
            19: "Bridge Height",
            20: "Lane Ends",
            21: "Freeway Ends",
            22: "Rest Area",
            23: "Highway Exit",
            24: "Digital Sign",
            25: "No Turns",
            26: "No Left Turn",
            27: "No Right Turn",
            28: "No Turn on Red",
            29: "Left and Right Turn Only",
            30: "Left and Straight Only",
            31: "Left Turn Only",
            32: "Left and U-Turn Only",
            33: "Left Straight and U-Turn Only",
            34: "Right and Straight Only",
            35: "Right Turn Only",
            36: "Roundabout Left and Straight Only",
            37: "Roundabout Left Only",
            38: "Roundabout Left Straight and U-Turn Only",
            39: "Roundabout Left Right and Straight Only",
            40: "Roundabout Right and Straight Only",
            41: "Roundabout Straight Only",
            42: "Straight Only",
            43: "U-Turn Only",
            44: "Keep Left",
            45: "Keep Right",
            46: "One Way Left",
            47: "One Way Right",
            48: "One Way Straight",
            49: "Circular Intersection",
            50: "Dead End",
            51: "Wrong Way",
            52: "Authorized Vehicle",
            53: "Incident Management",
            54: "Electronic Toll",
            55: "Other – Turn",
            56: "Other – Red – Regulatory",
            57: "Other – White – Regulatory",
            58: "Other – Black – Warning",
            59: "Other – Yellow – Warning",
            60: "Other – Blue – Information",
            61: "Other – Brown – Information",
            62: "Other – Green – Information",
            63: "Other – Orange – Temporary",
            64: "Other – Complementary",
            65: "Unassigned",
            66: "Maximum Speed Limit 5",
            67: "Maximum Speed Limit 10",
            68: "Maximum Speed Limit 15",
            69: "Maximum Speed Limit 20",
            70: "Maximum Speed Limit 25",
            71: "Maximum Speed Limit 30",
            72: "Maximum Speed Limit 35",
            73: "Maximum Speed Limit 40",
            74: "Maximum Speed Limit 45",
            75: "Maximum Speed Limit 50",
            76: "Maximum Speed Limit 55",
            77: "Maximum Speed Limit 60",
            78: "Maximum Speed Limit 65",
            79: "Maximum Speed Limit 70",
            80: "Maximum Speed Limit 75",
            81: "Maximum Speed Limit 80",
            82: "Maximum Speed Limit 85",
            83: "Maximum Speed Limit 90",
            84: "Maximum Speed Limit 95",
            85: "Maximum Speed Limit 100",
            86: "Maximum Speed Limit 105",
            87: "Maximum Speed Limit 110",
            88: "Maximum Speed Limit 115",
            89: "Maximum Speed Limit 120",
            90: "Maximum Speed Limit 125",
            91: "Maximum Speed Limit 130",
            92: "Minimum Speed Limit 5",
            93: "Minimum Speed Limit 10",
            94: "Minimum Speed Limit 15",
            95: "Minimum Speed Limit 20",
            96: "Minimum Speed Limit 25",
            97: "Minimum Speed Limit 30",
            98: "Minimum Speed Limit 35",
            99: "Minimum Speed Limit 40",
            100: "Minimum Speed Limit 45",
            101: "Minimum Speed Limit 50",
            102: "Minimum Speed Limit 55",
            103: "Minimum Speed Limit 60",
            104: "Minimum Speed Limit 65",
            105: "Minimum Speed Limit 70",
            106: "Minimum Speed Limit 75",
            107: "Minimum Speed Limit 80",
            108: "Minimum Speed Limit 85",
            109: "Minimum Speed Limit 90",
            110: "Minimum Speed Limit 95",
            111: "Minimum Speed Limit 100",
            112: "Minimum Speed Limit 105",
            113: "Minimum Speed Limit 110",
            114: "Minimum Speed Limit 115",
            115: "Minimum Speed Limit 120",
            116: "Minimum Speed Limit 125",
            117: "Minimum Speed Limit 130",
            118: "Truck Speed Limit 5",
            119: "Truck Speed Limit 10",
            120: "Truck Speed Limit 15",
            121: "Truck Speed Limit 20",
            122: "Truck Speed Limit 25",
            123: "Truck Speed Limit 30",
            124: "Truck Speed Limit 35",
            125: "Truck Speed Limit 40",
            126: "Truck Speed Limit 45",
            127: "Truck Speed Limit 50",
            128: "Truck Speed Limit 55",
            129: "Truck Speed Limit 60",
            130: "Truck Speed Limit 65",
            131: "Truck Speed Limit 70",
            132: "Truck Speed Limit 75",
            133: "Truck Speed Limit 80",
            134: "Truck Speed Limit 85",
            135: "Truck Speed Limit 90",
            136: "Truck Speed Limit 95",
            137: "Truck Speed Limit 100",
            138: "Truck Speed Limit 105",
            139: "Truck Speed Limit 110",
            140: "Truck Speed Limit 115",
            141: "Truck Speed Limit 120",
            142: "Truck Speed Limit 125",
            143: "Truck Speed Limit 130",
            144: "Night Speed Limit 5",
            145: "Night Speed Limit 10",
            146: "Night Speed Limit 15",
            147: "Night Speed Limit 20",
            148: "Night Speed Limit 25",
            149: "Night Speed Limit 30",
            150: "Night Speed Limit 35",
            151: "Night Speed Limit 40",
            152: "Night Speed Limit 45",
            153: "Night Speed Limit 50",
            154: "Night Speed Limit 55",
            155: "Night Speed Limit 60",
            156: "Night Speed Limit 65",
            157: "Night Speed Limit 70",
            158: "Night Speed Limit 75",
            159: "Night Speed Limit 80",
            160: "Night Speed Limit 85",
            161: "Night Speed Limit 90",
            162: "Night Speed Limit 95",
            163: "Night Speed Limit 100",
            164: "Night Speed Limit 105",
            165: "Night Speed Limit 110",
            166: "Night Speed Limit 115",
            167: "Night Speed Limit 120",
            168: "Night Speed Limit 125",
            169: "Night Speed Limit 130",
            170: "Warning Speed Limit 5",
            171: "Warning Speed Limit 10",
            172: "Warning Speed Limit 15",
            173: "Warning Speed Limit 20",
            174: "Warning Speed Limit 25",
            175: "Warning Speed Limit 30",
            176: "Warning Speed Limit 35",
            177: "Warning Speed Limit 40",
            178: "Warning Speed Limit 45",
            179: "Warning Speed Limit 50",
            180: "Warning Speed Limit 55",
            181: "Warning Speed Limit 60",
            182: "Warning Speed Limit 65",
            183: "Warning Speed Limit 70",
            184: "Warning Speed Limit 75",
            185: "Warning Speed Limit 80",
            186: "Warning Speed Limit 85",
            187: "Warning Speed Limit 90",
            188: "Warning Speed Limit 95",
            189: "Warning Speed Limit 100",
            190: "Warning Speed Limit 105",
            191: "Warning Speed Limit 110",
            192: "Warning Speed Limit 115",
            193: "Warning Speed Limit 120",
            194: "Warning Speed Limit 125",
            195: "Warning Speed Limit 130"
        }
sign_shape_enum = {
            0: 'Rectangular',
            1: 'Circular',
            2: 'Triangle Point Up',
            3: 'Triangle Point Down',
            4: 'Square',
            5: 'Shield',
            6: 'Diamond',
            7: 'Polygonal',
            8: 'Compound',
            9: 'Crossbuck',
            10: 'Other'
        }
pavement_marking_type_enum = {
            1: 'Left and Right Arrow',
            2: 'Left and Straight Arrow',
            3: 'Left Arrow',
            4: 'Left and U - Turn Arrow',
            5: 'Left Right and Straight Arrow',
            6: 'Left Straight and U - Turn Arrow',
            7: 'Merge Arrow Left',
            8: 'Merge Arrow Right',
            9: 'Right and Straight Arrow',
            10: 'Right Arrow',
            11: 'Roundabout Left and Straight Arrow',
            12: 'Roundabout Left Arrow',
            13: 'Roundabout Left Right and Straight Arrow',
            14: 'Roundabout Left Straight and U - Turn Arrow',
            15: 'Roundabout Right and Straight Arrow',
            16: 'Roundabout Straight Arrow',
            17: 'Straight Arrow',
            18: 'U - Turn Arrow',
            19: 'Lane Number',
            20: 'Speed - 005',
            21: 'Speed - 010',
            22: 'Speed - 015',
            23: 'Speed - 020',
            24: 'Speed - 025',
            25: 'Speed - 030',
            26: 'Speed - 035',
            27: 'Speed - 040',
            28: 'Speed - 045',
            29: 'Speed - 050',
            30: 'Speed - 055',
            31: 'Speed - 060',
            32: 'Speed - 065',
            33: 'Speed - 070',
            34: 'Speed - 075',
            35: 'Speed - 080',
            36: 'Speed - 085',
            37: 'Speed - 090',
            38: 'Speed - 095',
            39: 'Speed - 100',
            40: 'Speed - 105',
            41: 'Speed - 110',
            42: 'Speed - 115',
            43: 'Speed - 120',
            44: 'Speed - 125',
            45: 'Speed - 130',
            46: 'Toll Speed',
            47: 'Bicycle',
            48: 'Express Toll',
            49: 'HOV Diamond',
            50: 'OK',
            51: 'Road Shield',
            52: 'RXR',
            53: 'Yield Triangles',
            54: 'AHEAD',
            55: 'BELT',
            56: 'BIKE',
            57: 'BR',
            58: 'BRIDGE',
            59: 'BUS',
            60: 'BUSES',
            61: 'CANADA',
            62: 'CAR',
            63: 'CARS',
            64: 'CASH',
            65: 'CLEAR',
            66: 'CRUISE',
            67: 'EB',
            68: 'EXIT',
            69: 'E - Z',
            70: 'FASTRAK',
            71: 'FWY',
            72: 'HWY',
            73: 'KEEP',
            74: 'LANE',
            75: 'LANES',
            76: 'LOW',
            77: 'MERGE',
            78: 'MPH',
            79: 'NB',
            80: 'NO',
            81: 'NORTH',
            82: 'ONLY',
            83: 'PASS',
            84: 'PED',
            85: 'PKWY',
            86: 'POOL',
            87: 'SB',
            88: 'SCHOOL',
            89: 'SIGNAL',
            90: 'SLOW',
            91: 'SOUTH',
            92: 'STOP',
            93: 'SUN',
            94: 'TO',
            95: 'TRUCK',
            96: 'TRUCKS',
            97: 'WB',
            98: 'X - ING',
            99: 'YIELD',
            100: 'Other'
        }


class UDBXMapData:
    def __init__(self, mainwin):
        self.main_win = mainwin
        self.conn = mainwin.customer_conn
        self.extent = mainwin.extent
        self.srid = 4326

        self.road_type = {
            0: ('green', 'Controlled Access Divided'),
            1: ('blue', 'Non-Controlled Access Divided'),
            2: ('orange', 'Interchange'),
            3: ('yellow', 'Ramp'),
            4: ('lime', 'Controlled Access Non-Divided'),
            5: ('cyan', 'Non-Controlled Access Non-Divided'),
            6: ('purple', 'Local Divided'),
            7: ('pink', 'Local Non-Divided')
        }

        # bitmask, one lane can have multiple types
        self.lane_type = {
            1: ('green', "Normal Driving Lane"),
            2: ('white', "HOV Lane"),
            4: ('magenta', "Bidirectional Lane"),
            8: ('orange', "Bus/Taxi Lane"),
            16: ('yellow', "Toll Booth Lane"),
            32: ('brown', "Convertible To Shoulder "),
            64: ('pink', "Turn Only Lane"),
            128: ('purple', "Other"),
            256: ('gray', "Autopay Toll Lane")
        }
        self.lane_add_remove_type = {
            0: "None",
            1: "Ending Lane",
            2: "Merging Lane",
            3: "Added Lane",
            4: "Diverging Lane"
        }
        self.lane_att_type = {
            0: 'lane_type',
            1: 'speed_limit',
            2: 'left_change_allowed',
            3: 'right_change_allowed',
            4: 'crossing_type',
            5: 'regulatory_traffic_device',
            6: 'functional_authority'
        }
        self.line_att_type = {
            0: 'line_type',
            1: 'line_color',
            2: 'line_width',
            3: 'reflective_markings',
            4: 'pavement_striping_present'
        }

        self.crossing_type = {
            0: ('white', "No Crossings"),
            1: ('gray', 'Overhead Bridge'),
            2: ('brown', "Overhead Tunnel"),
            4: ('pink', "Overhead Sign/Gantry"),
            8: ('green', "Toll Structure"),
            16: ('red', "Stop Bar"),
            32: ('purple', "At Grade Road Crossing"),
            64: ('orange', "At Grade Pedestrian"),
            128: ('blue', "At Grade Movable Bridge"),
            256: ('yellow', 'At Grade Authorized Vehicle'),
            512: ('navy', 'At Grade Access Only'),
            1024: ('magenta', 'At Grade Railroad Crossing')
        }
        self.lane_change_allowed = {
            False: ('red', 'False'),
            True: ('green', 'True')
        }
        self.regulatory_traffic_device = {
            0: ('green', "No regulatory Traffic Device"),
            1: ('red', "Stop Sign"),
            2: ('orange', "Yield Sign"),
            4: ('blue', "Traffic Light")
        }
        self.functional_authority = {
            0: ('green', "AD Allowed"),
            1: ('red', "Active Construction"),
            2: ('yellow', "Construction Completed Not Acquired"),
            3: ('purple', "Customer Requested Disable")
        }
        self.line_type = {
            0: ('dot', "Virtual"),
            1: ('solid', "Single Solid Paint Line"),
            2: ('dash', "Single Dashed Paint Line"),
            3: ('solid', "Double Paint Line, Left Solid, Right Solid"),
            4: ('dash', "Double Paint Line, Left Dashed, Right Solid"),
            5: ('solid', "Double Paint Line, Left Solid, Right Dashed"),
            6: ('dash', "Double Paint Line, Left Dashed, Right Dashed"),
            7: ('solid', "Triple Paint Line All Solid"),
            8: ('solid', "Other")
        }
        self.line_color = {
            0: ('red', "No Color"),
            1: ('white', "White"),
            2: ('yellow', "Yellow"),
            3: ('cyan', "White/Yellow/Yellow"),
            4: ('orange', "Yellow/Yellow/White"),
            5: ('pink', "Other")
        }
        self.line_width = {
            0: (0.05, "No Width"),
            1: (0.1, "Thin"),
            2: (0.2, "Thick"),
            3: (0.4, "Other")
        }
        self.edge_side = {
            False: 'Left',
            True: 'Right'
        }
        self.edge_type = {
            0: ('aqua', 'Surface Change'),
            1: ('magenta', 'Curb'),
            2: ('brown', 'Physical Barrier'),
            3: ('coffee', 'Movable Barrier'),
            4: ('orange', 'Pole'),
            5: ('blue', 'Paint Line'),
            6: ('red', 'Virtual'),
            7: ('pink', 'Other')
        }
        self.pavement_striping_present = {
            0: ('black', "None"),
            1: ('green', "Left"),
            2: ('red', "Right"),
            3: ('orange', "Left & Right")
        }
        self.sign_type = {
            1: "Stop",
            2: "Yield",
            3: "Red Traffic Light (excluding RR xing)",
            4: "Yellow Traffic Light",
            5: "Single Left Turn Light",
            6: "Single Right Turn Light",
            7: "Single Straight Light",
            8: "Horizontal Two Traffic Light",
            9: "Vertical Two Traffic Light",
            10: "Horizontal Three Traffic Light",
            11: "Vertical Three Traffic Light",
            12: "4+ Horizontal Traffic Light",
            13: "4+ Vertical Traffic Light",
            14: "Railroad Crossing Light",
            15: "Railroad Crossing Sign",
            16: "Interstate Route",
            17: "Overhead Directions",
            18: "Street Name",
            19: "Bridge Height",
            20: "Lane Ends",
            21: "Freeway Ends",
            22: "Rest Area",
            23: "Highway Exit",
            24: "Digital Sign",
            25: "No Turns",
            26: "No Left Turn",
            27: "No Right Turn",
            28: "No Turn on Red",
            29: "Left and Right Turn Only",
            30: "Left and Straight Only",
            31: "Left Turn Only",
            32: "Left and U-Turn Only",
            33: "Left Straight and U-Turn Only",
            34: "Right and Straight Only",
            35: "Right Turn Only",
            36: "Roundabout Left and Straight Only",
            37: "Roundabout Left Only",
            38: "Roundabout Left Straight and U-Turn Only",
            39: "Roundabout Left Right and Straight Only",
            40: "Roundabout Right and Straight Only",
            41: "Roundabout Straight Only",
            42: "Straight Only",
            43: "U-Turn Only",
            44: "Keep Left",
            45: "Keep Right",
            46: "One Way Left",
            47: "One Way Right",
            48: "One Way Straight",
            49: "Circular Intersection",
            50: "Dead End",
            51: "Wrong Way",
            52: "Authorized Vehicle",
            53: "Incident Management",
            54: "Electronic Toll",
            55: "Other – Turn",
            56: "Other – Red – Regulatory",
            57: "Other – White – Regulatory",
            58: "Other – Black – Warning",
            59: "Other – Yellow – Warning",
            60: "Other – Blue – Information",
            61: "Other – Brown – Information",
            62: "Other – Green – Information",
            63: "Other – Orange – Temporary",
            64: "Other – Complementary",
            65: "Unassigned",
            66: "Maximum Speed Limit 5",
            67: "Maximum Speed Limit 10",
            68: "Maximum Speed Limit 15",
            69: "Maximum Speed Limit 20",
            70: "Maximum Speed Limit 25",
            71: "Maximum Speed Limit 30",
            72: "Maximum Speed Limit 35",
            73: "Maximum Speed Limit 40",
            74: "Maximum Speed Limit 45",
            75: "Maximum Speed Limit 50",
            76: "Maximum Speed Limit 55",
            77: "Maximum Speed Limit 60",
            78: "Maximum Speed Limit 65",
            79: "Maximum Speed Limit 70",
            80: "Maximum Speed Limit 75",
            81: "Maximum Speed Limit 80",
            82: "Maximum Speed Limit 85",
            83: "Maximum Speed Limit 90",
            84: "Maximum Speed Limit 95",
            85: "Maximum Speed Limit 100",
            86: "Maximum Speed Limit 105",
            87: "Maximum Speed Limit 110",
            88: "Maximum Speed Limit 115",
            89: "Maximum Speed Limit 120",
            90: "Maximum Speed Limit 125",
            91: "Maximum Speed Limit 130",
            92: "Minimum Speed Limit 5",
            93: "Minimum Speed Limit 10",
            94: "Minimum Speed Limit 15",
            95: "Minimum Speed Limit 20",
            96: "Minimum Speed Limit 25",
            97: "Minimum Speed Limit 30",
            98: "Minimum Speed Limit 35",
            99: "Minimum Speed Limit 40",
            100: "Minimum Speed Limit 45",
            101: "Minimum Speed Limit 50",
            102: "Minimum Speed Limit 55",
            103: "Minimum Speed Limit 60",
            104: "Minimum Speed Limit 65",
            105: "Minimum Speed Limit 70",
            106: "Minimum Speed Limit 75",
            107: "Minimum Speed Limit 80",
            108: "Minimum Speed Limit 85",
            109: "Minimum Speed Limit 90",
            110: "Minimum Speed Limit 95",
            111: "Minimum Speed Limit 100",
            112: "Minimum Speed Limit 105",
            113: "Minimum Speed Limit 110",
            114: "Minimum Speed Limit 115",
            115: "Minimum Speed Limit 120",
            116: "Minimum Speed Limit 125",
            117: "Minimum Speed Limit 130",
            118: "Truck Speed Limit 5",
            119: "Truck Speed Limit 10",
            120: "Truck Speed Limit 15",
            121: "Truck Speed Limit 20",
            122: "Truck Speed Limit 25",
            123: "Truck Speed Limit 30",
            124: "Truck Speed Limit 35",
            125: "Truck Speed Limit 40",
            126: "Truck Speed Limit 45",
            127: "Truck Speed Limit 50",
            128: "Truck Speed Limit 55",
            129: "Truck Speed Limit 60",
            130: "Truck Speed Limit 65",
            131: "Truck Speed Limit 70",
            132: "Truck Speed Limit 75",
            133: "Truck Speed Limit 80",
            134: "Truck Speed Limit 85",
            135: "Truck Speed Limit 90",
            136: "Truck Speed Limit 95",
            137: "Truck Speed Limit 100",
            138: "Truck Speed Limit 105",
            139: "Truck Speed Limit 110",
            140: "Truck Speed Limit 115",
            141: "Truck Speed Limit 120",
            142: "Truck Speed Limit 125",
            143: "Truck Speed Limit 130",
            144: "Night Speed Limit 5",
            145: "Night Speed Limit 10",
            146: "Night Speed Limit 15",
            147: "Night Speed Limit 20",
            148: "Night Speed Limit 25",
            149: "Night Speed Limit 30",
            150: "Night Speed Limit 35",
            151: "Night Speed Limit 40",
            152: "Night Speed Limit 45",
            153: "Night Speed Limit 50",
            154: "Night Speed Limit 55",
            155: "Night Speed Limit 60",
            156: "Night Speed Limit 65",
            157: "Night Speed Limit 70",
            158: "Night Speed Limit 75",
            159: "Night Speed Limit 80",
            160: "Night Speed Limit 85",
            161: "Night Speed Limit 90",
            162: "Night Speed Limit 95",
            163: "Night Speed Limit 100",
            164: "Night Speed Limit 105",
            165: "Night Speed Limit 110",
            166: "Night Speed Limit 115",
            167: "Night Speed Limit 120",
            168: "Night Speed Limit 125",
            169: "Night Speed Limit 130",
            170: "Warning Speed Limit 5",
            171: "Warning Speed Limit 10",
            172: "Warning Speed Limit 15",
            173: "Warning Speed Limit 20",
            174: "Warning Speed Limit 25",
            175: "Warning Speed Limit 30",
            176: "Warning Speed Limit 35",
            177: "Warning Speed Limit 40",
            178: "Warning Speed Limit 45",
            179: "Warning Speed Limit 50",
            180: "Warning Speed Limit 55",
            181: "Warning Speed Limit 60",
            182: "Warning Speed Limit 65",
            183: "Warning Speed Limit 70",
            184: "Warning Speed Limit 75",
            185: "Warning Speed Limit 80",
            186: "Warning Speed Limit 85",
            187: "Warning Speed Limit 90",
            188: "Warning Speed Limit 95",
            189: "Warning Speed Limit 100",
            190: "Warning Speed Limit 105",
            191: "Warning Speed Limit 110",
            192: "Warning Speed Limit 115",
            193: "Warning Speed Limit 120",
            194: "Warning Speed Limit 125",
            195: "Warning Speed Limit 130"
        }
        self.sign_shape = {
            0: 'Rectangular',
            1: 'Circular',
            2: 'Triangle Point Up',
            3: 'Triangle Point Down',
            4: 'Square',
            5: 'Shield',
            6: 'Diamond',
            7: 'Polygonal',
            8: 'Compound',
            9: 'Crossbuck',
            10: 'Other'
        }
        self.pavement_marking_type = {
            1: 'Left and Right Arrow',
            2: 'Left and Straight Arrow',
            3: 'Left Arrow',
            4: 'Left and U - Turn Arrow',
            5: 'Left Right and Straight Arrow',
            6: 'Left Straight and U - Turn Arrow',
            7: 'Merge Arrow Left',
            8: 'Merge Arrow Right',
            9: 'Right and Straight Arrow',
            10: 'Right Arrow',
            11: 'Roundabout Left and Straight Arrow',
            12: 'Roundabout Left Arrow',
            13: 'Roundabout Left Right and Straight Arrow',
            14: 'Roundabout Left Straight and U - Turn Arrow',
            15: 'Roundabout Right and Straight Arrow',
            16: 'Roundabout Straight Arrow',
            17: 'Straight Arrow',
            18: 'U - Turn Arrow',
            19: 'Lane Number',
            20: 'Speed - 005',
            21: 'Speed - 010',
            22: 'Speed - 015',
            23: 'Speed - 020',
            24: 'Speed - 025',
            25: 'Speed - 030',
            26: 'Speed - 035',
            27: 'Speed - 040',
            28: 'Speed - 045',
            29: 'Speed - 050',
            30: 'Speed - 055',
            31: 'Speed - 060',
            32: 'Speed - 065',
            33: 'Speed - 070',
            34: 'Speed - 075',
            35: 'Speed - 080',
            36: 'Speed - 085',
            37: 'Speed - 090',
            38: 'Speed - 095',
            39: 'Speed - 100',
            40: 'Speed - 105',
            41: 'Speed - 110',
            42: 'Speed - 115',
            43: 'Speed - 120',
            44: 'Speed - 125',
            45: 'Speed - 130',
            46: 'Toll Speed',
            47: 'Bicycle',
            48: 'Express Toll',
            49: 'HOV Diamond',
            50: 'OK',
            51: 'Road Shield',
            52: 'RXR',
            53: 'Yield Triangles',
            54: 'AHEAD',
            55: 'BELT',
            56: 'BIKE',
            57: 'BR',
            58: 'BRIDGE',
            59: 'BUS',
            60: 'BUSES',
            61: 'CANADA',
            62: 'CAR',
            63: 'CARS',
            64: 'CASH',
            65: 'CLEAR',
            66: 'CRUISE',
            67: 'EB',
            68: 'EXIT',
            69: 'E - Z',
            70: 'FASTRAK',
            71: 'FWY',
            72: 'HWY',
            73: 'KEEP',
            74: 'LANE',
            75: 'LANES',
            76: 'LOW',
            77: 'MERGE',
            78: 'MPH',
            79: 'NB',
            80: 'NO',
            81: 'NORTH',
            82: 'ONLY',
            83: 'PASS',
            84: 'PED',
            85: 'PKWY',
            86: 'POOL',
            87: 'SB',
            88: 'SCHOOL',
            89: 'SIGNAL',
            90: 'SLOW',
            91: 'SOUTH',
            92: 'STOP',
            93: 'SUN',
            94: 'TO',
            95: 'TRUCK',
            96: 'TRUCKS',
            97: 'WB',
            98: 'X - ING',
            99: 'YIELD',
            100: 'Other'
        }
        self.regulatory_traffic_device_type = {
            0: ('red', 'Single Light Red'),
            1: ('yellow', 'Single Light Yellow'),
            2: ('lime', 'Three Light Horizontal'),
            3: ('green', 'Three Light Vertical'),
            4: ('navy', '4 + Light Vertical'),
            5: ('orange', '4 + Light Horizontal'),
            6: ('darkRed', 'Stop Sign'),
            7: ('darkYellow', 'Yield Sign'),
            8: ('pink', 'Other')
        }

        self.sd_hd_direction = {
            -1: 'backwards',
            1: 'forwards'
        }

    def is_udbx_db(self):
        query = '''SELECT *
                   FROM pg_catalog.pg_namespace
                   WHERE nspname = %s'''
        response = make_query(self.conn, query, ('ushr_format',))
        if len(response) == 0:
            return False
        else:
            return True

    def query_udbx_segment(self, segment_id):
        query = f'''with left_edge as (
                                        select road_segment.road_segment_id, road_type, number_of_lanes,
                                       	st_makeline(array_agg(left_edge_pts.position order by road_edge_point_sequence_index)) as left_edge_line,
										max(road_edge_point_sequence_index) as max_index
                                        from ushr_format.road_segment 
                                        join ushr_format.road_edge_points left_edge_pts on left_edge_pts.road_segment_id = road_segment.road_segment_id 
										where road_segment.road_segment_id = %s
										and left_edge_pts.road_edge_side = false										
                                        group by road_segment.road_segment_id
                                    ),
									road_edge as (									
                                    select left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line,
									st_makeline(array_agg(right_edge_pts.position order by road_edge_point_sequence_index desc)) as right_edge_line
                                    from left_edge
									join ushr_format.road_edge_points right_edge_pts on right_edge_pts.road_segment_id = left_edge.road_segment_id
									where right_edge_pts.road_edge_side = true
									group by left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line
									),
									segment_boundary_lines as (									
									select *, 
									st_makeline(array[ST_PointN(right_edge_line, -1), ST_PointN(left_edge_line, 1)]) as start_boundary_line, 
									st_makeline(array[ST_PointN(left_edge_line, -1), ST_PointN(right_edge_line, 1)]) as end_boundary_line 
									from road_edge
									)
									select road_segment_id, road_type, number_of_lanes,
									st_astext(st_makepolygon(st_makeline(array[left_edge_line, end_boundary_line, right_edge_line, start_boundary_line]))) as boundary_line
									from segment_boundary_lines
									'''

        response = make_query(self.conn, query, (segment_id,))
        if len(response) == 0:
            return 1
        row = response[0]
        segment_id = row[0]
        geom_wkt = row[3]

        layers = construct_layer(f'{segment_id}', 'segment_id', geom_wkt, [segment_id])

        return layers

    def query_udbx_sign(self, sign_id):
        query = '''select st_astext(centroid_position) from ushr_format.signs
                    where sign_id = %s'''
        response = make_query(self.conn, query, (sign_id,))
        if len(response) == 0:
            return 1
        for row in response:
            centroid = row[0]
            layers = construct_layer(f'{sign_id}', 'sign_id', centroid, [sign_id], geom_type='PointZ')
            return layers

    def query_intersection(self, intersection_id):
        query = '''select st_astext(geometry) from ushr_format.intersection
                            where intersection_id = %s'''
        response = make_query(self.conn, query, (intersection_id,))
        if len(response) == 0:
            return 1
        for row in response:
            poly = row[0]
            layers = construct_layer(f'{intersection_id}', 'intersection_id', poly, [intersection_id], geom_type='PolygonZ')
            return layers

    def query_pavement_marking(self, pm_id):
        query = '''select st_astext(pavement_marking_position) from ushr_format.pavement_markings
                            where pavement_marking_id = %s'''
        response = make_query(self.conn, query, (pm_id,))
        if len(response) == 0:
            return 1
        for row in response:
            poly = row[0]
            layers = construct_layer(f'{pm_id}', 'pm_id', poly, [pm_id], geom_type='PolygonZ')
            return layers

    def query_lane_geom_feat_in_extent(self):
        query = f'''
                    with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    )
                    	select lane_center_points.*, st_astext(position), st_z(position)
						from segments_in_extent
                    	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segment_id'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('xs_id', QVariant.Int), QgsField('curvature', QVariant.Double),
                      QgsField('heading', QVariant.Double), QgsField('cross_slope', QVariant.Double),
                      QgsField('along_slope', QVariant.Double), QgsField('lane_width', QVariant.Double),
                      QgsField('abs_curvature', QVariant.Double), QgsField('elevation', QVariant.Double)]
        feature_list = []
        abs_curvature_list = []
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            xs_id = row[2]
            curvature = row[3]
            heading = row[4]
            cross_slope = row[5]
            along_slope = row[6]
            lane_width = row[7]
            geom = row[9]
            elevation = row[10]
            abs_curvature = abs(curvature)
            abs_curvature_list.append(abs_curvature)

            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, lane_number, xs_id, curvature, heading, cross_slope, along_slope,
                             lane_width, abs_curvature, elevation])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'udbx_lane_geom_feat',
                                      feature_list, qgs_fields)
        if len(abs_curvature_list) > 0:
            v_layer = apply_graduated_symbol(v_layer, 'abs_curvature')
        return v_layer

    # The attributes in Lanes represent the start values of that lane
    # lane_add_remove_type, accelerating_lane, decelerating_lane only get attributed at the start
    #   (only in lanes table not in lane_attributes table)
    def query_lanes_in_extent(self, lane_attr_type):
        query = f'''
                    with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    lane_start_att as (
                    	select lanes.road_segment_id, lanes.lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id, 
						lane_add_remove_type, accelerating_lane, decelerating_lane, lane_type_attribute, lane_length,						
                    	array_agg(st_astext(position) order by lane_point_sequence_index) as geoms,
                    	max(lane_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.segment_id
                    	join ushr_format.lanes on lanes.road_segment_id = lane_center_points.road_segment_id
                    	where lane_center_points.lane_number = lanes.lane_number
                    	group by lanes.road_segment_id, lanes.lane_number
                    )
                    select lane_start_att.road_segment_id, lane_start_att.lane_number, 
					left_lane_line_ordinal_id, right_lane_line_ordinal_id, 
					lane_add_remove_type, accelerating_lane, decelerating_lane, lane_type_attribute, lane_length,
                    max_index, geoms, 
                    array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
					array_agg(lane_attributes.lane_attribute_type order by lane_point_sequence_index) as attr_types,
					array_agg(lane_attributes.lane_attribute_value order by lane_point_sequence_index) as attr_vals
                    from lane_start_att
                    left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                    	and lane_start_att.lane_number = lane_attributes.lane_number       	
                    	and lane_attributes.lane_attribute_type = %s					
                    group by lane_start_att.road_segment_id, lane_start_att.lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id, 
					lane_add_remove_type, accelerating_lane, decelerating_lane, lane_type_attribute, lane_length,
                    max_index, geoms'''
        response = make_query(self.conn, query, (lane_attr_type,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('lane_number', QVariant.Int), QgsField('length', QVariant.Int),
                      QgsField('lane_type', QVariant.String),
                      QgsField('left_lane_line_ordinal_id', QVariant.Int),
                      QgsField('right_lane_line_ordinal_id', QVariant.Int),
                      QgsField('lane_add_remove_type', QVariant.String),
                      QgsField('accelerating_lane', QVariant.String),
                      QgsField('decelerating_lane', QVariant.String),
                      ]
        feature_list = []
        lane_type_codes_list = []
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            left_lane_line_ordinal_id = row[2]
            right_lane_line_ordinal_id = row[3]
            lane_add_remove_type = row[4]
            accelerating_lane = row[5]
            decelerating_lane = row[6]
            lane_type_code = row[7]  # bitmask
            lane_length = row[8]
            max_index = row[9]
            point_geoms = row[10]
            change_inds = row[11]
            change_attr_types = row[12]
            change_attr_vals = row[13]

            # generate a list of all the bit-masks that a value contains, i.e. 5 -> 1 + 4
            # 5/16=0, 5/8=0, 5/4=1, 1/2=0, 1/1=1 ----> 4, 1
            # lane type
            lane_type_bitmasks = get_bitmask_array(lane_type_code)
            lane_type_list = []
            for item in lane_type_bitmasks:
                lane_type_list.append(self.lane_type[item][1])

            if lane_type_bitmasks not in lane_type_codes_list:
                lane_type_codes_list.append(lane_type_bitmasks)

            lane_attr_dict = {}
            seq_ind = 0
            lane_attr_dict[seq_ind] = {'lane_type': lane_type_list}

            if change_inds[0] is not None:
                for i, seq_ind in enumerate(change_inds):
                    change_attr_type = change_attr_types[i]
                    change_attr_val = change_attr_vals[i]
                    if self.lane_att_type[change_attr_type] == 'lane_type':
                        lane_type_list = []
                        lane_type_code = change_attr_val
                        lane_type_bitmasks = get_bitmask_array(lane_type_code)
                        for item in lane_type_bitmasks:
                            lane_type_list.append(self.lane_type[item][1])
                        if lane_type_bitmasks not in lane_type_codes_list:
                            lane_type_codes_list.append(lane_type_bitmasks)
                    lane_attr_dict[seq_ind] = {'lane_type': lane_type_list}

            point_geom_list = []
            lane_type = lane_attr_dict[0]['lane_type']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in lane_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    point_geom_list.append(loads(point_geom_wkt))
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    lane_geom = LineString(point_geom_list).wkt
                    lane_qgsgeom = g.fromWkt(lane_geom)
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    f.setAttributes([segment_id, lane_number, lane_length, f'{lane_type}', left_lane_line_ordinal_id,
                                     right_lane_line_ordinal_id, self.lane_add_remove_type[lane_add_remove_type],
                                     f'{accelerating_lane}', f'{decelerating_lane}'])
                    feature_list.append(f)
                    # clear the point geom list
                    point_geom_list = [loads(point_geom_wkt)]
                    lane_type = lane_attr_dict[i]['lane_type']

            max_change_ind = max(list(lane_attr_dict.keys()))
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            lane_type = lane_attr_dict[max_change_ind]['lane_type']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            lane_geom = LineString(point_geom_list).wkt
            lane_qgsgeom = g.fromWkt(lane_geom)
            f = QgsFeature()
            f.setGeometry(lane_qgsgeom)
            f.setAttributes([segment_id, lane_number, lane_length, f'{lane_type}', left_lane_line_ordinal_id,
                             right_lane_line_ordinal_id, self.lane_add_remove_type[lane_add_remove_type],
                             f'{accelerating_lane}', f'{decelerating_lane}'])
            feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_lane',
                                            feature_list, qgs_fields)
        feature_dict = {}

        for lane_type_codes in lane_type_codes_list:
            # blend colors
            color_list = []
            lane_types = []
            for lane_type_code in lane_type_codes:
                color_list.append(self.lane_type[lane_type_code][0])
                lane_types.append(self.lane_type[lane_type_code][1])
            color = blend_colors(color_list)
            feature_dict[f'{lane_types}'] = (color, f'{lane_types}')
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='lane_type', width=1.5)
        return v_layer

    def query_lane_attributes_in_extent(self, lane_attr_type):

        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    lane_start_att as (
                    	select lanes.road_segment_id, lanes.lane_number, {self.lane_att_type[lane_attr_type]}_attribute,
                    	array_agg(st_astext(position) order by lane_point_sequence_index) as geoms,
                    	max(lane_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.segment_id
                    	join ushr_format.lanes on lanes.road_segment_id = segments_in_extent.segment_id
                    	where lane_center_points.lane_number = lanes.lane_number
                    	group by lanes.road_segment_id, lanes.lane_number
                    )
                    select lane_start_att.road_segment_id, lane_start_att.lane_number, {self.lane_att_type[lane_attr_type]}_attribute, max_index, geoms,
                    array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
                    array_agg(lane_attribute_value order by lane_point_sequence_index) as vals
                    from lane_start_att
                    left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                    	and lane_start_att.lane_number = lane_attributes.lane_number
                    	and lane_attributes.lane_attribute_type = {lane_attr_type}
                    group by lane_start_att.road_segment_id, lane_start_att.lane_number, {self.lane_att_type[lane_attr_type]}_attribute, max_index, geoms'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        if lane_attr_type == 1:
            value_type = QVariant.Int
        else:
            value_type = QVariant.String
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('index_range', QVariant.String),
                      QgsField(self.lane_att_type[lane_attr_type], value_type)
                      ]
        feature_list = []
        lane_attr_val_set = set([])
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            initial_attr_val = row[2]
            max_index = row[3]
            point_geoms = row[4]
            change_inds = row[5]
            change_attr_vals = row[6]

            lane_attr_dict = {}
            seq_ind = 0

            # generate a list of all the bit-masks that a value contains, i.e. 5 -> 1 + 4
            # 5/16=0, 5/8=0, 5/4=1, 1/2=0, 1/1=1 ----> 4, 1
            # crossing type
            if self.lane_att_type[lane_attr_type] == 'crossing_type':
                lane_attr_val_bitmasks = get_bitmask_array(initial_attr_val)
                lane_attr_val_list = []
                for val in lane_attr_val_bitmasks:
                    lane_attr_val_list.append(val)
                    lane_attr_val_set.add(val)
                lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val_list}
            elif self.lane_att_type[lane_attr_type] in ('speed_limit', 'left_change_allowed', 'right_change_allowed'):
                lane_attr_val = initial_attr_val
                lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val}
                lane_attr_val_set.add(lane_attr_val)
            else:
                continue

            if change_inds[0] is not None:
                for i, seq_ind in enumerate(change_inds):
                    change_attr_val = change_attr_vals[i]
                    if self.lane_att_type[lane_attr_type] == 'crossing_type':
                        lane_attr_val_bitmasks = get_bitmask_array(change_attr_val)
                        lane_attr_val_list = []
                        for val in lane_attr_val_bitmasks:
                            lane_attr_val_list.append(val)
                            lane_attr_val_set.add(val)
                        lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val_list}
                    elif self.lane_att_type[lane_attr_type] in ('speed_limit',
                                                                'left_change_allowed', 'right_change_allowed'):
                        # for left_change_allowed and right_change_allowed, the initial value is stored as Boolean,
                        # the change value is stored as integer, 0 = False, 1 = True
                        if self.lane_att_type[lane_attr_type] in ('left_change_allowed', 'right_change_allowed'):
                            if change_attr_val == 0:
                                change_attr_val = False
                            else:
                                change_attr_val = True
                        lane_attr_val = change_attr_val
                        lane_attr_dict[seq_ind] = {'lane_attr_val': lane_attr_val}
                        lane_attr_val_set.add(lane_attr_val)
                    else:
                        continue

            # for crossing, if there are multiple crossings at one place, plot them separately
            ind_list = []
            point_geom_list = []
            lane_attr_val = lane_attr_dict[0]['lane_attr_val']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in lane_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    # point_geom_list.append(loads(point_geom_wkt))
                    ind_list.append(i)
                    point_geom_list.append(loads(point_geom_wkt))
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'{[min(ind_list), max(ind_list)]}'
                    length = max(ind_list) - min(ind_list)
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    lane_geom = LineString(point_geom_list).wkt
                    lane_qgsgeom = g.fromWkt(lane_geom)
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    if self.lane_att_type[lane_attr_type] == 'crossing_type':
                        for val in lane_attr_val:
                            f = QgsFeature()
                            f.setGeometry(lane_qgsgeom)
                            f.setAttributes([segment_id, lane_number, length, index_range, self.crossing_type[val][1]])
                            feature_list.append(f)
                    elif self.lane_att_type[lane_attr_type] in ('speed_limit',
                                                                'left_change_allowed', 'right_change_allowed'):
                        if self.lane_att_type[lane_attr_type] in ('left_change_allowed', 'right_change_allowed'):
                            lane_attr_val = f'{lane_attr_val}'
                        f.setAttributes([segment_id, lane_number, length, index_range, lane_attr_val])
                        feature_list.append(f)
                    else:
                        # clear the point geom list
                        ind_list = [i]
                        point_geom_list = [loads(point_geom_wkt)]
                        lane_attr_val = lane_attr_dict[i]['lane_attr_val']
                        continue

                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    lane_attr_val = lane_attr_dict[i]['lane_attr_val']

            max_change_ind = max(list(lane_attr_dict.keys()))
            index_range = f'{[max_change_ind, max_index]}'
            length = max_index - max_change_ind
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            lane_attr_val = lane_attr_dict[max_change_ind]['lane_attr_val']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            lane_geom = LineString(point_geom_list).wkt
            lane_qgsgeom = g.fromWkt(lane_geom)
            f = QgsFeature()
            f.setGeometry(lane_qgsgeom)
            if self.lane_att_type[lane_attr_type] == 'crossing_type':
                for val in lane_attr_val:
                    f = QgsFeature()
                    f.setGeometry(lane_qgsgeom)
                    f.setAttributes([segment_id, lane_number, length, index_range, self.crossing_type[val][1]])
                    feature_list.append(f)
            elif self.lane_att_type[lane_attr_type] in ('speed_limit',
                                                        'left_change_allowed', 'right_change_allowed'):
                if self.lane_att_type[lane_attr_type] in ('left_change_allowed', 'right_change_allowed'):
                    lane_attr_val = f'{lane_attr_val}'
                f.setAttributes([segment_id, lane_number, length, index_range, lane_attr_val])
                feature_list.append(f)
            else:
                continue

        v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', f'udbx_lane_att_{self.lane_att_type[lane_attr_type]}',
                                            feature_list, qgs_fields)

        feature_dict = {}
        lane_attribute = self.lane_att_type[lane_attr_type]
        color_selector = get_colors(len(lane_attr_val_set))
        sel_type_dict = None
        hsv = False
        if self.lane_att_type[lane_attr_type] in ('left_change_allowed', 'right_change_allowed'):
            sel_type_dict = self.lane_change_allowed
        elif self.lane_att_type[lane_attr_type] == 'crossing_type':
            sel_type_dict = self.crossing_type
        elif self.lane_att_type[lane_attr_type] == 'regulatory_traffic_device':
            sel_type_dict = self.regulatory_traffic_device_type
        else:
            hsv = True
        for i, lane_attr_val in enumerate(sorted(lane_attr_val_set)):
            if lane_attribute == 'speed_limit':
                label = f'{lane_attr_val}'
                color = QColor(color_selector[i])
            else:
                color, label = sel_type_dict[lane_attr_val]
            feature_dict[label] = (color, label)
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field=lane_attribute, width=1.5, hsv=hsv)

        return v_layer

    # new table functional authority is added
    def query_functional_authority_in_extent(self):

        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
							lane_pts as (
							select segments_in_extent.segment_id, lane_number,
							max(lane_center_points.lane_point_sequence_index) as max_index, 
							array_agg(st_astext(position) order by lane_center_points.lane_point_sequence_index) as geoms
                            from segments_in_extent
							join ushr_format.lane_center_points on lane_center_points.road_segment_id = segments_in_extent.segment_id                                               	
                            group by segments_in_extent.segment_id, lane_center_points.lane_number
							)						
                            select functional_authority.road_segment_id, functional_authority.lane_number, max_index, geoms, 
							array_agg(lane_point_sequence_index order by lane_point_sequence_index) as inds,
							array_agg(functional_authority_attribute order by lane_point_sequence_index) as vals
                            from lane_pts
							join ushr_format.functional_authority on functional_authority.road_segment_id = lane_pts.segment_id
                            	and functional_authority.lane_number = lane_pts.lane_number                            	
                            group by functional_authority.road_segment_id, functional_authority.lane_number, max_index, geoms
'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('index_range', QVariant.String),
                      QgsField('functional_authority', QVariant.String)
                      ]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            lane_number = row[1]
            max_index = row[2]
            geoms = row[3]  # all the points on the lane
            inds = row[4]
            vals = row[5]

            # process the functional_authority on a single lane each time
            fa_dict = {}
            fa_ind = 0  # one index for each functional authority stretch

            for i, ind in enumerate(inds):
                val = vals[i]
                if val == 0:
                    continue
                if val not in type_list:
                    type_list.append(val)
                if i + 1 < len(inds):
                    fa_dict = {fa_ind: {'type': val, 'geom': geoms[ind:inds[i + 1] + 1],
                                        'range': [ind, inds[i + 1]], 'length': inds[i + 1] - ind}}
                    fa_ind += 1
                else:
                    fa_dict = {fa_ind: {'type': val, 'geom': geoms[ind:max_index + 1],
                                        'range': [ind, max_index], 'length': max_index - ind}}
                    break

            for ind in fa_dict:
                if len(fa_dict[ind]['geom']) == 1:
                    fa_dict[ind]['geom'].append(fa_dict[ind]['geom'][0])
                line_geom = LineString([loads(point_geom) for point_geom in fa_dict[ind]['geom']]).wkt
                line = g.fromWkt(line_geom)
                f = QgsFeature()
                f.setGeometry(line)
                fa_type = self.functional_authority[fa_dict[ind]['type']][1]
                f.setAttributes([segment_id, lane_number, fa_dict[ind]['length'],
                                 f'{fa_dict[ind]["range"]}', fa_type])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                      f'udbx_functional_authority',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for fa_type in type_list:
            feature_dict[self.functional_authority[fa_type][1]] = self.functional_authority[fa_type]
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='functional_authority', width=1.5)
        return v_layer

    def query_lane_connection_node_in_extent(self):

        query = f'''with lane_conn as (
	select lane_connections.incident_road_segment_id, incident_lane_number, 
	lane_connections.emergent_road_segment_id, emergent_lane_number, node_position
	from ushr_format.lane_connection_nodes
	join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id	
	and st_within(node_position, 
              	  ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
),
incident_lane as (
select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, node_position, 
max(lcp_incident.lane_point_sequence_index) - 1 as incident_lane_last_to_second_index
from lane_conn
join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
where lcp_incident.lane_number = incident_lane_number
group by incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, node_position
),
incident_emergent_pts as (
select incident_lane.*, lcp_emergent.position as emergent_second_pt, lcp_incident.position as incident_lane_last_to_second_pt
from incident_lane
join ushr_format.lane_center_points lcp_emergent on lcp_emergent.road_segment_id = emergent_road_segment_id
join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
where lcp_incident.lane_number = incident_lane_number
and lcp_emergent.lane_number = emergent_lane_number
and lcp_emergent.lane_point_sequence_index = 1
and lcp_incident.lane_point_sequence_index = incident_lane_last_to_second_index
)
select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, st_astext(node_position),
st_astext(st_makeline(array[incident_lane_last_to_second_pt, node_position, emergent_second_pt]))
from incident_emergent_pts
'''
        response_connection = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('incident_road_segment_id', QVariant.Int),
                      QgsField('incident_lane_number', QVariant.Int),
                      QgsField('emergent_road_segment_id', QVariant.Int),
                      QgsField('emergent_lane_number', QVariant.Int),
                      QgsField('node_type', QVariant.String)
                      ]

        node_feature_list = []
        line_feature_list = []

        query = f'''with lane_conn_end as (
	select lane_connections.incident_road_segment_id, incident_lane_number, lane_connections.emergent_road_segment_id, emergent_lane_number, node_position
	from ushr_format.lane_connection_nodes
	join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id	
	and st_within(node_position, 
              	  ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
	and emergent_road_segment_id = 0
),
incident_lane as (
select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, node_position, 
max(lcp_incident.lane_point_sequence_index) - 1 as incident_lane_last_to_second_index
from lane_conn_end
join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
where lcp_incident.lane_number = incident_lane_number
group by incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, node_position
),
incident_pts as (
select incident_lane.*, lcp_incident.position as incident_lane_last_to_second_pt
from incident_lane
join ushr_format.lane_center_points lcp_incident on lcp_incident.road_segment_id = incident_road_segment_id
where lcp_incident.lane_number = incident_lane_number
and lcp_incident.lane_point_sequence_index = incident_lane_last_to_second_index
)
select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, st_astext(node_position),
st_astext(st_makeline(array[incident_lane_last_to_second_pt, node_position]))
from incident_pts'''
        response_end_node = make_query(self.conn, query, None)

        query = f'''with lane_conn_start as (
	select  lane_connections.incident_road_segment_id, incident_lane_number, lane_connections.emergent_road_segment_id, emergent_lane_number, node_position
	from ushr_format.lane_connection_nodes
	join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id	
	and st_within(node_position, 
              	  ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
	and incident_road_segment_id = 0
),
emergent_pts as (
select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, node_position, lcp_emergent.position as emergent_second_pt
from lane_conn_start
join ushr_format.lane_center_points lcp_emergent on lcp_emergent.road_segment_id = emergent_road_segment_id
where lcp_emergent.lane_number = emergent_lane_number
and lcp_emergent.lane_point_sequence_index = 1
)
select incident_road_segment_id, incident_lane_number, emergent_road_segment_id, emergent_lane_number, st_astext(node_position),
st_astext(st_makeline(array[node_position, emergent_second_pt]))
from emergent_pts'''

        response_start_node = make_query(self.conn, query, None)

        node_type_list = []
        for row in response_connection + response_end_node + response_start_node:
            incident_road_segment_id = row[0]
            incident_lane_number = row[1]
            emergent_road_segment_id = row[2]
            emergent_lane_number = row[3]
            node_geom = row[4]
            # arrow_geom is a line formed by: last-to-second point of the incident lane,
            # connection node and second point of the emergent lane
            line_geom = row[5]

            if incident_road_segment_id == 0:
                node_type = 'start'
            elif emergent_road_segment_id == 0:
                node_type = 'end'
            else:
                node_type = 'transition'

            if node_type not in node_type_list:
                node_type_list.append(node_type)

            qgs_node_geom = g.fromWkt(node_geom)
            qgs_line_geom = g.fromWkt(line_geom)

            f_node = QgsFeature()
            f_node.setGeometry(qgs_node_geom)
            f_node.setAttributes([incident_road_segment_id, incident_lane_number,
                                  emergent_road_segment_id, emergent_lane_number, node_type])
            node_feature_list.append(f_node)

            f_line = QgsFeature()
            f_line.setGeometry(qgs_line_geom)
            f_line.setAttributes([incident_road_segment_id, incident_lane_number,
                                  emergent_road_segment_id, emergent_lane_number, node_type])
            line_feature_list.append(f_line)

        # start_node: green
        # end_node: red
        # transition_node: yellow
        rules = ()
        colors = {'start': 'lime', 'end': 'red', 'transition': 'yellow'}
        for node_type in node_type_list:
            actual_width = 0.5
            label = f'{node_type}'
            exp = f'''node_type = \'{node_type}\''''
            line_style = 'solid'
            color = colors[node_type]
            rules += ((label, exp, line_style, color, actual_width),)

        node_v_layer = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', 'udbx_lane_connection_node',
                                                 node_feature_list, qgs_fields)

        feature_dict = {}
        for node_type in node_type_list:
            feature_dict[node_type] = (colors[node_type], node_type)
        node_v_layer = apply_categorized_symbol(feature_dict, node_v_layer, field='node_type', point=True)

        arrow_v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_lane_connection',
                                                  line_feature_list, qgs_fields)
        arrow_v_layer = setLineLayerStyleToArrow(arrow_v_layer)

        return node_v_layer, arrow_v_layer

    def query_lane_lines_in_extent(self):
        #   line_type, line_color, line_width
        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    line_start_att as (
                    	select lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id, 
						lane_line_type_attribute, lane_line_color_attribute, lane_line_width_attribute, 
						reflective_markings_attribute, pavement_striping_present_attribute,						
                    	array_agg(st_astext(position) order by lane_line_point_sequence_index) as geoms,
                    	max(lane_line_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.lane_line_points on lane_line_points.road_segment_id = segments_in_extent.segment_id
                    	join ushr_format.lane_lines on lane_lines.road_segment_id = lane_line_points.road_segment_id
                    	where lane_line_points.lane_line_ordinal_id = lane_lines.lane_line_ordinal_id
                    	group by lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id
                    )
                    select line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, 
                    max_index, geoms, lane_line_type_attribute, lane_line_color_attribute, lane_line_width_attribute,					
                    array_agg(lane_line_attributes.lane_line_point_sequence_index order by lane_line_point_sequence_index) as inds, 
					array_agg(lane_line_attribute_type order by lane_line_point_sequence_index) as attr_types,
                    array_agg(lane_line_attribute_value order by lane_line_point_sequence_index) as attr_vals
                    from line_start_att
                    left join ushr_format.lane_line_attributes on line_start_att.road_segment_id = lane_line_attributes.road_segment_id
                    	and line_start_att.lane_line_ordinal_id = lane_line_attributes.lane_line_ordinal_id    
                    	and lane_line_attribute_type in (0, 1, 2, 3)                	
                    group by line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, max_index, geoms, 
					lane_line_type_attribute, lane_line_color_attribute, lane_line_width_attribute
					'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('lane_line_ordinal_id', QVariant.Int),
                      QgsField('type', QVariant.String), QgsField('color', QVariant.String),
                      QgsField('width', QVariant.String)
                      ]
        feature_list = []
        line_attr_list = []
        for row in response:
            segment_id = row[0]
            lane_line_ordinal_id = row[1]
            max_index = row[2]
            point_geoms = row[3]
            initial_line_type = row[4]
            initial_line_color = row[5]
            initial_line_width = row[6]
            attr_inds = row[7]
            attr_types = row[8]
            attr_vals = row[9]

            line_attr_dict = {}
            seq_ind = 0
            line_attr_dict[seq_ind] = {'line_type': initial_line_type, 'line_color': initial_line_color,
                                       'line_width': initial_line_width}
            # maintain the attributes until there is a change
            line_type, line_color, line_width = initial_line_type, initial_line_color, initial_line_width
            # there is change
            if attr_inds[0] is not None:
                for i, seq_ind in enumerate(attr_inds):
                    attr_type = attr_types[i]
                    attr_val = attr_vals[i]
                    if self.line_att_type[attr_type] == 'line_type':
                        line_type = attr_val
                    if self.line_att_type[attr_type] == 'line_color':
                        line_color = attr_val
                    if self.line_att_type[attr_type] == 'line_width':
                        line_width = attr_val
                    line_attr_dict[seq_ind] = {'line_type': line_type, 'line_color': line_color,
                                               'line_width': line_width}
            for seq_ind in line_attr_dict:
                if line_attr_dict[seq_ind] not in line_attr_list:
                    line_attr_list.append(line_attr_dict[seq_ind])

            point_geom_list = []
            line_type = line_attr_dict[0]['line_type']
            line_color = line_attr_dict[0]['line_color']
            line_width = line_attr_dict[0]['line_width']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in line_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    point_geom_list.append(loads(point_geom_wkt))
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    line_geom = LineString(point_geom_list).wkt
                    line_qgsgeom = g.fromWkt(line_geom)
                    f = QgsFeature()
                    f.setGeometry(line_qgsgeom)
                    f.setAttributes([segment_id, lane_line_ordinal_id,
                                     self.line_type[line_type][1],
                                     self.line_color[line_color][1], self.line_width[line_width][1]])
                    feature_list.append(f)
                    # clear the point geom list
                    point_geom_list = [loads(point_geom_wkt)]
                    line_type = line_attr_dict[i]['line_type']
                    line_color = line_attr_dict[i]['line_color']
                    line_width = line_attr_dict[i]['line_width']

            max_change_ind = max(list(line_attr_dict.keys()))
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            line_type = line_attr_dict[max_change_ind]['line_type']
            line_color = line_attr_dict[max_change_ind]['line_color']
            line_width = line_attr_dict[max_change_ind]['line_width']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            line_geom = LineString(point_geom_list).wkt
            line_qgsgeom = g.fromWkt(line_geom)
            f = QgsFeature()
            f.setGeometry(line_qgsgeom)
            f.setAttributes([segment_id, lane_line_ordinal_id,
                             self.line_type[line_type][1],
                             self.line_color[line_color][1], self.line_width[line_width][1]])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_lane_line',
                                      feature_list, qgs_fields)

        # make rules
        rules = ()
        for line_attr in line_attr_list:
            line_type = line_attr['line_type']
            line_color = line_attr['line_color']
            line_width = line_attr['line_width']
            # self.main_win.push_message(f'line_width: {line_width}')
            layer_width = self.line_width[line_width][0] * 5
            label = f'{self.line_type[line_type][1]}'
            exp = f'''type = \'{self.line_type[line_type][1]}\' 
                                          and color = \'{self.line_color[line_color][1]}\' 
                                          and width = \'{self.line_width[line_width][1]}\''''
            line_style = self.line_type[line_type][0]
            color = self.line_color[line_color][0]
            rules += ((label, exp, line_style, color, layer_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)

        return v_layer

    # reflective_markings_attribute (3), pavement_striping_present_attribute (4)
    def query_lane_line_attributes_in_extent(self, line_att_type):

        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    line_start_att as (
                    	select lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id, {self.line_att_type[line_att_type]}_attribute,
                    	array_agg(st_astext(position) order by lane_line_point_sequence_index) as geoms,
                    	max(lane_line_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.lane_line_points on lane_line_points.road_segment_id = segments_in_extent.segment_id
                    	join ushr_format.lane_lines on lane_lines.road_segment_id = segments_in_extent.segment_id
                    	where lane_line_points.lane_line_ordinal_id = lane_lines.lane_line_ordinal_id
                    	group by lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id
                    )
                    select line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, 
                    {self.line_att_type[line_att_type]}_attribute, max_index, geoms,
                    array_agg(lane_line_attributes.lane_line_point_sequence_index order by lane_line_point_sequence_index) as inds, 
                    array_agg(lane_line_attribute_value order by lane_line_point_sequence_index) as vals
                    from line_start_att
                    left join ushr_format.lane_line_attributes on line_start_att.road_segment_id = lane_line_attributes.road_segment_id
                    	and line_start_att.lane_line_ordinal_id = lane_line_attributes.lane_line_ordinal_id
                    	and lane_line_attributes.lane_line_attribute_type = {line_att_type}
                    group by line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, {self.line_att_type[line_att_type]}_attribute, max_index, geoms'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_line_ordinal_id', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('index_range', QVariant.String),
                      QgsField(self.line_att_type[line_att_type], QVariant.String)
                      ]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            lane_line_ordinal_id = row[1]
            initial_attr_val = row[2]
            max_index = row[3]
            point_geoms = row[4]
            attr_inds = row[5]
            attr_vals = row[6]

            line_attr_dict = {}
            seq_ind = 0
            line_attr_dict[seq_ind] = {'line_attr_val': initial_attr_val}

            # there is change
            if attr_inds[0] is not None:
                for i, seq_ind in enumerate(attr_inds):
                    attr_val = attr_vals[i]
                    line_attr_dict[seq_ind] = {'line_attr_val': attr_val}

            for seq_ind in line_attr_dict:
                if line_attr_dict[seq_ind]['line_attr_val'] != 0 \
                        and line_attr_dict[seq_ind]['line_attr_val'] not in type_list:
                    type_list.append(line_attr_dict[seq_ind]['line_attr_val'])

            ind_list = []
            point_geom_list = []
            line_attr_val = line_attr_dict[0]['line_attr_val']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in line_attr_dict:
                    # the last point of the current piece is also the first point of next piece
                    ind_list.append(i)
                    point_geom_list.append(loads(point_geom_wkt))
                    if len(ind_list) == 1:
                        ind_list.insert(0, 0)
                    index_range = f'{[min(ind_list), max(ind_list)]}'
                    length = max(ind_list) - min(ind_list)
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    if line_att_type == 3:
                        line_attr = line_attr_val   # False/True
                        if not line_attr:
                            ind_list = [i]
                            point_geom_list = [loads(point_geom_wkt)]
                            line_attr_val = line_attr_dict[i]['line_attr_val']
                            continue
                        line_attr = f'{line_attr}'
                    elif line_att_type == 4:
                        if line_attr_val == 0:
                            ind_list = [i]
                            point_geom_list = [loads(point_geom_wkt)]
                            line_attr_val = line_attr_dict[i]['line_attr_val']
                            continue
                        line_attr = self.pavement_striping_present[line_attr_val][1]
                    else:
                        continue
                    # complete the geometry for the current type duration
                    line_geom = LineString(point_geom_list).wkt
                    line_qgsgeom = g.fromWkt(line_geom)
                    f = QgsFeature()
                    f.setGeometry(line_qgsgeom)
                    f.setAttributes([segment_id, lane_line_ordinal_id, length, index_range, line_attr])
                    feature_list.append(f)
                    # clear the point geom list
                    ind_list = [i]
                    point_geom_list = [loads(point_geom_wkt)]
                    line_attr_val = line_attr_dict[i]['line_attr_val']

            max_change_ind = max(list(line_attr_dict.keys()))
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            line_attr_val = line_attr_dict[max_change_ind]['line_attr_val']
            index_range = f'{[max_change_ind, max_index]}'
            length = max_index - max_change_ind
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            if line_att_type == 3:
                line_attr = line_attr_val  # False/True
                if not line_attr:
                    continue
                line_attr = f'{line_attr}'
            elif line_att_type == 4:
                if line_attr_val == 0:
                    continue
                line_attr = self.pavement_striping_present[line_attr_val][1]

            else:
                continue
            line_geom = LineString(point_geom_list).wkt
            line_qgsgeom = g.fromWkt(line_geom)
            f = QgsFeature()
            f.setGeometry(line_qgsgeom)
            f.setAttributes([segment_id, lane_line_ordinal_id, length, index_range, line_attr])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', f'udbx_line_attr_{self.line_att_type[line_att_type]}',
                                      feature_list, qgs_fields)
        feature_dict = {}
        if line_att_type == 3:
            sel_type_dict = {False: ('black', '0'), True: ('golden', '1')}
        elif line_att_type == 4:
            sel_type_dict = self.pavement_striping_present
        else:
            return
        for type_i in type_list:
            feature_dict[sel_type_dict[type_i][1]] = sel_type_dict[type_i]
        v_layer = apply_categorized_symbol(feature_dict, v_layer, field=self.line_att_type[line_att_type], width=1.5)
        return v_layer

    def query_road_segment_in_extent(self):
        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as road_segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as road_segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct road_segment_id from segments_in_extent_union
                    where road_segment_id != 0
                    ),
                    left_edge as (
                                        select road_segment.road_segment_id, road_type, number_of_lanes, 
                                       	st_makeline(array_agg(left_edge_pts.position order by road_edge_point_sequence_index)) as left_edge_line,
										max(road_edge_point_sequence_index) as max_index
                                        from segments_in_extent
                                        join ushr_format.road_segment on road_segment.road_segment_id = segments_in_extent.road_segment_id
                                        join ushr_format.road_edge_points left_edge_pts on left_edge_pts.road_segment_id = segments_in_extent.road_segment_id 
										where left_edge_pts.road_edge_side = false										
                                        group by road_segment.road_segment_id
                                    ),
									road_edge as (									
                                    select left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line,
									st_makeline(array_agg(right_edge_pts.position order by road_edge_point_sequence_index desc)) as right_edge_line
                                    from left_edge
									join ushr_format.road_edge_points right_edge_pts on right_edge_pts.road_segment_id = left_edge.road_segment_id
									where right_edge_pts.road_edge_side = true
									group by left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line
									),
									segment_boundary_lines as (									
									select *, 
									st_makeline(array[ST_PointN(right_edge_line, -1), ST_PointN(left_edge_line, 1)]) as start_boundary_line, 
									st_makeline(array[ST_PointN(left_edge_line, -1), ST_PointN(right_edge_line, 1)]) as end_boundary_line 
									from road_edge
									)
									select road_segment_id, road_type, number_of_lanes,
									st_astext(st_makepolygon(st_makeline(array[left_edge_line, end_boundary_line, right_edge_line, start_boundary_line]))) as boundary_line
									from segment_boundary_lines'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('road_type', QVariant.String),
                      QgsField('number_of_lanes', QVariant.Int)]
        feature_list = []
        road_type_set = set([])
        for row in response:
            segment_id = row[0]
            road_type = row[1]
            number_of_lanes = row[2]
            geom = row[3]
            road_type_set.add(road_type)
            polygon = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            f.setAttributes([segment_id, self.road_type[road_type][1], number_of_lanes])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', f'udbx_road_segment',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for road_type in road_type_set:
            actual_width = 1
            label = f'{self.road_type[road_type][1]}'
            exp = f'''road_type = \'{self.road_type[road_type][1]}\''''
            line_style = 'solid'  # self.edge_type[edge_type][0]
            color = self.road_type[road_type][0]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    def query_road_edge_in_extent(self):

        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    edge_start_att as (
                    	select road_edges.road_segment_id, road_edges.road_edge_side, road_edge_type, 	
						array_agg(shoulder_width) as shoulder_widths,
                    	array_agg(st_astext(position) order by road_edge_point_sequence_index) as geoms,
                    	max(road_edge_point_sequence_index) as max_index
                    	from segments_in_extent
                    	join ushr_format.road_edge_points on road_edge_points.road_segment_id = segments_in_extent.segment_id
                    	join ushr_format.road_edges on road_edges.road_segment_id = road_edge_points.road_segment_id
                    	where road_edge_points.road_edge_side = road_edges.road_edge_side
                    	group by road_edges.road_segment_id, road_edges.road_edge_side
                    )
                    select edge_start_att.road_segment_id, edge_start_att.road_edge_side, edge_start_att.road_edge_type,
                    max_index, shoulder_widths, geoms, 
                    array_agg(road_edge_attributes.road_edge_point_sequence_index order by road_edge_point_sequence_index) as inds, 
					array_agg(road_edge_attributes.road_edge_type order by road_edge_point_sequence_index) as road_edge_types                    
                    from edge_start_att
                    left join ushr_format.road_edge_attributes on edge_start_att.road_segment_id = road_edge_attributes.road_segment_id
                    	and edge_start_att.road_edge_side = road_edge_attributes.road_edge_side       						
                    group by edge_start_att.road_segment_id, edge_start_att.road_edge_side, edge_start_att.road_edge_type, max_index, geoms, shoulder_widths
					'''
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('road_edge_side', QVariant.String),
                      QgsField('road_edge_type', QVariant.String),
                      QgsField('shoulder_widths', QVariant.String)
                      ]
        feature_list = []
        edge_type_list = []
        response = make_query(self.conn, query, None)
        for row in response:
            segment_id = row[0]
            road_edge_side = row[1]
            initial_road_edge_type_code = row[2]
            max_index = row[3]
            shoulder_widths = row[4]
            point_geoms = row[5]
            change_inds = row[6]
            change_types = row[7]

            edge_type_dict = {}
            seq_ind = 0
            edge_type_dict[seq_ind] = {'road_edge_side': road_edge_side,
                                       'road_edge_type_code': initial_road_edge_type_code}
            # maintain the attributes until there is a change
            # road_edge_type_code = initial_road_edge_type_code

            # there is change
            if change_inds[0] is not None:
                for i, seq_ind in enumerate(change_inds):
                    change_type = change_types[i]
                    edge_type_dict[seq_ind] = {'road_edge_side': road_edge_side,
                                               'road_edge_type_code': change_type}
            for seq_ind in edge_type_dict:
                if edge_type_dict[seq_ind]['road_edge_type_code'] not in edge_type_list:
                    edge_type_list.append(edge_type_dict[seq_ind]['road_edge_type_code'])

            point_geom_list = []
            road_edge_type_code = edge_type_dict[0]['road_edge_type_code']
            for i, point_geom_wkt in enumerate(point_geoms):
                point_geom_list.append(loads(point_geom_wkt))
                if i != 0 and i in edge_type_dict:
                    # the last point of the current piece is also the first point of next piece
                    point_geom_list.append(loads(point_geom_wkt))
                    # complete the geometry for the current type duration
                    if len(point_geom_list) == 1:
                        point_geom_list.append(point_geom_list[0])
                    edge_geom = LineString(point_geom_list).wkt
                    edge_qgsgeom = g.fromWkt(edge_geom)
                    f = QgsFeature()
                    f.setGeometry(edge_qgsgeom)
                    f.setAttributes([segment_id, self.edge_side[road_edge_side], self.edge_type[road_edge_type_code][1],
                                     f'{shoulder_widths}'])
                    feature_list.append(f)
                    # clear the point geom list
                    point_geom_list = [loads(point_geom_wkt)]
                    road_edge_type_code = edge_type_dict[i]['road_edge_type_code']

            max_change_ind = max(list(edge_type_dict.keys()))
            # complete the last portion of the line, if there is no type change on this line, this is the entire line.
            road_edge_type_code = edge_type_dict[max_change_ind]['road_edge_type_code']
            if len(point_geom_list) == 1:
                point_geom_list.append(point_geom_list[0])
            edge_geom = LineString(point_geom_list).wkt
            edge_qgsgeom = g.fromWkt(edge_geom)
            f = QgsFeature()
            f.setGeometry(edge_qgsgeom)
            f.setAttributes([segment_id, self.edge_side[road_edge_side], self.edge_type[road_edge_type_code][1],
                             f'{shoulder_widths}'])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_edge', feature_list, qgs_fields)

        # make rules
        rules = ()
        for edge_type in edge_type_list:
            actual_width = 1
            label = f'{self.edge_type[edge_type][1]}'
            exp = f'''road_edge_type = \'{self.edge_type[edge_type][1]}\''''
            line_style = 'solid'  # self.edge_type[edge_type][0]
            color = self.edge_type[edge_type][0]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)

        return v_layer

    def query_pavement_markings_in_extent(self):

        query = f'''with lane_conn_in_extent as (select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    pm_lane_mapping as (
                        select pavement_markings.pavement_marking_id, marking_type, width, height, 
                        pavement_marking_lane_mapping.road_segment_id, pavement_marking_lane_mapping.lane_number, top_left_corner_position,
                        st_astext(st_polygon(st_linefrommultipoint(st_collect(array[bottom_left_corner_position, top_left_corner_position, 
                                            											   	   top_right_corner_position, bottom_right_corner_position, 
                                            												   bottom_left_corner_position])), 4326)) as pavement_marking_geom
                        from ushr_format.pavement_markings
                        join ushr_format.pavement_marking_lane_mapping ON pavement_marking_lane_mapping.pavement_marking_id = pavement_markings.pavement_marking_id
                        join segments_in_extent on segments_in_extent.segment_id = pavement_marking_lane_mapping.road_segment_id
                        	)
                    select pm_lane_mapping.*, 
                    st_astext(st_makeline(top_left_corner_position, st_centroid(st_makeline(position order by lane_point_sequence_index)))) as lane_mapping
                    from pm_lane_mapping
                    join ushr_format.lane_center_points on lane_center_points.road_segment_id = pm_lane_mapping.road_segment_id
                    where lane_center_points.lane_number = pm_lane_mapping.lane_number
                    group by pavement_marking_id, marking_type, width, height, pm_lane_mapping.road_segment_id, pm_lane_mapping.lane_number, top_left_corner_position, pavement_marking_geom'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('pavement_marking_id', QVariant.Int),
                      QgsField('pavement_marking_type', QVariant.String),
                      QgsField('width', QVariant.Double), QgsField('height', QVariant.Double),
                      QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int)
                      ]
        feature_list1 = []
        feature_list2 = []
        pm_type_list = []

        for row in response:
            pavement_marking_id = row[0]
            pavement_marking_type = row[1]
            width = row[2]
            height = row[3]
            segment_id = row[4]
            lane_number = row[5]
            pm_geom = row[7]
            lane_mapping_geom = row[8]
            if pavement_marking_type not in pm_type_list:
                pm_type_list.append(pavement_marking_type)

            # pm_geom = loads(pm_geom).wkt
            pm_qgsgeom = g.fromWkt(pm_geom)

            # lm_geom = loads(lane_mapping_geom).wkt
            lm_qgsgeom = g.fromWkt(lane_mapping_geom)

            f = QgsFeature()
            f.setGeometry(pm_qgsgeom)
            f.setAttributes([pavement_marking_id, self.pavement_marking_type[pavement_marking_type],
                             width, height, segment_id, lane_number])
            feature_list1.append(f)

            f = QgsFeature()
            f.setGeometry(lm_qgsgeom)
            f.setAttributes([pavement_marking_id, self.pavement_marking_type[pavement_marking_type],
                             width, height, segment_id, lane_number])
            feature_list2.append(f)

        v_layer1 = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', 'udbx_pavement_marking',
                                       feature_list1, qgs_fields)
        v_layer2 = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_pavement_marking_lane_mapping',
                                             feature_list2, qgs_fields)

        # make rules
        rules = ()
        pm_color_selector = ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'purple', 'cyan', 'navy', 'coffee']
        for i, pm_type in enumerate(pm_type_list):
            actual_width = 0.5

            label = f'{self.pavement_marking_type[pm_type]}'
            exp = f'''pavement_marking_type = \'{self.pavement_marking_type[pm_type]}\''''
            line_style = 'solid'
            color = pm_color_selector[i]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer1 = apply_rule_based_symbol(rules, v_layer1)

        return v_layer1, v_layer2

    # sign type 1~13: regulatory traffic device: lane mapping correct
    # sign type > 13: regular signs: lane mapping: 0
    def query_signs_in_extent(self):
        query = f'''with lane_conn_in_extent as (
                        select lane_connections.incident_road_segment_id ,lane_connections.emergent_road_segment_id
                        from ushr_format.lane_connection_nodes
                        join ushr_format.lane_connections 
                            on lane_connections.lane_connection_node_id = lane_connection_nodes.lane_connection_node_id
                        where st_within(node_position, 
                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    segments_in_extent_union as (
                    select incident_road_segment_id as segment_id from lane_conn_in_extent
                    union 
                    select emergent_road_segment_id as segment_id from lane_conn_in_extent
                    ),
                    segments_in_extent as (
                    select distinct segment_id from segments_in_extent_union
                    where segment_id != 0
                    ),
                    sign_lane_mapping as (
                        select signs.sign_id, sign_face_azimuth, sign_face_elevation, height, width, shape, type, 
                        is_digital, sign_lane_mapping.road_segment_id, sign_lane_mapping.lane_number, 
                        sign_lane_mapping.lane_point_sequence_index, centroid_position,
                        st_polygon(st_linefrommultipoint(
                            st_collect(array[bottom_left_corner_position, top_left_corner_position, 
                                        top_right_corner_position, bottom_right_corner_position, 
                                        bottom_left_corner_position])), 4326) as sign_geom
                        from ushr_format.signs
                        join ushr_format.sign_lane_mapping ON sign_lane_mapping.sign_id = signs.sign_id
                        join segments_in_extent on segments_in_extent.segment_id = sign_lane_mapping.road_segment_id
                    )
                    select sign_id, sign_face_azimuth, sign_face_elevation, height, width, shape, type, 
                    is_digital, sign_lane_mapping.road_segment_id, sign_lane_mapping.lane_number, 
                    sign_lane_mapping.lane_point_sequence_index, st_astext(centroid_position), st_astext(sign_geom), 
                    st_astext(st_makeline(centroid_position, position)) as lane_mapping
                    from sign_lane_mapping
                    join ushr_format.lane_center_points 
                        on lane_center_points.road_segment_id = sign_lane_mapping.road_segment_id
                    where ((type > 13 and lane_center_points.lane_number = sign_lane_mapping.lane_number + 1) or 
                    (type <= 13 and lane_center_points.lane_number = sign_lane_mapping.lane_number))
                    and lane_center_points.lane_point_sequence_index = sign_lane_mapping.lane_point_sequence_index
                    '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('udbx_sign_id', QVariant.Int), QgsField('rfdb_sign_id', QVariant.Int),
                      QgsField('type', QVariant.String),
                      QgsField('is_digital', QVariant.String), QgsField('shape', QVariant.String),
                      QgsField('height', QVariant.Double), QgsField('width', QVariant.Double),
                      QgsField('face_azimuth', QVariant.Double), QgsField('face_elevation', QVariant.Double),
                      QgsField('segment_id', QVariant.Int), QgsField('lane_number', QVariant.Int),
                      QgsField('lane_point_sequence_index', QVariant.Int), QgsField('arrow_length', QVariant.Int)
                      ]
        feature_list1 = []
        feature_list2 = []
        sign_type_list = []
        sign_centroid_feature_list = []

        for row in response:
            sign_id, sign_face_azimuth, sign_face_elevation, height, width, shape, sign_type, \
                is_digital, segment_id, lane_number, lane_point_sequence_index, centroid, \
                sign_geom, lane_mapping_geom = row

            rfdb_sign_id = sign_id // 9
            if sign_type not in sign_type_list:
                sign_type_list.append(sign_type)

            sign_qgsgeom = g.fromWkt(sign_geom)
            sign_centroid_qgsgeom = g.fromWkt(centroid)
            lm_qgsgeom = g.fromWkt(lane_mapping_geom)

            f = QgsFeature()
            f.setGeometry(sign_qgsgeom)
            f.setAttributes([sign_id, rfdb_sign_id, self.sign_type[sign_type], f'{is_digital}', self.sign_shape[shape],
                             height, width, sign_face_azimuth, sign_face_elevation, segment_id, lane_number,
                             lane_point_sequence_index, 1])
            feature_list1.append(f)

            f = QgsFeature()
            f.setGeometry(sign_centroid_qgsgeom)
            f.setAttributes([sign_id, rfdb_sign_id, self.sign_type[sign_type], f'{is_digital}', self.sign_shape[shape],
                             height, width, sign_face_azimuth, sign_face_elevation, segment_id, lane_number,
                             lane_point_sequence_index, 1])
            sign_centroid_feature_list.append(f)

            f = QgsFeature()
            f.setGeometry(lm_qgsgeom)
            f.setAttributes([sign_id, rfdb_sign_id, self.sign_type[sign_type], f'{is_digital}', self.sign_shape[shape],
                             height, width, sign_face_azimuth, sign_face_elevation, segment_id, lane_number,
                             lane_point_sequence_index, 1])
            feature_list2.append(f)

        v_layer1 = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', 'udbx_sign',
                                       feature_list1, qgs_fields)
        v_layer2 = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_sign_lane_mapping',
                                             feature_list2, qgs_fields)
        v_layer_sign_centroid = buildSimpleQgsVectorLayer(f'PointZ?crs=epsg:4326',
                                                          'udbx_sign_centroid',
                                                          sign_centroid_feature_list, qgs_fields)
        v_layer_sign_face_azimuth = buildSimpleQgsVectorLayer(
            f'PointZ?crs=epsg:4326', 'udbx_sign_face_azimuth', sign_centroid_feature_list, qgs_fields)
        v_layer_sign_face_azimuth = setVectorFieldTypeStyle(v_layer_sign_face_azimuth, 'arrow_length', 'face_azimuth')

        # make rules
        rules = ()
        sign_color_selector = ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'purple']
        for i, sign_type in enumerate(sign_type_list):
            actual_width = 1

            label = f'{self.sign_type[sign_type]}'
            exp = f'''type = \'{self.sign_type[sign_type]}\''''
            line_style = 'solid'
            if i > 6:
                index = i % 6
            else:
                index = i
            color = sign_color_selector[index]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer1 = apply_rule_based_symbol(rules, v_layer1)

        return v_layer1, v_layer2, v_layer_sign_centroid, v_layer_sign_face_azimuth

    def query_osm_ways_in_extent(self):
        query = f'''SELECT * 
                 FROM INFORMATION_SCHEMA.TABLES 
                 WHERE TABLE_SCHEMA = 'ushr_format'
                 AND  TABLE_NAME = 'osm_original_data'
                 '''
        response = make_query(self.conn, query, None)
        if len(response) == 0:
            self.main_win.push_message('table ushr_format.osm_original_data does not exist!')
            return 1
        query = f'''SELECT osm_original_data.*, road_segment_id, direction,
                    st_astext(wkb_geometry)
                    FROM ushr_format.osm_original_data
                    left join ushr_format.sd_alignment on sd_alignment.osm_way_id = osm_original_data.osm_id
                    where st_intersects(wkb_geometry,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('hd_segment_id', QVariant.Int), QgsField('osm_id', QVariant.Int),
                      QgsField('road type', QVariant.String), QgsField('road name', QVariant.String),
                      QgsField('tunnel', QVariant.String), QgsField('bridge', QVariant.String),
                      QgsField('oneway', QVariant.String), QgsField('layer', QVariant.String),
                      QgsField('sd_hd_aligned', QVariant.String),
                      QgsField('sd_hd direction', QVariant.String)
                      ]
        feature_list = []
        road_type_list = []
        aligned_list = []

        for row in response:
            osm_id = row[0]
            fclass = row[1]
            road_name = row[2]
            tunnel = row[3]
            bridge = row[4]
            oneway = row[5]
            layer = row[6]
            hd_segment_id = row[8]
            sd_hd_direction = row[9]
            osm_geom = row[10]

            if fclass not in road_type_list:
                road_type_list.append(fclass)
            if hd_segment_id is None:
                aligned = False
            else:
                aligned = True
            if aligned not in aligned_list:
                aligned_list.append(aligned)

            # geom_wkt = loads(osm_geom).wkt
            osm_qgsgeom = g.fromWkt(osm_geom)

            f = QgsFeature()
            f.setGeometry(osm_qgsgeom)
            f.setAttributes([hd_segment_id, osm_id, fclass, road_name, tunnel, bridge, oneway, layer,
                             f'{aligned}', sd_hd_direction])
            feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'udbx_osm_data',
                                            feature_list, qgs_fields)

        # make rules
        rules = ()
        osm_width_selector = {False: 0.3, True: 0.6}  # 1: aligned, 0.3: not aligned
        osm_color_selector = {False: 'red', True: 'lime'}
        for i, aligned in enumerate(aligned_list):
            actual_width = osm_width_selector[aligned]

            label = f'sd-hd aligned - {aligned}'
            exp = f'''sd_hd_aligned = \'{aligned}\''''
            line_style = 'solid'
            color = osm_color_selector[aligned]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)

        return v_layer

