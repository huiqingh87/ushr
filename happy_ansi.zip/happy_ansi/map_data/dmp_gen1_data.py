from map_data.utils import *
from shapely.geometry import LineString, Point, Polygon
from shapely.ops import nearest_points
from map_data.db_conn import *
from map_data.dmp_gen1_enums import *
import configparser
import os
import pathlib
from dataclasses import dataclass
from calculations.projection import project_wgs84_utm, project_utm_wgs84


class MainWinTest:
    def __init__(self, conn):
        self.customer_conn = conn
        self.extent = None


class DMPGen1MapData:
    def __init__(self, mainwin):
        self.main_win = mainwin
        self.conn = mainwin.customer_conn
        self.extent = mainwin.extent
        self.srid = 4326

    def is_dmp_gen1_db(self):
        query = '''SELECT * 
                   FROM INFORMATION_SCHEMA.TABLES 
                   WHERE TABLE_SCHEMA = %s
                   AND  TABLE_NAME = %s
                   '''
        response = make_query(self.conn, query, ('dmp', 'carriageway_marking'))
        if len(response) == 0:
            return False
        else:
            return True

    # line type layer, incorporate virtual flag
    # carriageway marking code layer
    # installed object layer
    # deceleration marking code layer
    def query_carriageway_marking_in_extent(self):
        query = f'''select dm_id, mesh_id, starting_point_line_width, end_point_line_width, 
                    line_type_code, installed_object_code, deceleration_marking_code, 
                    carriageway_marking_code, virtual_flag, coordinate_string_ll
                    from pub_tracking.delivered_roads
                    join dmp.carriageway_marking on carriageway_marking.road_unit_rfdb_id = segment_id					
                    and st_intersects(geom, 
                                      ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                      {self.extent.x_max}, {self.extent.y_max}, {self.srid}))                                                    
                    '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields_line_type = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                                QgsField('line_type', QVariant.String),
                                QgsField('starting_point_line_width', QVariant.Int),
                                QgsField('end_point_line_width', QVariant.Int),
                                QgsField('virtual_flag', QVariant.String)
                                ]
        qgs_fields_carriageway_marking_type = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                                               QgsField('carriageway_marking_type', QVariant.String),
                                               QgsField('virtual_flag', QVariant.String)
                                               ]
        qgs_fields_installed_object = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                                       QgsField('installed_object_type', QVariant.String)
                                       ]
        qgs_fields_deceleration_marking = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                                           QgsField('deceleration_marking_side', QVariant.String)
                                           ]
        line_type_feature_list = []
        carriageway_marking_type_feature_list = []
        installed_object_feature_list = []
        deceleration_marking_feature_list = []
        line_type_dict = {}
        carriageway_marking_type_dict = {}
        installed_object_dict = {}
        deceleration_marking_dict = {}
        for row in response:
            dm_id, mesh_id, starting_point_line_width, end_point_line_width, \
                line_type_code, installed_object_code, deceleration_marking_code, \
                carriageway_marking_code, virtual_flag, coordinate_string_ll = row[0:10]
            if line_type_code is None:  # multi-lines are not supported yet
                line_type_code = 'None'
            wgs_coordinate_list = coordinate_string_ll.split(';')
            wgs_point_list = []
            for i in range(len(wgs_coordinate_list)):
                wgs_coordinate = wgs_coordinate_list[i]
                lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
                wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = g.fromWkt(LineString(wgs_point_list).wkt)

            # line type code
            f = QgsFeature()
            f.setGeometry(geom)
            line_type_class = line_type_df[line_type_df['id'] == line_type_code]['class'].values[0]
            line_type_color = line_type_df[line_type_df['id'] == line_type_code]['color'].values[0]
            line_type_type = line_type_df[line_type_df['id'] == line_type_code]['type'].values[0]
            draw_width = line_type_df[line_type_df['id'] == line_type_code]['draw_width'].values[0]
            line_type = f'{line_type_class}_{line_type_color}_{line_type_type}_virtual_{virtual_flag}'
            line_type_dict[line_type] = {'line_type_class': line_type_class, 'line_type_color': line_type_color,
                                         'line_type_type': line_type_type, 'virtual_flag': virtual_flag,
                                         'draw_width': draw_width}
            f.setAttributes(
                [dm_id, mesh_id, line_type, starting_point_line_width, end_point_line_width, f'{virtual_flag}'])
            line_type_feature_list.append(f)

            # carriageway marking code
            f = QgsFeature()
            f.setGeometry(geom)
            carriageway_marking_type = carriageway_marking_code_df[carriageway_marking_code_df['id']
                                                                   == carriageway_marking_code]['type'].values[0]
            carriageway_marking_draw_color = carriageway_marking_code_df[carriageway_marking_code_df['id']
                                                                         == carriageway_marking_code]['draw_color'].values[0]
            carriageway_marking_type_dict[carriageway_marking_type] = {'draw_color': carriageway_marking_draw_color,
                                                                       'virtual_flag': virtual_flag}
            f.setAttributes(
                [dm_id, mesh_id, carriageway_marking_type, f'{virtual_flag}'])
            carriageway_marking_type_feature_list.append(f)

            # installed object
            if installed_object_code != 0:
                f = QgsFeature()
                f.setGeometry(geom)
                installed_object_type = installed_object_df[installed_object_df['id']
                                                            == installed_object_code]['type'].values[0]
                installed_object_draw_color = installed_object_df[installed_object_df['id']
                                                                  == installed_object_code]['draw_color'].values[0]
                installed_object_dict[installed_object_type] = {'draw_color': installed_object_draw_color}
                f.setAttributes([dm_id, mesh_id, installed_object_type])
                installed_object_feature_list.append(f)

            # deceleration marking
            if deceleration_marking_code != 0:
                f = QgsFeature()
                f.setGeometry(geom)
                deceleration_marking_side = deceleration_marking_df[deceleration_marking_df['id']
                                                            == deceleration_marking_code]['side'].values[0]
                deceleration_marking_draw_color = deceleration_marking_df[deceleration_marking_df['id']
                                                                  == deceleration_marking_code]['draw_color'].values[0]
                deceleration_marking_dict[deceleration_marking_side] = {'draw_color': deceleration_marking_draw_color}
                f.setAttributes([dm_id, mesh_id, deceleration_marking_side])
                deceleration_marking_feature_list.append(f)

        line_type_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', f'dmp_gen1_carriageway_marking_line_type',
                                              line_type_feature_list, qgs_fields_line_type)
        carriageway_marking_type_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                             f'dmp_gen1_carriageway_marking_type',
                                                             carriageway_marking_type_feature_list,
                                                             qgs_fields_carriageway_marking_type)
        installed_object_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', f'dmp_gen1_installed_object',
                                                     installed_object_feature_list, qgs_fields_installed_object)
        deceleration_marking_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', f'dmp_gen1_deceleration_marking',
                                                         deceleration_marking_feature_list, qgs_fields_deceleration_marking)
        # make rules
        line_type_rules = ()
        for line_type in line_type_dict:
            draw_width = line_type_dict[line_type]['draw_width'] * 5
            # line_type_class = line_type_dict[line_type]['line_type_class']
            line_type_color = line_type_dict[line_type]['line_type_color']
            line_type_type = line_type_dict[line_type]['line_type_type']
            virtual_flag = line_type_dict[line_type]['virtual_flag']
            label = f'{line_type}'
            exp = f'''line_type = \'{line_type}\''''
            if line_type_type is None or line_type_type == 'unsupported':
                line_style = 'dash'
            else:
                line_style = line_type_type.split('-')[0]
                if line_style == 'dashed':
                    line_style = 'dash'
            if virtual_flag:
                line_style = 'dot'

            color = blend_colors(line_type_color.split('-'))
            line_type_rules += ((label, exp, line_style, color, draw_width),)

        carriageway_marking_type_rules = ()
        for carriageway_marking_type in carriageway_marking_type_dict:
            draw_width = 0.5
            draw_color = carriageway_marking_type_dict[carriageway_marking_type]['draw_color']
            virtual_flag = carriageway_marking_type_dict[carriageway_marking_type]['virtual_flag']
            label = f'{carriageway_marking_type}'
            exp = f'''carriageway_marking_type = \'{carriageway_marking_type}\''''
            line_style = 'solid'
            if virtual_flag:
                line_style = 'dot'
            carriageway_marking_type_rules += ((label, exp, line_style, draw_color, draw_width),)

        installed_object_rules = ()
        for installed_object_type in installed_object_dict:
            draw_width = 1.5
            draw_color = installed_object_dict[installed_object_type]['draw_color']
            label = f'{installed_object_type}'
            exp = f'''installed_object_type = \'{installed_object_type}\''''
            line_style = 'solid'
            installed_object_rules += ((label, exp, line_style, draw_color, draw_width),)

        deceleration_marking_rules = ()
        for deceleration_marking_side in deceleration_marking_dict:
            draw_width = 1.5
            draw_color = deceleration_marking_dict[deceleration_marking_side]['draw_color']
            label = f'{deceleration_marking_side}'
            exp = f'''deceleration_marking_side = \'{deceleration_marking_side}\''''
            line_style = 'solid'
            deceleration_marking_rules += ((label, exp, line_style, draw_color, draw_width),)

        line_type_layer = apply_rule_based_symbol(line_type_rules, line_type_layer)
        carriageway_marking_type_layer = apply_rule_based_symbol(carriageway_marking_type_rules,
                                                                 carriageway_marking_type_layer)
        installed_object_layer = apply_rule_based_symbol(installed_object_rules, installed_object_layer)
        deceleration_marking_layer = apply_rule_based_symbol(deceleration_marking_rules, deceleration_marking_layer)
        return line_type_layer, carriageway_marking_type_layer, installed_object_layer, deceleration_marking_layer

    def query_lane_node_linkage_in_extent(self):
        query = f'''select lnl.dm_id, mesh_id, lane_node_linkage_length, 
                    entry_lane_node_linkage, exit_lane_node_linkage, coordinate_string_ll
                    from pub_tracking.delivered_roads
                    join dmp.lane_node_linkage lnl on lnl.road_unit_rfdb_id = segment_id		
                    join dmp.lane_node_linkage_connection lnlconn on lnlconn.dm_id = lnl.dm_id
                    and st_intersects(geom, 
                                      ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                      {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    '''

        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('lane_node_linkage_length', QVariant.Double),
                      QgsField('entry_lane_node_linkage', QVariant.String),
                      QgsField('exit_lane_node_linkage', QVariant.String)
                      ]
        g = QgsGeometry()
        feature_list = []
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id, mesh_id, lane_node_linkage_length, \
                entry_lane_node_linkage, exit_lane_node_linkage, coordinate_string_ll = row[0:6]
            wgs_coordinate_list = coordinate_string_ll.split(';')
            wgs_point_list = []
            for i in range(len(wgs_coordinate_list)):
                wgs_coordinate = wgs_coordinate_list[i]
                lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
                wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = g.fromWkt(LineString(wgs_point_list).wkt)

            f = QgsFeature()
            f.setGeometry(geom)

            f.setAttributes([dm_id, mesh_id, lane_node_linkage_length, f'{entry_lane_node_linkage}', f'{exit_lane_node_linkage}'])
            feature_list.append(f)

        lane_node_linkage_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                            f'dmp_gen1_lane_node_linkage',
                                                            feature_list, qgs_fields)
        return lane_node_linkage_layer

    def query_lane_node_linkage_intersection_in_extent(self):
        query = f'''select dm_id, mesh_id, lane_node_intersection_length, coordinate_string_ll
                    from pub_tracking.delivered_roads
                    join dmp.lane_node_linkage_intersection 
                        on lane_node_linkage_intersection.road_unit_rfdb_id = segment_id
                    where st_intersects(geom, 
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))                            
                    '''

        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('lane_node_intersection_length', QVariant.Double)
                      ]
        g = QgsGeometry()
        feature_list = []
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id, mesh_id, lane_node_intersection_length, coordinate_string_ll = row[0:4]
            wgs_coordinate_list = coordinate_string_ll.split(';')
            wgs_point_list = []
            for i in range(len(wgs_coordinate_list)):
                wgs_coordinate = wgs_coordinate_list[i]
                lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
                wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = g.fromWkt(LineString(wgs_point_list).wkt)

            f = QgsFeature()
            f.setGeometry(geom)

            f.setAttributes([dm_id, mesh_id, lane_node_intersection_length])
            feature_list.append(f)

        lane_node_linkage_intersection_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                         f'dmp_gen1_lane_node_linkage_intersection',
                                                                         feature_list, qgs_fields)
        return lane_node_linkage_intersection_layer

    def query_lane_node_linkage_connection_in_extent(self):
        query = f'''with lnl_in_extent as (select dm_id, coordinate_string_ll
                        from pub_tracking.delivered_roads
                        join dmp.lane_node_linkage on lane_node_linkage.road_unit_rfdb_id = segment_id
                        where st_intersects(geom, 
                                      ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                      {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ), 
                    lane_conn as (					
                    select lnl_in_extent.dm_id, coordinate_string_ll, 
                    unnest(exit_lane_node_linkage) as exit_lane_node_linkage
                    from lnl_in_extent
                    join dmp.lane_node_linkage_connection lnlconn on lnlconn.dm_id = lnl_in_extent.dm_id                       
                    )
                    select lane_conn.dm_id, lane_conn.coordinate_string_ll, 
                    exit_lane_node_linkage, lnl.coordinate_string_ll
                    from lane_conn
                    join dmp.lane_node_linkage lnl on lnl.dm_id = exit_lane_node_linkage
                    '''
        response_transition = make_query(self.conn, query, None)

        query = f'''with lnl_in_extent as (select dm_id, coordinate_string_ll
                        from pub_tracking.delivered_roads
                        join dmp.lane_node_linkage on lane_node_linkage.road_unit_rfdb_id = segment_id
                        where st_intersects(geom, 
                                      ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                      {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select lnl_in_extent.dm_id, coordinate_string_ll, -1, 0
                    from lnl_in_extent
                    join dmp.lane_node_linkage_connection lnlconn on lnlconn.dm_id = lnl_in_extent.dm_id         					
                    where exit_lane_node_linkage[1] is null                        
                    '''

        response_end = make_query(self.conn, query, None)

        query = f'''with lnl_in_extent as (select dm_id, coordinate_string_ll
                        from pub_tracking.delivered_roads
                        join dmp.lane_node_linkage on lane_node_linkage.road_unit_rfdb_id = segment_id
                        where st_intersects(geom, 
                                      ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                      {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )					
                    select lnl_in_extent.dm_id, coordinate_string_ll, 0, 0
                    from lnl_in_extent                    
					join dmp.lane_node_linkage_connection lnlconn on lnlconn.dm_id = lnl_in_extent.dm_id         					
					where entry_lane_node_linkage[1] is null                    
					'''

        response_start = make_query(self.conn, query, None)

        g = QgsGeometry()
        qgs_fields = [QgsField('dm_id', QVariant.String),
                      QgsField('exit_lane_dm_id', QVariant.String),
                      QgsField('node_type', QVariant.String)
                      ]

        node_type_set = set([])
        node_feature_list = []
        conn_feature_list = []
        for row in response_transition + response_end + response_start:
            dm_id, coordinate_string_ll, exit_lane_dm_id, exit_lane_coordinate_string_ll = row[0:4]
            wgs_coordinate_list = coordinate_string_ll.split(';')

            lnl_end_pts_dict = {}
            for i in [0, 1, -2, -1]:
                lat, lon, h, alt = wgs_coordinate_list[i].split(':')[0:4]
                lnl_pt = Point(float(lon), float(lat), float(alt))
                lnl_end_pts_dict[i] = lnl_pt

            if exit_lane_dm_id == -1:
                node_type = 'end'
                exit_lane_dm_id = None
                node_geom = lnl_end_pts_dict[-1].wkt
                conn_geom = LineString([lnl_end_pts_dict[-2], lnl_end_pts_dict[-1]]).wkt
            elif exit_lane_dm_id == 0:
                node_type = 'start'
                exit_lane_dm_id = dm_id
                dm_id = None
                node_geom = lnl_end_pts_dict[0].wkt
                conn_geom = LineString([lnl_end_pts_dict[0], lnl_end_pts_dict[1]]).wkt
            else:
                node_type = 'transition'
                node_geom = lnl_end_pts_dict[-1].wkt
                exit_lane_wgs_coordinate_list = exit_lane_coordinate_string_ll.split(';')
                lat, lon, h, alt = exit_lane_wgs_coordinate_list[1].split(':')[0:4]
                exit_lane_second_pt = Point(float(lon), float(lat), float(alt))
                conn_geom = LineString([lnl_end_pts_dict[-2], exit_lane_second_pt]).wkt

            node_type_set.add(node_type)
            qgs_node_geom = g.fromWkt(node_geom)
            qgs_conn_geom = g.fromWkt(conn_geom)

            f_node = QgsFeature()
            f_node.setGeometry(qgs_node_geom)
            f_node.setAttributes([dm_id, exit_lane_dm_id, node_type])
            node_feature_list.append(f_node)

            f_line = QgsFeature()
            f_line.setGeometry(qgs_conn_geom)
            f_line.setAttributes([dm_id, exit_lane_dm_id, node_type])
            conn_feature_list.append(f_line)

        # start_node: green
        # end_node: red
        # transition_node: yellow
        colors = {'start': 'lime', 'end': 'red', 'transition': 'yellow'}
        node_v_layer = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', 'dmp_gen1_lane_node_linkage_connection_node',
                                                 node_feature_list, qgs_fields)

        feature_dict = {}
        for node_type in node_type_set:
            feature_dict[node_type] = (colors[node_type], node_type)
        node_v_layer = apply_categorized_symbol(feature_dict, node_v_layer, field='node_type', point=True)

        arrow_v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'dmp_gen1_lane_node_linkage_connection',
                                                  conn_feature_list, qgs_fields)
        arrow_v_layer = setLineLayerStyleToArrow(arrow_v_layer)

        return node_v_layer, arrow_v_layer

    def query_lane_related_carriageway_marking_position_in_extent(self):
        query = f'''with lnl_in_extent as (select dm_id, coordinate_string_ll
                        from pub_tracking.delivered_roads
                        join dmp.lane_node_linkage on lane_node_linkage.road_unit_rfdb_id = segment_id
                        where st_intersects(geom, 
                                              ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                              {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                            )
                    SELECT lane_node_linkage_id, carriageway_marking_ref_id, carriageway_marking_position,
                    lnl_in_extent.coordinate_string_ll, carriageway_marking.coordinate_string_ll
                    FROM lnl_in_extent
                    join dmp.lane_related_carriageway_marking_info lrcm 
                        on lrcm.lane_node_linkage_id = lnl_in_extent.dm_id
                    join dmp.carriageway_marking on carriageway_marking.dm_id = carriageway_marking_ref_id
                    '''
        response = make_query(self.conn, query, None)

        g = QgsGeometry()
        qgs_fields = [QgsField('lane_node_linkage_id', QVariant.String),
                      QgsField('carriageway_marking_id', QVariant.String),
                      QgsField('carriageway_marking_position', QVariant.String)
                      ]

        position_type_set = set([])
        lane_node_linkage_id_set = set([])
        node_feature_list = []
        ref_feature_list = []
        for row in response:
            lane_node_linkage_id, carriageway_marking_id, carriageway_marking_position, \
                lnl_coordinate_string_ll, cm_coordinate_string_ll = row[0:5]
            lnl_wgs_coordinate_list = lnl_coordinate_string_ll.split(';')
            lat, lon, h, alt = lnl_wgs_coordinate_list[len(lnl_wgs_coordinate_list)//2].split(':')[0:4]
            node_geom = Point(float(lon), float(lat), float(alt))
            cm_wgs_coordinate_list = cm_coordinate_string_ll.split(';')
            lat, lon, h, alt = cm_wgs_coordinate_list[len(cm_wgs_coordinate_list) // 2].split(':')[0:4]
            cm_node_geom = Point(float(lon), float(lat), float(alt))
            ref_geom = LineString([node_geom, cm_node_geom]).wkt
            node_geom = node_geom.wkt

            position = carriageway_marking_position_df[carriageway_marking_position_df['id']
                                                       == carriageway_marking_position]['position'].values[0]
            position_type_set.add(position)

            if lane_node_linkage_id not in lane_node_linkage_id_set:
                lane_node_linkage_id_set.add(lane_node_linkage_id)
                qgs_node_geom = g.fromWkt(node_geom)
                f_node = QgsFeature()
                f_node.setGeometry(qgs_node_geom)
                f_node.setAttributes([lane_node_linkage_id, carriageway_marking_id, position])
                node_feature_list.append(f_node)

            qgs_ref_geom = g.fromWkt(ref_geom)
            f_line = QgsFeature()
            f_line.setGeometry(qgs_ref_geom)
            f_line.setAttributes([lane_node_linkage_id, carriageway_marking_id, position])
            ref_feature_list.append(f_line)

        node_v_layer = buildQgsVectorLayer('PointZ?crs=epsg:4326',
                                           'dmp_gen1_lane_related_carriageway_marking_position_node',
                                           node_feature_list, qgs_fields, color='white')

        arrow_v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                  'dmp_gen1_lane_related_carriageway_marking_position_ref',
                                                  ref_feature_list, qgs_fields)
        # arrow_v_layer = setLineLayerStyleToArrow(arrow_v_layer)
        rules = ()
        draw_width = 0.7
        line_style = 'solid'
        for position in position_type_set:
            color = carriageway_marking_position_df[carriageway_marking_position_df['position'] == position]['draw_color'].values[0]
            label = f'{position}'
            exp = f'''carriageway_marking_position = \'{position}\''''
            rules += ((label, exp, line_style, color, draw_width),)
        arrow_v_layer = apply_rule_based_symbol(rules, arrow_v_layer, geometry='arrow')

        return node_v_layer, arrow_v_layer

    def query_shoulder_edge_in_extent(self):
        query = f'''select dm_id, mesh_id, virtual_flag, coordinate_string_ll
                    from pub_tracking.delivered_roads
                    join dmp.shoulder_edge on shoulder_edge.road_unit_rfdb_id = segment_id
                    where st_intersects(geom, 
                                          ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                          {self.extent.x_max}, {self.extent.y_max}, {self.srid}))                                         
                    '''
        g = QgsGeometry()
        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('virtual_flag', QVariant.String)
                      ]
        feature_list = []
        virtual_flag_set = set([])
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id, mesh_id, virtual_flag, coordinate_string_ll = row[0:4]
            virtual_flag_set.add(virtual_flag)

            wgs_coordinate_list = coordinate_string_ll.split(';')
            wgs_point_list = []
            for i in range(len(wgs_coordinate_list)):
                wgs_coordinate = wgs_coordinate_list[i]
                lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
                wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = g.fromWkt(LineString(wgs_point_list).wkt)

            f = QgsFeature()
            f.setGeometry(geom)

            f.setAttributes([dm_id, mesh_id, f'{virtual_flag}'])
            feature_list.append(f)

        shoulder_edge_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', f'dmp_gen1_shoulder_edge',
                                                        feature_list, qgs_fields)
        rules = ()
        draw_width = 1
        for virtual_flag in virtual_flag_set:
            draw_color = 'brown'
            label = f'virtual_{virtual_flag}'
            exp = f'''virtual_flag = \'{virtual_flag}\''''
            line_style = 'solid'
            if virtual_flag:
                line_style = 'dot'
                draw_color = 'red'
            rules += ((label, exp, line_style, draw_color, draw_width),)
        shoulder_edge_layer = apply_rule_based_symbol(rules, shoulder_edge_layer)
        return shoulder_edge_layer

    def query_road_marking_in_extent(self):
        query = f'''
                    select rm.dm_id, mesh_id, road_object_id, marking_code, coordinate_string_ll                        
                    from dmp.road_markings rm     
                                '''
        g = QgsGeometry()
        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('road_object_id', QVariant.Int),
                      QgsField('road_marking_type', QVariant.String)
                      ]
        feature_list = []
        base_pt_feature_list = []
        road_marking_type_dict = {}
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id = row[0]
            mesh_id = row[1]
            road_object_id = row[2]
            marking_code = row[3]
            geom_string = row[4]

            road_marking_type = road_marking_df[road_marking_df['id'] == marking_code]['type'].values[0]
            draw_color = road_marking_df[road_marking_df['id'] == marking_code]['draw_color'].values[0]
            road_marking_type_dict[road_marking_type] = {'draw_color': draw_color}

            geom_corner_pts = geom_string.split(';')
            geom_corner_pts += [geom_corner_pts[0]]
            point_list = []
            for geom_corner_pt in geom_corner_pts:
                lat, lon, h, alt = geom_corner_pt.split(':')[0:4]
                point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = Polygon(point_list).wkt
            geom = g.fromWkt(geom)

            f = QgsFeature()
            f.setGeometry(geom)

            f.setAttributes([dm_id, mesh_id, road_object_id, road_marking_type])
            feature_list.append(f)

            geom = point_list[0].wkt
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([dm_id, mesh_id, road_object_id, road_marking_type])
            base_pt_feature_list.append(f)

        road_marking_layer = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', f'dmp_gen1_road_marking',
                                                       feature_list, qgs_fields)
        road_marking_base_pt_layer = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', f'dmp_gen1_road_marking_1st_pt',
                                                               base_pt_feature_list, qgs_fields)
        rules = ()
        draw_width = 1
        line_style = 'solid'
        for road_marking_type in road_marking_type_dict:
            r, g, b = road_marking_type_dict[road_marking_type]['draw_color']
            draw_color = QColor(r * 255, g * 255, b * 255)
            # self.main_win.push_message(draw_color)
            label = f'{road_marking_type}'
            exp = f'''road_marking_type = \'{road_marking_type}\''''
            rules += ((label, exp, line_style, draw_color, draw_width),)
        road_marking_layer = apply_rule_based_symbol(rules, road_marking_layer, qcolor=True)
        return road_marking_layer, road_marking_base_pt_layer

    def query_multiple_carriageway_marking_in_extent(self):
        query = f'''select dm_id, mesh_id, carriageway_markings_id, carriageway_markings_no, 
                    starting_point_line_width, end_point_line_width, line_type_code, coordinate_string_ll
                    from pub_tracking.delivered_roads
                    join dmp.multiple_carriageway_marking on multiple_carriageway_marking.road_unit_rfdb_id = segment_id
                    where st_intersects(geom, 
                                  ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                  {self.extent.x_max}, {self.extent.y_max}, {self.srid}))                     
                                    '''
        g = QgsGeometry()
        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('carriageway_marking_dm_id', QVariant.String),
                      QgsField('carriageway_marking_no', QVariant.Int),
                      QgsField('start_point_line_width', QVariant.Int),
                      QgsField('end_point_line_width', QVariant.Int), QgsField('line_type', QVariant.String)
                      ]
        feature_list = []
        line_type_dict = {}
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id, mesh_id, carriageway_markings_id, carriageway_markings_no, \
                starting_point_line_width, end_point_line_width, line_type_code, coordinate_string_ll = row[0:8]

            line_type = line_type_df[line_type_df['id'] == line_type_code]['type'].values[0]
            line_type_color = line_type_df[line_type_df['id'] == line_type_code]['color'].values[0]
            line_type_dict[line_type] = {'line_type_color': line_type_color}

            wgs_coordinate_list = coordinate_string_ll.split(';')
            wgs_point_list = []
            for i in range(len(wgs_coordinate_list)):
                wgs_coordinate = wgs_coordinate_list[i]
                lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
                wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = g.fromWkt(LineString(wgs_point_list).wkt)

            f = QgsFeature()
            f.setGeometry(geom)

            f.setAttributes([dm_id, mesh_id, carriageway_markings_id, carriageway_markings_no,
                             starting_point_line_width, end_point_line_width, line_type])
            feature_list.append(f)

        multiple_carriagaway_marking_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                       f'dmp_gen1_multiple_carriagaway_marking',
                                                                       feature_list, qgs_fields)
        rules = ()
        draw_width = 0.5
        line_style = 'solid'
        for line_type in line_type_dict:
            line_type_color = line_type_dict[line_type]['line_type_color']
            draw_color = blend_colors(line_type_color.split('-'))
            label = f'{line_type}'
            exp = f'''line_type = \'{line_type}\''''
            rules += ((label, exp, line_style, draw_color, draw_width),)
        multiple_carriagaway_marking_layer = apply_rule_based_symbol(rules, multiple_carriagaway_marking_layer)
        return multiple_carriagaway_marking_layer

    def query_vehicle_traffic_light(self, main=True):
        if main:
            tb = 'vehicle_main_traffic_light'
        else:
            tb = 'vehicle_aux_traffic_light'
        query = f'''select dm_id, mesh_id, depth, height, ground_height, directiontype, lenstype, coordinate_string_ll                        
                    from dmp.{tb}'''
        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('depth', QVariant.Double), QgsField('height', QVariant.Double),
                      QgsField('ground_height', QVariant.Double),
                      QgsField('direction_type', QVariant.String),
                      QgsField('lens_type', QVariant.String),
                      QgsField('traffic_light_type_verbose', QVariant.String)
                      ]
        g = QgsGeometry()
        feature_list = []
        light_dict = {}
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id = row[0]
            mesh_id = row[1]
            depth = row[2]
            height = row[3]
            ground_height = row[4]
            directiontype = row[5]
            lenstype = row[6]
            geom_string = row[7]
            geom_corner_pts = geom_string.split(';')
            point_list = []
            for geom_corner_pt in geom_corner_pts:
                lat, lon, h, alt = geom_corner_pt.split(':')[0:4]
                point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = LineString(point_list).wkt
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            if directiontype not in [1, 2]:
                directiontype = -1
            direction_type = vehicle_traffic_light_direction_df[vehicle_traffic_light_direction_df['id'] == directiontype]['direction'].values[0]
            lens_type = vehicle_traffic_light_df[vehicle_traffic_light_df['id'] == lenstype]['type'].values[0]
            draw_color = vehicle_traffic_light_df[vehicle_traffic_light_df['id'] == lenstype]['draw_color'].values[0]
            traffic_light_type_verbose = f'{direction_type}_{lens_type}'
            light_dict[traffic_light_type_verbose] = {'draw_color': draw_color}

            f.setAttributes([dm_id, mesh_id, depth, height, ground_height, direction_type, lens_type, traffic_light_type_verbose])
            feature_list.append(f)

        vehicle_traffic_light_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                f'dmp_gen1_{tb}',
                                                                feature_list, qgs_fields)
        rules = ()
        draw_width = 0.5
        line_style = 'solid'
        for traffic_light_type_verbose in light_dict:
            draw_color = light_dict[traffic_light_type_verbose]['draw_color']
            draw_color = blend_colors(draw_color.split('-'))
            label = f'{traffic_light_type_verbose}'
            exp = f'''traffic_light_type_verbose = \'{traffic_light_type_verbose}\''''
            rules += ((label, exp, line_style, draw_color, draw_width),)
        vehicle_traffic_light_layer = apply_rule_based_symbol(rules, vehicle_traffic_light_layer)

        return vehicle_traffic_light_layer

    def query_vehicle_arrow_traffic_light(self):
        query = '''with arrow_light as (
	select dm_id, mesh_id, depth, height, ground_height, arrow_directiontype, mobile_sig_id, unnest(lane_id_list) as lane_id, coordinate_string_ll                        
	from dmp.vehicle_arrow_traffic_light
)
select arrow_light.dm_id, arrow_light.mesh_id, depth, height, ground_height, arrow_directiontype, mobile_sig_id, arrow_light.coordinate_string_ll, 
array_agg(lane_id order by lane_id) as lane_id_list, array_agg(lane_node_linkage.coordinate_string_ll order by lane_id) as lane_coordinate_string_ll_list
from arrow_light
join dmp.lane_node_linkage on lane_node_linkage.dm_id = arrow_light.lane_id
group by arrow_light.dm_id, arrow_light.mesh_id, depth, height, ground_height, arrow_directiontype, mobile_sig_id, arrow_light.coordinate_string_ll
'''
        arrow_light_qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                                  QgsField('depth', QVariant.Double), QgsField('height', QVariant.Double),
                                  QgsField('ground_height', QVariant.Double),
                                  QgsField('direction_type', QVariant.String),
                                  QgsField('sign_dm_id', QVariant.String),
                                  QgsField('lane_id_list', QVariant.String)
                                  ]

        arrow_light_lm_qgs_fields = [QgsField('arrow_light_dm_id', QVariant.String), QgsField('lane_dm_id', QVariant.String)]
        g = QgsGeometry()
        arrow_light_feature_list = []
        arrow_light_lm_feature_list = []
        light_dict = {}
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id = row[0]
            mesh_id = row[1]
            depth = row[2]
            height = row[3]
            ground_height = row[4]
            directiontype = row[5]
            sign_dm_id = row[6]
            light_geom_string = row[7]
            lane_id_list = row[8]
            lane_geom_string_list = row[9]
            geom_corner_pts = light_geom_string.split(';')
            point_list = []
            for geom_corner_pt in geom_corner_pts:
                lat, lon, h, alt = geom_corner_pt.split(':')[0:4]
                point_list.append(Point(float(lon), float(lat), float(alt)))
            light_geom = LineString(point_list)
            geom = g.fromWkt(light_geom.wkt)
            f = QgsFeature()
            f.setGeometry(geom)
            if directiontype is None:
                direction_type = 'None'
                draw_color = 'red'
            else:
                direction_type = vehicle_arrow_traffic_light_direction_df[vehicle_arrow_traffic_light_direction_df['id'] == directiontype]['type'].values[0]
                draw_color = vehicle_arrow_traffic_light_direction_df[vehicle_arrow_traffic_light_direction_df['id'] == directiontype]['draw_color'].values[0]
            light_dict[direction_type] = {'draw_color': draw_color}

            f.setAttributes([dm_id, mesh_id, depth, height, ground_height, direction_type, sign_dm_id, f'{lane_id_list}'])
            arrow_light_feature_list.append(f)

            for i, lane_dm_id in enumerate(lane_id_list):
                lane_geom_string = lane_geom_string_list[i]
                geom_corner_pts = lane_geom_string.split(';')
                point_list = []
                for geom_corner_pt in geom_corner_pts:
                    lat, lon, h, alt = geom_corner_pt.split(':')[0:4]
                    point_list.append(Point(float(lon), float(lat), float(alt)))
                lane_geom = LineString(point_list)
                nearest_pt_on_lane = nearest_points(project_wgs84_utm(lane_geom), project_wgs84_utm(light_geom.centroid))[0]
                geom = LineString([light_geom.centroid, project_utm_wgs84(nearest_pt_on_lane)]).wkt
                geom = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(geom)
                f.setAttributes([dm_id, lane_dm_id])
                arrow_light_lm_feature_list.append(f)

        vehicle_arrow_traffic_light_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                      f'dmp_gen1_vehicle_arrow_traffic_light',
                                                                      arrow_light_feature_list, arrow_light_qgs_fields)
        vehicle_arrow_traffic_light_lm_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                      f'dmp_gen1_vehicle_arrow_traffic_light_lane_mapping',
                                                                      arrow_light_lm_feature_list, arrow_light_lm_qgs_fields)
        vehicle_arrow_traffic_light_lm_layer = setLineLayerStyleToArrow(vehicle_arrow_traffic_light_lm_layer, arrow_start_width=0.5,
                                                                        arrow_width=0.5, color='orange')

        rules = ()
        draw_width = 0.5
        line_style = 'solid'
        for direction_type in light_dict:
            draw_color = light_dict[direction_type]['draw_color']
            if draw_color == 'red':
                draw_color = QColor(draw_color)
            else:
                r, g, b = draw_color
                draw_color = QColor(r * 255, g * 255, b * 255)
            label = f'{direction_type}'
            exp = f'''direction_type = \'{direction_type}\''''
            rules += ((label, exp, line_style, draw_color, draw_width),)
        vehicle_arrow_traffic_light_layer = apply_rule_based_symbol(rules, vehicle_arrow_traffic_light_layer, qcolor=True)

        return vehicle_arrow_traffic_light_layer, vehicle_arrow_traffic_light_lm_layer

    def query_vehicle_traffic_sign(self):
        query = '''select dm_id, mesh_id, height, ground_height, signcode, signformcode, signcolorcode, variableflag, 
                   speedlimit, auxiliarysigncode, coordinate_string_ll                        
                   from dmp.vehicle_traffic_sign
                   '''
        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String),
                      QgsField('height', QVariant.Double),
                      QgsField('ground_height', QVariant.Double),
                      QgsField('type', QVariant.String),
                      QgsField('shape', QVariant.String), QgsField('color', QVariant.String),
                      QgsField('variable_flag', QVariant.String), QgsField('speed_limit', QVariant.Int),
                      QgsField('auxiliary_sign_type', QVariant.String),
                      QgsField('traffic_sign_type_verbose', QVariant.String)
                      ]
        g = QgsGeometry()
        feature_list = []
        sign_dict = {}
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id = row[0]
            mesh_id = row[1]
            height = row[2]
            ground_height = row[3]
            sign_code = row[4]
            sign_form_code = row[5]
            sign_color_code = row[6]
            variable_flag = row[7]
            speed_limit = row[8]
            auxiliary_sign_code = row[9]
            geom_string = row[10]
            geom_corner_pts = geom_string.split(';')
            point_list = []
            for geom_corner_pt in geom_corner_pts:
                lat, lon, h, alt = geom_corner_pt.split(':')[0:4]
                point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = LineString(point_list).wkt
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)

            if sign_code is None:
                sign_code = 600101
            if sign_color_code is None:
                sign_color_code = 'X'
            if auxiliary_sign_code is None:
                auxiliary_sign_code = 'N'
            if sign_form_code is None:
                sign_form_code = 255

            sign_type = vehicle_traffic_sign_df[vehicle_traffic_sign_df['id'] == sign_code]['type'].values[0]
            sign_shape = vehicle_traffic_sign_shape_df[vehicle_traffic_sign_shape_df['id'] == sign_form_code]['shape'].values[0]
            sign_color = vehicle_traffic_sign_color_df[vehicle_traffic_sign_color_df['id'] == sign_color_code]['color'].values[0]
            auxiliary_sign_type = vehicle_traffic_sign_auxiliary_sign_df[vehicle_traffic_sign_auxiliary_sign_df['id'] == auxiliary_sign_code]['type'].values[0]
            traffic_sign_type_verbose = f'{sign_type}_Auxiliary_{auxiliary_sign_type}'

            draw_color = sign_color
            if sign_color == 'other':
                draw_color = 'purple'
            if sign_color == 'unknown':
                draw_color = 'pink'
            sign_dict[traffic_sign_type_verbose] = {'draw_color': draw_color}

            f.setAttributes(
                [dm_id, mesh_id, height, ground_height, sign_type, sign_shape, sign_color, variable_flag, speed_limit,
                 auxiliary_sign_type, traffic_sign_type_verbose])
            feature_list.append(f)

        vehicle_traffic_sign_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                               f'dmp_gen1_vehicle_traffic_sign',
                                                               feature_list, qgs_fields)
        rules = ()
        draw_width = 0.5
        line_style = 'solid'
        for traffic_sign_type_verbose in sign_dict:
            draw_color = sign_dict[traffic_sign_type_verbose]['draw_color']
            label = f'{traffic_sign_type_verbose}'
            exp = f'''traffic_sign_type_verbose = \'{traffic_sign_type_verbose}\''''
            rules += ((label, exp, line_style, draw_color, draw_width),)
        vehicle_traffic_sign_layer = apply_rule_based_symbol(rules, vehicle_traffic_sign_layer)

        return vehicle_traffic_sign_layer

    def query_tunnel_boundary_in_extent(self):
        query = f'''
                    select tunnel_boundary.dm_id, mesh_id, coordinate_string_ll
                    from dmp.tunnel_boundary 
                   '''
        qgs_fields = [QgsField('dm_id', QVariant.String), QgsField('mesh_id', QVariant.String)]
        g = QgsGeometry()
        feature_list = []
        response = make_query(self.conn, query, None)
        for row in response:
            dm_id = row[0]
            mesh_id = row[1]
            geom_string = row[2]
            geom_corner_pts = geom_string.split(';')
            point_list = []
            for geom_corner_pt in geom_corner_pts:
                lat, lon, h, alt = geom_corner_pt.split(':')[0:4]
                point_list.append(Point(float(lon), float(lat), float(alt)))
            geom = LineString(point_list).wkt
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([dm_id, mesh_id])
            feature_list.append(f)

        tunnel_boundary_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                          f'dmp_gen1_tunnel_boundary',
                                                          feature_list, qgs_fields)
        tunnel_boundary_layer = setLineLayerStyleToArrow(tunnel_boundary_layer, head_thickness=2)

        return tunnel_boundary_layer


@dataclass
class Extent:
    x_min: float
    y_min: float
    x_max: float
    y_max: float


if __name__ == '__main__':
    current_dir = pathlib.Path(__file__).parent.parent
    init_file = os.path.join(current_dir, 'user.ini')
    config = configparser.ConfigParser()
    config.read(init_file)
    if 'Customer' in config:
        host = config['Customer']['host']
        port = config['Customer']['port']
        db = config['Customer']['db']
        username = config['Customer']['username']
        password = config['Customer']['password']
    else:
        sys.exit('No connection')
    conn_data = {'host': host, 'db': db, 'port': port, 'username': username, 'password': password}
    conn = connect_to_db(conn_data['host'], conn_data['username'], conn_data['password'], conn_data['db'],
                         conn_data['port'])
    main_win_test = MainWinTest(conn)
    main_win_test.extent = Extent(129.92851, 32.76941, 129.93839, 32.77924)
    dmp_gen1_map_data = DMPGen1MapData(main_win_test)
    dmp_gen1_map_data.query_tunnel_boundary_in_extent()
