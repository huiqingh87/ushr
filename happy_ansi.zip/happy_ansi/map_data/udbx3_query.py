from .db_conn import make_query
from .udbx_enums import udbx_sign_types_df, udbx_lane_attr_type_df
from shapely.wkt import loads
from shapely import wkb


# True - NA
# False - Japan
def query_driving_side(conn):
    query = '''select driving_side from ushr_format.road_segment limit 1'''
    response = make_query(conn, query, None)
    row = response[0]
    region = row[0]

    return region


def query_lane_connections(conn):
    lane_connections_dict = {}
    query = '''select *
               from ushr_format.lane_connections
               where emergent_road_segment_id != 0'''
    response = make_query(conn, query, None)
    for row in response:
        incident_road_segment_id = row[0]
        incident_lane_number = row[1]
        emergent_road_segment_id = row[2]
        emergent_lane_number = row[3]

        if (incident_road_segment_id, incident_lane_number) not in lane_connections_dict:
            lane_connections_dict[(incident_road_segment_id, incident_lane_number)] = [
                (emergent_road_segment_id, emergent_lane_number)]
        else:
            lane_connections_dict[(incident_road_segment_id, incident_lane_number)].append(
                (emergent_road_segment_id, emergent_lane_number))
    return lane_connections_dict


def query_crossings(conn, crossing_type_id):
    crossing_dict = {}
    crossing_ind = 0
    query = f'''with lane_start_att as (
                            	select lanes.road_segment_id, lanes.lane_number, crossing_type_attribute & {crossing_type_id} as crossing_attribute,                            	
                            	max(lane_point_sequence_index) as max_index
                            	from ushr_format.lane_center_points 
                            	join ushr_format.lanes on lanes.road_segment_id = lane_center_points.road_segment_id
                            	where lane_center_points.lane_number = lanes.lane_number
                            	group by lanes.road_segment_id, lanes.lane_number
                            ), 
							lane_attr as (
                            select lane_start_att.road_segment_id, lane_start_att.lane_number, crossing_attribute, max_index,
                            array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
                            array_agg(lane_attribute_value & {crossing_type_id} order by lane_point_sequence_index) as vals
                            from lane_start_att
                            left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                            	and lane_start_att.lane_number = lane_attributes.lane_number
                            	and lane_attribute_type = 4 								
                            group by lane_start_att.road_segment_id, lane_start_att.lane_number, crossing_attribute, max_index
							)
							select *
							from lane_attr
							where crossing_attribute <> 0 or (crossing_attribute = 0 and vals && array[{crossing_type_id}])
            '''
    response = make_query(conn, query, None)
    for row in response:
        segment_id = row[0]
        lane_number = row[1]
        initial_stop_bar_attribute = row[2]
        lane_max_index = row[3]
        change_inds = row[4]
        change_vals = row[5]

        pre_crossing_dict = {0: initial_stop_bar_attribute}
        for i, change_ind in enumerate(change_inds):
            pre_crossing_dict[change_ind] = change_vals[i]
        stop_bar_start = False
        index_start = 0
        for ind in pre_crossing_dict:
            if pre_crossing_dict[ind] != 0 and not stop_bar_start:
                index_start = ind
                stop_bar_start = True
            if pre_crossing_dict[ind] == 0 and stop_bar_start:
                index_end = ind
                stop_bar_start = False
                crossing_dict[crossing_ind] = {'segment_id': segment_id, 'lane_number': lane_number,
                                               'index_range': [index_start, index_end],
                                               'lane_max_index': lane_max_index, 'start_pt': None}
                crossing_ind += 1
        if stop_bar_start:
            crossing_dict[crossing_ind] = {'segment_id': segment_id, 'lane_number': lane_number,
                                           'index_range': [index_start, lane_max_index],
                                           'lane_max_index': lane_max_index, 'start_pt': None}
            crossing_ind += 1
    return crossing_dict


def query_signs(conn, srid):
    sign_dict = {}
    sign_lane_mapping_dict = {}
    sign_lane_mapping_dict2 = {}
    query = '''select signs.sign_id, sign_face_azimuth, sign_face_elevation, 
                type, centroid_position, bottom_left_corner_position,
               top_left_corner_position, top_right_corner_position, bottom_right_corner_position,
               road_segment_id, lane_number, lane_point_sequence_index, st_transform(centroid_position, %s)
               from ushr_format.signs
               join ushr_format.sign_lane_mapping on sign_lane_mapping.sign_id = signs.sign_id
               where bottom_left_corner_position is not null'''
    response = make_query(conn, query, (srid,))
    sign_lane_mapping_ind = 0
    for row in response:
        sign_id, sign_face_azimuth, sign_face_elevation, type_id, centroid_position, bl_corner, \
               tl_corner, tr_corner, br_corner, \
               segment_id, lane_number, lane_point_sequence_index, centroid_utm = row
        sign_type = udbx_sign_types_df[udbx_sign_types_df['id'] == type_id]['type'].values[0]
        centroid = wkb.loads(centroid_position, hex=True)
        bl_corner = wkb.loads(bl_corner, hex=True)
        tl_corner = wkb.loads(tl_corner, hex=True)
        tr_corner = wkb.loads(tr_corner, hex=True)
        br_corner = wkb.loads(br_corner, hex=True)
        centroid_utm = wkb.loads(centroid_utm, hex=True)
        if sign_id not in sign_dict:
            sign_lane_mapping_ind = 0
            sign_dict[sign_id] = {'type': sign_type, 'centroid': centroid, 'centroid_utm': centroid_utm,
                                  'bl_corner': bl_corner, 'tl_corner': tl_corner, 'tr_corner': tr_corner,
                                  'br_corner': br_corner}
            sign_lane_mapping_dict[sign_id, sign_lane_mapping_ind] = {'segment_id': segment_id,
                                                                      'lane_number': lane_number,
                                                                      'lane_point_index': lane_point_sequence_index}
            sign_lane_mapping_dict2[sign_id] = [{'segment_id': segment_id,
                                                 'lane_number': lane_number,
                                                 'lane_point_index': lane_point_sequence_index}]
        else:
            sign_lane_mapping_ind += 1
            sign_lane_mapping_dict[sign_id, sign_lane_mapping_ind] = {'segment_id': segment_id,
                                                                      'lane_number': lane_number,
                                                                      'lane_point_index': lane_point_sequence_index}
            sign_lane_mapping_dict2[sign_id].append({'segment_id': segment_id,
                                                     'lane_number': lane_number,
                                                     'lane_point_index': lane_point_sequence_index})

    return sign_dict, sign_lane_mapping_dict, sign_lane_mapping_dict2


def query_nearby_signs(conn, thold):
    query = '''with signs as (
                	select sign_id, st_setsrid(centroid_position, 4326)::geography as centroid
                	from ushr_format.signs
                	where bottom_left_corner_position is not null
                )
                select sign1.sign_id, sign2.sign_id , st_distance(sign1.centroid, sign2.centroid)
                from signs sign1
                join signs sign2 on sign1.sign_id < sign2.sign_id
                where st_distance(sign1.centroid, sign2.centroid) < %s'''
    response = make_query(conn, query, (thold,))
    nearby_sign_dict = {}
    for row in response:
        sign1_id, sign2_id, distance = row
        nearby_sign_dict[sign1_id, sign2_id] = distance
    return nearby_sign_dict


def query_road_segments(conn):
    query = '''select road_segment_id, number_of_lanes, road_type, driving_side, road_division, measurement_units
               from ushr_format.road_segment'''
    response = make_query(conn, query, None)
    road_segment_dict = {}
    for row in response:
        segment_id, number_of_lanes, road_type, driving_side, road_division, measurement_units = row
        road_segment_dict[segment_id] = {'number_of_lanes': number_of_lanes, 'road_type': road_type,
                                         'driving_side': driving_side, 'road_division': road_division,
                                         'measurement_units': measurement_units}
    return road_segment_dict


def query_lane_center_points(conn, segment_id_list, srid):
    query = f'''select road_segment_id, lane_number, array_agg(st_astext(position) order by lane_point_sequence_index),
                array_agg(st_astext(st_transform(position, {srid})) order by lane_point_sequence_index)
                from ushr_format.lane_center_points
                where road_segment_id = any(%s)
                group by road_segment_id, lane_number'''
    response = make_query(conn, query, (segment_id_list,))
    lane_center_points_dict = {}
    for row in response:
        segment_id, lane_number, geom_list, utm_geom_list = row
        wgs_point_list, utm_point_list = [], []
        for geom in geom_list:
            wgs_point_list.append(loads(geom))
        for geom in utm_geom_list:
            utm_point_list.append(loads(geom))
        if segment_id not in lane_center_points_dict:
            lane_center_points_dict[segment_id] = {lane_number: {
                'wgs_point_list': wgs_point_list, 'utm_point_list': utm_point_list}}
        else:
            lane_center_points_dict[segment_id].update({lane_number: {
                'wgs_point_list': wgs_point_list, 'utm_point_list': utm_point_list}})

    return lane_center_points_dict


def query_lane_line_points(conn, segment_id_list, srid):
    query = f'''select road_segment_id, lane_line_ordinal_id,                 
                array_agg(st_astext(position) order by lane_line_point_sequence_index), 
                array_agg(st_astext(st_transform(position, {srid})) order by lane_line_point_sequence_index)
                from ushr_format.lane_line_points
                where road_segment_id = any(%s)
                group by road_segment_id, lane_line_ordinal_id'''
    response = make_query(conn, query, (segment_id_list,))
    lane_line_points_dict = {}
    for row in response:
        segment_id, lane_line_ordinal_id, geom_list, utm_geom_list = row[0:4]
        wgs_point_list, utm_point_list = [], []
        for geom in geom_list:
            wgs_point_list.append(loads(geom))
        for geom in utm_geom_list:
            utm_point_list.append(loads(geom))
        if segment_id not in lane_line_points_dict:
            lane_line_points_dict[segment_id] = {
                lane_line_ordinal_id: {'wgs_point_list': wgs_point_list, 'utm_point_list': utm_point_list}}
        else:
            lane_line_points_dict[segment_id].update({
                lane_line_ordinal_id: {'wgs_point_list': wgs_point_list, 'utm_point_list': utm_point_list}})
    return lane_line_points_dict


def query_road_edge_points(conn, segment_id_list, srid):
    query = f'''select road_segment_id, road_edge_side,                 
                array_agg(st_astext(position) order by road_edge_point_sequence_index), 
                array_agg(st_astext(st_transform(position, {srid})) order by road_edge_point_sequence_index)
                from ushr_format.road_edge_points
                where road_segment_id = any(%s)
                group by road_segment_id, road_edge_side'''
    response = make_query(conn, query, (segment_id_list,))
    road_edge_points_dict = {}
    for row in response:
        segment_id, road_edge_side, geom_list, utm_geom_list = row
        wgs_point_list, utm_point_list = [], []
        for geom in geom_list:
            wgs_point_list.append(loads(geom))
        for geom in utm_geom_list:
            utm_point_list.append(loads(geom))
        road_edge_points_dict[segment_id, road_edge_side] = {'wgs_point_list': wgs_point_list,
                                                             'utm_point_list': utm_point_list}
    return road_edge_points_dict


def query_left_road_edge_first_pt_xy(conn):
    query = '''select road_segment_id, st_x(position), st_y(position)
               from ushr_format.road_edge_points
               where road_edge_side = false
               and road_edge_point_sequence_index = 0'''
    left_road_edge_first_pt_xy_dict = {}
    response = make_query(conn, query, None)
    for row in response:
        road_segment_id = row[0]
        lon = row[1]
        lat = row[2]
        left_road_edge_first_pt_xy_dict[road_segment_id] = {'lon': lon, 'lat': lat}
    return left_road_edge_first_pt_xy_dict


def query_lane_attr(conn, lane_attr_type_id):
    lane_attribute = \
        udbx_lane_attr_type_df[udbx_lane_attr_type_df['id'] == lane_attr_type_id]['lane_attr_type'].values[0]
    query = f'''with lane_start_att as (
                    	select lanes.road_segment_id, lanes.lane_number, {lane_attribute},
                    	max(lane_point_sequence_index) as max_index
                    	from ushr_format.lane_center_points 
                    	join ushr_format.lanes on lanes.road_segment_id = lane_center_points.road_segment_id 
                    	where lane_center_points.lane_number = lanes.lane_number
                    	group by lanes.road_segment_id, lanes.lane_number
                    )
                    select lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}, max_index,
                    array_agg(lane_attributes.lane_point_sequence_index order by lane_point_sequence_index) as inds, 
                    array_agg(lane_attribute_value order by lane_point_sequence_index) as vals
                    from lane_start_att
                    left join ushr_format.lane_attributes on lane_start_att.road_segment_id = lane_attributes.road_segment_id
                    	and lane_start_att.lane_number = lane_attributes.lane_number
                    	and lane_attributes.lane_attribute_type = {lane_attr_type_id}
                    group by lane_start_att.road_segment_id, lane_start_att.lane_number, {lane_attribute}, max_index
            '''
    response = make_query(conn, query, None)
    lane_attr_dict = {}
    for row in response:
        segment_id = row[0]
        lane_number = row[1]
        init_val = row[2]
        max_index = row[3]
        change_inds = row[4]
        change_vals = row[5]
        lane_attr_dict[segment_id, lane_number] = {'init_val': init_val,
                                                   'max_index': max_index,
                                                   'change_inds': change_inds,
                                                   'change_vals': change_vals}
    return lane_attr_dict


def query_lane_line_attr(conn):
    query = '''with line_start_att as (
                    	select lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id, 
						lane_line_type_attribute, lane_line_color_attribute
                    	from ushr_format.lane_lines 
                    	group by lane_lines.road_segment_id, lane_lines.lane_line_ordinal_id
                    )
                    select line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id, 
                    lane_line_type_attribute, lane_line_color_attribute,
                    array_agg(lane_line_attributes.lane_line_point_sequence_index order by lane_line_point_sequence_index) as inds, 
					array_agg(lane_line_attribute_type order by lane_line_point_sequence_index) as attr_types,
                    array_agg(lane_line_attribute_value order by lane_line_point_sequence_index) as attr_vals
                    from line_start_att
                    left join ushr_format.lane_line_attributes on line_start_att.road_segment_id = lane_line_attributes.road_segment_id
                    	and line_start_att.lane_line_ordinal_id = lane_line_attributes.lane_line_ordinal_id    
                    	and lane_line_attribute_type in (0, 1)            	
                    group by line_start_att.road_segment_id, line_start_att.lane_line_ordinal_id,
					lane_line_type_attribute, lane_line_color_attribute'''
    response = make_query(conn, query, None)
    lane_line_attr_dict = {}
    for row in response:
        segment_id = row[0]
        lane_line_ordinal_id = row[1]
        lane_line_type_init_val = row[2]
        lane_line_color_init_val = row[3]
        change_inds = row[4]
        change_types = row[5]
        change_vals = row[6]
        lane_line_attr_dict[segment_id, lane_line_ordinal_id] = \
            {'lane_line_type_init_val': lane_line_type_init_val, 'lane_line_color_init_val': lane_line_color_init_val,
             'change_inds': change_inds, 'change_types': change_types, 'change_vals': change_vals}
    return lane_line_attr_dict


def query_road_edge_type(conn):
    query = '''with edge_start_att as (
                    	select road_edges.road_segment_id, road_edges.road_edge_side, road_edge_type
                    	from ushr_format.road_edges                    	
                    )
                    select edge_start_att.road_segment_id, edge_start_att.road_edge_side, edge_start_att.road_edge_type,
                    array_agg(road_edge_attributes.road_edge_point_sequence_index order by road_edge_point_sequence_index) as inds, 
					array_agg(road_edge_attributes.road_edge_type order by road_edge_point_sequence_index) as road_edge_types                    
                    from edge_start_att
                    left join ushr_format.road_edge_attributes on edge_start_att.road_segment_id = road_edge_attributes.road_segment_id
                    	and edge_start_att.road_edge_side = road_edge_attributes.road_edge_side       						
                    group by edge_start_att.road_segment_id, edge_start_att.road_edge_side, edge_start_att.road_edge_type'''
    response = make_query(conn, query, None)
    road_edge_type_dict = {}
    for row in response:
        segment_id, road_edge_side, init_road_edge_type, change_inds, change_vals = row[0:5]
        road_edge_type_dict[segment_id, road_edge_side] = {'init_val': init_road_edge_type,
                                                           'change_inds': change_inds, 'change_vals': change_vals}
    return road_edge_type_dict


def query_lane_line_ordinal_id(conn):
    query = '''select road_segment_id, lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id
               from ushr_format.lanes'''
    response = make_query(conn, query, None)
    lane_line_ordinal_id_dict = {}
    for row in response:
        segment_id, lane_number, left_lane_line_ordinal_id, right_lane_line_ordinal_id = row[0:4]
        lane_line_ordinal_id_dict[segment_id, lane_number] = {'left_lane_line_ordinal_id': left_lane_line_ordinal_id,
                                                              'right_lane_line_ordinal_id': right_lane_line_ordinal_id}
    return lane_line_ordinal_id_dict


def query_segment(conn):
    query = '''select road_segment_id, number_of_lanes, road_type, road_division
               from ushr_format.road_segment'''
    response = make_query(conn, query, None)
    segment_dict = {}
    for row in response:
        segment_id, numlns, road_type, road_division = row[0:4]
        segment_dict[segment_id] = {'numlns': numlns, 'road_type': road_type, 'road_division': road_division}
    return segment_dict


def query_pm(conn, srid=6697):
    query = f'''select pavement_marking_id, marking_type, 
               st_astext(centroid_position), st_astext(pavement_marking_position), 
               st_astext(st_transform(pavement_marking_position, {srid}))
               from ushr_format.pavement_markings'''
    response = make_query(conn, query, None)
    pm_dict = {}
    for row in response:
        pavement_marking_id, marking_type_id, centroid, geom, utm_geom = row
        pm_dict[pavement_marking_id] = {'marking_type_id': marking_type_id, 'centroid': centroid,
                                        'geom': geom, 'utm_geom': utm_geom}
    return pm_dict


