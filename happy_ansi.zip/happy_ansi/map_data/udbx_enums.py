import pandas as pd


udbx_sign_super_type_df = pd.DataFrame(
    {
        'name': ['RTD', 'non-RTD']
    }
)

udbx_sign_types_df = pd.DataFrame(
    {
        'id': range(1, 204),
        'type': ["Stop",
                 "Yield",
                 "Red Traffic Light (excluding RR xing)",
                 "Yellow Traffic Light",
                 "Single Left Turn Light",
                 "Single Right Turn Light",
                 "Single Straight Light",
                 "Horizontal Two Traffic Light",
                 "Vertical Two Traffic Light",
                 "Horizontal Three Traffic Light",
                 "Vertical Three Traffic Light",
                 "4+ Horizontal Traffic Light",
                 "4+ Vertical Traffic Light",
                 "Railroad Crossing Light",
                 "Railroad Crossing Sign",
                 "Interstate Route",
                 "Overhead Directions",
                 "Street Name",
                 "Bridge Height",
                 "Lane Ends",
                 "Freeway Ends",
                 "Rest Area",
                 "Highway Exit",
                 "Digital Sign",
                 "No Turns",
                 "No Left Turn",
                 "No Right Turn",
                 "No Turn on Red",
                 "Left and Right Turn Only",
                 "Left and Straight Only",
                 "Left Turn Only",
                 "Left and U-Turn Only",
                 "Left Straight and U-Turn Only",
                 "Right and Straight Only",
                 "Right Turn Only",
                 "Roundabout Left and Straight Only",
                 "Roundabout Left Only",
                 "Roundabout Left Straight and U-Turn Only",
                 "Roundabout Left Right and Straight Only",
                 "Roundabout Right and Straight Only",
                 "Roundabout Straight Only",
                 "Straight Only",
                 "U-Turn Only",
                 "Keep Left",
                 "Keep Right",
                 "One Way Left",
                 "One Way Right",
                 "One Way Straight",
                 "Circular Intersection",
                 "Dead End",
                 "Wrong Way",
                 "Authorized Vehicle",
                 "Incident Management",
                 "Electronic Toll",
                 "Other – Turn",
                 "Other – Red – Regulatory",
                 "Other – White – Regulatory",
                 "Other – Black – Warning",
                 "Other – Yellow – Warning",
                 "Other – Blue – Information",
                 "Other – Brown – Information",
                 "Other – Green – Information",
                 "Other – Orange – Temporary",
                 "Other – Complementary",
                 "Unassigned",
                 "Maximum Speed Limit 5",
                 "Maximum Speed Limit 10",
                 "Maximum Speed Limit 15",
                 "Maximum Speed Limit 20",
                 "Maximum Speed Limit 25",
                 "Maximum Speed Limit 30",
                 "Maximum Speed Limit 35",
                 "Maximum Speed Limit 40",
                 "Maximum Speed Limit 45",
                 "Maximum Speed Limit 50",
                 "Maximum Speed Limit 55",
                 "Maximum Speed Limit 60",
                 "Maximum Speed Limit 65",
                 "Maximum Speed Limit 70",
                 "Maximum Speed Limit 75",
                 "Maximum Speed Limit 80",
                 "Maximum Speed Limit 85",
                 "Maximum Speed Limit 90",
                 "Maximum Speed Limit 95",
                 "Maximum Speed Limit 100",
                 "Maximum Speed Limit 105",
                 "Maximum Speed Limit 110",
                 "Maximum Speed Limit 115",
                 "Maximum Speed Limit 120",
                 "Maximum Speed Limit 125",
                 "Maximum Speed Limit 130",
                 "Minimum Speed Limit 5",
                 "Minimum Speed Limit 10",
                 "Minimum Speed Limit 15",
                 "Minimum Speed Limit 20",
                 "Minimum Speed Limit 25",
                 "Minimum Speed Limit 30",
                 "Minimum Speed Limit 35",
                 "Minimum Speed Limit 40",
                 "Minimum Speed Limit 45",
                 "Minimum Speed Limit 50",
                 "Minimum Speed Limit 55",
                 "Minimum Speed Limit 60",
                 "Minimum Speed Limit 65",
                 "Minimum Speed Limit 70",
                 "Minimum Speed Limit 75",
                 "Minimum Speed Limit 80",
                 "Minimum Speed Limit 85",
                 "Minimum Speed Limit 90",
                 "Minimum Speed Limit 95",
                 "Minimum Speed Limit 100",
                 "Minimum Speed Limit 105",
                 "Minimum Speed Limit 110",
                 "Minimum Speed Limit 115",
                 "Minimum Speed Limit 120",
                 "Minimum Speed Limit 125",
                 "Minimum Speed Limit 130",
                 "Truck Speed Limit 5",
                 "Truck Speed Limit 10",
                 "Truck Speed Limit 15",
                 "Truck Speed Limit 20",
                 "Truck Speed Limit 25",
                 "Truck Speed Limit 30",
                 "Truck Speed Limit 35",
                 "Truck Speed Limit 40",
                 "Truck Speed Limit 45",
                 "Truck Speed Limit 50",
                 "Truck Speed Limit 55",
                 "Truck Speed Limit 60",
                 "Truck Speed Limit 65",
                 "Truck Speed Limit 70",
                 "Truck Speed Limit 75",
                 "Truck Speed Limit 80",
                 "Truck Speed Limit 85",
                 "Truck Speed Limit 90",
                 "Truck Speed Limit 95",
                 "Truck Speed Limit 100",
                 "Truck Speed Limit 105",
                 "Truck Speed Limit 110",
                 "Truck Speed Limit 115",
                 "Truck Speed Limit 120",
                 "Truck Speed Limit 125",
                 "Truck Speed Limit 130",
                 "Night Speed Limit 5",
                 "Night Speed Limit 10",
                 "Night Speed Limit 15",
                 "Night Speed Limit 20",
                 "Night Speed Limit 25",
                 "Night Speed Limit 30",
                 "Night Speed Limit 35",
                 "Night Speed Limit 40",
                 "Night Speed Limit 45",
                 "Night Speed Limit 50",
                 "Night Speed Limit 55",
                 "Night Speed Limit 60",
                 "Night Speed Limit 65",
                 "Night Speed Limit 70",
                 "Night Speed Limit 75",
                 "Night Speed Limit 80",
                 "Night Speed Limit 85",
                 "Night Speed Limit 90",
                 "Night Speed Limit 95",
                 "Night Speed Limit 100",
                 "Night Speed Limit 105",
                 "Night Speed Limit 110",
                 "Night Speed Limit 115",
                 "Night Speed Limit 120",
                 "Night Speed Limit 125",
                 "Night Speed Limit 130",
                 "Warning Speed Limit 5",
                 "Warning Speed Limit 10",
                 "Warning Speed Limit 15",
                 "Warning Speed Limit 20",
                 "Warning Speed Limit 25",
                 "Warning Speed Limit 30",
                 "Warning Speed Limit 35",
                 "Warning Speed Limit 40",
                 "Warning Speed Limit 45",
                 "Warning Speed Limit 50",
                 "Warning Speed Limit 55",
                 "Warning Speed Limit 60",
                 "Warning Speed Limit 65",
                 "Warning Speed Limit 70",
                 "Warning Speed Limit 75",
                 "Warning Speed Limit 80",
                 "Warning Speed Limit 85",
                 "Warning Speed Limit 90",
                 "Warning Speed Limit 95",
                 "Warning Speed Limit 100",
                 "Warning Speed Limit 105",
                 "Warning Speed Limit 110",
                 "Warning Speed Limit 115",
                 "Warning Speed Limit 120",
                 "Warning Speed Limit 125",
                 "Warning Speed Limit 130",
                 '4 Horizontal Traffic Light',
                 '4 Vertical Traffic Light',
                 '5 Horizontal Traffic Light',
                 '5 Vertical Traffic Light',
                 '6+ Horizontal Traffic Light',
                 '6+ Vertical Traffic Light',
                 'Single Other Traffic Light',
                 'Other Traffic Light'
                 ],
        'super_type': ['non-RTD',
'non-RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'non-RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD',
'RTD'
]
    }
)

udbx_sign_shape_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10],
        'shape': ['Rectangular',
                  'Circular',
                  'Triangle Point Up',
                  'Triangle Point Down',
                  'Square',
                  'Shield',
                  'Diamond',
                  'Polygonal',
                  'Compound',
                  'Crossbuck',
                  'Other']
    }
)

udbx_pm_type_df = pd.DataFrame(
    {
        'id': range(1, 118),
        'type': ['Left and Right Arrow',
                 'Left and Straight Arrow',
                 'Left Arrow',
                 'Left and U - Turn Arrow',
                 'Left Right and Straight Arrow',
                 'Left Straight and U - Turn Arrow',
                 'Merge Arrow Left',
                 'Merge Arrow Right',
                 'Right and Straight Arrow',
                 'Right Arrow',
                 'Roundabout Left and Straight Arrow',
                 'Roundabout Left Arrow',
                 'Roundabout Left Right and Straight Arrow',
                 'Roundabout Left Straight and U - Turn Arrow',
                 'Roundabout Right and Straight Arrow',
                 'Roundabout Straight Arrow',
                 'Straight Arrow',
                 'U - Turn Arrow',
                 'Lane Number',
                 'Speed - 005',
                 'Speed - 010',
                 'Speed - 015',
                 'Speed - 020',
                 'Speed - 025',
                 'Speed - 030',
                 'Speed - 035',
                 'Speed - 040',
                 'Speed - 045',
                 'Speed - 050',
                 'Speed - 055',
                 'Speed - 060',
                 'Speed - 065',
                 'Speed - 070',
                 'Speed - 075',
                 'Speed - 080',
                 'Speed - 085',
                 'Speed - 090',
                 'Speed - 095',
                 'Speed - 100',
                 'Speed - 105',
                 'Speed - 110',
                 'Speed - 115',
                 'Speed - 120',
                 'Speed - 125',
                 'Speed - 130',
                 'Toll Speed',
                 'Bicycle',
                 'Express Toll',
                 'HOV Diamond',
                 'OK',
                 'Road Shield',
                 'RXR',
                 'Yield Triangles',
                 'AHEAD',
                 'BELT',
                 'BIKE',
                 'BR',
                 'BRIDGE',
                 'BUS',
                 'BUSES',
                 'CANADA',
                 'CAR',
                 'CARS',
                 'CASH',
                 'CLEAR',
                 'CRUISE',
                 'EB',
                 'EXIT',
                 'E - Z',
                 'FASTRAK',
                 'FWY',
                 'HWY',
                 'KEEP',
                 'LANE',
                 'LANES',
                 'LOW',
                 'MERGE',
                 'MPH',
                 'NB',
                 'NO',
                 'NORTH',
                 'ONLY',
                 'PASS',
                 'PED',
                 'PKWY',
                 'POOL',
                 'SB',
                 'SCHOOL',
                 'SIGNAL',
                 'SLOW',
                 'SOUTH',
                 'STOP',
                 'SUN',
                 'TO',
                 'TRUCK',
                 'TRUCKS',
                 'WB',
                 'X - ING',
                 'YIELD',
                 'Other',
                 'Stop Bar',
                 'Pedestrian Crossing',
                 'Xplus',
                 'Queuing Bar',
                 'No Stopping',
                 'Bicycle No Entry',
                 'Priority Road Ahead',
                 'End Regulation',
                 'Turn Method',
                 'Parallel Parking',
                 'Perpendicular Parking',
                 'Regular Car Lane',
                 'Special Vehicle Lane',
                 'Towing Vehicle Lane',
                 'ETC Guide',
                 'ETC',
                 'Fire Hydrant']
    }
)

udbx3_road_type_df = pd.DataFrame(
    {
        'id': range(0, 10),
        'type': ['Controlled Access', 'Non-Controlled Access', 'Interchange', 'Ramp', 'Not Used',
                 'Not Used', 'Local', 'Not Used', 'Turn Maneuver', 'Roundabout'],
        'draw_color': ['green', 'blue', 'orange', 'yellow', 'black',
                       'black', 'purple', 'black', 'pink', 'navy']
    }
)

udbx3_road_division_df = pd.DataFrame(
    {
        'boolean': [False, True],
        'division': ['Non-Divided', 'Divided'],
        'draw_color': ['brown', 'lime']
    }
)

udbx_line_att_type_df = pd.DataFrame(
    {
        'id': range(0, 7),
        'line_att_type': ['line_type', 'line_color', 'line_width',
                          'reflective_markings_attribute', 'pavement_striping_present_attribute',
                          'deceleration_marking_present', 'lane_line_geometry_centered'],
        'shp_line_att_type': ['line_type', 'line_color', 'line_width',
                              'refl_mk', 'pm_strip', 'decel_mk', 'line_ctr']
    }
)

udbx_reflective_markings_df = pd.DataFrame(
    {
        'id': [0, 1],
        'type': ['False', 'True'],
        'draw_color': ['black', 'yellow']
    }
)

udbx_pavement_striping_present_df = pd.DataFrame(
    {
        'id': range(0, 4),
        'type': [None, 'Left', 'Right', 'Left & Right'],
        'draw_color': [None, 'green', 'red', 'orange']
    }
)

udbx_deceleration_marking_present_df = pd.DataFrame(
    {
        'id': range(0, 4),
        'type': [None, 'Left', 'Right', 'Left & Right'],
        'draw_color': [None, 'blue', 'green', 'cyan']
    }
)

udbx_lane_line_geometry_centered_df = pd.DataFrame(
    {
        'id': [0, 1],
        'type': ['False', 'True'],
        'draw_color': ['orange', 'black']
    }
)

udbx_line_type_df = pd.DataFrame(
    {
        'id': range(0, 9),
        'type': ['Virtual', 'Single Solid Paint Line', 'Single Dashed Paint Line',
                 'Double Paint Line, Left Solid, Right Solid', 'Double Paint Line, Left Dashed, Right Solid',
                 'Double Paint Line, Left Solid, Right Dashed', 'Double Paint Line, Left Dashed, Right Dashed',
                 'Triple Paint Line All Solid', 'Other'],
        'stroke_style': ['dot', 'solid', 'dash', 'solid', 'dash', 'dash', 'dash', 'solid', 'solid']
    }
)

udbx_line_color_df = pd.DataFrame(
    {
        'id': range(0, 6),
        'name': ['No Color', 'White', 'Yellow', 'White/Yellow/Yellow', 'Yellow/Yellow/White', 'Other'],
        'draw_color': ['red', 'white', 'yellow', 'cyan', 'orange', 'pink']
    }
)

udbx_line_width_df = pd.DataFrame(
    {
        'id': range(0, 4),
        'name': ['No Width', 'Thin', 'Thick', 'Other'],
        'width_value': [0, 10, 20, 999],
        'draw_width': [0.05, 0.1, 0.2, 0.4]
    }
)


def get_line_type_comb():
    type_list = []
    for type_ in udbx_line_type_df['type']:
        if type_ == 'Virtual':
            type_list.append(type_)
        elif type_ != 'Other':
            if type_ in ('Single Solid Paint Line', 'Single Dashed Paint Line'):
                color_list = ['White', 'Yellow', 'Other']
                width_list = ['Thin', 'Thick']
            elif type_ in ('Double Paint Line, Left Solid, Right Solid', 'Double Paint Line, Left Dashed, Right Solid',
                           'Double Paint Line, Left Solid, Right Dashed', 'Double Paint Line, Left Dashed, Right Dashed'):
                color_list = ['White', 'Yellow', 'Other']
                width_list = ['Thin', 'Thick']
            else:
                color_list = ['White/Yellow/Yellow', 'Yellow/Yellow/White', 'Other']
                width_list = ['Thin', 'Thick']
            for color_ in color_list:
                for width_ in width_list:
                    type_list.append(f'{type_}_{color_}_{width_}')
        else:
            type_list.append('Other')
    return type_list


udbx_lane_attr_type_df = pd.DataFrame(
    {
        'id': range(0, 9),
        'lane_attr_type': ['lane_type_attribute', 'speed_limit_attribute', 'left_change_allowed_attribute',
                           'right_change_allowed_attribute', 'crossing_type_attribute',
                           'regulatory_traffic_device_attribute', 'minimum_speed_limit', 'parking_lane_type',
                           'truck_speed_limit'],
        'shp_lane_attr_type': ['lane_type_attribute', 'speed_limit_attribute', 'left_chg',
                               'right_chg', 'xing_type',
                               'rtd', 'minimum_speed_limit', 'parking_lane_type',
                               'truck_speed_limit'],
        'bitmask_type': [True, False, False, False, True, True, False, False, False]
    }
)

udbx_lane_type_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 4, 8,
               16, 32, 64, 128, 256,
               512, 1024, 2048, 4096, 8192, 16384],
        'type': ['Not Used', 'Normal Driving Lane', 'HOV Lane', ' Bidirectional Lane', 'Restricted Use Vehicle Lane',
                 'Toll Booth Lane', 'Convertible To Shoulder', 'Turn Only Lane', 'Other', 'Autopay Toll Lane',
                 'Bicycle Lane', 'Express Lane', 'Parking Lane', 'Emergency Lane', 'Streetcar Lane', 'Not Used'],
        'draw_color': ['black', 'green', 'white', 'magenta', 'orange',
                       'yellow', 'brown', 'pink', 'purple', 'gray',
                       'blue', 'lime', 'cyan', 'red', 'navy', 'black']
    }
)

udbx_lane_category_df = pd.DataFrame(
    {
        'id': [0, 1],
        'category': ['lane_add_remove_type', 'lane_accelerating_decelerating']
    }
)

udbx_lane_add_remove_type_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 4, 5, 6],
        'type': ['Continuing Lane', 'Added Lane', 'Ending Lane',
                 'Continuing Lane, Equal', 'Added Lane, Equal', 'Ending Lane, Equal'],
        'draw_color': ['white', 'green', 'red', 'blue', 'lime', 'orange']
    }
)

udbx_acc_dec_type_df = pd.DataFrame(
    {
        'id': [1, 0, -1],
        'type': ['Accelerating Lane', 'Accelerating & Decelerating Lane', 'Decelerating Lane'],
        'draw_color': ['green', 'orange', 'red']
    }
)


udbx_road_edge_side_df = pd.DataFrame(
    {
        'boolean': [False, True],
        'side': ['Left', 'Right']
    }
)

udbx_road_edge_type_df = pd.DataFrame(
    {
        'id': range(0, 8),
        'type': ['Surface Change', 'Curb', 'Physical Barrier', 'Movable Barrier', 'Pole', 'Paint Line', 'Virtual', 'Other'],
        'draw_color': ['aqua', 'magenta', 'brown', 'coffee', 'orange', 'blue', 'red', 'pink']
    }
)

udbx_lane_change_allowed_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 3],
        'type': ['no left no right', 'left only', 'right only', 'left & right'],
        'draw_color': ['red', 'blue', 'yellow', 'green']
    }
)

udbx_left_right_change_allowed_df = pd.DataFrame(
    {
        'id': [0, 1],
        'type': ['not allowed', 'allowed'],
        'draw_color': ['red', 'green']
    }
)

udbx_crossing_type_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 4, 8, 16, 32, 64, 128, 256, 512, 1024, 2048, 4096, 8192, 16384],
        'type': ['No Crossings', 'Overhead Bridge/Overpass', 'Overhead Tunnel', 'Overhead Sign/Gantry', 'Toll Structure',
                 'Stop Bar', 'At Grade Road Crossing', 'At Grade Pedestrian', 'At Grade Movable Bridge', 'At Grade Authorized Vehicle',
                 'At Grade Access Road Only', 'At Grade Railroad Crossing', 'Under Grade Bridge', 'At Grade Access Driveway',
                 'Not Used', 'Not Used'],
        'draw_color': ['white', 'gray', 'brown', 'pink', 'green', 'red', 'purple', 'orange', 'blue', 'yellow',
                       'navy', 'magenta', 'coffee', 'cyan', 'black', 'black'],
        'length_range': [None, [1, 99999], [1, 99999], [1, 5], [5, 100], [1, 2], [5, 100], [2, 10], None, None, [2, 50],
                         [2, 20], None, None, None, None]
    }
)

udbx_rtd_type_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 4],
        'type': ['No RTD', 'Stop Sign', 'Yield Sign', 'Traffic Light'],
        'draw_color': ['white', 'orange', 'yellow', 'red']
    }
)


special_shoulder_df = pd.DataFrame(
    {
        'type': ['obstructed_shoulder', 'shared_use_shoulder'],
        'draw_color': ['orange', 'yellow']
    }
)

