import pandas as pd
from enum import Enum


class CrossingTypeColor(Enum):
    RC_AG_RESTRICTIVE_GATE = 'darkRed'
    RC_AG_ROAD = 'purple'
    RC_AG_RAILROAD = 'magenta'
    RC_AG_PEDESTRIAN_BYCYCLE = 'orange'
    RC_AG_ACCESS_ONLY = 'navy'
    RC_AG_AUTHORIZED_VEHICLE_ACCESS = 'yellow'
    RC_AG_TOLL_STRUCTURE = 'green'
    RC_AG_STOP_BAR = 'red'
    RC_AG_MOVABLE_BRIDGE = 'blue'
    RC_AG_SPEED_BUMP = 'darkYellow'
    RC_AG_CONSTRUCTION = 'darkOrange'
    RC_OH_OVERPASS_BRIDGE = 'gray'
    RC_OH_OVERHEAD_SIGN = 'pink'
    RC_OH_TUNNEL = 'brown'
    RC_UG_ON_BRIDGE = 'darkGray'
    RC_AG_DRIVEWAY_ACCESS = 'darkNavy'


# NA
class RoadType(Enum):
    CONTROLLED_ACCESS_DIVIDED                           = 1
    INTERCHANGE_LINK                                    = 2
    NON_CONTROLLED_ACCESS_DIVIDED                       = 3
    CONTROLLED_ACCESS_NON_DIVIDED                       = 4
    ACCESS_RAMP                                         = 5
    NON_CONTROLLED_ACCESS_NON_DIVIDED                   = 6
    LOCAL_DIVIDED                                       = 7
    LOCAL_NON_DIVIDED                                   = 8
    CONTROLLED_ACCESS_DIVIDED_COLLECTOR                 = 9
    BI_DIRECTIONAL_CONTROLLED_ACCESS_DIVIDED            = 145
    BI_DIRECTIONAL_CONTROLLED_ACCESS_NON_DIVIDED        = 146
    BI_DIRECTIONAL_NON_CONTROLLED_ACCESS_DIVIDED        = 147
    BI_DIRECTIONAL_NON_CONTROLLED_ACCESS_NON_DIVIDED    = 148
    TURN_MANEUVRE                                       = 149
    BI_DIRECTIONAL_LOCAL_DIVIDED                        = 289
    BI_DIRECTIONAL_LOCAL_NON_DIVIDED                    = 290
    BI_DIRECTIONAL_INTERCHANGE_LINK                     = 356
    BI_DIRECTIONAL_ACCESS_RAMP                          = 357
    BI_DIRECTIONAL_TURN_MANEUVRE                        = 358
    ROUND_ABOUT                                         = 375


# Japan
class RoadTypeJapan(Enum):
    CONTROLLED_ACCESS_DIVIDED                           = 1
    INTERCHANGE_LINK                                    = 2
    NON_CONTROLLED_ACCESS_DIVIDED                       = 3
    CONTROLLED_ACCESS_NON_DIVIDED                       = 4
    ACCESS_RAMP                                         = 5
    NON_CONTROLLED_ACCESS_NON_DIVIDED                   = 6
    LOCAL_DIVIDED                                       = 7
    LOCAL_NON_DIVIDED                                   = 8
    CONTROLLED_ACCESS_DIVIDED_COLLECTOR                 = 9
    BI_DIRECTIONAL_CONTROLLED_ACCESS_DIVIDED            = 10
    BI_DIRECTIONAL_CONTROLLED_ACCESS_NON_DIVIDED        = 11
    BI_DIRECTIONAL_NON_CONTROLLED_ACCESS_DIVIDED        = 12
    BI_DIRECTIONAL_NON_CONTROLLED_ACCESS_NON_DIVIDED    = 13
    TURN_MANEUVRE                                       = 14
    BI_DIRECTIONAL_LOCAL_DIVIDED                        = 28
    BI_DIRECTIONAL_LOCAL_NON_DIVIDED                    = 29
    ROUND_ABOUT                                         = 79
    BI_DIRECTIONAL_INTERCHANGE_LINK                     = 97
    BI_DIRECTIONAL_ACCESS_RAMP                          = 98
    BI_DIRECTIONAL_TURN_MANEUVRE                        = 99


class RoadTypeColor(Enum):
    CONTROLLED_ACCESS_DIVIDED                           = 'green'
    INTERCHANGE_LINK                                    = 'orange'
    NON_CONTROLLED_ACCESS_DIVIDED                       = 'navy'
    CONTROLLED_ACCESS_NON_DIVIDED                       = 'cyan'
    ACCESS_RAMP                                         = 'yellow'
    NON_CONTROLLED_ACCESS_NON_DIVIDED                   = 'blue'
    LOCAL_DIVIDED                                       = 'magenta'
    LOCAL_NON_DIVIDED                                   = 'pink'
    CONTROLLED_ACCESS_DIVIDED_COLLECTOR                 = 'lime'
    BI_DIRECTIONAL_CONTROLLED_ACCESS_DIVIDED            = 'purple'
    BI_DIRECTIONAL_CONTROLLED_ACCESS_NON_DIVIDED        = 'brown'
    BI_DIRECTIONAL_NON_CONTROLLED_ACCESS_DIVIDED        = 'coffee'
    BI_DIRECTIONAL_NON_CONTROLLED_ACCESS_NON_DIVIDED    = 'gray'
    TURN_MANEUVRE                                       = 'red'
    BI_DIRECTIONAL_LOCAL_DIVIDED                        = 'aqua'
    BI_DIRECTIONAL_LOCAL_NON_DIVIDED                    = 'black'
    BI_DIRECTIONAL_INTERCHANGE_LINK                     = 'darkOrange'
    BI_DIRECTIONAL_ACCESS_RAMP                          = 'darkYellow'
    BI_DIRECTIONAL_TURN_MANEUVRE                        = 'darkRed'
    ROUNDABOUT                                          = 'darkBrown'


class OSMHWColor(Enum):
    motorway                           = 'green'
    motorway_link                                    = 'orange'
    trunk                       = 'navy'
    trunk_link                                         = 'yellow'
    primary                   = 'blue'
    primary_link                                       = 'magenta'
    secondary                                   = 'pink'
    secondary_link                 = 'lime'
    tertiary            = 'purple'
    tertiary_link        = 'brown'
    unclassified        = 'wheat'
    residential    = 'maroon'
    living_street                                       = 'red'
    service                        = 'aqua'
    pedestrian                    = 'cyan'


rfdb_ottonomo_signs_df = pd.DataFrame(
    {
        'column': ["vehicle__identification__otonomo_id",
"metadata__time__epoch",
"location__country__code",
"location__city__name",
"location__latitude__value",
"location__longitude__value",
"mobility__heading__angle",
"mobility__speed__value",
"location__altitude__value",
"metadata__provider__name",
"location__polygon__geohash",
"location__continent__name",
"location__country__name",
"location__state__name",
"location__region__name",
"location__county__name",
"location__island__name",
"location__town__name",
"location__village__name",
"location__municipality__name",
"location__district__name",
"location__suburb__name",
"location__farm__name",
"location__neighbourhood__name",
"location__house__address",
"location__quarter__name",
"location__city__block_name",
"location__square__name",
"location__road__name",
"location__house__number",
"metadata__identification__type",
"environment__road__speed_limit",
"metadata__speed__sign_unit",
"metadata__subject__reference",
"metadata__condition__value",
"metadata__offset__longitudinal",
"metadata__offset__lateral",
"metadata__offset__vertical",
"mobility__pitch__angle",
"metadata__fixed__indicator",
"metadata__distance__indicator",
"metadata__duration__indicator",
"metadata__zone__indicator",
"metadata__vehicle_type__reference",
"metadata__position_to_vehicle__value",
"location__latitude__sign_value",
"location__longitude__sign_value",
"metadata__sign_location__source"],
        'dtype': ["text",
"bigint",
"text",
"text",
"double precision",
"double precision",
"double precision",
"double precision",
"double precision",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"text",
"double precision",
"text",
"text",
"text",
"double precision",
"double precision",
"double precision",
"double precision",
"boolean",
"boolean",
"boolean",
"boolean",
"text",
"text",
"double precision",
"double precision",
"double precision"]
    }
)


color_dict = {1: 'white', 2: 'yellow', 3: 'pink', 4: 'purple'}

wu_state_df = pd.DataFrame(
    {
        'wu_state': ["Created", 'Partially_Collected', "On_Hold", "Fix_On_Hold", "Collecting", "Ready_Collecting",
                     "In_BPS_QC", "BPS_QC_Error", "BPS_Review_Error", "Ready_BPS_QC", 'Ready_Supplier_QC',
                     'In_Supplier_QC', 'Supplier_QC_Error', 'Batch_QC_Error', 'Supplier_Review_Error',
                     'Fix_Ushr_Error', 'Auto_QC_Error', 'Fix_Auto_Error', 'Fix_Supplier_Error',
                     "In_Ushr_QC",  "Ushr_QC_Error", "Ready_Ushr_QC", "Ready_Publish"
                     ],
        'draw_color': ["red", 'red', "red", "red", "red", "red", 'red', 'red', 'red',
                       "red", "red", "red", "red", 'red', 'red', 'red', 'red', 'red', 'red',
                       "red",  "red", "green", "green"]
    }
)

wu_is_publishable_df = pd.DataFrame(
    {
        'wu_is_publishable': [False, True],
        'draw_color': ['red', 'green']
    }
)

delin_type_df = pd.DataFrame(
    {'type': ["DEL_LN_IMPLIED", "DEL_LN_SINGLE_DASHED", "DEL_LN_SINGLE_SOLID", "DEL_LN_DOUBLE_ALL_SOLID",
              "DEL_LN_DOUBLE_ALL_DASHED", "DEL_LN_DOUBLE_R_SOLID", "DEL_LN_DOUBLE_R_DASHED", "DEL_LN_TRIPLE_ALL_SOLID",
              "DEL_LN_TRIPLE_ALL_DASHED", "DEL_LN_OTHER", "DEL_RD_IMPLIED", "DEL_RD_DITCH",
              "DEL_RD_BERM", "DEL_RD_SURFACE_CHANGE", "DEL_RD_PAINT_LINE", "DEL_RD_CURB",
              "DEL_RD_DROP_OFF", "DEL_RD_DRIVE_THRU_GAP", "DEL_RD_OTHER", "DEL_BA_GUARD_RAIL",
              "DEL_BA_BARRIER_CONCRETE", "DEL_BA_BARRIER_METAL", "DEL_BA_BARRIER_PLASTIC", "DEL_BA_BARRIER_WOOD",
              "DEL_BA_WALL_CONCRETE", "DEL_BA_WALL_METAL", "DEL_BA_WALL_WOOD", "DEL_BA_MOVABLE_BARRIER",
              "DEL_LN_IMPLIED_SECONDARY", "DEL_LN_SURFACE_CHANGE", 'DEL_BA_PLASTIC_POLES'],
     'stroke_style': ['dot', 'dash', 'solid', 'solid',
                      'dash', 'solid', 'dash', 'solid',
                      'dash', 'solid', 'dot', 'solid',
                      'solid', 'solid', 'solid', 'solid',
                      'solid', 'dot', 'solid', 'solid',
                      'solid', 'solid', 'solid', 'solid',
                      'solid', 'solid', 'solid', 'solid',
                      'dot', 'solid', 'solid'],
     'draw_color': ['red', None, None, None,
                    None, None, None, None,
                    None, None, 'red', 'pink',
                    'pink', 'aqua', 'blue', 'magenta',
                    'pink', 'red', 'pink', 'brown',
                    'brown', 'brown', 'brown', 'brown',
                    'brown', 'brown', 'brown', 'coffee',
                    'orange', None, 'brown']
     }

)
delin_color_df = pd.DataFrame(
    {
        'id': [1, 2, 3, 4, None],
        'name': ["WHITE", "YELLOW_ORANGE", "OTHER", "UNKNOWN", None],
        'draw_color': ['white', 'yellow', 'pink', 'purple', 'magenta']
    }
)

delin_width_df = pd.DataFrame(
    {
        'name': ["THIN", "THICK", None],
        'draw_width': [0.5, 1, 0.5]
    }
)


