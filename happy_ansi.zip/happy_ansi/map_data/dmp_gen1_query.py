from .db_conn import make_query
from shapely.geometry import Point, LineString, MultiPoint
from calculations.projection import project_wgs84_utm


def query_cm_line_width_precision(conn, precision_cm):
    query = f'''select dm_id, starting_point_line_width, end_point_line_width, coordinate_string_ll
                from dmp.carriageway_marking
                where starting_point_line_width%{precision_cm} <> 0 or end_point_line_width%{precision_cm} <> 0
                '''
    response = make_query(conn, query, None)
    cm_line_width_precision_err_dict = {}
    for row in response:
        dm_id = row[0]
        starting_point_line_width = row[1]
        end_point_line_width = row[2]
        coords_string = row[3]
        coord_pts = coords_string.split(';')
        cm_line_width_precision_err_dict[dm_id] = []
        if starting_point_line_width % precision_cm != 0:
            lat, lon, h, alt = coord_pts[0].split(':')[0:4]
            geom = Point(float(lon), float(lat), float(alt))
            cm_line_width_precision_err_dict[dm_id].append(
                {'err': f'dm_id {dm_id} starting_point_line_width {starting_point_line_width} is not multiples of {precision_cm}',
                 'geom': geom})
        if end_point_line_width % precision_cm != 0:
            lat, lon, h, alt = coord_pts[-1].split(':')[0:4]
            geom = Point(float(lon), float(lat), float(alt))
            cm_line_width_precision_err_dict[dm_id].append(
                {'err': f'dm_id {dm_id} end_point_line_width {end_point_line_width} is not multiples of {precision_cm}',
                 'geom': geom})

    return cm_line_width_precision_err_dict


def query_cm(conn):
    query = '''SELECT dm_id, slice_id, line_type_code, carriageway_marking_code, virtual_flag, 
               starting_point_line_width, end_point_line_width, 
               coordinate_string_ll, coordinate_string_jgd
               FROM dmp.carriageway_marking'''
    response = make_query(conn, query, None)
    carriageway_marking_dict = {}
    for row in response:
        dm_id, slice_id, line_type_code, carriageway_marking_code, virtual_flag, \
            starting_point_line_width, end_point_line_width, \
            coordinate_string_ll, coordinate_string_jgd = row[0:9]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        carriageway_marking_dict[dm_id] = {'slice_id': slice_id,
                                           'line_type_code': line_type_code,
                                           'carriageway_marking_code': carriageway_marking_code,
                                           'virtual_flag': virtual_flag,
                                           'starting_point_line_width': starting_point_line_width,
                                           'end_point_line_width': end_point_line_width,
                                           'wgs_point_list': wgs_point_list, 'jgd_point_list': jgd_point_list}
    return carriageway_marking_dict


def query_mcm(conn):
    query = '''SELECT dm_id, line_type_code, carriageway_markings_id, carriageway_markings_no, 
               starting_point_line_width, end_point_line_width, 
               coordinate_string_ll, coordinate_string_jgd
               FROM dmp.multiple_carriageway_marking'''
    response = make_query(conn, query, None)
    multiple_carriageway_marking_dict = {}
    for row in response:
        dm_id, line_type_code, carriageway_markings_id, carriageway_markings_no, \
            starting_point_line_width, end_point_line_width, \
            coordinate_string_ll, coordinate_string_jgd = row[0:8]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        multiple_carriageway_marking_dict[dm_id] = {'line_type_code': line_type_code,
                                                    'carriageway_markings_code': carriageway_markings_id,
                                                    'carriageway_markings_no': carriageway_markings_no,
                                                    'starting_point_line_width': starting_point_line_width,
                                                    'end_point_line_width': end_point_line_width,
                                                    'wgs_point_list': wgs_point_list, 'jgd_point_list': jgd_point_list}
    return multiple_carriageway_marking_dict


def query_mcm_cm_belong(conn):
    mcm_cm_dict = {}
    query = '''SELECT carriageway_markings_id, array_agg(dm_id) FROM dmp.multiple_carriageway_marking
               group by carriageway_markings_id'''
    response = make_query(conn, query, None)
    for row in response:
        cm_dm_id, mcm_dm_id_list = row[0:2]
        mcm_cm_dict[cm_dm_id] = mcm_dm_id_list
    return mcm_cm_dict


def query_cm_mcm_line_width_relation(conn):
    query = '''with mcm_cm as (SELECT cm.dm_id, cm.line_type_code, 
               cm.starting_point_line_width, cm.end_point_line_width, 
               array_agg(mcm.carriageway_markings_no) as carriageway_markings_nos,
               array_agg(mcm.dm_id order by carriageway_markings_no) as mcm_dm_ids, 
               array_agg(mcm.line_type_code) as mcm_line_type_codes, 
               sum(mcm.starting_point_line_width) as start_point_line_width_sum, 
               sum(mcm.end_point_line_width) as end_point_line_width_sum
               FROM dmp.carriageway_marking cm
               join dmp.multiple_carriageway_marking mcm ON mcm.carriageway_markings_id = cm.dm_id
               group by cm.dm_id
               )
               select *
               from mcm_cm
               where starting_point_line_width < start_point_line_width_sum 
               or end_point_line_width < end_point_line_width_sum'''
    response = make_query(conn, query, None)
    cm_mcm_line_width_relation_err_dict = {}
    for row in response:
        dm_id = row[0]
        line_type_code = row[1]
        starting_point_line_width = row[2]
        end_point_line_width = row[3]
        carriageway_markings_nos = row[4]
        mcm_dm_ids = row[5]
        mcm_line_type_codes = row[6]
        mcm_start_point_line_width_sum = row[7]
        mcm_end_point_line_width_sum = row[8]
        cm_mcm_line_width_relation_err_dict[dm_id] = {'starting_point_line_width': starting_point_line_width,
                                                      'end_point_line_width': end_point_line_width,
                                                      'mcm_dm_ids': mcm_dm_ids,
                                                      'mcm_start_point_line_width_sum': mcm_start_point_line_width_sum,
                                                      'mcm_end_point_line_width_sum': mcm_end_point_line_width_sum}
    return cm_mcm_line_width_relation_err_dict


def query_deceleration_marking_cm_width_change(conn):
    query = '''with dm_cm as (
	select cm.dm_id, cm.starting_point_line_width, cm.end_point_line_width,
	lcm.lane_node_linkage_id, lcm.carriageway_marking_position, 
	unnest(lconn.entry_lane_node_linkage) as entry_lane_node_linkage, unnest(lconn.exit_lane_node_linkage) as exit_lane_node_linkage
	FROM dmp.carriageway_marking cm
	join dmp.lane_related_carriageway_marking_info lcm on lcm.carriageway_marking_ref_id = cm.dm_id
	join dmp.lane_node_linkage_connection lconn on lconn.dm_id = lcm.lane_node_linkage_id
	where deceleration_marking_code <> 0
)
select dm_cm.*, entry_cm.dm_id as entry_cm_dm_id, exit_cm.dm_id as exit_cm_dm_id, 
entry_cm.end_point_line_width, exit_cm.starting_point_line_width
from dm_cm
join dmp.lane_node_linkage entry_lane on entry_lane.dm_id = entry_lane_node_linkage
join dmp.lane_node_linkage exit_lane on exit_lane.dm_id = exit_lane_node_linkage
join dmp.lane_related_carriageway_marking_info entry_lcm on entry_lcm.lane_node_linkage_id = entry_lane.dm_id 
join dmp.lane_related_carriageway_marking_info exit_lcm on exit_lcm.lane_node_linkage_id = exit_lane.dm_id
join dmp.carriageway_marking entry_cm on entry_cm.dm_id = entry_lcm.carriageway_marking_ref_id 
join dmp.carriageway_marking exit_cm on exit_cm.dm_id = exit_lcm.carriageway_marking_ref_id 
where entry_lcm.carriageway_marking_position = dm_cm.carriageway_marking_position
and exit_lcm.carriageway_marking_position = dm_cm.carriageway_marking_position
and (entry_cm.end_point_line_width <> dm_cm.starting_point_line_width 
	 or exit_cm.starting_point_line_width <> dm_cm.end_point_line_width)
'''
    response = make_query(conn, query, None)
    deceleration_marking_cm_width_change_dict = {}
    for row in response:
        dm_id = row[0]
        starting_point_line_width = row[1]
        end_point_line_width = row[2]
        lane_node_linkage_id = row[3]
        carriageway_marking_position = row[4]
        entry_lane_node_linkage = row[5]
        exit_lane_node_linkage = row[6]
        entry_cm_dm_id = row[7]
        exit_cm_dm_id = row[8]
        entry_cm_end_point_line_width = row[9]
        exit_cm_starting_point_line_width = row[10]
        deceleration_marking_cm_width_change_dict[dm_id] \
            = {'starting_point_line_width': starting_point_line_width,
               'end_point_line_width': end_point_line_width,
               'entry_cm_dm_id': entry_cm_dm_id,
               'exit_cm_dm_id': exit_cm_dm_id,
               'entry_cm_end_point_line_width': entry_cm_end_point_line_width,
               'exit_cm_starting_point_line_width': exit_cm_starting_point_line_width}
    return deceleration_marking_cm_width_change_dict


def query_slice_lnl(conn):
    slice_lnl_dict = {}
    query = '''select slice_id, array_agg(dm_id)
               from dmp.lane_node_linkage
               group by slice_id'''
    response = make_query(conn, query, None)
    for row in response:
        slice_id, dm_ids = row[0:2]
        slice_lnl_dict[slice_id] = dm_ids
    return slice_lnl_dict


def query_slice_cm(conn):
    slice_cm_dict = {}
    query = '''select slice_id, array_agg(dm_id)
               from dmp.carriageway_marking
               group by slice_id'''
    response = make_query(conn, query, None)
    for row in response:
        slice_id, dm_ids = row[0:2]
        slice_cm_dict[slice_id] = dm_ids
    return slice_cm_dict


def query_rfdb_road_unit_lnl(conn):
    rfdb_road_unit_lnl_dict = {}
    query = '''select road_unit_rfdb_id, array_agg(dm_id)
               from dmp.lane_node_linkage
               group by road_unit_rfdb_id'''
    response = make_query(conn, query, None)
    for row in response:
        road_unit_rfdb_id, dm_ids = row[0:2]
        rfdb_road_unit_lnl_dict[road_unit_rfdb_id] = dm_ids
    return rfdb_road_unit_lnl_dict


def query_lane_node_linkage(conn):
    lnl_dict = {}
    query = '''SELECT dm_id, slice_id, mesh_id, lane_node_linkage_length, coordinate_string_ll, coordinate_string_jgd
               FROM dmp.lane_node_linkage'''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, slice_id, mesh_id, lane_node_linkage_length, coordinate_string_ll, coordinate_string_jgd = row[0:6]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        lnl_dict[dm_id] = {'slice_id': slice_id, 'mesh_id': mesh_id, 'length': lane_node_linkage_length,
                           'wgs_point_list': wgs_point_list, 'jgd_point_list': jgd_point_list}
    return lnl_dict


def query_lane_node_linkage_connection(conn):
    lnl_conn_dict = {}
    query = '''SELECT dm_id, entry_lane_node_linkage, exit_lane_node_linkage
               FROM dmp.lane_node_linkage_connection'''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, entry_lane_node_linkage, exit_lane_node_linkage = row[0:3]
        lnl_conn_dict[dm_id] = {'entry_lnl_list': entry_lane_node_linkage,
                                'exit_lnl_list': exit_lane_node_linkage}
    return lnl_conn_dict


def query_lane_related_cm_info(conn):
    lane_related_cm_dict = {}
    query = '''SELECT * FROM dmp.lane_related_carriageway_marking_info'''
    response = make_query(conn, query, None)
    for row in response:
        lnl_dm_id, mesh_id, cm_dm_id, pos = row[0:4]
        if lnl_dm_id not in lane_related_cm_dict:
            lane_related_cm_dict[lnl_dm_id] = {}
        lane_related_cm_dict[lnl_dm_id][pos] = cm_dm_id
    return lane_related_cm_dict


def query_shoulder_edge(conn):
    shoulder_edge_dict = {}
    virtual_shoulder_edge_set = set([])
    query = '''select dm_id, mesh_id, virtual_flag, coordinate_string_ll, coordinate_string_jgd
               from dmp.shoulder_edge
               '''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, mesh_id, virtual_flag, coordinate_string_ll, coordinate_string_jgd = row[0:5]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        shoulder_edge_dict[dm_id] = \
            {'mesh_id': mesh_id, 'virtual_flag': virtual_flag,
             'wgs_point_list': wgs_point_list, 'jgd_point_list': jgd_point_list}
        if virtual_flag:
            virtual_shoulder_edge_set.add(dm_id)
    return shoulder_edge_dict, virtual_shoulder_edge_set


def query_tunnel_boundary(conn):
    tunnel_boundary_dict = {}
    query = '''select dm_id, road_unit_rfdb_id, coordinate_string_ll, coordinate_string_jgd
               from dmp.tunnel_boundary'''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, road_unit_rfdb_id, coordinate_string_ll, coordinate_string_jgd = row[0:4]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        tunnel_boundary_dict[dm_id] = {'road_unit_rfdb_id': road_unit_rfdb_id,
                                       'wgs_point_list': wgs_point_list,
                                       'jgd_point_list': jgd_point_list}
    return tunnel_boundary_dict


def query_road_marking(conn):
    road_marking_dict = {}
    query = '''select dm_id, mesh_id, marking_code, coordinate_string_ll, coordinate_string_jgd
               from dmp.road_markings
               '''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, mesh_id, marking_code, coordinate_string_ll, coordinate_string_jgd = row[0:5]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        road_marking_dict[dm_id] = {
            'mesh_id': mesh_id, 'marking_code': marking_code,
            'wgs_point_list': wgs_point_list, 'jgd_point_list': jgd_point_list
        }
    return road_marking_dict


def query_road_marking_lnl_mapping(conn):
    road_marking_lnl_dict = {}
    query = '''select road_markings.dm_id, array_agg(lane_node_linkage.dm_id)
               from dmp.road_markings
               join dmp.road_marking_mapping on road_markings.dm_id = road_marking_mapping.road_marking_dm_id
               left join dmp.lane_node_linkage on lane_node_linkage.path_rfdb_id = road_marking_mapping.path_rfdb_id
                    and lane_node_linkage.slice_id = road_marking_mapping.slice_id
               where lane_node_linkage.dm_id is not null
               group by road_markings.dm_id'''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, lnl_dm_id_list = row[0:2]
        road_marking_lnl_dict[dm_id] = lnl_dm_id_list
    return road_marking_lnl_dict


def query_traffic_sign(conn):
    traffic_sign_dict = {}
    query = '''select vehicle_traffic_sign.dm_id, vehicle_traffic_sign.mesh_id, height, ground_height, 
               signcode, signformcode, signcolorcode, variableflag, speedlimit, auxiliarysigncode, 
               vehicle_traffic_sign.coordinate_string_ll, vehicle_traffic_sign.coordinate_string_jgd, 
               lane_node_linkage.dm_id
               from dmp.vehicle_traffic_sign
               left join dmp.lane_node_linkage on lane_node_linkage.path_rfdb_id = vehicle_traffic_sign.path_rfdb_id
                    and lane_node_linkage.slice_id = vehicle_traffic_sign.slice_id'''
    response = make_query(conn, query, None)
    for row in response:
        dm_id, mesh_id, height, ground_height, signcode, signformcode, signcolorcode, \
            variableflag, speedlimit, auxiliarysigncode, coordinate_string_ll, coordinate_string_jgd, \
            lnl_dm_id = row[0:13]
        wgs_coordinate_list = coordinate_string_ll.split(';')
        jgd_coordinate_list = coordinate_string_jgd.split(';')
        wgs_point_list = []
        jgd_point_list = []
        for i in range(len(jgd_coordinate_list)):
            jgd_coordinate = jgd_coordinate_list[i]
            wgs_coordinate = wgs_coordinate_list[i]
            zone, y, x, h, z = jgd_coordinate.split(':')[0:5]
            lat, lon, h, alt = wgs_coordinate.split(':')[0:4]
            wgs_point_list.append(Point(float(lon), float(lat), float(alt)))
            jgd_point_list.append(Point(float(x), float(y), float(z)))
        traffic_sign_dict[dm_id] = {
            'mesh_id': mesh_id, 'height': height, 'ground_height': ground_height, 'signcode': signcode,
            'signformcode': signformcode, 'signcolorcode': signcolorcode, 'variableflag': variableflag,
            'speedlimit': speedlimit, 'auxiliarysigncode': auxiliarysigncode,
            'wgs_point_list': wgs_point_list, 'jgd_point_list': jgd_point_list, 'lnl_dm_id': lnl_dm_id
        }
    return traffic_sign_dict

