from .db_conn import *
from shapely import wkb


def query_segment(conn, segment_id):
    segment_dict = {}
    query = f'''with left_edge as (
                                            select road_segment.road_segment_id, road_type, number_of_lanes,
                                           	st_makeline(array_agg(left_edge_pts.position order by road_edge_point_sequence_index)) as left_edge_line,
    										max(road_edge_point_sequence_index) as max_index
                                            from ushr_format.road_segment 
                                            join ushr_format.road_edge_points left_edge_pts on left_edge_pts.road_segment_id = road_segment.road_segment_id 
    										where road_segment.road_segment_id = %s
    										and left_edge_pts.road_edge_side = false										
                                            group by road_segment.road_segment_id
                                        ),
    									road_edge as (									
                                        select left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line,
    									st_makeline(array_agg(right_edge_pts.position order by road_edge_point_sequence_index desc)) as right_edge_line
                                        from left_edge
    									join ushr_format.road_edge_points right_edge_pts on right_edge_pts.road_segment_id = left_edge.road_segment_id
    									where right_edge_pts.road_edge_side = true
    									group by left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line
    									),
    									segment_boundary_lines as (									
    									select *, 
    									st_makeline(array[ST_PointN(right_edge_line, -1), ST_PointN(left_edge_line, 1)]) as start_boundary_line, 
    									st_makeline(array[ST_PointN(left_edge_line, -1), ST_PointN(right_edge_line, 1)]) as end_boundary_line 
    									from road_edge
    									)
    									select road_segment_id, road_type, number_of_lanes,
    									st_astext(st_makepolygon(st_makeline(array[left_edge_line, end_boundary_line, right_edge_line, start_boundary_line]))) as boundary_line
    									from segment_boundary_lines
    									'''

    response = make_query(conn, query, (segment_id,))
    for row in response:
        segment_id, road_type, number_of_lanes, geom = row[0:4]
        segment_dict[segment_id] = {'road_type': road_type, 'number_of_lanes': number_of_lanes, 'geom': geom}
    return segment_dict


def query_subcountry_list(conn):
    query = '''select name
                from public.extent
                join pub_tracking.delivered_roads on delivered_roads.region_gid = gid
                join pub_tracking.segment_tracking on segment_tracking.rfdb_id = delivered_roads.segment_id
                group by name
                order by name'''
    response = make_query(conn, query, None)
    subcountry_list = []
    for row in response:
        subcountry = row[0]
        subcountry_list.append(subcountry)
    return subcountry_list


def query_subcountry_segments(conn, subcountry_list):
    query = '''select name, array_agg(segment_tracking.id_)
                from public.extent
                join pub_tracking.delivered_roads on delivered_roads.region_gid = gid
                join pub_tracking.segment_tracking on segment_tracking.rfdb_id = delivered_roads.segment_id
                where name = any(%s)
                group by name
                order by name'''
    subcountry_segment_dict = {}
    response = make_query(conn, query, (subcountry_list,))
    for row in response:
        subcountry, segment_id_list = row
        subcountry_segment_dict[subcountry] = segment_id_list
    return subcountry_segment_dict


def query_signs(conn, segment_id_list):
    sign_dict = {}
    sign_lane_mapping_dict = {}
    query = '''select signs.sign_id, type, centroid_position, bottom_left_corner_position,
               top_left_corner_position, top_right_corner_position, bottom_right_corner_position,
               road_segment_id, lane_number, lane_point_sequence_index
               from ushr_format.signs
               join ushr_format.sign_lane_mapping on sign_lane_mapping.sign_id = signs.sign_id
               where road_segment_id = any(%s)'''
    response = make_query(conn, query, (segment_id_list,))
    for row in response:
        sign_id = row[0]
        # sign_type = udbx_sign_types_df[udbx_sign_types_df['id'] == row[1]]['type'].values[0]
        sign_type = row[1]
        centroid = wkb.loads(row[2], hex=True)
        bl_corner = wkb.loads(row[3], hex=True)
        tl_corner = wkb.loads(row[4], hex=True)
        tr_corner = wkb.loads(row[5], hex=True)
        br_corner = wkb.loads(row[6], hex=True)
        segment_id, lane_number, lane_point_index = row[7:10]
        if sign_id not in sign_dict:
            sign_dict[sign_id] = {'type': sign_type, 'centroid': centroid,
                                  'bl_corner': bl_corner, 'tl_corner': tl_corner, 'tr_corner': tr_corner,
                                  'br_corner': br_corner}
            sign_lane_mapping_dict[sign_id] = [{'segment_id': segment_id,
                                                'lane_number': lane_number,
                                                'lane_point_index': lane_point_index}]
        else:
            sign_lane_mapping_dict[sign_id].append({'segment_id': segment_id,
                                                    'lane_number': lane_number,
                                                    'lane_point_index': lane_point_index})

    return sign_dict, sign_lane_mapping_dict


def query_nearby_signs(conn, sign_id_list, thold):
    query = f'''
            with segment_sign as (
            select signs.sign_id, st_transform(centroid_position, 32616) as centroid_position
                           from ushr_format.signs
                           where signs.sign_id = any(%s)
                           group by signs.sign_id
            ),
            clusters AS (
              SELECT sign_id, 
              ST_ClusterDBSCAN(centroid_position, eps := {thold}, minpoints := 2) over () as clusterid, centroid_position 
              FROM segment_sign
            )
            SELECT clusterid, array_agg(sign_id) as sign_ids
            FROM clusters 
            where clusterid is not null
            GROUP BY clusterid            
            '''
    response = make_query(conn, query, (sign_id_list,))
    nearby_sign_dict = {}
    for row in response:
        cluster_id, sign_id_list = row
        nearby_sign_dict[cluster_id] = sign_id_list
    return nearby_sign_dict

