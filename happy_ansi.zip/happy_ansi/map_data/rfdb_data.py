from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
from .db_conn import *
from .utils import *
import shapely.wkb
import shapely.wkt
from shapely.geometry import Point, MultiPoint, LineString
from shapely.ops import nearest_points, split, snap, substring
from ..map_data.rfdb_enums import *
from ..calculations.projection import project_wgs84_utm, project_utm_wgs84
import logging
import time
import pandas as pd
import pandas.io.sql as sqlio


class RFDBMapData:
    def __init__(self, mainwin):
        self.main_win = mainwin
        self.conn = mainwin.rfdb_conn
        self.extent = mainwin.extent
        self.srid = 4326
        self.road_type_enum = None

    def is_rfdb(self):
        query = '''SELECT *
                   FROM pg_catalog.pg_namespace
                   WHERE nspname = %s'''
        response = make_query(self.conn, query, ('delineator',))
        if len(response) == 0:
            return False
        else:
            return True

    def has_schema(self, schema_name):
        query = '''SELECT *
                           FROM pg_catalog.pg_namespace
                           WHERE nspname = %s'''
        response = make_query(self.conn, query, (schema_name,))
        if len(response) == 0:
            return False
        else:
            return True

    def query_road_type_enum(self):
        query = '''select * from road_unit.road_type_names'''
        response = make_query(self.conn, query, None)
        road_type_enum_dict = {}
        for row in response:
            road_type_id, road_type = row
            road_type_enum_dict[road_type] = road_type_id
        self.road_type_enum = Enum('RoadType', road_type_enum_dict)

    def query_subcountries(self):
        query = '''select subcountry
                       from work_units.work_unit
                       group by subcountry
                       order by subcountry'''
        response = make_query(self.conn, query, None)
        subcountry_list = []
        for row in response:
            subcountry = row[0]
            subcountry_list.append(subcountry)
        query = '''                 '''
        response = make_query(self.conn, query, None)
        for row in response:
            subcountry = row[0]
            subcountry_list.append(subcountry)
        return subcountry_list

    def get_subcountry_by_pc_id_list(self, pc_id_list):
        query = '''select distinct pc_id, subcountry
    from work_units.wu_point_cloud
    join work_units.work_unit on work_unit.id = wu_point_cloud.wu_id
    where pc_id = any(%s)'''
        pc_id_set = set([])
        for pc_id in pc_id_list:
            pc_id_set.update([pc_id.lower(), pc_id.upper()])
        response = make_query(self.conn, query, (list(pc_id_set),))
        pc_subcountry_dict = {}
        for row in response:
            pc_id = row[0]
            subcountry = row[1]
            pc_subcountry_dict[pc_id] = subcountry
        return pc_subcountry_dict

    # this function is used in "Search"
    def query_rfdb_feature(self, feature_id, feature='segment'):
        if feature == 'subcountry':
            geom_type = 'MultiLineString'
            query = f'''select distinct id, st_astext(geom)
                        from work_units.work_unit
                        join work_units.extra_subcountries on wu_id = work_unit.id
                        where work_unit.subcountry = %s or extra_subcountries.subcountry = %s
                        order by id'''
        elif feature == 'WU':
            geom_type = 'MultiLineString'
            query = f'''select st_astext(geom)
                        from work_units.work_unit
                        where id = %s'''
        elif feature == 'segment':
            geom_type = 'PolygonZ'
            query = f'''select st_astext(st_union(paths.envelope::geometry))
                        from road_unit.segment_paths
                        join path.paths on paths.id = segment_paths.id
                        where segment_id = %s
                        group by segment_id'''
        elif feature == 'path':
            geom_type = 'PolygonZ'
            query = f'''select st_astext(paths.envelope)
                        from path.paths 
                        where paths.id = %s
                        '''
        elif feature == 'delin_ctrl_pts':
            geom_type = 'PointZ'
            query = '''select 
                        st_astext((st_dump(control_points_sequence::geometry)).geom)                     
                        from road_unit.segment_paths 
                        join path.paths on paths.id = segment_paths.id                                     
                        join delineator.delineator_control_points_sequences ctrl_pts on ctrl_pts.delineator_id = left_delineator_id 
                            or ctrl_pts.delineator_id = right_delineator_id
					    where segment_id = %s'''
        elif feature == 'crossing':
            geom_type = 'LinestringZ'
            query = f'''select st_astext(st_collect(start_line::geometry, end_line::geometry))
                        from crossing.crossings
                        where crossings.id = %s
                        '''
        elif feature == 'road_object':
            geom_type = 'PointZ'
            query = f'''select st_astext(location)
                        from road_object.road_objects
                        where road_objects.id = %s
                        '''
        elif feature == 'sign':
            geom_type = 'PointZ'
            query = f'''select st_astext(centroid)
                        from signs.signs
                        where signs.id = %s
                        '''
        else:
            return 1
        if feature == 'subcountry':
            qgs_fields = [QgsField(f'WU', QVariant.Int), QgsField(f'{feature}', QVariant.String)]
            response = make_query(self.conn, query, (feature_id, feature_id,))
        else:
            qgs_fields = [QgsField(f'{feature}_id', QVariant.Int)]
            response = make_query(self.conn, query, (feature_id,))
        if len(response) == 0:
            return 1

        feature_list = []
        for row in response:
            g = QgsGeometry()
            f = QgsFeature()
            if feature == 'subcountry':
                wu_id, geom_wkt = row
                geom = g.fromWkt(geom_wkt)
                f.setGeometry(geom)
                f.setAttributes([wu_id, feature_id])
            else:
                geom_wkt = row[0]
                geom = g.fromWkt(geom_wkt)
                f.setGeometry(geom)
                feature_id = int(feature_id)
                f.setAttributes([feature_id])
            feature_list.append(f)

        layer = buildSimpleQgsVectorLayer(f'{geom_type}?crs=epsg:4326', f'{feature_id}',
                                          feature_list, qgs_fields)
        if geom_type == 'PolygonZ':
            layer = setPolygonLayerStyle(layer, stroke_color='yellow')
        layers = [layer]

        return layers

    def query_wu_in_extent(self):
        query = f'''with x as (
                    select work_unit.id, subcountry, array_agg(distinct project), 
                    array['Ready_Publish', 'Ready_Ushr_QC'] && array_agg(activity.wu_state::text) as publishable, 
					array_agg(activity.wu_state::text order by activity.start_time) as wu_states, 
					array_agg(activity.start_time::text order by activity.start_time) as wu_states_time,						
                    latest_activity.wu_state as latest_state, latest_activity.description, 
                    array_agg(distinct pc_id) as pc_ids, st_astext(geom), st_length(geom::geography) / 1000 as length_km
                    from work_units.work_unit
                    join work_units.projects on projects.wu_id = work_unit.id
                    join work_units.activity on activity.wu_id = work_unit.id
                    join work_units.latest_activity on latest_activity.wu_id = work_unit.id
                    left join work_units.wu_point_cloud on wu_point_cloud.wu_id = work_unit.id
                    where st_intersects(geom,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by work_unit.id, latest_activity.wu_state, latest_activity.description
                	)
                select *, array_positions(wu_states, 'Ready_Ushr_QC'), array_positions(wu_states, 'Ready_Publish') from x
                    '''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('wu_id', QVariant.Int), QgsField('subcountry', QVariant.String),
                      QgsField('project', QVariant.String), QgsField('length_km', QVariant.Double),
                      QgsField('wu_publishable', QVariant.Bool), QgsField('publishable_date', QVariant.String),
                      QgsField('latest_state', QVariant.String), QgsField('description', QVariant.String),
                      QgsField('pointcloud', QVariant.String)]
        feature_list = []
        wu_publishable_set = set([])
        for row in response:
            wu_id, subcountry, project, wu_publishable, wu_states, wu_states_time, latest_state, description, pc_ids, \
                geom, length, Ready_Ushr_QC_inds, Ready_Publish_inds = row
            publishable_inds = sorted(Ready_Ushr_QC_inds + Ready_Publish_inds)
            publishable_date = None
            if len(publishable_inds) > 0:
                publishable_date = wu_states_time[min(publishable_inds)]
            wu_publishable_set.add(wu_publishable)
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([wu_id, subcountry, f'{project}', length,
                             wu_publishable, publishable_date, latest_state, description, f'{pc_ids}'])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', f'rfdb_wu',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for wu_publishable in wu_publishable_set:
            actual_width = 1
            label = f'publishable - {wu_publishable}'
            exp = f'''wu_publishable = {wu_publishable}'''
            line_style = 'solid'
            color = wu_is_publishable_df[wu_is_publishable_df['wu_is_publishable']
                                         == wu_publishable]['draw_color'].values[0]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        v_layer.setDisplayExpression('wu_id')
        return v_layer

    def query_wu_connection_in_extent(self):
        query = f'''select from_wuid, to_wuid, description, bypass, boundary_id, connection_type, 
                    from_subcountry, to_subcountry, st_astext(geom)
                    from work_units.wu_connections
                    where st_intersects(geom,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('from_wuid', QVariant.Int), QgsField('to_wuid', QVariant.Int),
                      QgsField('description', QVariant.String), QgsField('bypass', QVariant.Bool),
                      QgsField('boundary_id', QVariant.Int), QgsField('connection_type', QVariant.String),
                      QgsField('from_subcountry', QVariant.String), QgsField('to_subcountry', QVariant.String)]
        feature_list = []
        for row in response:
            from_wuid, to_wuid, description, bypass, boundary_id, connection_type, from_subcountry, to_subcountry, geom\
                = row
            line = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(line)
            f.setAttributes([from_wuid, to_wuid, description, bypass, boundary_id, connection_type,
                             from_subcountry, to_subcountry])
            feature_list.append(f)
        arrow_v_layer = buildSimpleQgsVectorLayer(f'LinestringZ?crs=epsg:{self.main_win.srid}', 'udbx3_wu_connection',
                                                  feature_list, qgs_fields)
        arrow_v_layer = setLineLayerStyleToArrow(arrow_v_layer)
        return arrow_v_layer

    def query_osm_in_extent(self):
        query = f'''SELECT id, version, tags -> 'highway' as highway, 
                    tags -> 'name' as name, tags -> 'name:en' as name_en, tags -> 'name:ja' as name_jp,
                    tags -> 'bridge' as bridge, tags -> 'oneway' as oneway, st_astext(linestring)  
                    FROM osm.ways
                    where st_intersects(linestring,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('osm_id', QVariant.Int), QgsField('version', QVariant.Int),
                      QgsField('highway', QVariant.String), QgsField('name', QVariant.String),
                      QgsField('name:en', QVariant.String), QgsField('name:ja', QVariant.String),
                      QgsField('bridge', QVariant.String), QgsField('oneway', QVariant.String)]
        feature_list = []
        highway_type_set = set([])
        for row in response:
            osm_id, version, highway_type, name, name_en, name_ja, bridge, oneway, geom = row
            highway_type_set.add(highway_type)
            line = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(line)
            f.setAttributes([osm_id, version, highway_type, name, name_en, name_ja, bridge, oneway])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer('Linestring?crs=epsg:4326', f'rfdb_osm_way',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        osm_highway_types = [highway_type.name for highway_type in OSMHWColor]
        for highway_type in highway_type_set:
            actual_width = 1
            label = f'{highway_type}'
            exp = f'''highway = \'{highway_type}\''''
            line_style = 'solid'
            if highway_type in osm_highway_types:
                color = OSMHWColor[highway_type].value
            else:
                color = 'black'
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    def query_segments_in_extent(self):
        query = f'''with segs_in_extent as (select se.segment_id, road_type_id, road_name, envelope_simple as seg_geom, 
                    work_unit.id as wu_id, subcountry, 
                    array_agg(wu_projects.project order by wu_projects.project) as wu_project, 
                    ru_projects.project as ru_project, replaced_by_wuid                    
                    from road_unit.segments 
                    join road_unit.road_names on road_names.id = road_name_id
                    join road_unit.segment_envelopes se on se.segment_id = segments.id
                    join road_unit.segment_boundaries on segment_boundaries.segment_id = segments.id
                    join work_units.work_unit on work_unit.id = segment_boundaries.wu_id    
                    join work_units.projects wu_projects on wu_projects.wu_id = work_unit.id
                    left join road_unit.projects ru_projects on ru_projects.segment_id = segments.id
                    where st_intersects(envelope_simple,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by se.segment_id, envelope_simple, road_type_id, road_name, ru_projects.project,
                    work_unit.id, replaced_by_wuid, subcountry
                    ), 
                    seg_wu_state as (
                    select segment_id, road_type_id, road_name, segs_in_extent.wu_id, subcountry, wu_project, 
                    ru_project, seg_geom, 
                    array['Ready_Publish', 'Ready_Ushr_QC'] && array_agg(activity.wu_state::text) as wu_publishable, 
                    latest_activity.wu_state as latest_state, latest_activity.description, replaced_by_wuid                    
                    from segs_in_extent                    
                    join work_units.activity on activity.wu_id = segs_in_extent.wu_id
                    join work_units.latest_activity on latest_activity.wu_id = activity.wu_id                    
                    group by segment_id, road_type_id, road_name, segs_in_extent.wu_id, segs_in_extent.seg_geom, 
                        subcountry, wu_project, ru_project, replaced_by_wuid, latest_activity.wu_state, 
                        latest_activity.description 
                    )
                    select segment_id, road_type_id, road_name, seg_wu_state.wu_id, subcountry, wu_project, ru_project, 
                    st_astext(seg_geom), wu_publishable, latest_state, seg_wu_state.description, replaced_by_wuid, 
                    array['Ready_Publish', 'Ready_Ushr_QC'] && array_agg(activity.wu_state::text) as re_wu_publishable, 
                    latest_activity.wu_state as re_wu_latest_state
                    from seg_wu_state
                    left join work_units.activity on activity.wu_id = replaced_by_wuid
                    left join work_units.latest_activity on latest_activity.wu_id = replaced_by_wuid  
                    group by segment_id, road_type_id, road_name, seg_wu_state.wu_id, subcountry, 
                        wu_project, ru_project, seg_geom, 
                        wu_publishable, latest_state, seg_wu_state.description, 
                        replaced_by_wuid,latest_activity.wu_state										
                    '''

        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('road_type', QVariant.String),
                      QgsField('road_name', QVariant.String), QgsField('wu_id', QVariant.Int),
                      QgsField('subcountry', QVariant.String), QgsField('wu_project', QVariant.String),
                      QgsField('ru_project', QVariant.String),
                      QgsField('wu_publishable', QVariant.Bool), QgsField('latest_state', QVariant.String),
                      QgsField('latest_description', QVariant.String),
                      QgsField('replaced_by_wuid', QVariant.Int),
                      QgsField('replaced_by_wu_publishable', QVariant.Bool),
                      QgsField('replaced_by_wu_latest_state', QVariant.String)]
        feature_list = []
        road_type_set = set([])
        for row in response:
            segment_id, road_type_id, road_name, wu_id, subcountry, wu_project, ru_project, geom, wu_is_publishable, \
                latest_state, \
                description, replaced_by_wuid, replaced_by_wu_publishable, replaced_by_wu_latest_state = row
            if replaced_by_wu_publishable:
                continue
            road_type_set.add(road_type_id)
            polygon = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            f.setAttributes([segment_id, self.road_type_enum(road_type_id).name, road_name, wu_id, subcountry,
                             f'{wu_project}', ru_project, wu_is_publishable, latest_state, description,
                             replaced_by_wuid, replaced_by_wu_publishable, replaced_by_wu_latest_state])
            feature_list.append(f)
        v_layer = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', f'rfdb_road_segment',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for road_type_id in road_type_set:
            actual_width = 1
            road_type = self.road_type_enum(road_type_id).name
            label = f'{road_type}'
            exp = f'''road_type = \'{road_type}\''''
            line_style = 'solid'
            color = RoadTypeColor[road_type].value
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    def query_intersections_in_extent(self):
        query = f'''select intersections.id, array_agg(segment_id) as segment_ids, st_astext(envelope)
                    from road_unit.intersections
                    left join road_unit.intersection_segments 
                        on intersection_segments.intersection_id = intersections.id
                    where st_intersects(envelope,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by intersections.id	'''
        g = QgsGeometry()
        qgs_fields = [QgsField('intersection_id', QVariant.Int), QgsField('segment_ids', QVariant.String)]
        response = make_query(self.conn, query, None)
        feature_list = []
        for row in response:
            intersection_id, segment_ids, geom = row
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([intersection_id, f'{segment_ids}'])
            feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', 'rfdb_intersection', feature_list, qgs_fields)
        v_layer = setPolygonLayerStyle(v_layer, stroke_color='yellow', fill_color='255,0,0,20', width=0.3)

        return v_layer

    # todo: use path left delineator to display path types. This is better for QC purpose.
    def query_paths_in_extent(self):
        query = f'''with segment_in_extent as (
	select segment_paths.segment_id, road_type_id, wu_id, subcountry, replaced_by_wuid
	from path.paths
	join road_unit.segment_paths on segment_paths.id = paths.id
	join road_unit.segments on segments.id = segment_paths.segment_id
	join road_unit.segment_boundaries on segment_boundaries.segment_id = segments.id
	join work_units.work_unit on work_unit.id = segment_boundaries.wu_id
	where st_intersects(envelope,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
	and replaced_by_wuid is null				
	group by segment_paths.segment_id, road_type_id, wu_id, subcountry, replaced_by_wuid
),
path_type as (
select segment_paths.segment_id, road_type_id, paths.id as path_id, 
wu_id, subcountry, replaced_by_wuid, 
paths.left_delineator_id as left_delin_id, boundary_points.location as start_loc, 
array_agg(spt.type_name order by spt.type_name) as start_path_type
from segment_in_extent
join road_unit.segment_paths ON segment_paths.segment_id = segment_in_extent.segment_id
join segment_path_type.segment_path_type_sets_members sptsm on sptsm.segment_path_type_set_id = segment_paths.start_type_set_id
join segment_path_type.segment_path_types spt on spt.id = sptsm.segment_path_type_id	
join path.paths on paths.id = segment_paths.id
join delineator.delineators on delineators.id = paths.left_delineator_id
join boundary.boundary_points on boundary_points.id = start_boundary_point_id
group by segment_paths.segment_id, road_type_id, paths.id, start_type_set_id, boundary_points.location, wu_id, subcountry, replaced_by_wuid
),
path_type_change as (
select path_type.*,
change_ord, array_agg(spt_change.type_name) as change_path_type,
segment_path_type_set_changes.location::geometry as path_type_change_loc
from path_type
left join road_unit.segment_path_type_set_changes ON segment_path_type_set_changes.segment_path_id = path_id
left join segment_path_type.segment_path_type_sets_members sptsm_change on sptsm_change.segment_path_type_set_id = segment_path_type_set_changes.path_type_set_id
left join segment_path_type.segment_path_types spt_change on spt_change.id = sptsm_change.segment_path_type_id	
group by segment_id, road_type_id, wu_id, subcountry, path_id, left_delin_id, start_loc, start_path_type, change_ord, location, replaced_by_wuid
),
path_types as (
select segment_id, road_type_id, path_id, start_path_type, st_astext(start_loc) as start_loc,
array_agg(change_ord order by change_ord) as ordinals, 
jsonb_agg(change_path_type order by change_ord) as change_path_types,
array_agg(st_astext(path_type_change_loc) order by change_ord) as path_type_change_locs, wu_id, subcountry, replaced_by_wuid
from path_type_change
group by segment_id, road_type_id, path_id, start_path_type, start_loc, wu_id, subcountry, replaced_by_wuid
)
select path_types.*, work_units.is_publishable(wu_id) as wu_is_publishable, 
work_units.is_publishable(replaced_by_wuid) as replaced_by_wuid_is_publishable,
st_astext(envelope) as path_geom
from path_types
join path.paths on paths.id = path_types.path_id

'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields_path_geom = [QgsField('path_id', QVariant.Int),
                                QgsField('segment_id', QVariant.Int), QgsField('road_type', QVariant.String),
                                QgsField('wu_id', QVariant.Int), QgsField('subcountry', QVariant.String)]
        qgs_fields_path_type = [QgsField('path_id', QVariant.Int), QgsField('path_type', QVariant.String)]
        feature_list_path_geom = []
        feature_list_path_type = []
        path_type_list = []

        for row in response:
            segment_id = row[0]
            road_type_id = row[1]
            path_id = row[2]
            path_start_type = row[3]
            path_start_geom = row[4]
            path_type_chg_ordinals = row[5]
            path_change_types = row[6]
            path_type_change_geoms = row[7]
            wu_id = row[8]
            subcountry = row[9]
            replaced_by_wuid = row[10]
            wu_is_publishable = row[11]
            replaced_by_wuid_is_publishable = row[12]
            path_geom = row[13]
            if replaced_by_wuid_is_publishable:
                continue
            polygon = g.fromWkt(path_geom)
            f = QgsFeature()
            f.setGeometry(polygon)
            road_type = self.road_type_enum(road_type_id).name
            f.setAttributes([path_id, segment_id, road_type, wu_id, subcountry])
            feature_list_path_geom.append(f)

            f = QgsFeature()
            path_start_geom = g.fromWkt(path_start_geom)
            f.setGeometry(path_start_geom)
            f.setAttributes([path_id, f'{path_start_type}'])
            feature_list_path_type.append(f)
            if path_start_type not in path_type_list:
                path_type_list.append(path_start_type)
            if path_type_chg_ordinals[0] is not None:
                for i, ordinal in enumerate(path_type_chg_ordinals):
                    path_type_geom = g.fromWkt(path_type_change_geoms[i])
                    f.setGeometry(path_type_geom)
                    path_type = path_change_types[i]
                    f.setAttributes([path_id, f'{path_type}'])
                    feature_list_path_type.append(f)
                    if path_type not in path_type_list:
                        path_type_list.append(path_type)
        v_layer_path_geom = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', f'rfdb_path',
                                                      feature_list_path_geom, qgs_fields_path_geom)
        v_layer_path_geom = setPolygonLayerStyle(v_layer_path_geom, stroke_color='navy', fill_color='255,0,0,20',
                                                 width=0.3)

        v_layer_path_type = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', 'rfdb_path_type',
                                                      feature_list_path_type, qgs_fields_path_type)
        # feature_dict = {}
        # for path_type in path_type_list:
        #     # blend colors
        #     color_list = []
        #     for single_path_type in path_type:
        #         color_list.append(QColor(self.path_type_color_dict[single_path_type]))
        #     color = blend_colors(color_list)
        #     feature_dict[f'{path_type}'] = (color, f'{path_type}')
        # v_layer_path_type = apply_categorized_symbol(feature_dict, v_layer_path_type, field='path_type', point=True)
        return v_layer_path_geom, v_layer_path_type

    # visualize delineator as line with type and attributes (width, color)
    def query_delineator_ctrl_pts_in_extent(self):

        query = f'''with segment_in_extent as (
                    select distinct segment_paths.segment_id
                    from path.paths
                    join road_unit.segment_paths on segment_paths.id = paths.id
                    where st_intersects(envelope,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select distinct segment_in_extent.segment_id, ctrl_pts.delineator_id, 
                    (st_dump(control_points_sequence::geometry)).path[1], 
                    st_astext((st_dump(control_points_sequence::geometry)).geom), 
                    st_z((st_dump(control_points_sequence::geometry)).geom) 
                    from segment_in_extent
                    join road_unit.segment_paths on segment_paths.segment_id = segment_in_extent.segment_id
                    join path.paths on paths.id = segment_paths.id                    
                    join road_unit.segment_boundaries on segment_boundaries.segment_id = segment_paths.segment_id
	                    and work_units.is_publishable(replaced_by_wuid) = false
                    join delineator.delineator_control_points_sequences ctrl_pts on ctrl_pts.delineator_id = left_delineator_id 
                        or ctrl_pts.delineator_id = right_delineator_id'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('delineator_id', QVariant.Int),
                      QgsField('index', QVariant.Int), QgsField('elevation', QVariant.Double),
                      QgsField('color', QVariant.String)]
        feature_list = []
        segment_id_list = []
        color_selector = ['red', 'pink', 'yellow', 'green', 'blue', 'magenta', 'purple']
        color_ind = 0
        color = None
        for row in response:
            segment_id = row[0]
            delineator_id = row[1]
            ind = row[2]
            geom = row[3]
            elev = row[4]
            if segment_id not in segment_id_list:
                segment_id_list.append(segment_id)
                if color_ind > 6:
                    index = color_ind % 6
                else:
                    index = color_ind
                color = color_selector[index]
                color_ind += 1
            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, delineator_id, ind, elev, color])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'rfdb_delin',
                                      feature_list, qgs_fields, color='magenta')

        feature_dict = {}

        for i, segment_id in enumerate(segment_id_list):
            if i > 6:
                index = i % 6
            else:
                index = i
            color = color_selector[index]
            feature_dict[f'{segment_id}'] = (color, f'{segment_id}')

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='segment_id', point=True)

        return v_layer

    def query_delineators_in_extent(self):
        query = f'''with delin_geom as (
	select delineators.id as delineator_id, start_type, delineators.start_boundary_point_id, delineators.end_boundary_point_id,
	array_agg(ordinal order by ordinal) as subrun_ordinals, 
	array_agg(st_astext(st_linefrommultipoint(st_force2d(control_points_sequence::geometry))) order by ordinal) as subrun_lines
    from road_unit.segments
    join road_unit.segment_boundaries on segment_boundaries.segment_id = segments.id    	
	join boundary.boundary_points sbp on sbp.boundary_id = segment_boundaries.start_boundary_id 
    join boundary.boundary_points ebp on ebp.boundary_id = segment_boundaries.end_boundary_id 
    join delineator.delineators on delineators.start_boundary_point_id = sbp.id and delineators.end_boundary_point_id = ebp.id
	join delineator.delineator_control_points_sequences on delineator_control_points_sequences.delineator_id = delineators.id
	join work_units.associated_boundaries on associated_boundaries.boundary_id = sbp.boundary_id
	join work_units.work_unit on work_unit.id = associated_boundaries.wu_id
	where st_intersects(work_unit.geom,
                    	ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))	
    and work_units.is_publishable(replaced_by_wuid) = false
	group by delineators.id
),
delin_geom_type as (
	select delin_geom.*, array_agg(ordinal order by ordinal) as type_change_ordinals, 
	array_agg(delineator_type_name order by ordinal) as type_change_names,
	array_agg(width_enum order by ordinal) as width_changes,
	array_agg(color order by ordinal) as color_changes, array_agg(bott_dots_only order by ordinal) as bott_dots_only_changes, 
	array_agg(splits_opposing_direction order by ordinal) as splits_opposing_direction_changes,
	array_agg(st_astext(location) order by ordinal) as type_change_locations
	from delin_geom
	left join delineator.delineator_type_changes on delineator_type_changes.delineator_id = delin_geom.delineator_id
	left join delineator.delineator_attribute_changes on delineator_attribute_changes.type_change_id = delineator_type_changes.id
	left join delineator.delineator_attribute_sets on delineator_attribute_sets.id = delineator_attribute_changes.attribute_set_id
	group by delin_geom.delineator_id, start_type, start_boundary_point_id, end_boundary_point_id, subrun_ordinals, subrun_lines
),
delin_geom_type_start_attr as (
	select delin_geom_type.*, width_enum, color, bott_dots_only, splits_opposing_direction
	from delin_geom_type
	left join delineator.delineator_attribute_start on delineator_attribute_start.delineator_id = delin_geom_type.delineator_id
	left join delineator.delineator_attribute_sets on delineator_attribute_sets.id = delineator_attribute_start.attribute_set_id
)
select * 
from delin_geom_type_start_attr'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        qgs_fields = [QgsField('delineator_id', QVariant.Int), QgsField('type_ordinal', QVariant.Int),
                      QgsField('type', QVariant.String),
                      QgsField('color', QVariant.String), QgsField('width', QVariant.String),
                      QgsField('start_boundary_point_id', QVariant.Int), QgsField('end_boundary_point_id', QVariant.Int)]
        feature_list = []
        delin_dict = {}     # each delineator -> subrun -> type
        type_dict_list = []
        for row in response:
            delineator_id, start_type, start_boundary_point_id, end_boundary_point_id, subrun_ordinals, subrun_lines, \
                type_change_ordinals, type_change_names, width_changes, color_changes, bott_dots_only_changes, \
                splits_opposing_direction_changes, type_change_locations, start_width, start_color, \
                start_bott_dots_only, start_splits_opposing_direction = row

            type_geom_dict = {}
            type_dict = {}
            type_ordinal = 0

            if type_change_ordinals[0] is None:
                for i, subrun_ordinal in enumerate(subrun_ordinals):
                    subrun_line = shapely.wkt.loads(subrun_lines[i])
                    type_geom_dict[type_ordinal] = {'type': start_type, 'color': start_color, 'width': start_width,
                                                    'geom': subrun_line}
                    type_dict[type_ordinal] = {'type': start_type, 'color': start_color, 'width': start_width}
                    if type_dict[type_ordinal] not in type_dict_list:
                        type_dict_list.append(type_dict[type_ordinal])
                    type_ordinal += 1

                delin_dict[delineator_id] = type_geom_dict
            else:
                # use the type change location to split the subrun lines. If output is a single geometry,
                # the type change is not on that subrun.
                current_type = start_type
                current_color = start_color
                current_width = start_width
                for i, subrun_ordinal in enumerate(subrun_ordinals):
                    subrun_line = subrun_lines[i]
                    subrun_line = shapely.wkt.loads(subrun_line)
                    for j, type_change_ordinal in enumerate(type_change_ordinals):
                        next_type = type_change_names[j]
                        next_color = color_changes[j]
                        next_width = width_changes[j]
                        type_change_location = type_change_locations[j]
                        type_change_location = shapely.wkt.loads(type_change_location)
                        subrun_line_utm = project_wgs84_utm(subrun_line)
                        type_change_location_utm = project_wgs84_utm(type_change_location)

                        normalized_dist = subrun_line_utm.project(type_change_location_utm, normalized=True)
                        # logging.debug(f'{next_type}, {normalized_dist}')
                        # self.main_win.push_message(f'{next_type}, {normalized_dist}')
                        if normalized_dist in (0, 1):
                            type_geom_dict[type_ordinal] = {'type': current_type, 'color': current_color,
                                                            'width': current_width, 'geom': subrun_line}
                            type_dict[type_ordinal] = {'type': current_type, 'color': current_color, 'width': current_width}
                            if type_dict[type_ordinal] not in type_dict_list:
                                type_dict_list.append(type_dict[type_ordinal])
                            type_ordinal += 1
                            break   # current type change is not on this subrun, move to next subrun
                        else:
                            geom = project_utm_wgs84(substring(subrun_line_utm, 0, normalized_dist, normalized=True))
                            type_geom_dict[type_ordinal] = {'type': current_type, 'color': current_color,
                                                            'width': current_width, 'geom': geom}
                            type_dict[type_ordinal] = {'type': current_type, 'color': current_color,
                                                       'width': current_width}
                            if type_dict[type_ordinal] not in type_dict_list:
                                type_dict_list.append(type_dict[type_ordinal])
                            type_ordinal += 1

                            current_type = next_type
                            current_color = next_color
                            current_width = next_width
                            subrun_line = project_utm_wgs84(substring(subrun_line_utm, normalized_dist, 1, normalized=True))

                    # finish the last piece
                    type_geom_dict[type_ordinal] = {'type': current_type, 'color': current_color,
                                                    'width': current_width, 'geom': subrun_line}
                    type_dict[type_ordinal] = {'type': current_type, 'color': current_color, 'width': current_width}
                    if type_dict[type_ordinal] not in type_dict_list:
                        type_dict_list.append(type_dict[type_ordinal])

            for type_ordinal in type_geom_dict:
                type_ = type_geom_dict[type_ordinal]['type']
                color = type_geom_dict[type_ordinal]['color']
                width = type_geom_dict[type_ordinal]['width']
                if color is not None:
                    color = delin_color_df[delin_color_df['id'] == color]['name'].values[0]
                else:
                    color = 'None'
                geom = type_geom_dict[type_ordinal]['geom']
                line = g.fromWkt(geom.wkt)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([delineator_id, type_ordinal, type_, color, width,
                                 start_boundary_point_id, end_boundary_point_id])
                feature_list.append(f)

        v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'rfdb_delin',
                                            feature_list, qgs_fields)

        # make rules
        # self.main_win.push_message(f'type_dict_list: {type_dict_list}')
        rules = ()
        for type_dict in type_dict_list:
            type_ = type_dict['type']   # type name
            if type_ is None:
                continue
            color = type_dict['color']  # color id
            # width = type_dict['width']  # width id
            width = 'THIN'
            # self.main_win.push_message(f'width: {width}')
            label = type_
            if color is None:
                color_field = delin_color_df[delin_color_df['id'].isnull()]['name'].values[0]
                draw_color = delin_color_df[delin_color_df['id'].isnull()]['draw_color'].values[0]
                width_field = width
                layer_width = delin_width_df[delin_width_df['name'].isnull()]['draw_width'].values[0]
            else:
                color_field = delin_color_df[delin_color_df['id'] == color]['name'].values[0]
                draw_color = delin_color_df[delin_color_df['id'] == color]['draw_color'].values[0]
                width_field = width
                layer_width = delin_width_df[delin_width_df['name'] == width]['draw_width'].values[0]
            # use different colors for different road edge types and implied lines
            if type_.split('_')[1] != 'LN' or type_ in ('DEL_LN_IMPLIED', 'DEL_LN_IMPLIED_SECONDARY'):
                draw_color = delin_type_df[delin_type_df['type'] == type_]['draw_color'].values[0]
            exp = f'''type = \'{type_}\' 
                      and color = \'{color_field}\' 
                      and width = \'{width_field}\''''
            stroke_style = delin_type_df[delin_type_df['type'] == type_]['stroke_style'].values[0]
            rules += ((label, exp, stroke_style, draw_color, layer_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)

        return v_layer

    def query_crossings_in_extent(self):
        query = f'''with crossings_in_extent as (
select id as crossing_id, type_name, ST_ConvexHull(st_collect(start_line::geometry, end_line::geometry)) as crossing_geom
from crossing.crossings    
where st_intersects(start_line,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
)
select crossings_in_extent.crossing_id, type_name, st_astext(crossing_geom), array_agg(path_id order by path_id),
array_agg(st_astext(st_makeline(st_centroid(crossing_geom), ST_PointOnSurface(envelope::geometry))) order by path_id) as crossing_path_geoms
from crossings_in_extent
join crossing.crossings_paths on crossings_paths.crossing_id = crossings_in_extent.crossing_id
join path.paths on paths.id = path_id
join road_unit.segment_paths on segment_paths.id = paths.id
join road_unit.segment_boundaries on segment_boundaries.segment_id = segment_paths.segment_id
	and work_units.is_publishable(replaced_by_wuid) = false
group by crossings_in_extent.crossing_id, type_name, crossing_geom'''
        response = make_query(self.conn, query, None)
        g = QgsGeometry()
        crossing_qgs_fields = [QgsField('crossing_id', QVariant.Int), QgsField('crossing_type', QVariant.String)]
        crossing_path_qgs_fields = [QgsField('crossing_id', QVariant.Int), QgsField('path_id', QVariant.Int)]
        crossing_feature_list = []
        crossing_path_feature_list = []
        crossing_type_set = set([])
        for row in response:
            crossing_id = row[0]
            crossing_type = row[1]
            crossing_geom = row[2]
            path_ids = row[3]
            crossing_path_geoms = row[4]
            crossing_type_set.add(crossing_type)
            crossing_geom = g.fromWkt(crossing_geom)
            f = QgsFeature()
            f.setGeometry(crossing_geom)
            f.setAttributes([crossing_id, crossing_type])
            crossing_feature_list.append(f)

            for i, crossing_path_geom in enumerate(crossing_path_geoms):
                crossing_path_geom = g.fromWkt(crossing_path_geom)
                f = QgsFeature()
                f.setGeometry(crossing_path_geom)
                path_id = path_ids[i]
                f.setAttributes([crossing_id, path_id])
                crossing_path_feature_list.append(f)
        crossing_v_layer = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', f'rfdb_crossing',
                                               crossing_feature_list, crossing_qgs_fields)
        crossing_path_v_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', f'rfdb_crossing_path',
                                                          crossing_path_feature_list, crossing_path_qgs_fields)
        # make rules
        rules = ()
        for crossing_type in crossing_type_set:
            actual_width = 1
            label = f'{crossing_type}'
            exp = f'''crossing_type = \'{crossing_type}\''''
            line_style = 'solid'
            color = CrossingTypeColor[crossing_type].value
            rules += ((label, exp, line_style, color, actual_width),)

        crossing_v_layer = apply_rule_based_symbol(rules, crossing_v_layer)
        return crossing_v_layer, crossing_path_v_layer

    # in order for the sign to get published, it has to be associated to a road object which is also associated
    #  to the paths. Therefore, only display the signs that has road object associated.
    def query_signs_in_extent(self):
        query = f'''select signs.id as sign_id, width, height, azimuth, elevation, visible, is_digital, is_hanging, value, 
st_astext(centroid) as sign_centroid, 
st_astext(st_polygon(st_linefrommultipoint(
	st_collect(array[bl_corner, tl_corner, tr_corner, br_corner, bl_corner])), 4326)) as sign_geom,
array_agg(path_id order by path_id) as path_ids, 
array_agg(st_astext(st_makeline(centroid, ST_PointOnSurface(envelope::geometry))) order by path_id) as path_mappings, 
sign_types.name as type_, sign_types.super_type as supertype, sign_shapes.name as shape, 
array_agg(st_astext(st_makeline(centroid, associated_location::geometry)) order by path_id) as associated_locations, 
array_agg(associated_crossing_id order by path_id) as associated_crossing_ids
from signs.signs
join signs.sign_types on sign_types.id = signs.type_id
join signs.sign_shapes on sign_shapes.id = signs.shape_id
left join road_object.road_object_signs on road_object_signs.sign_id = signs.id
left join road_object.road_objects_paths on road_objects_paths.road_object_id = road_object_signs.road_object_id
left join path.paths on paths.id = path_id
left join road_unit.segment_paths on segment_paths.id = paths.id
left join road_unit.segment_boundaries on segment_boundaries.segment_id = segment_paths.segment_id
	and work_units.is_publishable(replaced_by_wuid) = false
where st_intersects(centroid,
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
group by signs.id, sign_types.name, sign_shapes.name, sign_types.super_type
'''
        g = QgsGeometry()
        qgs_fields_sign = [QgsField('rfdb_sign_id', QVariant.Int), 
                           QgsField('type', QVariant.String),
                           QgsField('supertype', QVariant.String), 
                           QgsField('value', QVariant.Int),
                           QgsField('shape', QVariant.String), QgsField('is_digital', QVariant.String),
                           QgsField('is_hanging', QVariant.String), QgsField('visible', QVariant.String),
                           QgsField('height', QVariant.Double), QgsField('width', QVariant.Double),
                           QgsField('azimuth', QVariant.Double), QgsField('elevation', QVariant.Double),
                           QgsField('path_ids', QVariant.String)
                           ]
        qgs_fields_sign_centroid = \
            [QgsField('rfdb_sign_id', QVariant.Int), QgsField('type', QVariant.String),
             QgsField('value', QVariant.Int),
             QgsField('shape', QVariant.String), QgsField('is_digital', QVariant.String),
             QgsField('is_hanging', QVariant.String), QgsField('visible', QVariant.String),
             QgsField('height', QVariant.Double), QgsField('width', QVariant.Double),
             QgsField('azimuth', QVariant.Double), QgsField('elevation', QVariant.Double),
             QgsField('path_ids', QVariant.String), QgsField('arrow_length', QVariant.Int)
             ]
        qgs_fields_sign_path_association = [QgsField('rfdb_sign_id', QVariant.Int), QgsField('path_id', QVariant.Int),
                                            QgsField('crossing_id', QVariant.Int)]
        feature_list_sign = []
        feature_list_sign_centroid = []
        feature_list_sign_path_association = []
        response = make_query(self.conn, query, None)
        for row in response:
            print(row)
            sign_id, width, height, azimuth, elevation, visible, is_digital, is_hanging, value, \
                sign_centroid, sign_geom, path_ids, path_association_geoms, sign_type, supertype, sign_shape, \
                associated_locations, associated_crossing_ids = row

            sign_geom = g.fromWkt(sign_geom)
            f = QgsFeature()
            f.setGeometry(sign_geom)
            f.setAttributes([sign_id,sign_type,supertype,  value, sign_shape, f'{is_digital}', f'{is_hanging}', f'{visible}',
                             height, width, azimuth, elevation, f'{path_ids}'])
            feature_list_sign.append(f)

            sign_centroid = g.fromWkt(sign_centroid)
            f = QgsFeature()
            f.setGeometry(sign_centroid)
            f.setAttributes([sign_id, sign_type, value, sign_shape, f'{is_digital}', f'{is_hanging}', f'{visible}',
                             height, width, azimuth, elevation, f'{path_ids}', 1])
            feature_list_sign_centroid.append(f)

            for i, path_id in enumerate(path_ids):
                path_association_geom = path_association_geoms[i]
                path_association_geom = g.fromWkt(path_association_geom)
                associated_location = associated_locations[i]
                associated_crossing_id = associated_crossing_ids[i]
                f = QgsFeature()
                if associated_location is not None:
                    associated_location = g.fromWkt(associated_location)
                    f.setGeometry(associated_location)
                else:
                    f.setGeometry(path_association_geom)
                f.setAttributes([sign_id, path_id, associated_crossing_id])
                feature_list_sign_path_association.append(f)

        v_layer_sign = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', 'rfdb_sign',
                                                 feature_list_sign, qgs_fields_sign)
        v_layer_sign_centroid = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', 'rfdb_sign_centroid',
                                                          feature_list_sign_centroid, qgs_fields_sign_centroid)
        v_layer_sign_path_association = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                  'rfdb_sign_path_association',
                                                                  feature_list_sign_path_association,
                                                                  qgs_fields_sign_path_association)
        v_layer_sign_face_azimuth = buildSimpleQgsVectorLayer(
            f'PointZ?crs=epsg:4326', 'rfdb_sign_face_azimuth',
            feature_list_sign_centroid, qgs_fields_sign_centroid)
        v_layer_sign_face_azimuth = setVectorFieldTypeStyle(v_layer_sign_face_azimuth, 'arrow_length', 'azimuth')
        return v_layer_sign, v_layer_sign_centroid, v_layer_sign_path_association, v_layer_sign_face_azimuth

    def query_ottonomo_signs_in_extent(self):
        query = f'''select *, st_astext(st_setsrid(st_makepoint(location__longitude__value, location__latitude__value, location__altitude__value), 4326))
                    from ottonomo_signs.signs
                    where st_intersects(st_setsrid(st_makepoint(location__longitude__value, location__latitude__value, location__altitude__value), 4326),
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''
        g = QgsGeometry()
        qgs_fields = [QgsField('metadata__time', QVariant.DateTime)]
        for i, column_name in enumerate(rfdb_ottonomo_signs_df['column']):
            dtype = rfdb_ottonomo_signs_df['dtype'][i]
            if dtype == 'text':
                qgs_dtype = QVariant.String
            elif dtype == 'bigint':
                qgs_dtype = QVariant.Double
            elif dtype == 'double precision':
                qgs_dtype = QVariant.Double
            elif dtype == 'boolean':
                qgs_dtype = QVariant.Bool
            else:
                continue
            qgs_fields.append(QgsField(column_name, qgs_dtype))
        response = make_query(self.conn, query, None)
        feature_list = []
        for row in response:
            metadata_time_epoch = row[1]
            time_ = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(metadata_time_epoch/1000))
            geom = row[48]
            geom = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(geom)
            attrs = [time_]
            attrs.extend(list(row[0:48]))
            f.setAttributes(attrs)
            feature_list.append(f)
        v_layer_sign = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', 'ottonomo_sign',
                                                 feature_list, qgs_fields)
        return v_layer_sign

    def query_road_objects_in_extent(self):
        query = f'''
                    select road_objects.id, type_name, sign_id, array_agg(path_id),                     
                    array_agg(associated_crossing_id order by path_id) as associated_crossing_ids, 
                    st_astext(road_objects.envelope) as road_object_geom, GeometryType(road_objects.envelope), 
                    array_agg(st_astext(st_makeline(location::geometry, associated_location::geometry)) order by path_id) as associated_locations, 
                    array_agg(st_astext(st_makeline(location::geometry, ST_PointOnSurface(paths.envelope::geometry))) order by path_id) as path_mappings
                    from road_object.road_objects
                    left join road_object.road_object_signs on road_object_signs.road_object_id = road_objects.id
                    left join road_object.road_objects_paths on road_objects_paths.road_object_id = road_objects.id
                    left join path.paths on paths.id = path_id
                    left join road_unit.segment_paths on segment_paths.id = paths.id
                    left join road_unit.segment_boundaries on segment_boundaries.segment_id = segment_paths.segment_id
	                    and work_units.is_publishable(replaced_by_wuid) = false
                    where st_intersects(location,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                        {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by road_objects.id, type_name, sign_id	'''
        g = QgsGeometry()
        qgs_fields_ro = [QgsField('road_object_id', QVariant.Int), QgsField('type', QVariant.String),
                         QgsField('sign_id', QVariant.Int)]
        qgs_fields_ro_path_association = [QgsField('road_object_id', QVariant.Int), QgsField('path_id', QVariant.Int),
                                          QgsField('associated_crossing_id', QVariant.Int)]
        feature_list_ro_line = []
        feature_list_ro_polygon = []
        feature_list_ro_path_association = []
        response = make_query(self.conn, query, None)
        for row in response:
            road_object_id, road_object_type, sign_id, path_ids, associated_crossing_ids, road_object_geom, \
                road_object_geom_type, associated_locations, path_association_geoms = row[0:9]

            road_object_geom = g.fromWkt(road_object_geom)
            f = QgsFeature()
            f.setGeometry(road_object_geom)
            f.setAttributes([road_object_id, road_object_type, sign_id])

            if road_object_geom_type == 'LINESTRING':
                feature_list_ro_line.append(f)
            else:
                feature_list_ro_polygon.append(f)

            for i, path_id in enumerate(path_ids):
                path_association_geom = path_association_geoms[i]
                path_association_geom = g.fromWkt(path_association_geom)
                associated_location = associated_locations[i]
                associated_crossing_id = associated_crossing_ids[i]
                f = QgsFeature()
                if associated_location is not None:
                    associated_location = g.fromWkt(associated_location)
                    f.setGeometry(associated_location)
                else:
                    f.setGeometry(path_association_geom)
                f.setAttributes([road_object_id, path_id, associated_crossing_id])
                feature_list_ro_path_association.append(f)

        v_layer_ro_line = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'rfdb_road_object_linestring',
                                                    feature_list_ro_line, qgs_fields_ro)
        v_layer_ro_polygon = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', 'rfdb_road_object_polygon',
                                                       feature_list_ro_polygon, qgs_fields_ro)
        v_layer_ro_polygon = setPolygonLayerStyle(v_layer_ro_polygon, stroke_color='yellow', fill_color='255,0,0,20',
                                                  width=0.3)
        v_layer_ro_path_association = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326',
                                                                'rfdb_road_object_path_association',
                                                                feature_list_ro_path_association,
                                                                qgs_fields_ro_path_association)

        return v_layer_ro_line, v_layer_ro_polygon, v_layer_ro_path_association

    def query_road_object_signs(self, road_object_id):
        query = '''select sign_id
                    from road_object.road_object_signs
                    where road_object_id = %s'''
        response = make_query(self.conn, query, (road_object_id,))
        if len(response) == 0:
            return None
        else:
            sign_id = response[0][0]
            return sign_id

    def query_change_management(self):
        query = f'''
                    select change_tracking.*, cm_task.name as cm_task_name,
                    st_astext(st_collect(start_location, end_location)) as start_end_location
                    from chgman.change_tracking
                    left join chgman.cm_task on cm_task.id = cm_task_id
                    where st_within(start_location,
                                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                    {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    or st_within(end_location,
                                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, 
                                                    {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''
        g = QgsGeometry()
        qgs_fields = [QgsField('id', QVariant.Int), QgsField('condition_date', QVariant.String),
                      QgsField('est_start_date', QVariant.String), QgsField('est_completion_date', QVariant.String),
                      QgsField('country_id', QVariant.String), QgsField('state_id', QVariant.String),
                      QgsField('reacquire', QVariant.Bool), QgsField('website', QVariant.String),
                      QgsField('miles', QVariant.String), QgsField('notes', QVariant.String),
                      QgsField('edited_by', QVariant.String), QgsField('date_last_edited', QVariant.String),
                      QgsField('start_location', QVariant.String), QgsField('end_location', QVariant.String),
                      QgsField('restricted', QVariant.Bool), QgsField('archived', QVariant.Bool),
                      QgsField('data_source', QVariant.String), QgsField('cm_task_id', QVariant.String),
                      QgsField('pending_visual_evaluation', QVariant.Bool), QgsField('superclass_id', QVariant.Int),
                      QgsField('track_type', QVariant.String), QgsField('condition_type', QVariant.String),
                      QgsField('cm_task_name', QVariant.String), QgsField('start_end_location', QVariant.String)
                      ]
        feature_list = []
        archived_set = set([])
        df = sqlio.read_sql_query(query, self.conn)
        for i, row in df.iterrows():
            archived_set.add(row['archived'])
            f = QgsFeature()
            f.setGeometry(g.fromWkt(row['start_end_location']))
            f.setAttributes(row.tolist())
            feature_list.append(f)
        v_layer_change_tracking = buildSimpleQgsVectorLayer('PointZ?crs=epsg:4326', 'rfdb_change_tracking',
                                                            feature_list, qgs_fields)
        rules = ()
        colors = {True: 'green', False: 'red'}
        for archived in archived_set:
            actual_width = 1
            label = f'{archived}'
            exp = f'''archived = {archived}'''
            line_style = 'solid'
            color = colors[archived]
            rules += ((label, exp, line_style, color, actual_width),)

        v_layer_change_tracking = apply_rule_based_symbol(rules, v_layer_change_tracking,  geometry='point')
        return v_layer_change_tracking


def get_delin_color(color_code):
    if color_code is None:
        color = 'magenta'
    else:
        color = color_dict[color_code]
    return color
