from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
from .utils import *
from .db_conn import *
from shapely.geometry import LineString
from shapely.wkt import loads


class GMMapData:
    def __init__(self, mainwin):
        self.main_win = mainwin
        self.conn = mainwin.customer_conn
        self.extent = mainwin.extent
        self.srid = 4326
        self.lane_class = {
            1: ('green', "Controlled Access Divided Road Lane"),
            2: ('orange', "Controlled Access Divided Road Interchange Links Lane"),
            3: ('blue', "Non-Controlled Access Divided Road Lane"),
            4: ('lime', "Controlled Access Non-Divided Road Lane"),
            5: ('yellow', "Access Ramps Lane"),
            6: ('cyan', "Non-Divided Non-Controlled Access Road Lane"),
            7: ('purple', "Local Road Lane"),
            8: ('pink', "Turn Lane"),
            9: ('white', "HOV Lane"),
            10: ('brown', "Bidirectional Lane"),
            11: ('gray', "Other Lane 11"),
            12: ('gray', "Other Lane 12"),
            13: ('gray', "Other Lane 13")


        }
        self.stacking_type = {
            1: ('white', "None"),
            2: ('red', "Above"),
            3: ('green', "Between"),
            4: ('blue', "Below")
        }
        self.edge_type = {
            1: ('magenta', "Curb"),
            2: ('aqua', "Paved to Non-Paved"),
            3: ('gold', "Barrier"),
            4: ('pink', "Other")
        }
        self.barrier_type = {
            1: ('black', "Vertical Metal Barrier"),
            2: ('white', "Vertical Plastic Barrier"),
            3: ('purple', "Guard Rail"),
            4: ('brown', "Vertical Concrete Wall"),
            5: ('bronze', "Berm"),
            6: ('yellow', "Ditch"),
            7: ('coffee', "Movable Barrier")
        }
        self.crossing_type = {
            'Overpass / Gantry': ('pink', 'Overpass / Gantry'),
            'Tunnel': ('brown', 'Tunnel'),
            'At Grade Rail Road': ('magenta', 'At Grade Rail Road'),
            'At Grade Road': ('purple', 'At Grade Road'),
            'At Grade Access': ('navy', 'At Grade Access'),
            'At Grade Stop Bar': ('red', 'At Grade Stop Bar'),
            'At Grade Bike/Pedestrian': ('orange', 'At Grade Bike/Pedestrian'),
            'At Grade Authorized Vehicle': ('yellow', 'At Grade Authorized Vehicle'),
            'At Grade Toll Booth': ('green', 'At Grade Toll Booth'),
            'At Grade Movable Bridge': ('blue', 'At Grade Movable Bridge')
        }
        self.sign_type = {
            1: ('darkYellow', "Yield"),
            2: ('darkRed', "Stop Sign"),
            3: ('green', "Vertical Stack Red Yellow Green Traffic Light"),
            4: ('lime', "Horizontal Stack Red Yellow Green Traffic Light"),
            5: ('navy', "Vertical Stack Red Yellow Green With Indicator Traffic Light"),
            6: ('orange', "Horizontal Stack Red Yellow Green With Indicator Traffic Light"),
            7: ('red', "Red Traffic Light"),
            8: ('yellow', "Yellow Traffic Light")
        }
        self.gmfa_type = {
            0: ('green', "Map Valid"),
            1: ('yellow', "Road Construction"),
            2: ('gold', "Bad Road Condition"),
            3: ('purple', "Complex Road"),
            4: ('gray', "Movable Barriers"),
            5: ('brown', "Bidirectional"),
            6: ('orange', "High Cross-Track Slope"),
            7: ('orchid', "High Along-Track Slope"),
            8: ('navy', "High Vertical Curvature"),
            9: ('violet', "High Horizontal Curvature"),
            10: ('red', "Active Construction"),
            11: ('white', "Other")
        }
        self.marker_type = {
            1:  ('dash', "Thin Dashed Single Line, No Botts Dots"),
            2:  ('dash', "Thick Dashed Single Line, No Botts Dots"),
            3:  ('solid', "Thin Solid Single Line, No Botts Dots"),
            4:  ('solid', "Thick Solid Single Line, No Botts Dots"),
            5:  ('dash', "Thin Dashed Double Line, No Botts Dots"),
            6:  ('dash', "Thick Dashed Double Line, No Botts Dots"),
            7:  ('solid', "Thin Solid Double Line, No Botts Dots"),
            8:  ('solid', "Thick Solid Double Line, No Botts Dots"),
            9:  ('solid', "Thin Double Left Solid Right Dashed Line, No Botts Dots"),
            10: ('solid', "Thick Double Left Solid Right Dashed Line, No Botts Dots"),
            11: ('dash', "Thin Double Left Dashed Right Solid Line, No Botts Dots"),
            12: ('dash', "Thick Double Left Dashed Right Solid Line, No Botts Dots"),
            13: ('dash', "Thin Dashed Triple Line, No Botts Dots"),
            14: ('dash', "Thick Dashed Triple Line, No Botts Dots"),
            15: ('solid', "Thin Solid Triple Line, No Botts Dots"),
            16: ('solid', "Thick Solid Triple Line, No Botts Dots"),
            17: ('dash', "Dashed Single Line, Botts Dots"),
            18: ('solid', "Solid Single Line, Botts Dots"),
            19: ('dash', "Dashed Double Line, Botts Dots"),
            20: ('solid', "Solid Double Line, Botts Dots"),
            21: ('solid', "Double Left Solid Right Dashed Line, Botts Dots"),
            22: ('solid', "Double Left Dashed Right Solid Line, Botts Dots"),
            23: ('dash', "Dashed Triple Line, Botts Dots"),
            24: ('solid', "Solid Triple Line, Botts Dots"),
            25: ('dot', "Virtual Inferred Line")
        }
        self.marker_color = {
            1: ('white', "White"),
            2: ('yellow', "Yellow"),
            3: ('purple', "Other"),
            4: ('red', "Unknown"),
        }

    def is_gm_db(self):

        query = '''SELECT *
                   FROM pg_catalog.pg_namespace
                   WHERE nspname = %s'''
        response = make_query(self.conn, query, ('csav3',))
        if len(response) == 0:
            return False
        else:
            return True

    def query_segments_in_extent(self):

        query = f'''select id_ as gm_id, segment_id as rfdb_id, road_type_id, st_astext(geom)
                    from pub_tracking.delivered_roads
                    join csav3.roads on csav3.roads.rfdb_id = pub_tracking.delivered_roads.segment_id
                    where st_intersects(geom, ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''

        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('rfdb_id', QVariant.Int),
                      QgsField('road_type_id', QVariant.Int)]
        feature_list = []
        for row in response:
            segment_id = row[0]
            rfdb_id = row[1]
            road_type_id = row[2]
            geom = row[3]
            f = QgsFeature()
            poly = g.fromWkt(geom)
            f.setGeometry(poly)
            f.setAttributes([segment_id, rfdb_id, road_type_id])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('PolygonZ?crs=epsg:4326', 'rfdb_segment_geom',
                                      feature_list, qgs_fields)
        return v_layer

    def query_gm_segment(self, segment_id):
        query = f'''with seg_geom as (
                        select segment_id, ST_ConvexHull(st_collect(geom)) as geom
                        from csav3.point 
                        where segment_id = %s
                        group by segment_id
                    )
                    select st_astext(geom)
                    from seg_geom'''

        response = make_query(self.conn, query, (segment_id,))
        if len(response) == 0:
            return
        row = response[0]

        geom_wkt = row[0]

        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int)]
        feature_list = []

        polygon = g.fromWkt(geom_wkt)
        f = QgsFeature()
        f.setGeometry(polygon)
        f.setAttributes([segment_id])
        feature_list.append(f)
        layer = buildSimpleQgsVectorLayer('PolygonZ?crs=epsg:4326', f'{segment_id}',
                                          feature_list, qgs_fields)
        layer = setPolygonLayerStyle(layer, stroke_color='blue')
        v_layers = [layer]
        group_name = 'Search_Segment_GM'
        root = self.main_win.qgs_project_instance.layerTreeRoot()
        group = None
        child_names = [child.name() for child in root.children()]
        if group_name in child_names:
            for child in root.children():
                if child.name() == group_name:
                    group = child
                    break
        else:
            group = root.insertGroup(0, group_name)

        if len(v_layers) > 0:
            for layer in v_layers:
                self.main_win.qgs_project_instance.addMapLayer(layer, False)
                group.addLayer(layer)
                self.main_win.canvas.setExtent(layer.extent())
                self.main_win.canvas.refresh()

    # todo: use color code to represent values
    # todo: along_slope, cross_slope, width
    def query_lane_stacking_in_extent(self):

        query = f'''with seg_in_extent as (
                    select csav3.roads.id_ as segment_id
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    where st_intersects(pub_tracking.delivered_roads.geom,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select lane.segment_id, lane.lane_id, lane.stacking, 
                    array_agg(xs_id order by xs_id) as xs_ids,
                    array_agg(st_astext(geom) order by xs_id) as geoms
                    from seg_in_extent
                    join csav3.lane on lane.segment_id = seg_in_extent.segment_id                    
                    --where lane.stacking != 1
                    group by lane.segment_id, lane.lane_id, lane.stacking'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('xs_ids', QVariant.String), QgsField('length', QVariant.Int),
                      QgsField('type', QVariant.String)]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            stacking_type = row[2]
            xs_id_list = row[3]
            if stacking_type not in type_list:
                type_list.append(stacking_type)
            geoms = row[4]

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                # some crossings only last for 1m
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, lane_id, f'{xs_ids_list[i]}', len(xs_ids_list[i]),
                                 self.stacking_type[stacking_type][1]])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_lane_stacking',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for stacking_type in self.stacking_type:
            if stacking_type in type_list:
                feature_dict[self.stacking_type[stacking_type][1]] = self.stacking_type[stacking_type]

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='type', width=2)
        return v_layer

    def query_lane_speed_limit_in_extent(self):

        query = f'''with seg_in_extent as (
                    select csav3.roads.id_ as segment_id
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    where st_intersects(pub_tracking.delivered_roads.geom,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select lane.segment_id, lane.lane_id, lane.speed_limit, 
                    array_agg(xs_id order by xs_id) as xs_ids,
                    array_agg(st_astext(geom) order by xs_id) as geoms
                    from seg_in_extent
                    join csav3.lane on lane.segment_id = seg_in_extent.segment_id                                        
                    group by lane.segment_id, lane.lane_id, lane.speed_limit'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('xs_ids', QVariant.String), QgsField('length', QVariant.Int),
                      QgsField('speed_limit', QVariant.String)]
        feature_list = []
        speed_limit_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            speed_limit = row[2]
            xs_id_list = row[3]
            geoms = row[4]
            if speed_limit not in speed_limit_list:
                speed_limit_list.append(speed_limit)

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                # some crossings only last for 1m
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, lane_id, f'{xs_ids_list[i]}', len(xs_ids_list[i]), f'{speed_limit}'])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_lane_speed_limit',
                                      feature_list, qgs_fields)
        feature_dict = {}
        # max_speed = 150
        speed_limit_list.sort()
        max_speed = max(speed_limit_list)
        min_speed = min(speed_limit_list)
        for speed_limit in speed_limit_list:
            if max_speed == min_speed:
                h = 0
            else:
                h = 130 * ((speed_limit - min_speed) / (max_speed - min_speed))
            s, v, a = 255, 255, 255
            # h, s, v, a = 0, 255 * (speed_limit / max_speed), 255, 255
            # h, s, v, a = 0, 180, 255, 255
            color = QColor.fromHsv(h, s, v, a)
            feature_dict[f'{speed_limit}'] = (color, f'{speed_limit}')

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='speed_limit', width=2.5, hsv=True)
        return v_layer

    def query_lane_width_in_extent(self):

        query = f'''with seg_in_extent as (
                                select csav3.roads.id_ as segment_id
                                from pub_tracking.delivered_roads
                                join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                                where st_intersects(pub_tracking.delivered_roads.geom,
                                                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                            )
                            select lane.segment_id, lane.lane_id, xs_id, width, along_slope, cross_slope,
                            st_astext(geom), st_z(geom)
                            from seg_in_extent
                            join csav3.lane on lane.segment_id = seg_in_extent.segment_id
                            '''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('xs_id', QVariant.Int), QgsField('width', QVariant.Double),
                      QgsField('along_slope', QVariant.Double), QgsField('cross_slope', QVariant.Double),
                      QgsField('elevation', QVariant.Double)]
        feature_list = []
        width_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            xs_id = row[2]
            width = row[3]
            along_slope = row[4]
            cross_slope = row[5]
            geom = row[6]
            elevation = row[7]
            width_list.append(width)

            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, lane_id, xs_id, width, along_slope, cross_slope, elevation])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'gm_lane_width',
                                      feature_list, qgs_fields)

        v_layer = apply_graduated_symbol(v_layer, 0, 8,
                                         10, 'width')
        return v_layer

    # direction, curvature
    #   p.s. GM format: direction and curvature apply on the lines that form the lane
    #     Melco format: direction and curvature apply on the lane center points
    def query_point_curvature_direction_in_extent(self):

        query = f'''with seg_in_extent as (
                        select csav3.roads.id_ as segment_id
                        from pub_tracking.delivered_roads
                        join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                        where st_intersects(pub_tracking.delivered_roads.geom,
                                            ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select point.segment_id, point.point_id, xs_id, direction, curvature, 
                    abs(curvature) as abs_curv, st_astext(geom), st_z(geom)
                    from seg_in_extent
                    join csav3.point on point.segment_id = seg_in_extent.segment_id
                    '''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('point_id', QVariant.Int),
                      QgsField('xs_id', QVariant.Int), QgsField('direction', QVariant.Double),
                      QgsField('curvature', QVariant.Double), QgsField('abs_curvature', QVariant.Double),
                      QgsField('elevation', QVariant.Double)]
        feature_list = []
        abs_curvature_list = []
        for row in response:
            segment_id = row[0]
            point_id = row[1]
            xs_id = row[2]
            direction = row[3]
            curvature = row[4]
            abs_curvature = row[5]
            geom = row[6]
            elevation = row[7]
            abs_curvature_list.append(abs_curvature)

            point = g.fromWkt(geom)
            f = QgsFeature()
            f.setGeometry(point)
            f.setAttributes([segment_id, point_id, xs_id, direction, curvature, abs_curvature, elevation])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'gm_point_curvature_direction',
                                      feature_list, qgs_fields)

        v_layer = apply_graduated_symbol(v_layer, min(abs_curvature_list), max(abs_curvature_list),
                                         10, 'abs_curvature')
        return v_layer

    # add first/last point as segment boundary layer so that it is easier to detect any miss lane connection
    def query_lane_start_end_pts_in_extent(self):

        query = f'''with seg_in_extent as (
                        select csav3.roads.id_ as segment_id
                        from pub_tracking.delivered_roads
                        join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                        where st_intersects(pub_tracking.delivered_roads.geom,
                                            ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    ),
                    max_xs as (
                    select lane.segment_id, lane.lane_id, max(xs_id) as max_xs_id, 
                    array_agg(geom order by xs_id) as geoms
                    from seg_in_extent
                    join csav3.lane on lane.segment_id = seg_in_extent.segment_id
                    group by lane.segment_id, lane.lane_id
                    )
                    select segment_id, lane_id, max_xs_id, 
                    st_astext(geoms[1]), st_astext(geoms[max_xs_id+1])
                    from max_xs                    
                    '''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('xs_id', QVariant.Int)]
        first_pt_feature_list = []
        last_pt_feature_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            max_xs_id = row[2]
            first_pt_geom = row[3]
            last_pt_geom = row[4]

            first_point = g.fromWkt(first_pt_geom)
            f_first = QgsFeature()
            f_first.setGeometry(first_point)
            f_first.setAttributes([segment_id, lane_id, 0])
            first_pt_feature_list.append(f_first)

            last_point = g.fromWkt(last_pt_geom)
            f_last = QgsFeature()
            f_last.setGeometry(last_point)
            f_last.setAttributes([segment_id, lane_id, max_xs_id])
            last_pt_feature_list.append(f_last)

        v_layer1 = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'gm_lane_start_point',
                                       first_pt_feature_list, qgs_fields, color='lime')
        v_layer2 = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'gm_lane_end_point',
                                       last_pt_feature_list, qgs_fields, color='red')

        return v_layer1, v_layer2

    def query_lanes_in_extent(self):
        query = f'''with unnest_lane as (
                    select lane.segment_id, lane.lane_id, lane.xs_id, 
                    unnest(lane.class) as lane_class, lane.geom as geom
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.lane on lane.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select segment_id, lane_id, array_agg(xs_id order by xs_id) as xs_ids, 
                    lane_class, array_agg(st_astext(geom) order by xs_id) as geoms
                    from unnest_lane
                    group by segment_id, lane_id, lane_class'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('xs_ids', QVariant.String), QgsField('length', QVariant.Int),
                      QgsField('type', QVariant.String)]
        feature_list = []
        class_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            xs_id_list = row[2]
            lane_class = row[3]
            if lane_class not in class_list:
                class_list.append(lane_class)
            geoms = row[4]

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                # some crossings only last for 1m
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, lane_id, f'{xs_ids_list[i]}', len(xs_ids_list[i]),
                                 self.lane_class[lane_class][1]])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_lane',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for lane_class in self.lane_class:
            if lane_class in class_list:
                feature_dict[self.lane_class[lane_class][1]] = self.lane_class[lane_class]

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='type', width=1)
        return v_layer

    def query_edges_in_extent(self):
        query = f'''select edges.segment_id, edges.position, 
                    array_agg(xs_id order by xs_id) as xs_ids, edges.type, 
                    array_agg(st_astext(edges.geom) order by xs_id) as geoms
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.edges on edges.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by edges.segment_id, edges.position, edges.type'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('position', QVariant.String),
                      QgsField('xs_ids', QVariant.String), QgsField('length', QVariant.Int),
                      QgsField('type', QVariant.String)]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            bool_edge_position = row[1]  # true: left, false: right
            if bool_edge_position:
                edge_position = 'left'
            else:
                edge_position = 'right'
            xs_id_list = row[2]
            edge_type = row[3]
            if edge_type not in type_list:
                type_list.append(edge_type)
            geoms = row[4]

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                # some crossings only last for 1m
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, edge_position, f'{xs_ids_list[i]}', len(xs_ids_list[i]),
                                 self.edge_type[edge_type][1]])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_edge',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for edge_type in self.edge_type:
            if edge_type in type_list:
                feature_dict[self.edge_type[edge_type][1]] = self.edge_type[edge_type]

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='type', width=0.8)
        return v_layer

    # todo: type change, xs keep another one
    def query_barriers_in_extent(self):

        query = f'''select barriers.segment_id, barriers.position, 
                    array_agg(xs_id order by xs_id) as xs_ids, barriers.type, barriers.height,
                    array_agg(st_astext(barriers.geom) order by xs_id) as geoms
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.barriers on barriers.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by barriers.segment_id, barriers.position, barriers.type, barriers.height'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('position', QVariant.String),
                      QgsField('xs_ids', QVariant.String), QgsField('length', QVariant.Int),
                      QgsField('type', QVariant.String), QgsField('height', QVariant.Int)]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            bool_barrier_position = row[1]  # true: left, false: right
            if bool_barrier_position:
                barrier_position = 'left'
            else:
                barrier_position = 'right'
            xs_id_list = row[2]
            barrier_type = row[3]
            if barrier_type not in type_list:
                type_list.append(barrier_type)
            height = row[4]
            geoms = row[5]

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                # some crossings only last for 1m
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, barrier_position, f'{xs_ids_list[i]}', len(xs_ids_list[i]),
                                 self.barrier_type[barrier_type][1], height])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_barrier',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for barrier_type in self.barrier_type:
            if barrier_type in type_list:
                feature_dict[self.barrier_type[barrier_type][1]] = self.barrier_type[barrier_type]

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='type', width=2)
        return v_layer

    # plot crossing as a linestring based on the same lane and continuous xs
    def query_crossings_in_extent(self):

        query = f'''with unnest_xing as (
                    select distinct crossings.segment_id, crossings.lane_id, 
                    crossings.xs_id,
                    unnest(crossings.type) as xing_type_id, crossings.geom as geom
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.crossings on crossings.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom,
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select segment_id, lane_id, array_agg(xs_id order by xs_id) as xs_ids,
                    crossing_type.type, array_agg(st_astext(geom) order by xs_id) as geoms
                    from unnest_xing
                    join csav3.crossing_type on crossing_type.id_ = unnest_xing.xing_type_id
                    group by segment_id, lane_id, crossing_type.type'''

        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int),
                      QgsField('lane_id', QVariant.Int), QgsField('xs_ids', QVariant.String),
                      QgsField('length', QVariant.Int), QgsField('type', QVariant.String)]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            xs_id_list = row[2]
            crossing_type = row[3]
            if crossing_type not in type_list:
                type_list.append(crossing_type)
            geoms = row[4]

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                # some crossings only last for 1m
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, lane_id, f'{xs_ids_list[i]}',
                                 len(xs_ids_list[i]), crossing_type])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_crossing',
                                      feature_list, qgs_fields)
        feature_dict = {}
        for crossing_type in self.crossing_type:
            if crossing_type in type_list:
                feature_dict[crossing_type] = self.crossing_type[crossing_type]

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='type', width=1.5)
        return v_layer

    def query_signs_in_extent(self):

        query = f'''select signs.id_, signs.segment_id, signs.lane_id, signs.xs_id, signs.type, 
                    st_astext(signs.geom) as sign_geom, 
                    st_astext(st_makeline(signs.geom, lane.geom)) as sign_to_lane_geom
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.signs on signs.segment_id = csav3.roads.id_                    
                    join csav3.lane on lane.segment_id = signs.segment_id
                    where lane.lane_id = signs.lane_id
                    and lane.xs_id = signs.xs_id
                    and st_intersects(pub_tracking.delivered_roads.geom, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))'''
        response = make_query(self.conn, query, (None,))
        g1 = QgsGeometry()
        g2 = QgsGeometry()
        qgs_fields = [QgsField('sign_id', QVariant.Int), QgsField('segment_id', QVariant.Int),
                      QgsField('lane_id', QVariant.Int), QgsField('xs_id', QVariant.Int),
                      QgsField('type', QVariant.String)]
        feature_list1 = []
        feature_list2 = []
        type_list = []
        for row in response:
            sign_id = row[0]
            segment_id = row[1]
            lane_id = row[2]
            xs_id = row[3]
            sign_type = row[4]
            if sign_type not in type_list:
                type_list.append(sign_type)
            sign_geom = row[5]
            sign_to_lane_geom = row[6]
            f1 = QgsFeature()
            f2 = QgsFeature()
            point = g1.fromWkt(sign_geom)
            line = g2.fromWkt(sign_to_lane_geom)
            f1.setGeometry(point)
            f1.setAttributes([sign_id, segment_id, lane_id, xs_id, self.sign_type[sign_type][1]])
            f2.setGeometry(line)
            f2.setAttributes([sign_id, segment_id, lane_id, xs_id, self.sign_type[sign_type][1]])
            feature_list1.append(f1)
            feature_list2.append(f2)
        sign_layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', 'gm_sign',
                                         feature_list1, qgs_fields)
        sign_to_lane_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_sign_to_lane',
                                                 feature_list2, qgs_fields)
        feature_dict = {}
        for sign_type in self.sign_type:
            if sign_type in type_list:
                feature_dict[self.sign_type[sign_type][1]] = self.sign_type[sign_type]

        sign_layer = apply_categorized_symbol(feature_dict, sign_layer, field='type', width=0)
        sign_to_lane_layer = apply_categorized_symbol(feature_dict, sign_to_lane_layer, field='type', width=0.4)

        return sign_layer, sign_to_lane_layer

    def query_gmfas_in_extent(self):

        query = f'''with unnest_gmfa as (
                    select gmfa.segment_id, unnest(gmfa.lane_id) as lane_id, gmfa.start_xs_id, gmfa.end_xs_id, gmfa.type
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.gmfa on gmfa.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    and gmfa.type != 0
                    )
                    select unnest_gmfa.segment_id, unnest_gmfa.lane_id, unnest_gmfa.type, start_xs_id, end_xs_id, 
                    st_astext(st_makeline(lane.geom order by xs_id))
                    from unnest_gmfa
                    join csav3.lane on lane.segment_id = unnest_gmfa.segment_id
                    where lane.lane_id = unnest_gmfa.lane_id
                    and lane.xs_id >= start_xs_id and lane.xs_id <= end_xs_id
                    group by unnest_gmfa.segment_id, unnest_gmfa.lane_id, unnest_gmfa.type, start_xs_id, end_xs_id'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('type', QVariant.String), QgsField('start_xs_id', QVariant.Int),
                      QgsField('end_xs_id', QVariant.Int), QgsField('length', QVariant.Int)]
        feature_list = []
        type_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            gmfa_type = row[2]
            start_xs_id = row[3]
            end_xs_id = row[4]
            if gmfa_type not in type_list:
                type_list.append(gmfa_type)
            geom = row[5]
            f = QgsFeature()
            line = g.fromWkt(geom)
            f.setGeometry(line)
            f.setAttributes([segment_id, lane_id, self.gmfa_type[gmfa_type][1],
                             start_xs_id, end_xs_id, end_xs_id - start_xs_id])
            feature_list.append(f)
        gmfa_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gmfa',
                                         feature_list, qgs_fields)
        feature_dict = {}
        for gmfa_type in self.gmfa_type:
            if gmfa_type in type_list:
                feature_dict[self.gmfa_type[gmfa_type][1]] = self.gmfa_type[gmfa_type]

        gmfa_layer = apply_categorized_symbol(feature_dict, gmfa_layer, field='type', width=2)

        return gmfa_layer

    def query_priority_gmfa_in_extent(self):

        query = f'''with priority_gmfa_seg as (
                    select priority_gmfa.segment_id, priority_gmfa.gmfa_code
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.priority_gmfa on priority_gmfa.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom,
                                        ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    )
                    select lane.segment_id, lane.lane_id, count(xs_id) as lane_length, gmfa_code,
                    st_astext(st_makeline(lane.geom order by xs_id))
                    from priority_gmfa_seg
                    join csav3.lane on lane.segment_id = priority_gmfa_seg.segment_id
                    group by lane.segment_id, lane.lane_id, gmfa_code
                    '''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('length', QVariant.Int), QgsField('gmfa_code', QVariant.Int)]
        feature_list = []
        # type_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            length = row[2]
            gmfa_code = row[3]
            geom = row[4]
            f = QgsFeature()
            line = g.fromWkt(geom)
            f.setGeometry(line)
            f.setAttributes([segment_id, lane_id, length, gmfa_code])
            feature_list.append(f)
        layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'priority_gmfa',
                                          feature_list, qgs_fields)
        priority_gmfa_layer = setLineLayerStyle(layer, color='magenta', width=2)
        return priority_gmfa_layer

    def query_markers_in_extent(self):

        query = f'''select marker.segment_id, marker.marker_id, marker.type, marker.width, marker.color,
                    array_agg(xs_id order by xs_id) as xs_ids, 
                    array_agg(st_astext(marker.geom) order by xs_id) as geoms
                    from pub_tracking.delivered_roads
                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
                    join csav3.marker on marker.segment_id = csav3.roads.id_
                    where st_intersects(pub_tracking.delivered_roads.geom, 
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    group by marker.segment_id, marker.marker_id, width, marker.type, marker.width, marker.color'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('marker_id', QVariant.String),
                      QgsField('xs_ids', QVariant.String), QgsField('length', QVariant.Int),
                      QgsField('type', QVariant.String), QgsField('width', QVariant.Double),
                      QgsField('color', QVariant.String)]
        feature_list = []
        type_list = []
        width_list = []
        color_list = []
        marker_type_dict = {}
        ind = 0
        for row in response:
            segment_id = row[0]
            marker_id = row[1]
            marker_type = row[2]
            width = row[3]
            color = row[4]
            xs_id_list = row[5]
            geoms = row[6]
            type_dict = {'type': marker_type, 'color': color, 'width': width}
            if type_dict not in marker_type_dict.values():
                marker_type_dict[ind] = type_dict
                ind += 1
            if marker_type not in type_list:
                type_list.append(marker_type)
            if width not in width_list:
                width_list.append(width)
            if color not in color_list:
                color_list.append(color)

            point_geoms = []
            point_geoms_list = []
            xs_ids = []
            xs_ids_list = []
            for i, xs_id in enumerate(xs_id_list):
                if xs_id not in xs_ids:
                    point_geoms.append(loads(geoms[i]))
                    xs_ids.append(xs_id)
                if i + 1 < len(xs_id_list):
                    if xs_id_list[i] + 1 == xs_id_list[i + 1]:
                        point_geoms.append(loads(geoms[i + 1]))
                        xs_ids.append(xs_id_list[i + 1])
                    else:
                        point_geoms_list.append(point_geoms)
                        xs_ids_list.append(xs_ids)
                        point_geoms = []
                        xs_ids = []
                else:
                    point_geoms_list.append(point_geoms)
                    xs_ids_list.append(xs_ids)
                    break
            for i, point_geom_array in enumerate(point_geoms_list):
                if len(point_geom_array) == 1:
                    point_geom_array.append(point_geom_array[0])
                geom = LineString(point_geom_array).wkt
                line = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(line)
                f.setAttributes([segment_id, marker_id, f'{xs_ids_list[i]}', len(xs_ids_list[i]),
                                 self.marker_type[marker_type][1], width, self.marker_color[color][1]])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_marker',
                                      feature_list, qgs_fields)
        # make rules
        rules = ()
        for marker_type in self.marker_type:
            for marker_color in self.marker_color:
                for width in width_list:
                    type_dict = {'type': marker_type, 'color': marker_color, 'width': width}
                    if type_dict not in marker_type_dict.values():
                        continue
                    if width == 0:
                        actual_width = 0.05 * 5
                    else:
                        actual_width = width * 5
                    label = f'{self.marker_type[marker_type][1]}'
                    exp = f'''type = \'{self.marker_type[marker_type][1]}\' and color = \'{self.marker_color[marker_color][1]}\' and width = \'{width}\''''
                    color = self.marker_color[marker_color][0]
                    line_style = self.marker_type[marker_type][0]
                    rules += ((label, exp, line_style, color, actual_width),)

        v_layer = apply_rule_based_symbol(rules, v_layer)
        return v_layer

    def query_lane_connection_in_extent(self):
        # plot a point at the boundary point location to represent a connection
        query = f'''with ln_conn as (
                    	select lane_connections.segment_id, lane_id, to_lane_id, rfdb_lane_id, 
                    	unnest(to_rfdb_lane_id) as to_rfdb_lane_id
                    	from pub_tracking.delivered_roads
	                    join csav3.roads on abs(csav3.roads.rfdb_id) = pub_tracking.delivered_roads.segment_id
	                    join csav3.lane_connections on lane_connections.segment_id = csav3.roads.id_
	                    where st_intersects(pub_tracking.delivered_roads.geom,
	                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
	                    and lane_id != 0 and to_lane_id != 0
                    ),
                    ln_conn_geom as (
                    	select ln_conn.segment_id, ln_conn.lane_id, ln_conn.to_lane_id, to_rfdb_lane_id, 
                    	array_agg(cur_lane.geom order by xs_id) as geoms
                    	from ln_conn
                    	join csav3.lane cur_lane on cur_lane.rfdb_id = ln_conn.rfdb_lane_id
                    	group by ln_conn.segment_id, ln_conn.lane_id, ln_conn.to_lane_id, to_rfdb_lane_id
                    )
                    select ln_conn_geom.segment_id, ln_conn_geom.lane_id, ln_conn_geom.to_lane_id, next_lane.segment_id, 
                    st_astext(st_makeline(geoms[array_upper(geoms, 1)], next_lane.geom)) as lane_connection_geom
                    from ln_conn_geom
                    join csav3.lane next_lane on next_lane.rfdb_id = ln_conn_geom.to_rfdb_lane_id
                    where next_lane.xs_id = 0'''
        response = make_query(self.conn, query, (None,))
        g = QgsGeometry()
        qgs_fields = [QgsField('segment_id', QVariant.Int), QgsField('lane_id', QVariant.Int),
                      QgsField('to_lane_id', QVariant.Int), QgsField('to_segment_id', QVariant.Int)]
        feature_list = []
        for row in response:
            segment_id = row[0]
            lane_id = row[1]
            to_lane_id = row[2]
            to_segement_id = row[3]
            geom = row[4]
            f = QgsFeature()
            line = g.fromWkt(geom)
            f.setGeometry(line)
            f.setAttributes([segment_id, lane_id, to_lane_id, to_segement_id])
            feature_list.append(f)
        lane_conn_layer = buildSimpleQgsVectorLayer('LinestringZ?crs=epsg:4326', 'gm_lane_connection', feature_list, qgs_fields)

        lane_conn_layer = setLineLayerStyleToArrow(lane_conn_layer)

        return lane_conn_layer

