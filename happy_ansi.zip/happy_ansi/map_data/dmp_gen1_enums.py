import pandas as pd
# import seaborn as sns
from matplotlib import cm

viridis = cm.get_cmap('viridis', 100)

line_type_df = pd.DataFrame(
    {
        'id': ['None', 0, 1, 2, 4, 5, 11, 22, 44, 12, 21, 14, 41, 24, 42, 414, 424, 114, 411, 4114],
        'class': ['unsupported', None, 'single', 'single', 'single', 'single', 'double', 'double', 'double',
                  'mixed double', 'mixed double', 'mixed double', 'mixed double', 'mixed double', 'mixed double',
                  'triple', 'triple', 'triple', 'triple', 'quadruple'],
        'color': ['pink', 'red', 'white', 'white', 'yellow', 'yellow', 'white', 'white', 'yellow', 'white-white', 'white-white',
                  'white-yellow', 'yellow-white', 'white-yellow', 'yellow-white', 'yellow-white-yellow',
                  'yellow-white-yellow', 'white-white-yellow', 'yellow-white-white', 'yellow-white-white-yellow'],
        'type': ['unsupported', None, 'solid', 'dashed', 'solid', 'dashed', 'solid-solid', 'dashed-dashed',
                 'solid-solid', 'solid-dashed', 'dashed-solid', 'solid-solid', 'solid-solid',
                 'dashed-solid', 'solid-dashed', 'solid-solid-solid', 'solid-dashed-solid',
                 'solid-solid-solid', 'solid-solid-solid', 'solid-solid-solid'],
        'width_range': ['None', [0, 0], [10, 50], [10, 50], [10, 50], [10, 50],
                        [20, 150], [20, 150], [20, 150], [20, 150], [20, 150], [20, 150], [20, 150], [20, 150], [20, 150],
                        [30, 250], [30, 250], [30, 250], [30, 250], [40, 350]],
        'draw_width': [0.05, 0.05, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.1, 0.2, 0.2,
                       0.2, 0.2, 0.2, 0.2, 0.3, 0.3, 0.3, 0.3, 0.4]
    }
)

carriageway_marking_code_df = pd.DataFrame(
    {
        'id': range(0, 10),
        'type': ['unknown', 'carriageway_center_line', 'lane_boundary', 'carriageway_edge_line', 'crosswalk_line',
                 'side_strip_for_pedestrians', 'roadside_parking_area', 'no_parking_stopping_side_strip',
                 'priority_main_carriageway', 'channelizing_line'],
        'draw_color': ['pink', 'yellow', 'white', 'orange', 'brown', 'brown', 'brown', 'brown', 'brown', 'green']
    }
)

installed_object_df = pd.DataFrame(
    {
        'id': range(0, 3),
        'type': [None, 'delineator_post', 'road_stud'],
        'draw_color': [None, 'yellow', 'orange']
    }
)

deceleration_marking_df = pd.DataFrame(
    {
        'id': range(0, 4),
        'side': [None, 'Left', 'Right', 'Left & Right'],
        'draw_color': [None, 'blue', 'green', 'cyan']
    }
)

road_marking_df = pd.DataFrame(
    {
        'id': [200101, 200201, 200301, 200401, 200402, 200403, 200404, 200405, 200406, 200501, 200601, 200701, 200801,
               200901, 201001, 300101, 300102, 300301, 300401, 300601, 300801, 300901, 400101, 400201, 400301],
        'type': ['RO_PM_NO_U_TURN', 'RO_PM_SPEED_MAXIMUM', 'RO_PM_NO_STOPPING', 'RO_PM_REGULAR_CAR_LANE',
                 'RO_PM_SPECIAL_VEHICLE_LANE', 'RO_PM_TOWING_VEHICLE_LANE', 'RO_PM_VEHICLE_ONLY_LANE',
                 'RO_PM_BUS_PRIORITY_LANE', 'RO_PM_TOWING_VEHICLE_LEFTMOST_LANE', 'RO_PM_TURN_METHOD',
                 'RO_PM_PARKING_PARALLEL', 'RO_PM_PARKING_PERPENDICULAR', 'RO_PM_PARKING_DIAGONAL',
                 'RO_PM_BICYCLE_NOENTRY', 'RO_PM_END_REGULATION', 'RO_PM_PEDESTRIAN_XING', 'RO_PM_DIAG_XING',
                 'RO_PM_STOP_BAR', 'RO_PM_ARROW', 'RO_PM_CHANNELIZING_STRIPE', 'RO_PM_PED_BICYCLE_XING_ZONE',
                 'RO_PM_PRIORITY_RD_AHEAD', 'RO_PM_ETC_GUIDE', 'RO_PM_ETC', 'RO_PM_CHAR'],
        'draw_color': [viridis(i/25)[0:3] for i in range(25)]  # sns.color_palette("husl", 25)
    }
)

vehicle_traffic_light_df = pd.DataFrame(
    {
        'id': range(0, 9),
        'type': ['Unknown', 'Yellow', 'Red', 'O/X', 'Green_Red', 'Yellow_Yellow', 'Yellow_Red', 'Green_Yellow_Red',
                 'Green'],
        'draw_color': ['pink', 'yellow', 'red', 'brown', 'green-red', 'orange', 'yellow-red', 'green-yellow-red',
                       'green']
    }
)

vehicle_traffic_light_direction_df = pd.DataFrame(
    {
        'id': [-1, 1, 2],
        'direction': [None, 'Horizontal', 'Vertical']
    }

)

vehicle_arrow_traffic_light_direction_df = pd.DataFrame(
    {
        'id': range(0, 10),
        'type': ['Unknown', 'Left', 'Right', 'Up', 'Down', 'Top Left', 'Bottom Left', 'Top Right', 'Bottom Right',
                 'U-turn'],
        'draw_color': [viridis(i/10)[0:3] for i in range(10)]  # sns.color_palette("husl", 10)
    }

)

vehicle_traffic_sign_df = pd.DataFrame(
    {
        'id': [100101, 100201, 100301, 100401, 100402, 100403, 100501, 100601, 100701, 100801,
               100802, 100901, 200101, 200102, 200103, 200104, 200105, 200201, 200202, 200203, 200204, 200205, 200301,
               200401, 200501, 200701, 200801, 200901, 201001, 201101, 201201, 201301, 201302, 201401, 201501, 201601,
               300101, 300102, 300103, 300104, 300105, 300106, 300107, 300108, 300109, 300110, 300111, 300201, 300301,
               300401, 300501, 300601, 300701, 300801, 300901, 301001, 301101, 301201, 301301, 301401, 301501, 301502,
               301503, 301504, 301601, 301602, 301701, 301702, 301703, 301704, 301705, 301706, 301707, 301708, 301801,
               301802, 301901, 301902, 301903, 302001, 302101, 302201, 302301, 302401, 302501,
               400101, 400201, 400301, 400401, 400501, 400601, 400701, 400702, 400703, 400801, 400901,
               500101, 500102, 500201, 500301, 500401, 600101],
        'type': ['Guide_Road_Names', 'Guide_Parking', 'Guide_Toll_Gate', 'Guide_Emergency_Phone',
                 'Guide_Turnout', 'Guide_Emergency_Parking_Area', 'Guide_Lane_No_Change_Start_End',
                 'Guide_Weight_Limit_Relaxation', 'Guide_Height_Limit_Relaxation', 'Guide_DetourA',
                 'Guide_DetourB', 'Guide_for_Pedestrian',
                 'Warning_Cross_Intersection', 'Warning_T_Junction_Horizontal'
                 'Warning_T_Junction', 'Warning_Y_Junction', 'Warning_Circular_Intersection',
                 'Warning_Curve_Right_or_Left', 'Warning_Turn_Right_or_Left', 'Warning_Bend_Right_or_left',
                 'Warning_Jog_Right_or_Left', 'Warning_Zigzag_Right_or_Left', 'Warning_Railroad_Crossing',
                 'Warning_School', 'Warning_Slippery', 'Warning_Falling_Rock', 'Warning_Speed_Bump',
                 'Warning_Merging_Traffic', 'Warning_Lane_Decreases', 'Warning_Road_Narrows',
                 'Warning_2_Way_Traffic_Ahead', 'Warning_Steep_Ascending_Slope', 'Warning_Steep_Descending_Slope',
                 'Warning_Strong_Wind', 'Warning_Animal', 'Warning_Other_Danger',
                 'Regulatory_Road_Closed', 'Regulatory_Closed_to_Vehicle_Traffic', 'Regulatory_No_Entry_for_Vehicles',
                 'Regulatory_No_Motorized_Vehicles', 'Regulatory_No_Trucks', 'Regulatory_No_Buses',
                 'Regulatory_No_Motorcycles', 'Regulatory_No_Light_Vehicles', 'Regulatory_No_Bicycles',
                 'Regulatory_No_Vehicles_As_Shown', 'Regulatory_No_2_Passenger_Motorbikes',
                 'Regulatory_Certain_Direction_Only', 'Regulatory_No_Vehicle_Crossing', 'Regulatory_No_U_Turn',
                 'Regulatory_No_Passing', 'Regulatory_No_Parking_Stopping', 'Regulatory_No_Parking_Allowed_On_The_Road',
                 'Regulatory_Limited_Time_Parking_Zone', 'Regulatory_Vehicles_Carrying_Hazardous_Materials_Prohibited',
                 'Regulatory_Weight_Limit', 'Regulatory_Height_Limit', 'Regulatory_Maximum_Width',
                 'Regulatory_Maximum_Speed_Limit', 'Regulatory_Minimum_Speed_Limit', 'Regulatory_Motor_Vehicles_Only',
                 'Regulatory_Motor_Vehicles_Only', 'Regulatory_Bicycles_Only',
                 'Regulatory_Bicycles_and_Pedestrians_Only', 'Regulatory_Pedestrians_Only', 'Regulatory_One_Way',
                 'Regulatory_One_Way_For_Bicycles', 'Regulatory_Lane_For_Specific_Regular_Cars',
                 'Regulatory_Lane_For_Big_Cargo_Trucks', 'Regulatory_Lane_For_Towing_Vehicles',
                 'Regulatory_Dedicated_Lane_For_Cars', 'Regulatory_Dedicated_Lane_For_Bicycles',
                 'Regulatory_Priority_Lane_For_Bus', 'Regulatory_Towing_Vehicle_Leftmost_Lane',
                 'Regulatory_Lane_Travel_Direction_Designation', 'Regulatory_Two_Stage_Right_Turn_for_Moped',
                 'Regulatory_No_Two_Stage_Right_Turn_for_Moped', 'Regulatory_Parallel_Parking',
                 'Regulatory_Right_Angle_Parking', 'Regulatory_Diagonal_Parking',
                 'Regulatory_Roundabout_Clockwise_Traffic', 'Regulatory_Horn_Zone', 'Regulatory_Yield',
                 'Regulatory_Stop', 'Regulatory_Closed_to_Pedestrians', 'Regulatory_No_Pedestrian_Crossing',
                 'Indication - Riding Side by Side Allowed', 'Indication - Traffic Allowed in Tramway',
                 'Indication - Stopping Allowed', 'Indication - Priority Road', 'Indication - Center Line',
                 'Indication - Stop Line', 'Indication - Pedestrian Crossing', 'Indication - Bicycle Crossing Zone',
                 'Indication - Pedestrian or Bicycle Crossing Zone', 'Indication - Safety Zone',
                 'Indication - Advance Notice of Regulation',
                 'Other - Electronic Toll', 'Other - General / ETC Lane Division', 'Other - Lane Demarcation',
                 'Other - Left Turn Allowed', 'Other - Traffic Lane Starts', 'Unassigned'],
    }
)

vehicle_traffic_sign_shape_df = pd.DataFrame(
    {
        'id': list(range(0, 14)) + [255],
        'shape': ['Other', 'Rectangle', 'Shield', 'Hexagon', 'Arrow Type Hexagon - Horizontal',
                  'Arrow Type Pentagon', 'Unused', 'Diamond', 'Circular', 'Triangle Point Down',
                  'Pedestrian Crossing Type Pentagon', 'Arrow Type Hexagon - Vertical',
                  'Semicircle', 'Oval', 'Unassigned']
    }
)

vehicle_traffic_sign_color_df = pd.DataFrame(
    {
        'id': ['WH', 'RD', 'GN', 'BL', 'YL', 'UN', 'X'],
        'color': ['white', 'red', 'green', 'blue', 'yellow', 'other', 'unknown']
    }
)

vehicle_traffic_sign_auxiliary_sign_df = pd.DataFrame(
    {
        'id': ['S', 'M', 'E', 'N', 'U'],
        'type': ['Start', 'Inside the Area', 'End', 'None', 'Unknown']
    }
)

carriageway_marking_position_df = pd.DataFrame(
    {
        'id': [0, 1, 2, 3],
        'position': ['Unknown', 'Left', 'Right', 'Cross'],
        'draw_color': ['red', 'blue', 'green', 'cyan']
    }
)


