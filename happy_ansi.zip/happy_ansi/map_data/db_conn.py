import psycopg2
import sys
import numpy as np
from psycopg2.extensions import register_adapter, AsIs
psycopg2.extensions.register_adapter(np.int64, psycopg2._psycopg.AsIs)

def connect_to_rfdb_mumbai():
    username = 'ushr_azhang'
    pw = 'ushr_azhang_2020'
    # username = 'ushr_livonia'
    # pw = 'ushr_livonia_2019'
    host = 'rfdb-production-mumbai.cyyozlmkfkuq.ap-south-1.rds.amazonaws.com'
    dbname = 'road_features'
    try:
        conn = psycopg2.connect(host=host, port=5432, dbname=dbname, user=username, password=pw)
    except Exception:
        print(f'Connection to RFDB_Mumbai failed:(')
        conn = 1
    return conn


def connect_to_rfdb_oregon():
    # username = 'postgres'
    # pw = 'ushr2bps2018'
    username = 'ushr_azhang'
    pw = 'ushr_azhang_2020'
    host = 'rfdb-mumbai-read-replica.cfys574hvdpw.us-west-2.rds.amazonaws.com'
    dbname = 'road_features'
    try:
        conn = psycopg2.connect(host=host, port=5432, dbname=dbname, user=username, password=pw)
    except Exception:
        print(f'Connection to RFDB_Read_Replica failed:(')
        conn = 1
    return conn


def connect_to_rfdb_snapshot(db_identifier):
    username = 'ushr_azhang'
    pw = 'ushr_azhang_2020'
    host = db_identifier + '.cfpnjge4lhkj.us-east-2.rds.amazonaws.com'
    dbname = 'road_features'
    try:
        conn = psycopg2.connect(host=host, port=5432, dbname=dbname, user=username, password=pw)
    except Exception:
        print(f'Connection to RFDB_Snapshot failed:(')
        conn = 1
    return conn


def connect_to_pub_db(username, pw, dbname):
    # host = 'customer-delivery-2.cfpnjge4lhkj.us-east-2.rds.amazonaws.com'
    # host = 'customer-db-4x.cfpnjge4lhkj.us-east-2.rds.amazonaws.com'
    # host = 'production-pub-server.caaddenegmfo.us-east-2.rds.amazonaws.com'
    host = '10.70.1.102'  # Livonia local server
    try:
        conn = psycopg2.connect(host=host, port=5432, dbname=dbname, user=username, password=pw, connect_timeout=0)
    except Exception:
        print(f'Connection to customer delivery database failed:(')
        conn = 1
    return conn


def connect_to_db(host, username, pw, dbname, port=5432):
    
    try:
        print(host, username, pw, dbname)
        conn = psycopg2.connect(host=host, port=port, dbname=dbname, user=username, password=pw)
    except Exception:
        print(f'Connection to {host}: {dbname} failed:(')
        conn = 1
    return conn


def connect_to_siloc_db():
    host = 'read-replica-siloc-db-mumbai.cfpnjge4lhkj.us-east-2.rds.amazonaws.com'
    username = 'siloc'
    pw = 'SignsForLocalization_2020'
    port = 5432
    dbname = 'datalake'
    try:
        conn = psycopg2.connect(host=host, port=port, dbname=dbname, user=username, password=pw)
    except Exception:
        print(f'Connection to {host}: {dbname} failed:(')
        conn = 1
    return conn


def test_conn(conn):
    try:
        make_query(conn, 'select 1', (None,))
    except:
        return 1

    return 0


def make_query(connection, query, args):
    with connection.cursor() as cursor:
        cursor.execute(query, args)
        responses = cursor.fetchall()
    return responses
