import rsa
import os
import pickle

def encrypt(ws,message,verbal=False):
    # generate public and private keys with
    # rsa.newkeys method,this method accepts
    # key length as its parameter
    # key length should be atleast 16
    if os.path.exists(os.path.join(ws,'keys.rsa')):
        publicKey, privateKey =pickle.load(open(os.path.join(ws,'pkeys.rsa'),'rb'))
    else:
        publicKey, privateKey = rsa.newkeys(512)
        pickle.dump([publicKey, privateKey],open(os.path.join(ws,'pkeys.rsa'),'wb'))
    print(os.path.join(ws,'keys.rsa'))
    # this is the string that we will be encrypting

    # rsa.encrypt method is used to encrypt
    # string with public key string should be
    # encode to byte string before encryption
    # with encode method
    encMessage = rsa.encrypt(message.encode(),
                             publicKey)
    if verbal:
        print("original string: ", message)
        print("encrypted string: ", encMessage)
    try:
        os.environ['RSA365'] = encMessage
        print('ENVIRONMENT VARIABLE SETTING SUCCEED')
    except:
        print('ENVIRONMENT VARIABLE SETTING FAILED')

def decrypt(ws,verbal=False):
    # the encrypted message can be decrypted
    # with ras.decrypt method and private key
    # decrypt method returns encoded byte string,
    # use decode method to convert it to string
    # public key cannot be used for decryption
    encMessage = os.environ['RSA365']
    encMessage = bytes(encMessage,encoding='latin_1').decode('unicode-escape').encode('latin-1')
    if verbal:
        print(encMessage)
    if encMessage:
        publicKey, privateKey =pickle.load(open(os.path.join(ws,'pkeys.rsa'),'rb'))
        decMessage = rsa.decrypt(encMessage, privateKey).decode()
        return decMessage
    return ''


