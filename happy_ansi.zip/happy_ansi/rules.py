# This Python file uses the following encoding: utf-8
import os
from pathlib import Path
import sys

# from PySide2.QtWidgets import *
# from PySide2.QtCore import QFile, Qt
# from PySide2.QtUiTools import QUiLoader
from qgis.PyQt import uic
#from qgis.PyQt.QtWebEngineWidgets import *
from qgis.PyQt.QtCore import QSettings, QTranslator, QCoreApplication, Qt, QTimer,pyqtSlot
from qgis.PyQt.QtGui import *  #QIcon,QFont,QColor
from qgis.PyQt.QtWidgets import * #QAction,QMessageBox,QInputDialog
# Initialize Qt resources from file resources.py
from .resources import *
import os
from datetime import datetime
import psycopg2
import pyperclip as clipboard
import shutil
import pymysql

import ssl
# Get the path of the current Python file
file_path = os.path.abspath(__file__)
# SSL connection settings
ssl_ctx = ssl.create_default_context(purpose=ssl.Purpose.SERVER_AUTH, cafile=os.path.join(os.path.split(file_path)[0],"cacert.pem"))

def connect_to_db_rule_pg(host, username, pw, dbname, port=15448):
    try:
        conn = psycopg2.connect(host=host, port=port, dbname=dbname, user=username, password=pw)
    except Exception:
        print(f'Connection to {host}: {dbname} failed:(')
        conn = 1
    return conn



class Task(QDialog):
    def __init__(self, main_win):
        super().__init__()
        self.setWindowTitle('Add New Task')
        self.main_win = main_win
        self.setGeometry(240,120,200,100)
        formLayout = QFormLayout()
        self.label_cname = QLabel('Customer Name:')
        self.label_cname.setFixedWidth(80)
        self.ledit_cname = QLineEdit()
        self.ledit_cname.setPlaceholderText('Customer Name')
        self.ledit_cname.setFixedWidth(110)

        self.label_tname = QLabel('Task Name:')
        self.label_tname.setFixedWidth(80)
        self.ledit_tname = QLineEdit()
        self.ledit_tname.setFixedWidth(110)
        self.ledit_tname.setPlaceholderText('Task Name')

        self.label_tdate = QLabel('Task Date:')
        self.label_tdate.setFixedWidth(80)
        self.ledit_tdate = QLineEdit()
        self.ledit_tdate.setPlaceholderText('Task Date')
        self.ledit_tdate.setFixedWidth(110)
        self.ledit_tdate.setText(datetime.now().strftime('%m%d%Y'))

        hLayout_btn = QHBoxLayout()
        self.btn = QPushButton(self)
        self.btn.setText('Add New Task')
        self.btn.setFixedWidth(80)        
        hLayout_btn.addStretch()
        hLayout_btn.addWidget(self.btn)
        hLayout_btn.addStretch()

        formLayout.addRow(self.label_cname,self.ledit_cname)
        formLayout.addRow(self.label_tname,self.ledit_tname)
        formLayout.addRow(self.label_tdate,self.ledit_tdate)
        formLayout.addRow(hLayout_btn)
        self.setLayout(formLayout)
        self.btn.clicked.connect(self.save)

        geo = self.geometry()
        geo.moveCenter(self.main_win.geometry().center())
        self.setGeometry(geo)


    def save(self):

        cname = self.ledit_cname.text().strip().upper()
        tname = self.ledit_tname.text().strip().upper()
        tdate = self.ledit_tdate.text().strip().upper()
        print(cname, tname, tdate)
        if cname and tname and tdate:
            self.main_win.cname = cname
            self.main_win.tname = tname
            self.main_win.tdate = tdate            
            self.main_win.cbox_db_list.clear()
            self.main_win.cbox_task_list.clear()
            self.main_win.cbox_date_list.clear()
            self.main_win.cbox_db_list.addItems([cname])
            self.main_win.cbox_task_list.addItems([tname])
            self.main_win.cbox_date_list.addItems([tdate])
            self.main_win.cbox_db_list.setCurrentText(cname)
            self.main_win.cbox_task_list.setCurrentText(tname)
            self.main_win.cbox_date_list.setCurrentText(tdate)
            self.main_win.btn_rule_clear.click()
            self.main_win.task_on = False
            #self.main_win.update_db_list()
            QMessageBox.about(self,'Succeed','New task has been added')
            self.hide()


def connect_to_db_rule(host,  username, pw, dbname,port=3306):
    #conn = pymysql.connect(host=host,port=port,db=dbname, user=username, password=pw)
    try:
        conn = pymysql.connect( host=host,user=username,password=pw,database=dbname,ssl=ssl_ctx) #,cursorclass=pymysql.cursors.DictCursor)
    except Exception:
        print(f'Connection to {host}: {dbname} failed:(')
        conn = 1
    return conn


class rules_manager(QMainWindow):
    def __init__(self,mainwin,db_url = "aws.connect.psdb.cloud", db_port="3306",rules_file=None):
        super(rules_manager, self).__init__()
        self.ui = None
        self.main = mainwin
        self.task_on = False
        self.ws   = os.path.dirname(__file__)
        if self.main and not self.main.ws:
            self.ws = self.main.ws
        
        #self.rules_filename = os.path.join(self.ws, 'rules_server.txt')
        self.rules_filename = None
        # if not os.path.exists(self.rules_filename):            
        #     shutil.copyfile(os.path.join(os.path.dirname(__file__), 'default_rules.txt'), self.rules_filename)


        self.rules = {}
        self.setup_ui()

        self.cur_rule = ''
        if rules_file:
            self.load_rules(fn=rules_file)
            self.setWindowTitle('Happy ANSI Rules Manager [LOCAL]')
            #self.label_rules.setText(f'Standardize ANSI Notes [LOCAL]')  
        else:
            # self.host        = db_url #'2.tcp.ngrok.io' #"localhost"
            # self.dbname      ="mapit"
            # self.username    ="al532612l9ai9zvfdf3a"
            # self.password    ="pscale_pw_SQlqDMaVQzYdNPpYeuAm2TxwprsNslpDKNuBUNnGLmb"
            # if not db_port:
            #     db_port = '3306'
            # self.port        = int(db_port) #12850

            self.host        = self.main.config['Rules']['host']
            self.username    = self.main.config['Rules']['username']
            self.password    = self.main.config['Rules']['password']
            self.dbname      = self.main.config['Rules']['db']
            self.port        = self.main.config['Rules']['port']

            self.conn        = None
            self.fetch_id = 1
            self.get_rule_timer = QTimer(self)
        # self.customers = ['GM','NISSAN','RIVIAN']
        # self.cbox_db_list.addItems(self.customers)
        # self.cbox_db_list.setCurrentText('GM')

        self.connect_signals()
        try:
            self.get_customer()
        except:
            QMessageBox.about(self, "Error", "Can Not Connect to the Server!")
        self.newTask = None
        self.cname   = None
        self.tname   = None
        self.tdate   = None
        
    def connect_signals(self):
        self.btn_add_rule.clicked.connect(self.add_rule)
        self.btn_delete_rule.clicked.connect(self.delete_rule)
        self.btn_backup_rule.clicked.connect(self.push_rules)
        self.btn_save_rules.clicked.connect(self.save_rules)
        self.btn_rule_clear.clicked.connect(self.remove_all)
        self.btn_load_rules.clicked.connect(self.load_saved_rules)
        self.btn_new_task.clicked.connect(self.add_new_task)
        self.pushButton_load_db_rules.clicked.connect(self.get_rules)
        self.cbox_db_list.currentIndexChanged.connect(self.get_tasks)
        self.cbox_task_list.currentIndexChanged.connect(self.get_dates)
        self.list_rules.itemClicked.connect(self.get_select_rule)

    def get_tasks(self):
        if self.task_on:
            self.cbox_task_list.clear()
            self.cbox_task_list.addItems([self.tname])
            return
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        customer_name = self.cbox_db_list.currentText().strip()
        cur.execute(f'select distinct task_name from rules where customer_name = \'{customer_name}\'')
        task_names = [r[0] for r in cur.fetchall()]
        print(task_names)
        self.cbox_task_list.clear()
        self.cbox_task_list.addItems(set(task_names))
    @pyqtSlot()
    def add_new_task(self):
        self.newTask = Task(main_win = self)
        self.task_on = True
        self.newTask.show()
    def update_db_list(self):
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        #customer_name = self.cbox_db_list.currentText().strip()
        cur.execute(f'select distinct customer_name from rules')
        cnames = [r[0] for r in cur.fetchall()]
        if self.cname not in cnames:
            cnames.insert(0,self.cname)
        self.cbox_db_list.clear()
        self.cbox_db_list.addItems(sorted(list(set(cnames))))
        self.cbox_db_list.setCurrentText(self.cname)
    def get_dates(self):
        if self.task_on:
            self.cbox_date_list.clear()
            self.cbox_date_list.addItems([self.tdate])
            return
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        customer_name = self.cbox_db_list.currentText().strip()
        task_name     = self.cbox_task_list.currentText().strip()
        cur.execute(f'select distinct task_date from rules where customer_name = \'{customer_name}\' and task_name = \'{task_name}\'')
        task_dates = [r[0].strftime('%m%d%Y') for r in cur.fetchall()]
        self.cbox_date_list.clear()
        self.cbox_date_list.addItems(sorted(list(set(task_dates))))
    def get_customer(self):
        if self.task_on:
            self.cbox_date_list.clear()
            self.cbox_date_list.addItems([self.cname])
            return
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        cur.execute(f'select distinct customer_name from rules')
        cnames = [r[0].upper() for r in cur.fetchall()]
        self.cbox_db_list.clear()
        self.cbox_db_list.addItems(sorted(list(set(cnames))))
        #self.cbox_db_list.setCurrentText(customer_name)


    def push_rules(self):

        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        print(self.cname, self.tname, self.tdate)
        cur = self.conn.cursor()
        if self.task_on:
            customer_name = self.cname
            task_name     = self.tname
            task_date     = self.tdate
        else:
            customer_name = self.cbox_db_list.currentText().strip()
            task_name     = self.cbox_task_list.currentText().strip()
            task_date     = datetime.strptime(self.cbox_date_list.currentText().strip().replace('/','').replace('-',''),'%m%d%Y')

        cur.execute(f'delete from rules where customer_name =\'{customer_name}\' and task_name =\'{task_name}\' and  DATE(task_date)= \'{task_date.date()}\'')
        self.conn.commit()

        if not task_date:
            task_date = datetime.now()
        for i in range(self.list_rules.count()):
            key_text, rule_text = self.list_rules.item(i).text().title().split('|')
            if key_text.strip().title():
                self.rules[key_text.strip().title()] = rule_text
                cur.execute(f'select rule_short,rule_long from rules where customer_name = \'{customer_name}\' and task_name = \'{task_name}\' and  DATE(task_date)= \'{task_date.date()}\' and rule_short=\'{key_text}\'')
                rule_exist = cur.fetchall()
                if rule_exist:
                    cur.execute(f'update rules set rule_long = \'{rule_text}\' where customer_name =\'{customer_name}\' and task_name =\'{task_name}\' and  DATE(task_date)= \'{task_date.date()}\' and rule_short = \'{key_text}\'')
                else:
                    cur.execute(f'insert into rules (customer_name, task_name,rule_long,rule_short,task_date) values (\'{customer_name}\', \'{task_name}\',\'{rule_text}\', \'{key_text}\',\'{task_date.date()}\')')
        self.conn.commit()
        #print(self.rules)
        QMessageBox.about(self, "Congratulations", "Rules has been pushed to the server!")


        self.get_customer()
        self.get_tasks()
        self.get_dates()
        print(self.cname, self.tname, self.tdate)
        self.cbox_db_list.setCurrentText(customer_name)
        self.cbox_task_list.setCurrentText(task_name)
        self.cbox_date_list.setCurrentText(task_date.strftime('%m%d%Y'))

        #self.save_rules()

        # try:
        #     for i in range(self.list_rules.count()):
        #         key_text, rule_text = self.list_rules.item(i).text().title().split('|')
        #         if key_text.strip().title():
        #             self.rules[key_text.strip().title()] = rule_text
        #             cur.execute(f'insert into rules (customer_name, task_name,rule_long,rule_short) values (\'{customer_name}\', \'{task_name}\',\'{rule_text}\', \'{key_text.strip().title()}\');')
        #     conn.commit()
        #     self.main.rules = self.rules
        # except:
        #     continue
    def get_rules(self):
        self.remove_all()
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        customer_name = self.cbox_db_list.currentText().strip()
        task_name     = self.cbox_task_list.currentText().strip()
        date_str      = self.cbox_date_list.currentText().strip().replace('/','').replace('-','')
        if not date_str or not task_name or not customer_name:
            QMessageBox.about(self,'Warning','')
        task_date     = datetime.strptime(date_str,'%m%d%Y')
        if not customer_name and task_name and task_date:
            QMessageBox.about(self, "Warning", "Please check the configuration before fetching data from the server!")
            return
        cur.execute(f'select rule_short,rule_long from rules where customer_name = \'{customer_name}\' and task_name = \'{task_name}\' and   DATE(task_date)= \'{task_date.date()}\' order by rule_id')
        for rec in cur.fetchall():
            self.rules[rec[0]] = rec[1]
            self.list_rules.addItem(f"{rec[0]}|{rec[1].strip().strip('.').title()}")
        self.main.rules = self.rules
        #self.btn_backup_rule.setEnabled(True)
        self.setWindowTitle('Happy ANSI Rules Manager [SERVER]')
        #self.label_rules.setText(f'Standardize ANSI Notes [SERVER]')
        # self.rules_filename = os.path.join(self.ws,'rules_server.txt')
        # print(self.rules_filename)
        # with open(self.rules_filename,'w') as f:
        #     for rec in cur.fetchall():
        #         f.write(f'{rec[0]}|{rec[1]}\n')
        # self.load_rules(self.rules_filename)




        #now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        #self.load_rule_from_server()
        #QMessageBox.about(self, "Congratulations", "Rules has been obtained from the server!")


        self.btn_backup_rule.setEnabled(False)
        
    def load_rule_from_server(self):
        #QTimer(1000, self.get_rules())
        if self.fetch_id<20:
            self.get_rule_timer.singleShot(1000,self.get_rules)

    def load_saved_rules(self):
        self.rules = {}
        directory = QFileDialog.getOpenFileName(self,
                      "Select Pre-Defined Rules File",self.main.ws,
                      "Text Files (*.txt)")
        try:
            self.load_rules(fn=directory[0])
        except:
            QMessageBox.about(self, "Warning", "No Rule File has been selected or Incorrect Format for Rule File!")
        #self.label_rules.setText(f'Standardize ANSI Notes [LOCAL]')

    def remove_all(self):
        self.list_rules.clear()
        self.rules = {}


    def checkall_rules(self):
        if self.cbox_all_rules.isChecked():
            state = Qt.Checked
        else:
            state = Qt.Unchecked
        for i in range(self.list_rules.count()):
            self.list_rules.item(i).setCheckState(state)
    def refresh_rules(self):
        for i in range(self.list_rules.count()):
            key_text, rule_text = self.list_rules.item(i).text().title().split('|')
            if key_text.strip().title():
                self.rules[key_text.strip().title()] = rule_text
        print(self.rules)
        self.main.rules = self.rules
    def delete_rule(self):
        listItems=self.list_rules.selectedItems()
        if not listItems:
            QMessageBox.about(self, "Warning", "No Rule has been selected for deleting purpose!")
            return
        for item in listItems:
            self.list_rules.takeItem(self.list_rules.row(item))
        self.refresh_rules()
        #QMessageBox.about(self, "Rule Deleted", "The selected rule has been deleted!")
    def add_rule(self,text=''):
        hint = "Please add new rule for the task (sep=\'|\')"
        new_rule, ok = QInputDialog.getText(self, "Add New Rule",hint)
        if new_rule and len(new_rule.split('|'))==2:
            if new_rule.split('|')[0].strip().title() in self.rules:
                QMessageBox.about(self, "Warning", "The keyword for this rule has been used!")
                self.add_rule(text=new_rule)
                return
            total_rules = self.list_rules.count()
            self.list_rules.addItem(new_rule.strip().strip('.').title())
            self.list_rules.item(total_rules).setCheckState(Qt.Checked)
            self.refresh_rules()
            QMessageBox.about(self, "New Rule Added", "New Rule has been added!")
            if self.main.tech_role != 'admin':
                self.btn_backup_rule.setEnabled(False)
            else:
                self.btn_backup_rule.setEnabled(True)
        else:
            QMessageBox.about(self, "Warning", "The rule text is empty or wrong format!")
    def save_rules(self):
        #self.refresh_rules()
        # Open a file dialog for saving a file
        filename, _ = QFileDialog.getSaveFileName(None, "Save Rules File", "", "Text Files (*.txt)")
        # If the user selected a file, save the file
        if filename:
            with open(filename, 'w') as fn:
                for k, v in self.rules.items():
                    fn.write('%s\n'%v)
        QMessageBox.about(self, "Succeed", "Rules have been saved!")

    def get_select_rule(self):
        items = self.list_rules.selectedItems()
        x = []
        for item in items:
            if self.cbox_rule_index.isChecked():
                x.append(str(self.list_rules.indexFromItem(item).row()))
            else:
                #print(self.list_rules.indexFromItem(item).row(),item.text())
                try:
                    curItem = item.text().split('|')[1].strip('.')
                except:
                    curItem = item.text().strip('.')
                x.append(curItem)
        self.cur_rule = '.'.join(x)
        clipboard.copy(self.cur_rule)
        self.main.current_note_label.setText(self.cur_rule)


    def load_rules(self,fn=None):
        self.remove_all()
        if not fn:
            fn = self.rules_filename
        with open(fn,'r') as f:
            i = 0
            for lines in f.readlines():
                c = lines.strip('\n').strip()
                if not c.strip():continue
                self.rules[c.split('|')[0].title().strip()] = c
                self.list_rules.addItem(c.strip().strip('.').title())
                self.list_rules.item(i).setCheckState(Qt.Checked)
                i += 1
        self.rules_filename = fn
        self.main.rules = self.rules
        if self.main.tech_role != 'admin':
            self.btn_backup_rule.setEnabled(False)
        else:
            self.btn_backup_rule.setEnabled(True)
        self.setWindowTitle('Happy ANSI Rules Manager [LOCAL]')

        # try:
        #     with open(fn,'r') as f:
        #         i = 0
        #         for lines in f.readlines():
        #             c = lines.strip('\n')
        #             self.list_rules.addItem(c.strip().strip('.').title())
        #             self.list_rules.item(i).setCheckState(Qt.Checked)
        #             i += 1
        #     self.rules_filename = fn
        #     #self.refresh_rules()
        # except:
        #     QMessageBox.about(self, "Error", "Fail at loading predefined rules!")

    def setup_ui(self):
        # Set window properties
        self.setWindowTitle('Happy ANSI Rules Manager')
        self.setMinimumSize(600, 400)
        self.setWindowIcon(QIcon(":/plugin/happy_ansi/rules.png"))

        # Create main widget
        central_widget = QWidget(self)
        self.setCentralWidget(central_widget)

        # Create layout for main widget
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(5, 5, 5, 5)

        # Create first horizontal layout
        db_layout = QHBoxLayout()
        main_layout.addLayout(db_layout)

        # Create label, checkbox, and combo boxes
        self.label_rules = QLabel('Standardize ANSI Notes', self)
        db_layout.addWidget(self.label_rules)

        self.cbox_rule_index = QCheckBox('Index')
        db_layout.addWidget(self.cbox_rule_index)

        self.cbox_db_list= QComboBox(self)
        db_layout.addWidget(self.cbox_db_list)

        self.cbox_task_list = QComboBox(self)
        db_layout.addWidget(self.cbox_task_list)

        self.cbox_date_list = QComboBox(self)
        db_layout.addWidget(self.cbox_date_list)

        self.pushButton_load_db_rules = QToolButton()
        self.pushButton_load_db_rules.setText('...')
        db_layout.addWidget(self.pushButton_load_db_rules)
        # Create second horizontal layout
        btn_layout = QHBoxLayout()
        main_layout.addLayout(btn_layout)

        # Create buttons and connect event handlers

        self.btn_add_rule    = QPushButton('Add', self)
        self.btn_delete_rule = QPushButton('Delete', self)
        self.btn_backup_rule = QPushButton('Push', self)
        self.btn_save_rules  = QPushButton('Save', self)
        self.btn_rule_clear  = QPushButton('Clear', self)
        self.btn_load_rules  = QPushButton('Local', self)
        self.btn_new_task    = QPushButton('Task', self)   
        for btn in (self.btn_new_task, self.btn_load_rules,self.btn_add_rule,self.btn_delete_rule,self.btn_rule_clear,self.btn_save_rules,self.btn_backup_rule):
            btn.setStyleSheet("width:80px; border-radius: 25%;border:1px solid #9ecae1")
            btn_layout.addWidget(btn)
        # Create third horizontal layout
        rules_layout = QHBoxLayout()
        main_layout.addLayout(rules_layout)

        # Create list view
        self.list_rules = QListWidget(self)
        rules_layout.addWidget(self.list_rules)

        self.pushButton_load_db_rules.setIcon(QIcon(':/plugin/happy_ansi/down'))
        self.pushButton_load_db_rules.setStyleSheet("border:0px")
        self.btn_backup_rule.setEnabled(False)


class rules_manager2(QWidget):
    def __init__(self,mainwin,db_url = "aws.connect.psdb.cloud", db_port="3306",rules_file=None):
        super(rules_manager, self).__init__()
        self.ui = None
        self.main = mainwin
        self.task_on = False
        self.ws   = os.path.dirname(__file__)
        if self.main and not self.main.ws:
            self.ws = self.main.ws
        
        #self.rules_filename = os.path.join(self.ws, 'rules_server.txt')
        self.rules_filename = None
        # if not os.path.exists(self.rules_filename):            
        #     shutil.copyfile(os.path.join(os.path.dirname(__file__), 'default_rules.txt'), self.rules_filename)


        self.rules = {}
        self.load_ui()
        self.ui.setWindowTitle("Rules Configuration")
        self.ui.setWindowIcon(QIcon(":/plugin/happy_ansi/rules.png"))
        self.ui.btn_add_rule.clicked.connect(self.add_rule)
        self.ui.btn_delete_rule.clicked.connect(self.delete_rule)
        self.ui.btn_backup_rule.clicked.connect(self.push_rules)
        self.ui.btn_save_rules.clicked.connect(self.save_rules)
        self.ui.btn_rule_clear.clicked.connect(self.remove_all)
        self.ui.btn_load_rules.clicked.connect(self.load_saved_rules)
        self.ui.btn_new_task.clicked.connect(self.add_new_task)


        self.ui.pushButton_load_db_rules.clicked.connect(self.get_rules)
        self.ui.cbox_db_list.currentIndexChanged.connect(self.get_tasks)
        self.ui.cbox_task_list.currentIndexChanged.connect(self.get_dates)
        self.ui.list_rules.itemClicked.connect(self.get_select_rule)


        self.ui.pushButton_load_db_rules.setIcon(QIcon(':/plugin/happy_ansi/down'))
        self.ui.pushButton_load_db_rules.setStyleSheet("border:0px")
        self.ui.btn_backup_rule.setEnabled(False)

        self.cur_rule = ''
        if rules_file:
            self.load_rules(fn=rules_file)
            self.ui.label_rules.setText(f'Standardize ANSI Notes [LOCAL]')  
        else:
            # self.host        = db_url #'2.tcp.ngrok.io' #"localhost"
            # self.dbname      ="mapit"
            # self.username    ="al532612l9ai9zvfdf3a"
            # self.password    ="pscale_pw_SQlqDMaVQzYdNPpYeuAm2TxwprsNslpDKNuBUNnGLmb"
            # if not db_port:
            #     db_port = '3306'
            # self.port        = int(db_port) #12850

            self.host        = self.main.config['Rules']['host']
            self.username    = self.main.config['Rules']['username']
            self.password    = self.main.config['Rules']['password']
            self.dbname      = self.main.config['Rules']['db']
            self.port        = self.main.config['Rules']['port']

            self.conn        = None
            self.fetch_id = 1
            self.get_rule_timer = QTimer(self)
        # self.customers = ['GM','NISSAN','RIVIAN']
        # self.ui.cbox_db_list.addItems(self.customers)
        # self.ui.cbox_db_list.setCurrentText('GM')
        try:
            self.get_customer()
        except:
            QMessageBox.about(self, "Error", "Can Not Connect to the Server!")

        self.newTask = None
        self.cname   = None
        self.tname   = None
        self.tdate   = None
        


    def get_tasks(self):
        if self.task_on:
            self.ui.cbox_task_list.clear()
            self.ui.cbox_task_list.addItems([self.tname])
            return
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        customer_name = self.ui.cbox_db_list.currentText().strip()
        cur.execute(f'select distinct task_name from rules where customer_name = \'{customer_name}\'')
        task_names = [r[0] for r in cur.fetchall()]
        print(task_names)
        self.ui.cbox_task_list.clear()
        self.ui.cbox_task_list.addItems(set(task_names))
    @pyqtSlot()
    def add_new_task(self):
        self.newTask = Task(main_win = self)
        self.task_on = True
        self.newTask.show()
    def update_db_list(self):
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        #customer_name = self.ui.cbox_db_list.currentText().strip()
        cur.execute(f'select distinct customer_name from rules')
        cnames = [r[0] for r in cur.fetchall()]
        if self.cname not in cnames:
            cnames.insert(0,self.cname)
        self.ui.cbox_db_list.clear()
        self.ui.cbox_db_list.addItems(sorted(list(set(cnames))))
        self.ui.cbox_db_list.setCurrentText(self.cname)
    def get_dates(self):
        if self.task_on:
            self.ui.cbox_date_list.clear()
            self.ui.cbox_date_list.addItems([self.tdate])
            return
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        customer_name = self.ui.cbox_db_list.currentText().strip()
        task_name     = self.ui.cbox_task_list.currentText().strip()
        cur.execute(f'select distinct task_date from rules where customer_name = \'{customer_name}\' and task_name = \'{task_name}\'')
        task_dates = [r[0].strftime('%m%d%Y') for r in cur.fetchall()]
        self.ui.cbox_date_list.clear()
        self.ui.cbox_date_list.addItems(sorted(list(set(task_dates))))
    def get_customer(self):
        if self.task_on:
            self.ui.cbox_date_list.clear()
            self.ui.cbox_date_list.addItems([self.cname])
            return
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        cur.execute(f'select distinct customer_name from rules')
        cnames = [r[0].upper() for r in cur.fetchall()]
        self.ui.cbox_db_list.clear()
        self.ui.cbox_db_list.addItems(sorted(list(set(cnames))))
        #self.ui.cbox_db_list.setCurrentText(customer_name)


    def push_rules(self):

        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        print(self.cname, self.tname, self.tdate)
        cur = self.conn.cursor()
        if self.task_on:
            customer_name = self.cname
            task_name     = self.tname
            task_date     = self.tdate
        else:
            customer_name = self.ui.cbox_db_list.currentText().strip()
            task_name     = self.ui.cbox_task_list.currentText().strip()
            task_date     = datetime.strptime(self.ui.cbox_date_list.currentText().strip().replace('/','').replace('-',''),'%m%d%Y')

        cur.execute(f'delete from rules where customer_name =\'{customer_name}\' and task_name =\'{task_name}\' and  DATE(task_date)= \'{task_date.date()}\'')
        self.conn.commit()

        if not task_date:
            task_date = datetime.now()
        for i in range(self.ui.list_rules.count()):
            key_text, rule_text = self.ui.list_rules.item(i).text().title().split('|')
            if key_text.strip().title():
                self.rules[key_text.strip().title()] = rule_text
                cur.execute(f'select rule_short,rule_long from rules where customer_name = \'{customer_name}\' and task_name = \'{task_name}\' and  DATE(task_date)= \'{task_date.date()}\' and rule_short=\'{key_text}\'')
                rule_exist = cur.fetchall()
                if rule_exist:
                    cur.execute(f'update rules set rule_long = \'{rule_text}\' where customer_name =\'{customer_name}\' and task_name =\'{task_name}\' and  DATE(task_date)= \'{task_date.date()}\' and rule_short = \'{key_text}\'')
                else:
                    cur.execute(f'insert into rules (customer_name, task_name,rule_long,rule_short,task_date) values (\'{customer_name}\', \'{task_name}\',\'{rule_text}\', \'{key_text}\',\'{task_date.date()}\')')
        self.conn.commit()
        #print(self.rules)
        QMessageBox.about(self, "Congratulations", "Rules has been pushed to the server!")


        self.get_customer()
        self.get_tasks()
        self.get_dates()
        print(self.cname, self.tname, self.tdate)
        self.ui.cbox_db_list.setCurrentText(customer_name)
        self.ui.cbox_task_list.setCurrentText(task_name)
        self.ui.cbox_date_list.setCurrentText(task_date.strftime('%m%d%Y'))

        #self.save_rules()

        # try:
        #     for i in range(self.ui.list_rules.count()):
        #         key_text, rule_text = self.ui.list_rules.item(i).text().title().split('|')
        #         if key_text.strip().title():
        #             self.rules[key_text.strip().title()] = rule_text
        #             cur.execute(f'insert into rules (customer_name, task_name,rule_long,rule_short) values (\'{customer_name}\', \'{task_name}\',\'{rule_text}\', \'{key_text.strip().title()}\');')
        #     conn.commit()
        #     self.main.rules = self.rules
        # except:
        #     continue
    def get_rules(self):
        # if not self.conn:
        #     self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname)
        self.conn = connect_to_db_rule(self.host, self.username, self.password, self.dbname,self.port)
        cur = self.conn.cursor()
        customer_name = self.ui.cbox_db_list.currentText().strip()
        task_name     = self.ui.cbox_task_list.currentText().strip()
        date_str      = self.ui.cbox_date_list.currentText().strip().replace('/','').replace('-','')
        if not date_str or not task_name or not customer_name:
            QMessageBox.about(self,'Warning','')
        task_date     = datetime.strptime(date_str,'%m%d%Y')
        if not customer_name and task_name and task_date:
            QMessageBox.about(self, "Warning", "Please check the configuration before fetching data from the server!")
            return
        cur.execute(f'select distinct rule_short,rule_long from rules where customer_name = \'{customer_name}\' and task_name = \'{task_name}\' and   DATE(task_date)= \'{task_date.date()}\' order by rule_short')
        self.rules_filename = os.path.join(self.ws,'rules_server.txt')
        print(self.rules_filename)
        with open(self.rules_filename,'w') as f:
            for rec in cur.fetchall():
                f.write(f'{rec[0]}|{rec[1]}\n')
        self.load_rules(self.rules_filename)
        #now = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.ui.label_rules.setText(f'Standardize ANSI Notes [SERVER]')
        height = max(400,self.ui.list_rules.count()*20)

        if height>=800:
            self.ui.list_rules.setFixedSize(570,height-20)
            self.ui.setFixedSize(580,height+40)
        else:
            self.ui.list_rules.setFixedSize(570,height-20)
            self.ui.setFixedSize(580,height+40)
        self.fetch_id += 1
        #self.load_rule_from_server()
        #QMessageBox.about(self, "Congratulations", "Rules has been obtained from the server!")

        self.ui.btn_backup_rule.setEnabled(True)
    def load_rule_from_server(self):
        #QTimer(1000, self.get_rules())
        if self.fetch_id<20:
            self.get_rule_timer.singleShot(1000,self.get_rules)

    def load_saved_rules(self):
        self.rules = {}
        directory = QFileDialog.getOpenFileName(self,
                      "Select Pre-Defined Rules File",self.main.ws,
                      "Text Files (*.txt)")
        try:
            self.load_rules(fn=directory[0])
            self.ui.label_rules.setText(f'Standardize ANSI Notes [LOCAL]')
        except:
            QMessageBox.about(self, "Warning", "No Rule File has been selected or Incorrect Format for Rule File!")
        

    def remove_all(self):
        self.ui.list_rules.clear()
        self.rules = {}


    def checkall_rules(self):
        if self.ui.cbox_all_rules.isChecked():
            state = Qt.Checked
        else:
            state = Qt.Unchecked
        for i in range(self.ui.list_rules.count()):
            self.ui.list_rules.item(i).setCheckState(state)
    def refresh_rules(self):
        for i in range(self.ui.list_rules.count()):
            key_text, rule_text = self.ui.list_rules.item(i).text().title().split('|')
            if key_text.strip().title():
                self.rules[key_text.strip().title()] = rule_text
        print(self.rules)
        self.main.rules = self.rules
    def delete_rule(self):
        listItems=self.ui.list_rules.selectedItems()
        if not listItems:
            QMessageBox.about(self, "Warning", "No Rule has been selected for deleting purpose!")
            return
        for item in listItems:
            self.ui.list_rules.takeItem(self.ui.list_rules.row(item))
        self.refresh_rules()
        #QMessageBox.about(self, "Rule Deleted", "The selected rule has been deleted!")
    def add_rule(self,text=''):
        hint = "Please add new rule for the task (sep=\'|\')"
        new_rule, ok = QInputDialog.getText(self, "Add New Rule",hint)
        if new_rule and len(new_rule.split('|'))==2:
            if new_rule.split('|')[0].strip().title() in self.rules:
                QMessageBox.about(self, "Warning", "The keyword for this rule has been used!")
                self.add_rule(text=new_rule)
                return
            total_rules = self.ui.list_rules.count()
            self.ui.list_rules.addItem(new_rule.strip().strip('.').title())
            self.ui.list_rules.item(total_rules).setCheckState(Qt.Checked)
            self.refresh_rules()
            QMessageBox.about(self, "New Rule Added", "New Rule has been added!")
            self.ui.btn_backup_rule.setEnabled(True)
        else:
            QMessageBox.about(self, "Warning", "The rule text is empty or wrong format!")
    def save_rules(self):
        #self.refresh_rules()
        # Open a file dialog for saving a file
        filename, _ = QFileDialog.getSaveFileName(None, "Save Rules File", "", "Text Files (*.txt)")
        # If the user selected a file, save the file
        if filename:
            with open(filename, 'w') as fn:
                for k, v in self.rules.items():
                    fn.write('%s\n'%v)
        QMessageBox.about(self, "Succeed", "Rules have been saved!")

    def get_select_rule(self):
        items = self.ui.list_rules.selectedItems()
        x = []
        for item in items:
            if self.ui.cbox_rule_index.isChecked():
                x.append(str(self.ui.list_rules.indexFromItem(item).row()))
            else:
                #print(self.ui.list_rules.indexFromItem(item).row(),item.text())
                try:
                    curItem = item.text().split('|')[1].strip('.')
                except:
                    curItem = item.text().strip('.')
                x.append(curItem)
        self.cur_rule = '.'.join(x)
        clipboard.copy(self.cur_rule)
        self.main.current_note_label.setText(self.cur_rule)


    def load_rules(self,fn=None):
        self.remove_all()
        if not fn:
            fn = self.rules_filename
        with open(fn,'r') as f:
            i = 0
            for lines in f.readlines():
                c = lines.strip('\n').strip()
                if not c.strip():continue
                self.rules[c.split('|')[0].title().strip()] = c
                self.ui.list_rules.addItem(c.strip().strip('.').title())
                self.ui.list_rules.item(i).setCheckState(Qt.Checked)
                i += 1
        self.rules_filename = fn
        self.main.rules = self.rules
        self.ui.btn_backup_rule.setEnabled(True)
        # try:
        #     with open(fn,'r') as f:
        #         i = 0
        #         for lines in f.readlines():
        #             c = lines.strip('\n')
        #             self.ui.list_rules.addItem(c.strip().strip('.').title())
        #             self.ui.list_rules.item(i).setCheckState(Qt.Checked)
        #             i += 1
        #     self.rules_filename = fn
        #     #self.refresh_rules()
        # except:
        #     QMessageBox.about(self, "Error", "Fail at loading predefined rules!")

    def load_ui(self):
        # loader = QUiLoader()
        # path = os.fspath(Path(__file__).resolve().parent / "form.ui")
        # ui_file = QFile(path)
        # ui_file.open(QFile.ReadOnly)
        # self.ui = loader.load(ui_file, self)
        # ui_file.close()
        self.ui =uic.loadUi(os.path.join(os.path.dirname(__file__), "rules.ui"))
        for btn in (self.ui.btn_add_rule,self.ui.btn_delete_rule,self.ui.btn_backup_rule,self.ui.btn_rule_clear,self.ui.btn_load_rules,self.ui.btn_new_task):
            btn.setStyleSheet("border-radius: 25%;border:1px solid #9ecae1")
if __name__ == "__main__":
    app = QApplication([])

    widget = rules_manager(None)
    widget.show()
    sys.exit(app.exec_())
