import matplotlib.pyplot as plt

fig, ax = plt.subplots()

values = [0.2, 0.5, 0.3]
labels = ['label',
          'looooooog label',
          'very loooooooooooooooooooooooog label'
         ]

ax.pie(values, labels=labels)
ax.axis('equal')
ax.set_ylabel('label here', rotation=270, color='k', labelpad=15)
fig.tight_layout()
plt.draw()
#plt.show()
for i in range(50):
    print('settings[%s]'%i)