from .tiles import *
from ..map_data.db_conn import *
from ..map_data.utils import *
import datetime
from qgis.core import QgsGeometry, QgsCoordinateReferenceSystem, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
# from shapely.wkt import dumps, loads


class LidarTiles:
    def __init__(self, url):
        self.tile_server_url = url
        self.extent = None
        self.srid = 4326
        self.tile_locator = TileLocator()
        self.zoom = 16
        self.conn = None
        self.pointcloud_id_list = []
        self.pointcloud_id_dict = {}    # key: year, month
        self.pointcloud_trail_dict = {}     # key: pointcloud_id
        self.pointcloud_s3_dict = {}

    def clear_data(self):
        self.pointcloud_id_list.clear()
        self.pointcloud_id_dict.clear()
        self.pointcloud_trail_dict.clear()
        self.pointcloud_s3_dict.clear()

    def get_pointcloud_ids_in_extent(self):
        self.pointcloud_id_list = []
        self.pointcloud_id_dict.clear()
        query = f'''select distinct on (start_date, pointcloud_acquisitions.pointcloud_id) pointcloud_acquisitions.pointcloud_id, 
                    asset_pointclouds.asset_id, s3_location, start_date, st_astext(trail)
                    from external_data_metadata.pointcloud_acquisitions
                    left join datalake.asset_pointclouds 
                        on pointcloud_acquisitions.pointcloud_id = asset_pointclouds.pointcloud_id
                    left join datalake.laz on laz.asset_id = asset_pointclouds.asset_id
                    where st_intersects(trail::geometry,
                    ST_MakeEnvelope({self.extent.x_min}, {self.extent.y_min}, {self.extent.x_max}, {self.extent.y_max}, {self.srid}))
                    order by start_date desc, pointcloud_acquisitions.pointcloud_id desc'''
        response = make_query(self.conn, query, None)
        for row in response:
            pointcloud_id, asset_id, s3_location, start_date, trail = row[0:5]
            start_date = str(start_date)
            datee = datetime.datetime.strptime(start_date, "%Y-%m-%d")
            year = datee.year
            month = datee.month
            # day = datee.day
            year_month = f'{year}/{month}'
            self.pointcloud_id_list.append(pointcloud_id)
            self.pointcloud_trail_dict[pointcloud_id] = trail
            self.pointcloud_s3_dict[pointcloud_id] = s3_location
            if year_month not in self.pointcloud_id_dict:
                self.pointcloud_id_dict[year_month] = [pointcloud_id]
            else:
                self.pointcloud_id_dict[year_month].append(pointcloud_id)

    def get_pointcloud_trail_in_extent(self):
        layer_dict = {}

        g = QgsGeometry()
        qgs_fields = [QgsField('pointcloud_id', QVariant.String)]
        for date in self.pointcloud_id_dict:
            for pointcloud_id in self.pointcloud_id_dict[date]:
                feature_list = []
                trail_wkt = self.pointcloud_trail_dict[pointcloud_id]
                # geom_wkt = loads(trail_wkt).wkt
                trail_qgsgeom = g.fromWkt(trail_wkt)

                f = QgsFeature()
                f.setGeometry(trail_qgsgeom)
                f.setAttributes([pointcloud_id])
                feature_list.append(f)
                v_layer = buildSimpleQgsVectorLayer('Linestring?crs=epsg:4326', f'{pointcloud_id}',
                                                    feature_list, qgs_fields)

                if date not in layer_dict:
                    layer_dict[date] = [v_layer]
                else:
                    layer_dict[date].append(v_layer)
        return layer_dict

    def get_tiles_in_extent(self):

        layer_dict = {}

        for date in self.pointcloud_id_dict:
            for pointcloud_id in self.pointcloud_id_dict[date]:
                # scanner = pointcloud_id.split('_')[-1]
                # for i, item in enumerate(pointcloud_id.split('_')):
                #     if i == 0:
                #         pointcloud = item
                #     elif item == scanner:
                #         break
                #     else:
                #         pointcloud += '_' + item
                # img_url = f'{scanner.lower()}/' + '{z}/{x}/{-y}_' + f'{pointcloud}.png'
                img_url = f'/{pointcloud_id}/' + '{z}/{x}/{-y}_0.png'
                r_layer = buildQgsRasterLayer(self.tile_server_url, img_url, f'{pointcloud_id}')
                if r_layer == 1:
                    continue
                if date not in layer_dict:
                    layer_dict[date] = [r_layer]
                else:
                    layer_dict[date].append(r_layer)
        return layer_dict


if __name__ == '__main__':

    host = '10.80.1.98'
    file = '1323737_140516_163454.png'
    # path = '33090ce3-c493-4c41-9be4-b3fa4b167061/s2/21/564091/1323737_140516_163454.png'

