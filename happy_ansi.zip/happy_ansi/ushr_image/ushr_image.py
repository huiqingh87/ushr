import boto3
from PIL import Image
import os
import io
import csv
from qgis.core import QgsGeometry, QgsField, QgsFeature
from qgis.PyQt.QtCore import QVariant
from ..map_data.utils import buildQgsVectorLayer
from ..map_data.db_conn import make_query
from ..map_data.utils import parse_s3_url
import datetime


class UshrImage:
    def __init__(self,mainwin):
        self.mainwin = mainwin
        self.aws_access_key_id = ''
        self.aws_secret_access_key = ''
        self.aws_default_region = ''
        self.set_aws_env()
        # self.s3 = boto3.client('s3', region_name=self.aws_default_region, aws_access_key_id=self.aws_access_key_id,
        #                        aws_secret_access_key=self.aws_secret_access_key)
        self.s3 = boto3.client('s3')
        self.gen2_image_dirs = None
        self.camera_image_dict = {}
        self.intensity_lidar_image_dict = {}

    def update_aws_key(self):
        self.aws_access_key_id = self.mainwin.config['AWS']['AWS_ACCESS_KEY_ID']
        self.aws_secret_access_key = self.mainwin.config['AWS']['AWS_SECRET_ACCESS_KEY']
        self.aws_default_region = self.mainwin.config['AWS']['AWS_DEFAULT_REGION']

    def set_aws_env(self):
        """Setup the qc_user account within the application. Environment variables override local cred files."""
        os.environ['AWS_ACCESS_KEY_ID'] = 'AKIAUR5F46KQ7UP7H67S'
        os.environ['AWS_SECRET_ACCESS_KEY'] = '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'
        os.environ['AWS_DEFAULT_REGION'] = 'us-east-2'
        os.environ['TZ'] = 'UTC'

    def get_image(self, bucket=None, key=None):
        self.update_aws_key()
        obj = self.s3.get_object(Bucket=bucket, Key=key)
        img = obj['Body'].read()
        return img

    def get_object(self, bucket=None, key=None, range=None):
        if range is None:
            obj = self.s3.get_object(Bucket=bucket, Key=key)
        else:
            obj = self.s3.get_object(Bucket=bucket, Key=key, Range=range)
        return obj['Body']

    def get_bucket_dirs(self, bucket='ushr-gen2'):
        dir_list = []
        result = self.s3.list_objects(Bucket=bucket, Delimiter='/')
        for obj in result.get('CommonPrefixes'):
            prefix = obj.get('Prefix')
            dir_list.extend(list_dirs(self.s3, bucket, prefix))
        self.gen2_image_dirs = dir_list

    def get_trail_camera_images(self, pointcloud_id_list, bucket='ushr-gen2'):
        self.camera_image_dict.clear()
        if self.gen2_image_dirs is None:
            self.get_bucket_dirs()
        for pointcloud_id in pointcloud_id_list:
            self.camera_image_dict[pointcloud_id] = {}
            pointcloud_date = pointcloud_id.split('_')[-3]
            pointcloud_dir = None
            camera_dir_dict = {}
            for dir_ in self.gen2_image_dirs:
                date_ = dir_.split('_')[-3][2:8]
                if date_ == pointcloud_date:
                    file_list = list_files(self.s3, bucket, dir_)
                    sub_dir_list = list_dirs(self.s3, bucket, dir_)
                    found = False
                    eor_file = None
                    for file in file_list:
                        if file.split('/')[-1].split('.')[0][0:3] == 'EOR':
                            eor_file = file
                        if pointcloud_dir is None and file.split('/')[-1].split('.')[0] == pointcloud_id:
                            pointcloud_dir = dir_
                            for sub_dir in sub_dir_list:
                                sub_dir_name = sub_dir.split('/')[-2][0:6]
                                if sub_dir_name == 'Camera':
                                    camera_dir_dict[int(sub_dir.split('/')[-2][6:8])] = sub_dir
                            found = True
                        if found and eor_file is not None:
                            obj = self.s3.get_object(Bucket=bucket, Key=eor_file)
                            data = obj['Body'].read().decode('utf-8')
                            for row in csv.reader(io.StringIO(data)):
                                gps_time, image_filename = row[0:2]
                                alt, lat, lon = row[4:7]
                                camera_no = int(image_filename.split("_")[0])
                                camera_image_key = f'{camera_dir_dict[camera_no]}{image_filename}.jpg'
                                if camera_no not in self.camera_image_dict[pointcloud_id]:
                                    self.camera_image_dict[pointcloud_id][camera_no] = []
                                self.camera_image_dict[pointcloud_id][camera_no].append({
                                    'gps_time': gps_time, 'lat': float(lat), 'lon': float(lon), 'alt': float(alt),
                                    's3_key': camera_image_key, 'eor': eor_file})
                            break

    # US format: s3://ushr-image/200818_162557951_C1.jpg
    #            s3://ushr-image/200818_162557951_C2.jpg
    # Japan formar: s3://ushr-gen2/23_3_19/GD_1112_202105110929_S02_01/Camera01/01_2021051110521910.jpg
    #               s3://ushr-gen2/23_3_19/GD_1112_202105110929_S02_01/Camera02/02_2021051110522216.jpg
    def query_datalake_camera_image(self, pointcloud_id_list):
        self.camera_image_dict.clear()
        query = '''select pointcloud_id, s3_location, datetime, st_astext(geom)
                   from datalake.asset_pointclouds
                   join datalake.camera_image on camera_image.asset_id = asset_pointclouds.asset_id
                   where pointcloud_id = any(%s)
                   and processing_index is not null
                   order by processing_index'''
        response = make_query(self.mainwin.rfdb_conn, query, (pointcloud_id_list,))
        for row in response:
            pointcloud_id, s3_location, date_time, geom = row[0:4]
            s3_bucket, s3_key = parse_s3_url(s3_location)
            # Japan
            if s3_bucket == 'ushr-gen2':
                camera_no = int(s3_key.split('/')[-2][6:8])
            # US
            elif s3_bucket == 'ushr-image':
                camera_no = int(s3_key.split('.')[0].split('_')[-1][1])
            else:
                return
            if pointcloud_id not in self.camera_image_dict:
                self.camera_image_dict[pointcloud_id] = {}
            if camera_no not in self.camera_image_dict[pointcloud_id]:
                self.camera_image_dict[pointcloud_id][camera_no] = []
            self.camera_image_dict[pointcloud_id][camera_no].append({
                'gps_time': str(date_time), 'geom': geom, 's3_bucket': s3_bucket, 's3_key': s3_key})

    # US format: s3://ushr-siloc-image/200818_162556-intensity_lidar_image-0.jpg
    # Japan format: s3://ushr-gen2/23_3_19/GD_1112_202105110929_S02_01/IntensityLidarImage/JG_210511_015207-intensity_lidar_image-2.jpg
    def query_datalake_intensity_lidar_image(self, pointcloud_id_list):
        self.intensity_lidar_image_dict.clear()
        query = '''select pointcloud_id, intensity_lidar_image.s3_location, start_datetime, st_astext(intensity_lidar_image.geom)
                   from datalake.asset_pointclouds
                   join datalake.intensity_lidar_image on intensity_lidar_image.asset_id = asset_pointclouds.asset_id
				   join datalake.laz on laz.asset_id = intensity_lidar_image.asset_id
                   where pointcloud_id = any(%s)
                   and processing_index is not null
                   order by processing_index'''
        response = make_query(self.mainwin.rfdb_conn, query, (pointcloud_id_list,))
        for row in response:
            pointcloud_id, s3_location, date_time, geom = row[0:4]
            s3_bucket, s3_key = parse_s3_url(s3_location)
            if pointcloud_id not in self.intensity_lidar_image_dict:
                self.intensity_lidar_image_dict[pointcloud_id] = []
            self.intensity_lidar_image_dict[pointcloud_id].append({
                'gps_time': str(date_time), 'geom': geom, 's3_bucket': s3_bucket, 's3_key': s3_key})

    def plot_camera_image_trail(self):
        if len(self.camera_image_dict) == 0:
            return
        g = QgsGeometry()
        qgs_camera_image_trail_fields = [
            QgsField('pointcloud_id', QVariant.String), QgsField('camera_no', QVariant.Int),
            QgsField('seq_ind', QVariant.Int), QgsField('gps_time', QVariant.String),
            QgsField('s3_bucket', QVariant.String), QgsField('s3_key', QVariant.String)]
        layers = []
        color_selector = ['red', 'orange', 'cyan', 'green', 'blue', 'magenta', 'purple']
        ind = 0
        layer_dict = {}
        for pointcloud_id in sorted(self.camera_image_dict, reverse=True):
            for camera_no in sorted(self.camera_image_dict[pointcloud_id]):
                feature_list = []
                year_month = None
                camera_image_pt_dict_list = self.camera_image_dict[pointcloud_id][camera_no]
                for i, camera_image_pt_dict in enumerate(camera_image_pt_dict_list):
                    geom = camera_image_pt_dict['geom']
                    gps_time = camera_image_pt_dict['gps_time']
                    datee = datetime.datetime.strptime(gps_time.split(' ')[0], "%Y-%m-%d")
                    year_month = f'{datee.year}/{datee.month}'
                    s3_bucket = camera_image_pt_dict['s3_bucket']
                    s3_key = camera_image_pt_dict['s3_key']
                    polygon = g.fromWkt(geom)
                    f = QgsFeature()
                    f.setGeometry(polygon)
                    f.setAttributes([pointcloud_id, camera_no, i, gps_time, s3_bucket, s3_key])
                    feature_list.append(f)
                if ind > 6:
                    index = ind % 6
                else:
                    index = ind
                ind += 1
                color = color_selector[index]
                layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', f'{pointcloud_id}_{camera_no}',
                                            feature_list, qgs_camera_image_trail_fields, color=color)
                if year_month not in layer_dict:
                    layer_dict[year_month] = []
                layer_dict[year_month].append(layer)
                layers.append(layer)
        self.mainwin.add_layer('camera_image_trails', layers, layer_dict=layer_dict, replace=True)

    def plot_intensity_lidar_image_trail(self):
        if len(self.intensity_lidar_image_dict) == 0:
            return
        g = QgsGeometry()
        qgs_intensity_lidar_image_trail_fields = [
            QgsField('pointcloud_id', QVariant.String), QgsField('seq_ind', QVariant.Int),
            QgsField('s3_bucket', QVariant.String), QgsField('s3_key', QVariant.String)]
        layers = []
        layer_dict = {}
        color_selector = ['purple', 'magenta', 'blue', 'green', 'cyan', 'orange', 'red']
        ind = 0
        for pointcloud_id in sorted(self.intensity_lidar_image_dict, reverse=True):
            feature_list = []
            year_month = None
            intensity_lidar_image_dict_list = self.intensity_lidar_image_dict[pointcloud_id]
            for i, intensity_lidar_image_dict in enumerate(intensity_lidar_image_dict_list):
                geom = intensity_lidar_image_dict['geom']
                s3_bucket = intensity_lidar_image_dict['s3_bucket']
                s3_key = intensity_lidar_image_dict['s3_key']
                gps_time = intensity_lidar_image_dict['gps_time']
                datee = datetime.datetime.strptime(gps_time.split(' ')[0], "%Y-%m-%d")
                year_month = f'{datee.year}/{datee.month}'
                polygon = g.fromWkt(geom)
                f = QgsFeature()
                f.setGeometry(polygon)
                f.setAttributes([pointcloud_id, i, s3_bucket, s3_key])
                feature_list.append(f)
            if ind > 6:
                index = ind % 6
            else:
                index = ind
            ind += 1
            color = color_selector[index]
            layer = buildQgsVectorLayer('PointZ?crs=epsg:4326', f'{pointcloud_id}',
                                        feature_list, qgs_intensity_lidar_image_trail_fields, color=color)
            if year_month not in layer_dict:
                layer_dict[year_month] = []
            layer_dict[year_month].append(layer)
            layers.append(layer)
        self.mainwin.add_layer('intensity_lidar_image_trails', layers, layer_dict=layer_dict, replace=True)

    def query_image(self, bucket, key):
        obj = self.s3.get_object(Bucket=bucket, Key=key)
        img_data = obj['Body'].read()
        image = Image.open(io.BytesIO(img_data))
        return image


def list_dirs(client, bucket_name, prefix):
    """List files in specific S3 URL"""
    response = client.list_objects(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
    for content in response.get('CommonPrefixes'):
        yield content.get('Prefix')


def list_files(client, bucket_name, prefix):
    """List files in specific S3 URL"""
    response = client.list_objects(Bucket=bucket_name, Prefix=prefix, Delimiter='/')
    for content in response.get('Contents'):
        yield content.get('Key')


if __name__ == '__main__':
    # ushr_image = UshrImage()
    # img = ushr_image.get_image(bucket='ushr-image', key='A9-141113_170729333_C1.jpg')
    # im = Image.open(img)
    # im.show()
    # bix_file = ushr_image.get_object(bucket='ushr-point-cloud', key='JPN_Kanto/Z_201024_004741_S1.laz')
    # file_name_in = 's3://ushr-point-cloud/JPN_Kanto/Z_201024_004741_S1.laz'
    # file_name_in = 'arn:aws:s3:::ushr-point-cloud/JPN_Kanto/Z_201024_004741_S1.laz'
    # file_name_in = r'D:\CSAV3\pointcloud\USA_Michigan\140516_144451_s1.laz'
    # libc = CDLL(r'..\LASzip\dll\LASzip64.dll')
    # c_file_name_in = c_char_p(file_name_in.encode('utf-8'))
    # print(c_file_name_in)
    # open laz/las file
    # is_compressed = c_int()
    # laszip_reader = pointer(c_void_p())
    # libc.laszip_create(laszip_reader)
    # libc.laszip_open_reader(laszip_reader.contents, c_file_name_in, byref(is_compressed))
    # print(f'is_compressed: {is_compressed.value}')
    #
    # file_name_in = r'D:\CSAV3\pointcloud\USA_Michigan\140516_144451_s1.laz'
    # with open(fp, 'r') as f:
    #     print(f)
    # print(type(fp))
    s3_client = boto3.client(
        's3', region_name='us-east-2',
        aws_access_key_id='AKIAUR5F46KQRZKPC66K',
        aws_secret_access_key='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')
    obj = s3_client.get_object(Bucket='ushr-gen2',
                               Key='23_3_19/GD_1112_202105110929_S02_01/Camera01/01_2021051111225336.jpg')
    img_data = obj['Body'].read()
    image = Image.open(io.BytesIO(img_data))
    image.show()
    # s3_client = boto3.client('s3')











