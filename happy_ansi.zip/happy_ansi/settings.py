from PyQt5 import QtCore, uic
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtWidgets import *
from PyQt5.QtGui import QBrush, QColor, QIcon
import os, sys
import pyperclip as clipboard
from .resources import *

from .calculations.config_init import *
from .rules import *


def getShortName(name):
    n0 = [s[0] for s in name.split() if s]
    return ''.join(n0).upper()


dbs = ['RFDB','GM','UDBX','AWS']

class db_manager(QMainWindow):
    def __init__(self,mainwin=None,config_file=None):
        super().__init__()
        self.setWindowTitle("Credentials Configuration")
        self.setWindowIcon(QIcon(":/plugin/happy_ansi/db.png"))
        self.main = mainwin
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignLeft)
        form.setFormAlignment(Qt.AlignRight)
        form.setContentsMargins(15,10,15,10)
        self.client = QComboBox()
        self.client.addItems(dbs)
        self.server = QLineEdit()
        self.database = QLineEdit()
        self.port = QLineEdit()
        #self.port.setFixedWidth(50)
        #self.port.setStyleSheet('QLineEdit{ float:right;align:right;border-width: 1px; border-style: solid; border-color:  red white black black;border-top-style:none; }')
        self.username = QLineEdit()
        self.password = QLineEdit()
        self.password.setEchoMode(QLineEdit.Password)
        self.rfdbBtn     = QPushButton('RFDB')
        self.clientBtn     = QPushButton('Client')
        self.new     = QPushButton('New')
        self.save     = QPushButton('Save')
        self.copy     = QPushButton('Copy')
        self.clear    = QPushButton('Clear')
        self.exit    = QPushButton('Close')
        

        self.qclient  = QLabel("Product")
        self.qserver  = QLabel("Server")
        self.qdb      = QLabel("Database")
        self.qport    = QLabel("Port")
        self.quname   = QLabel("Username")
        self.qpwd     = QLabel("Password")

        form.addRow(self.qclient, self.client)
        form.addRow(self.qserver, self.server)
        form.addRow(self.qdb, self.database)
        form.addRow(self.qport, self.port)
        form.addRow(self.quname, self.username)
        form.addRow(self.qpwd  , self.password)
        buttonRow = QHBoxLayout()
        buttonRow.addWidget(self.new)
        buttonRow.addWidget(self.save)
        buttonRow.addWidget(self.rfdbBtn)
        buttonRow.addWidget(self.clientBtn)
        buttonRow.addWidget(self.copy) 
        buttonRow.addWidget(self.clear)    
        buttonRow.addWidget(self.exit)      
        form.addRow(buttonRow)
        #self.setMinimumSize(QSize(300, 200))
        self.setFixedSize(QSize(300, 200))
        widget = QWidget()
        widget.setLayout(form)
        #self.setStyleSheet('QLabel {margin-left:2px; };')
        self.setCentralWidget(widget)
        self.clear.clicked.connect(self.clearForm)
        self.copy.clicked.connect(self.copySetting)
        self.save.clicked.connect(self.saveSetting)
        self.rfdbBtn.clicked.connect(self.setRFDB)
        self.clientBtn.clicked.connect(self.setClient)
        self.new.clicked.connect(self.addSetting)
        self.exit.clicked.connect(self.close)

        self.init_file = config_file  #os.path.join(r'C:\Users\hhuang\Downloads\happyAnsi_ver0', 'user.ini')
        self.config_init = ConfigInit(self.init_file)
        self.config = {}
        # self.config['RFDB']:{'host': None, 'db': None, 'port': None, 'username': None, 'password': None}
        # self.config['GM']:{'host': None, 'db': None, 'port': None, 'username': None, 'password': None}
        # self.config['UBDX']:{'host': None, 'db': None, 'port': None, 'username': None, 'password': None}
        # self.config['AWS']:{'AWS_ACCESS_KEY_ID': None, 'AWS_SECRET_ACCESS_KEY': None, 'AWS_DEFAULT_REGION': None}
        # self.config['2D_LiDAR']:{'URL': None}
        # self.config['Rules']:{'host': None, 'port': None, 'username': None, 'password': None}
        # self.config['Technician']:{'full_name': None, 'short_name': None}
        self.load_user_init()
        self.update_fields()
        self.client.currentIndexChanged.connect(self.update_fields)

    def setClient(self):
        clientName = self.client.currentText().strip()
        self.main.ansi_database = clientName
        if clientName not in self.config:
            QMessageBox.about(self, "Warning", 'Please save current database setting before setting as client database!')
            return    
        self.main.update_current_conn(client=clientName)
    def setRFDB(self):
        rfdbName = self.client.currentText().strip()
        if rfdbName not in self.config:
            QMessageBox.about(self, "Warning", 'Please save current database setting before setting as client database!')
            return    
        self.main.update_current_conn(client=rfdbName)

    def clearForm(self):
        self.server.clear()
        self.database.clear()
        self.port.clear()
        self.username.clear()
        self.password.clear()

    def copySetting(self):
        self.client.addItems(dbs)
        conn_info = 'Host: %s\nDatabase: %s\nPort: %s\nUsername: %s\nPassword: %s\n'%(  self.server.text(),
                                                                                        self.database.text(), 
                                                                                        self.port.text(),       
                                                                                        self.username.text(),
                                                                                        self.password.text())
        clipboard.copy(conn_info)
        QMessageBox.about(self, "Connection Info Copied", conn_info)

    def addSetting(self,tech=False):
        self.setFixedSize(QSize(300, 200))
        if not tech:            
            self.client.setEditable(True)
            self.qserver.setText("Server")
            self.qdb.setText("Database")
            self.qport.setText("Port")
            self.quname.setText("Username")
            self.qpwd.setText("Password")
            self.server.clear()
            self.database.clear()
            self.port.clear()
            self.username.clear()
            self.password.clear()
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setVisible(True)
        else:
            self.client.setEditable(True)
            self.client.setCurrentText('Technician')
            self.qserver.setText("Full Name")
            self.server.clear()
            self.database.clear()
            self.port.clear()
            self.username.clear()
            self.password.clear()
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setText('')
                w.setVisible(False)


    def saveSetting(self):
        clientName = self.client.currentText().strip()
        print(clientName)
        if clientName not in self.config:
            if clientName != 'Technician':
                kvs = {'host':self.server.text(),
                       'db':self.database.text(),
                         'port':self.port.text(),
                'username': self.username.text(),
                'password': self.password.text()}
            else:
                fullname = self.server.text().strip().title()
                kvs = {
                'full_name':fullname,   
                'short_name':getShortName(fullname)             
                }
            self.config_init.update_whole_section(clientName, kvs)
            QMessageBox.about(self, "Congratulations", 'New Server Information Has Been Saved!')
            self.config_init = ConfigInit(self.init_file)
            self.load_user_init()
            return

        if clientName.find('RFDB')!=-1 or clientName.startswith('Toyota') or clientName.startswith('GM') or clientName.startswith('UDBX') or clientName.startswith('Rules') or clientName.startswith('CR'):
            self.config_init.update_section(clientName, 'host', self.server.text())
            self.config_init.update_section(clientName, 'db', self.database.text())
            self.config_init.update_section(clientName, 'port', self.port.text())
            self.config_init.update_section(clientName, 'username', self.username.text())
            self.config_init.update_section(clientName, 'password', self.password.text())
            if clientName=='Rules':
                self.rules_manager = rules_manager(self.main,self.server.text(),self.port.text())
        elif clientName.startswith('AWS'):
            self.config_init.update_section(clientName, 'AWS_ACCESS_KEY_ID', self.server.text())
            self.config_init.update_section(clientName, 'AWS_SECRET_ACCESS_KEY', self.database.text())
            self.config_init.update_section(clientName, 'AWS_DEFAULT_REGION', self.port.text())
        elif clientName.startswith('2D_LiDAR'):
            self.config_init.update_section(clientName, 'url', self.server.text())
        elif clientName.startswith('LAZ'):
            self.config_init.update_section(clientName, 'dir', self.server.text())
        elif clientName.startswith('Technician'):
            fullname = self.server.text()
            short_name = getShortName(fullname)
            self.config_init.update_section(clientName, 'full_name', fullname)
            self.config_init.update_section(clientName, 'short_name', short_name)
        else:
            pass

        QMessageBox.about(self, "Congratulations", 'New Server Information Has Been Saved!')
        self.config_init = ConfigInit(self.init_file)
        self.load_user_init()
                  



    def load_user_init(self):
        config = self.config_init.config
        self.client.clear()
        configItems = [k for k in config.keys() if k.lower()!='default']
        self.client.addItems(configItems)
        for k in configItems:
            self.config[k] = config[k]
        if self.main:
            self.main.config = self.config
        # if 'RFDB' in config:
        #     self.config['RFDB'] = config['RFDB']
        # if 'GM' in config:
        #     self.config['GM'] = config['GM']
        # if 'UBDX' in config:
        #     self.config['UBDX'] = config['UBDX']
        # if 'AWS' in config:
        #     self.config['AWS'] = config['AWS']
        # if 'Technician' in config:
        #     self.config['Technician'] = config['Technician']
        # if 'Rules' in config:
        #     self.config['Rules'] = config['Rules']
        # if 'LAZ' in config:
        #     self.config['LAZ'] = config['LAZ']
        # if '2D_LiDAR' in config:
        #     self.config['2D_LiDAR'] = config['2D_LiDAR']
        # else:
        #     self.config['2D_LiDAR'] = {'URL': 'https://2d.ushrauto-dev.com'}
        #print(self.config)

    def update_fields(self):
        clientName = self.client.currentText()
        if not clientName or not self.config:
            return
        if clientName.find('RFDB')!=-1 or clientName.startswith('Toyota') or clientName.startswith('GM') or clientName.startswith('UDBX') or clientName.startswith('Rules') or clientName.startswith('CR'):
            self.setFixedSize(QSize(300, 200))
            self.qserver.setText("Server")
            self.qdb.setText("Database")
            self.qport.setText("Port")
            self.quname.setText("Username")
            self.qpwd.setText("Password")
            self.server.setText(self.config[clientName]['host'])
            self.database.setText(self.config[clientName]['db'])
            self.port.setText(self.config[clientName]['port'])
            self.username.setText(self.config[clientName]['username'])
            self.password.setText(self.config[clientName]['password'])
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setVisible(True)
        elif clientName.startswith('AWS'):
            self.setFixedSize(QSize(400, 160))
            self.qserver.setText('AWS_ACCESS_KEY_ID')
            self.qdb.setText('AWS_SECRET_ACCESS_KEY')
            self.qport.setText('AWS_DEFAULT_REGION')
            self.server.setText(self.config[clientName]['AWS_ACCESS_KEY_ID'])
            self.database.setText(self.config[clientName]['AWS_SECRET_ACCESS_KEY'])
            self.port.setText(self.config[clientName]['AWS_DEFAULT_REGION'])
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setVisible(True)
            for w in self.quname, self.username, self.qpwd  , self.password:
                w.setText('')
                w.setVisible(False)
        elif clientName.find('2D_LiDAR')!=-1:
            self.setFixedSize(QSize(300, 140))
            self.qserver.setText('URL')
            self.server.setText(self.config[clientName]['URL'])
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setText('')
                w.setVisible(False)
        elif clientName.startswith('LAZ'):
            self.setFixedSize(QSize(400, 140))
            self.qserver.setText('dir')
            self.server.setText(self.config[clientName]['dir'])
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setText('')
                w.setVisible(False)
        elif clientName.startswith('Technician'):
            self.setFixedSize(QSize(300, 140))
            self.qserver.setText('Full Name')
            self.server.setText(self.config[clientName]['full_name'])
            for w in self.quname, self.username, self.qpwd, self.password, self.qdb, self.database,  self.qport, self.port:
                w.setText('')
                w.setVisible(False)
        else:
            pass

if __name__=='__main__':       
    app = QApplication(sys.argv)
    window = db_manager()
    window.show()
    app.exec_()