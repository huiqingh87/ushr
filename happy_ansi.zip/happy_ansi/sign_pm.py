from .map_data.rfdb_enums import *
from .map_data.rfdb_query import *
from .map_data.udbx_enums import *
from .map_data.udbx_query import query_segment
import numpy as np
from .map_data.siloc import *
from qgis.PyQt.QtGui import QPixmap, QPainter, QPen, QIcon
from qgis.PyQt.QtCore import Qt, QRect, pyqtSlot,QVariant, QSize
from .calculations.logger import *
from .lidar_tile.lidar_data import *
from shapely.wkt import loads
from dataclasses import dataclass
import logging
from .siloc_camera_image_dialog import *
import pandas as pd
from qgis.PyQt.QtWidgets import * #QApplication, QMainWindow, QFileDialog, QAction, QLabel, QMenuBar,QStatusBar, QMenu, QToolBar,QStatusBar ,QAction, QMessageBox,QVBoxLayout,QHBoxLayout,QToolButton,QGridLayout
from qgis.core import QgsProject, QgsPalLayerSettings, QgsVectorLayer,QgsVectorFileWriter, QgsCoordinateReferenceSystem, QgsRasterLayer, QgsVectorDataProvider, QgsField, QgsRendererCategory, QgsFillSymbol, QgsCategorizedSymbolRenderer,QgsPointXY, edit
from datetime import datetime
import os
from PIL.ImageQt import ImageQt
import geopandas as gpd

@dataclass
class Extent:
    x_min: float
    y_min: float
    x_max: float
    y_max: float

def clearLayout(layout):
    while layout.count():
        child = layout.takeAt(0)
        if child.widget() is not None:
            child.widget().deleteLater()
        elif child.layout() is not None:
            clearLayout(child.layout())
def string2array(x):
    if type(x) == np.ndarray:
        return x.tolist()
    elif x == '':
        return None
    else:
        return [x]


def string2bool(x):
    if x.lower() == 'true':
        return True
    else:
        return False


def string_list2bool_list(x_list):
    b_list = []
    for x in x_list:
        b = string2bool(x)
        b_list.append(b)
    return b_list


def udbx_sign_pm_type_name_to_id(type_, feature=None):
    if feature == 'sign':
        df = udbx_sign_types_df
    elif feature == 'pm':
        df = udbx_pm_type_df
    else:
        return None
    id_ = df[df['type'] == type_]['id'].values[0]
    return id_


def udbx_sign_pm_type_name_list_to_id_list(name_list, feature=None):
    id_list = []
    for name in name_list:
        id_ = udbx_sign_pm_type_name_to_id(name, feature)
        id_list.append(id_)
    return id_list


def udbx_sign_shape_name_to_id(shape):
    id_ = udbx_sign_shape_df[udbx_sign_shape_df['shape'] == shape]['id'].values[0]
    return id_


def udbx_sign_shape_name_list_to_id_list(name_list):
    id_list = []
    for name in name_list:
        id_ = udbx_sign_shape_name_to_id(name)
        id_list.append(id_)
    return id_list


def to_file(layer, fn, ws=r'C:\Users\hhuang\Downloads\work2023', format=0,open_after=False,verbose=False):
    file_formats = ['ESRI Shapefile','GeoJSON','CSV']
    file_exts    = [['.shp'],['.geojson'],['.csv']]
    if not os.path.exists(ws):
        os.makedirs(ws)    
    fn = os.path.join(ws,fn.replace('.','_') +file_exts[format][0])
    fn = fn.replace("\\","/")
    error = QgsVectorFileWriter.writeAsVectorFormat(layer,fn,"UTF-8", driverName=file_formats[format])
    if error[0] == QgsVectorFileWriter.NoError:
        if verbose:
            QMessageBox.about(None, "Succeed", 'Data [%s] Exported under %s'%(fn,ws))
        if open_after:
            #subprocess.Popen(f'explorer "{ws}"')
            #os.system(f'start {os.path.realpath(ws)}')
            webbrowser.open(os.path.realpath(ws))
    else:
        print('exporting failed')
        return False

def create_layer(feature_dict, qgs_fields, geom_type='Point',layer_name='temp layer'):
    feature_list = []
    g = QgsGeometry()
    for id_ in feature_dict:
        f = QgsFeature()
        geom = feature_dict[id_]['geom']
        geom = g.fromWkt(geom)
        f.setGeometry(geom)
        attribute_list = feature_dict[id_]['attribute_list']
        f.setAttributes(attribute_list)
        feature_list.append(f)
    v_layer = buildSimpleQgsVectorLayer(f'{geom_type}?crs=epsg:4326', layer_name, feature_list, qgs_fields)
    return v_layer

def draw_sign_image(sign_id, image, captured_at, bbox, type_, value, shape, is_digital, is_hanging,ws=r'C:\Users\hhuang\Downloads\temp',save=False,overwrite=False,is_ushr_image=True, is_lidar=False):
    if not os.path.exists(ws):
        os.makedirs(ws)  
    if is_lidar:
        fout  = os.path.join(ws,'%s_lidar.png'%sign_id).replace("\\","/")
    else:  
        fout  = os.path.join(ws,'%s.png'%sign_id).replace("\\","/")
    if os.path.exists(fout) and not overwrite:
        return fout

    cols = bbox.strip('[]').split(',')
    x_min = min(float(cols[0]), float(cols[2]))
    x_max = max(float(cols[0]), float(cols[2]))
    y_min = min(float(cols[1]), float(cols[3]))
    y_max = max(float(cols[1]), float(cols[3]))

    hanging_str = ''
    if is_hanging:
        hanging_str = 'Hanging '
    digital_str = ''
    if is_digital:
        digital_str = 'Digital'

    if value:
        type_ += str(value)

    if is_ushr_image:
        qim = ImageQt(image)
        pixmap = QPixmap.fromImage(qim)
    else:
        pixmap = QPixmap()
        pixmap.loadFromData(image)

    image_width = pixmap.width()
    image_height = pixmap.height()

    painter = QPainter(pixmap)
    pen = QPen(Qt.red, 4)
    painter.setPen(pen)
    painter.drawRect(x_min, y_min, x_max - x_min, y_max - y_min)
    painter.end()

    

    if image_width>640 and image_height>640:
        if image_width > image_height:
            scaled_height = 640
            scaled_width  = (image_width * scaled_height) // image_height
        else:
            scaled_width = 640
            scaled_height  = (image_height * scaled_width) // image_width
    else:
        scaled_width   = image_width
        scaled_height  = image_height


    scaled = pixmap.scaled(scaled_width, scaled_height, Qt.KeepAspectRatio, Qt.SmoothTransformation)
    painter = QPainter(scaled)
    pen = QPen(Qt.red, 4)
    painter.setPen(pen)
    painter.setFont(QFont("times",20))
    painter.drawText(200, scaled_height-130, "# " + str(sign_id) ) 
    painter.drawText(200, scaled_height-100, hanging_str + digital_str )
    painter.drawText(200, scaled_height-70, shape)
    painter.drawText(200, scaled_height-40, type_)
    painter.drawText(200, scaled_height-10, captured_at)
    painter.end()

    
    try:
        #image.save(fout)
        scaled.save(fout,'PNG')
        return fout
    except:
        return None

def save_sign_image(pixmap,fn,ws):
    #image = ImageQt.fromqpixmap(pixmap)

    fout  = os.path.join(ws,'%s.png'%fn).replace("\\","/")
    try:
        #image.save(fout)
        pixmap.save(fout,'PNG')
        return fout
    except:
        return None

class SignWin(QWidget):
    def __init__(self,mainwin=None):
        super().__init__()
        self.setWindowTitle("Sampling-SIGN")
        self.setWindowIcon(QIcon(":/plugin/happy_ansi/db.png"))
        #self.setWindowFlags(Qt.CustomizeWindowHint)
        self.setWindowFlags(Qt.WindowCloseButtonHint)
        self.main   = mainwin
        self.conn   = None #self.main.customer_conn
        self.siloc  = None
        self.siloc_camera_image_dialog = None
        self.n_samples = 10


        self.sign_id_list = []
        self.sign_super_type_dict = {}
        self.sign_type_dict = {}
        self.sign_dict = {}
        self.sign_lane_mapping_dict = {}
        self.sign_qrt_dict = {}

        self.pm_id_list = []
        self.pm_dict = {}
        self.pm_lane_mapping_dict = {}
        self.pm_qrt_dict = {}


        self.mode = 'NEW'
        self.form = QFormLayout()
        self.layout_sign()
        #self.connect_signals()

    def layout_pm(self):
        clearLayout(self.form)
        self.setFixedSize(180,200) 
        self.radioSign = QRadioButton('Sign')
        self.radioSign.setChecked(False)
        self.radioPM = QRadioButton('PM')
        self.radioPM.setChecked(True)
        self.clientField    = QComboBox()  
        self.clientField.addItems(['RFDB','UDBX','UDBX3'])
        self.populateBtn  = QPushButton('Populate')
        self.subcLabel    = QLabel('Subcountry')
        self.subcField    = QComboBox()  
        self.pmLabel    = QLabel('P Markings')
        self.pmField    = QComboBox() 
        self.sampleLabel = QLabel('Sample #')
        self.sampleField = QLineEdit('250')   
        self.sampleField.setAlignment(Qt.AlignRight) 
        self.loadBtn      = QPushButton('Load Data')
        self.gen_sample = QPushButton('Sample')
        widgets = [self.pmLabel, self.pmField, self.populateBtn,self.gen_sample, self.clientField,self.loadBtn,self.subcLabel,self.subcField,self.suptLabel,self.suptField,self.sampleLabel,self.sampleField]
        for w in widgets:
            w.setFixedWidth(60)
        self.form.setLabelAlignment(Qt.AlignLeft)
        self.form.setFormAlignment(Qt.AlignCenter)
        self.form.setContentsMargins(10,10,10,10)
        self.form.addRow(self.clientField,self.populateBtn)
        self.form.addRow(self.radioSign,self.radioPM)
        self.form.addRow(self.sampleLabel,self.sampleField)
        self.form.addRow(self.subcLabel,self.subcField)
        self.form.addRow(self.pmLabel,self.pmField)
        self.form.addRow(self.loadBtn,self.gen_sample) 
        self.connect_signals()
        #self.move(100,200)
        self.setLayout(self.form)
        self.show()
    def layout_sign(self):
        clearLayout(self.form)
        self.setFixedSize(180,290) 

        self.radioSign = QRadioButton('Sign')
        self.radioSign.setChecked(True)
        self.radioPM = QRadioButton('PM')
        self.radioPM.setChecked(False)
        self.clientField    = QComboBox()  
        self.clientField.addItems(['RFDB','UDBX','UDBX3'])
        self.populateBtn  = QPushButton('Populate')
        self.subcLabel    = QLabel('Subcountry')
        self.subcField    = QComboBox()  
        self.suptLabel    = QLabel('Super Type')
        self.suptField    = QComboBox() 
        self.typeLabel    = QLabel('Type')
        self.typeField    = QComboBox()     
        self.valueLabel   = QLabel('Value')
        self.valueField   = QComboBox()       
        self.shapeLabel   = QLabel('Shape')
        self.shapeField   = QComboBox()       
        self.digitalLabel = QLabel('Digital')
        self.digitalField = QComboBox()       
        self.hangingLabel = QLabel('Hanging')
        self.hangingField = QComboBox()    
        self.sampleLabel = QLabel('Sample #')
        self.sampleField = QLineEdit('250')   
        self.sampleField.setAlignment(Qt.AlignRight) 
        self.loadBtn      = QPushButton('Load Data')
        self.gen_sample = QPushButton('Sample')
        widgets = [self.populateBtn,self.gen_sample, self.clientField,self.loadBtn,self.subcLabel,self.subcField,self.suptLabel,self.suptField,self.typeLabel,self.typeField,self.valueLabel,self.valueField,self.shapeLabel,self.shapeField,self.digitalLabel,self.digitalField,self.hangingLabel,self.hangingField,self.sampleLabel,self.sampleField]
        for w in widgets:
            w.setFixedWidth(60)
        #self.form = QFormLayout()
        self.form.setLabelAlignment(Qt.AlignLeft)
        self.form.setFormAlignment(Qt.AlignCenter)
        self.form.setContentsMargins(10,10,10,10)
        self.form.addRow(self.clientField,self.populateBtn)
        self.form.addRow(self.radioSign,self.radioPM)
        self.form.addRow(self.sampleLabel,self.sampleField)
        self.form.addRow(self.subcLabel,self.subcField)
        self.form.addRow(self.suptLabel,self.suptField)
        self.form.addRow(self.typeLabel,self.typeField)
        self.form.addRow(self.valueLabel,self.valueField)
        self.form.addRow(self.shapeLabel,self.shapeField)
        self.form.addRow(self.digitalLabel,self.digitalField)
        self.form.addRow(self.hangingLabel,self.hangingField)   
        self.form.addRow(self.loadBtn,self.gen_sample) 
        #self.move(100,200)
        self.connect_signals()
        self.setLayout(self.form)
        self.show()
    def load_samples(self):
        db_format = self.get_db_format()
        self.clear_qrt_dict()        
        self.main.update_current_conn(db_format)

        self.data_uri  = QFileDialog.getOpenFileName(None,'Open On', r'C:\Users\hhuang\Downloads', 'CSV(*.csv);;Shapefile(*.shp);;GeoJSON(*.GeoJSON)')[0]
        if not self.data_uri:
            return 
        if self.data_uri.lower().endswith('.csv'):
            sign_df = pd.read_csv(self.data_uri)    
        elif self.data_uri.lower().endswith('.shp') or self.data_uri.lower().endswith('.geojson'):
            sign_df = gpd.read_file(self.data_uri)    
        else:
            QMessageBox.about(self,'Warning','Unknown file format, please retry')
            self.load_samples()



        sign_id_field, okPressed = QInputDialog.getItem(self,'Please select Sign Id Field','Sign ID Field',sign_df.columns,0,False)

        if db_format=='RFDB':
            self.main.update_current_conn("RFDB")
            self.siloc = Siloc(self.main,client='RFDB')
            self.conn   = self.main.rfdb_conn
        elif db_format=='UDBX':
            self.siloc = Siloc(self.main,client='UDBX')
            self.conn   = self.main.customer_conn
            sign_df[sign_id_field] *= 9
        elif db_format=='UDBX3':
            self.main.update_current_conn("JPRFDB")
            self.main.update_current_conn("UDBX3")
            self.conn   = self.main.rfdb_conn
            self.siloc = Siloc(self.main,client='UDBX3')

        if okPressed and sign_id_field:           
            sign_ids = sign_df[sign_id_field].tolist()
            print(len(sign_ids))
            #sign_ids = [s*9 for s in sign_ids]
            #print(sign_ids)
            params = [tuple(sign_ids)]
        else:
            QMessageBox.about(self,'Warning','Please select the sign id field and click okay')
            self.load_samples()
    
        if db_format=="UDBX3":
            rst          = []
            colNames = ['udbx_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']
            for sid in sign_ids:
                captured_at, lidar_at, lidar_image, image, lidar_bbox, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid = self.siloc.get_sign_image(int(sid))
                if image is not None:
                    image_url = draw_sign_image(sid, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
                else:
                    with open(self.main.no_image_path, 'rb') as f:
                        image = f.read()
                    image_url = draw_sign_image(sid, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
                rst.append([sid, str(captured_at), type_, value, shape, is_digital, is_hanging, image_url, centroid])
            now             = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            df = pd.DataFrame(rst)
            df.columns = colNames
            df.to_csv(os.path.join(self.main.ws,'sign_samples_%s.csv'%now),index=False)
            QMessageBox.about(self,'Wow UDBX3','Saved Sign/PM Samples Have Been Retrieved!')
            return
        elif db_format=="RFDB":
            rst          = []
            colNames = ['rfdb_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']
            for sid in sign_ids:
                captured_at, lidar_at, lidar_image, image, lidar_bbox, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid = self.siloc.get_sign_image(int(sid))
                print('*'*25)                
                if image is not None:
                    try:
                        image_url = draw_sign_image(sid, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
                    except:
                        image_url = self.main.no_image_path.replace('\\','/')
                        print('error on # %s'%sid)
                else:
                    image_url = self.main.no_image_path.replace('\\','/')
                    # with open(self.main.no_image_path, 'rb') as f:
                    #     image = f.read()
                    # image_url = draw_sign_image(sid, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
                rst.append([sid, str(captured_at), type_, value, shape, is_digital, is_hanging, image_url, centroid])
                print('*'*25)
            now             = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
            df = pd.DataFrame(rst)
            df.columns = colNames
            df.to_csv(os.path.join(self.main.ws,'sign_samples_%s.csv'%now),index=False)
            QMessageBox.about(self,'Wow RFDB','Saved Sign/PM Samples Have Been Retrieved!')
            return
        else:
            query = f'''with sign_sample as (select sign_id, centroid_position, type
                                from ushr_format.signs 
                                where sign_id in %s)
                                select sign_sample.sign_id / 9 as rfdb_sid, 
                                array_agg(sign_lane_mapping.road_segment_id order by sign_lane_mapping.lane_number), 
                                array_agg(sign_lane_mapping.lane_number order by sign_lane_mapping.lane_number), 
                                array_agg(sign_lane_mapping.lane_point_sequence_index order by sign_lane_mapping.lane_number),
                                array_agg(st_astext(st_makeline(centroid_position, position)) order by sign_lane_mapping.lane_number) as lane_mapping
                                from sign_sample
                                join ushr_format.sign_lane_mapping on sign_lane_mapping.sign_id = sign_sample.sign_id       
                                join ushr_format.lane_center_points on lane_center_points.road_segment_id = sign_lane_mapping.road_segment_id
                                where ((type > 13 and lane_center_points.lane_number = sign_lane_mapping.lane_number + 1) or 
                                    (type <= 13 and lane_center_points.lane_number = sign_lane_mapping.lane_number))
                                and lane_center_points.lane_point_sequence_index = sign_lane_mapping.lane_point_sequence_index                                                
                                group by sign_sample.sign_id
                                '''


        response = make_query(self.conn, query, params)
        sign_id_list = []
        rst          = []
        sign_count   = 0
        colNames = ['rfdb_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']
        for row in response:
            id_ = row[0]
            sign_id_list.append(id_)
            sign_count += 1
            print(f"working on sign #{id_}")
            try:                
                captured_at, lidar_at, lidar_image, image, lidar_bbox, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid = self.siloc.get_sign_image(id_)
                if image is not None:
                    image_url = draw_sign_image(id_, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
                else:
                    with open(self.main.no_image_path, 'rb') as f:
                        image = f.read()
                    image_url = draw_sign_image(id_, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
            except:
                print("POWWEF")

            if db_format == 'UDBX':
                segment_id_list = row[1]
                lane_number_list = row[2]
                lane_pt_seq_index_list = row[3]
                geom_list = row[4]
                self.sign_lane_mapping_dict[id_] = {}
                for i in range(len(segment_id_list)):
                    self.sign_lane_mapping_dict[id_][i] = {'segment_id': segment_id_list[i],
                                                           'lane_number': lane_number_list[i],
                                                           'lane_pt_seq_index': lane_pt_seq_index_list[i],
                                                           'geom': geom_list[i]}
                sign_id = id_
                lane_mapping_feature_dict = {}
                segment_feature_dict = {}
                for lane_mapping_ind in self.sign_lane_mapping_dict[sign_id]:
                    segment_id = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['segment_id']
                    lane_number = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['lane_number']
                    lane_pt_seq_index = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['lane_pt_seq_index']
                    geom = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['geom']
                    attribute_list = [sign_id * 9, segment_id, lane_number, lane_pt_seq_index]
                    lane_mapping_feature_dict[lane_mapping_ind] = {}
                    lane_mapping_feature_dict[lane_mapping_ind]['attribute_list'] = attribute_list
                    lane_mapping_feature_dict[lane_mapping_ind]['geom'] = geom
                    segment_feature_dict[lane_mapping_ind] = {}
                    segment_feature_dict[lane_mapping_ind]['attribute_list'] = attribute_list
                    segment_dict = query_segment(self.conn, segment_id)
                    geom = segment_dict[segment_id]['geom']
                    segment_feature_dict[lane_mapping_ind]['geom'] = geom
                qgs_fields = [QgsField('sign_id', QVariant.Int), QgsField('segment_id', QVariant.Int),
                              QgsField('lane_number', QVariant.Int), QgsField('lane_pt_seq_index', QVariant.Int)]

                lane_mapping_layer = create_layer(lane_mapping_feature_dict, qgs_fields, geom_type='LinestringZ',layer_name='lane_mapping_%s'%id_)
                segment_layer      = create_layer(segment_feature_dict, qgs_fields, geom_type='PolygonZ',layer_name='segment_%s'%id_)
                to_file(lane_mapping_layer,'%s_lane_mapping'%id_,format=1, ws=os.path.join(self.main.ws,'data'))
                to_file(segment_layer,'%s_segment'%id_,format=1, ws=os.path.join(self.main.ws,'data'))
                colNames = ['udbx_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']
                rst.append([id_*9, str(captured_at), type_, value, shape, is_digital, is_hanging, image_url, centroid])
            else:
                rst.append([id_, str(captured_at), type_, value, shape, is_digital, is_hanging, image_url, centroid])

        if len(response) == 0:
            self.main.push_message('No sign found for this category!')
        df = pd.DataFrame(rst)
        df.columns = colNames
        df.to_csv(r'C:\Users\hhuang\Downloads\temp\data_existing.csv',index=False)
        now             = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        df = pd.DataFrame(rst)
        df.columns = colNames
        df.to_csv(os.path.join(self.main.ws,'sign_samples_%s.csv'%now),index=False)
        QMessageBox.about(self,'Wow','Saved Sign/PM Samples Have Been Retrieved!')


    def connect_signals(self):
        self.radioPM.clicked.connect(self.layout_pm)
        self.radioSign.clicked.connect(self.layout_sign)
        self.loadBtn.clicked.connect(self.load_samples)        
        self.populateBtn.clicked.connect(self.on_comboBox_qrt_db_format_changed)

        self.gen_sample.clicked.connect(self.on_pushButton_gen_signs_qrt_clicked)

        self.clientField.currentTextChanged.connect(self.on_comboBox_qrt_db_format_changed)
        self.suptField.currentTextChanged.connect(self.on_combobox_sign_super_type_changed)
        self.typeField.currentTextChanged.connect(self.on_combobox_sign_type_changed)

    def get_db_format(self):
        db_format = self.clientField.currentText()
        return db_format 
    def get_sign_types_by_super_type(self, super_type):
        db_format = self.get_db_format()
        if db_format == 'RFDB':
            types = self.sign_super_type_dict[super_type]
        elif db_format == 'UDBX':
            types = udbx_sign_types_df[udbx_sign_types_df['super_type'] == super_type]['type'].unique()
        else:
            return ''
        return types

    def on_comboBox_qrt_db_format_changed(self):
        db_format = self.get_db_format()
        self.clear_qrt_dict()
        self.main.update_current_conn(db_format)
        if db_format == 'RFDB': 
            self.conn   = self.main.rfdb_conn
            if self.radioSign.isChecked():
                for w in (self.subcField, self.valueField,self.hangingField):
                    w.setEnabled(True)
                self.load_subcountry_list()
                self.load_rfdb_sign_super_types()
                self.load_rfdb_sign_types()
            if self.radioPM.isChecked():
                self.load_rfdb_pm_types()
        elif db_format in ('UDBX','UDBX3'):
            self.conn   = self.main.customer_conn
            if self.radioSign.isChecked():
                for w in (self.subcField, self.valueField,self.hangingField):
                    w.setEnabled(False)
                self.load_udbx_sign_super_types()
                self.load_udbx_sign_shapes()
                self.load_udbx_sign_is_digital()
            if self.radioPM.isChecked():
                self.load_udbx_pm_types()
        else:
            return
    def clear_qrt_dict(self):
        self.sign_qrt_dict.clear()
        self.pm_qrt_dict.clear()
    # if type is speed limit type, make value available
    def on_combobox_sign_type_changed(self):
        db_format = self.get_db_format()
        if db_format != 'RFDB':
            return
        super_type = self.suptField.currentText()
        type_ = self.typeField.currentText()
        if super_type == 'Speed Limit' or type_ == '':  # the values should already be available
            return
        super_type = self.sign_type_dict[type_]
        if super_type == 'Speed Limit':
            self.valueField.clear()
            #self.load_rfdb_speed_limit_vals()
    #   if type is speed limit type, make value available
    def on_combobox_sign_super_type_changed(self):
        self.typeField.clear()
        self.valueField.clear()
        super_type = self.suptField.currentText()
        db_format = self.get_db_format()

        if db_format == 'RFDB':
            if super_type == '':
                self.load_rfdb_sign_types()
            else:
                self.typeField.addItems([''] + self.sign_super_type_dict[super_type])
            if super_type == 'Speed Limit':
                self.load_rfdb_speed_limit_vals()
        elif db_format == 'UDBX':
            if super_type == '':
                self.load_udbx_sign_types()
            else:
                self.load_udbx_sign_types_filter_super_type(super_type)
    def load_rfdb_sign_types(self):
        self.typeField.clear()
        self.typeField.addItems([''] + sorted(list(self.sign_type_dict)))

    def load_subcountry_list(self):
        if self.radioSign.isChecked():
            self.subcField.clear()
        if self.radioPM.isChecked():
            self.pmField.clear()
        subcountry_list = query_subcountry_list(self.conn)
        extra_subcountry_list = query_extra_subcountry_list(self.conn)
        self.subcField.addItems(np.insert(subcountry_list + extra_subcountry_list, 0, ''))
        
    def load_rfdb_sign_super_types(self):
        self.suptField.clear()
        self.sign_type_dict = query_sign_types(self.conn)
        for sign_type in self.sign_type_dict:
            super_type = self.sign_type_dict[sign_type]
            if super_type not in self.sign_super_type_dict:
                self.sign_super_type_dict[super_type] = []
            self.sign_super_type_dict[super_type].append(sign_type)
        self.suptField.addItems([''] + sorted(self.sign_super_type_dict))


    def load_rfdb_pm_types(self):
        self.pmField.clear()
        pm_type_list = query_pm_types(self.conn)
        self.pmField.addItems([''] + sorted(pm_type_list))

    def load_rfdb_speed_limit_vals(self):
        self.valueField.clear()
        self.valueField.addItems(np.insert(list(map(str, sorted(self.rfdb_sign_speed_limit_vals))), 0, ''))

    # RTD vs non-RTD
    def load_udbx_sign_super_types(self):
        self.suptField.clear()
        self.suptField.addItems(np.insert(sorted(udbx_sign_super_type_df['name'].unique()), 0, ''))

    def load_udbx_sign_types(self):
        self.typeField.clear()
        self.typeField.addItems(np.insert(sorted(udbx_sign_types_df['type'].unique()), 0, ''))

    def load_udbx_sign_types_filter_super_type(self, super_type):
        self.typeField.clear()
        self.typeField.addItems(np.insert(sorted(udbx_sign_types_df[udbx_sign_types_df['super_type'] == super_type]['type'].unique()), 0,''))

    def load_udbx_sign_shapes(self):
        self.shapeField.clear()
        self.shapeField.addItems(np.insert(sorted(udbx_sign_shape_df['shape'].unique()), 0, ''))

    def load_udbx_sign_is_digital(self):
        self.digitalField.clear()
        self.digitalField.addItems(['', 'True', 'False'])
    def load_udbx_pm_types(self):
        self.pmField.clear()
        self.pmField.addItems(np.insert(sorted(udbx_pm_type_df['type'].unique()), 0, ''))

    @pyqtSlot()    
    def on_pushButton_gen_signs_qrt_clicked(self):
        print('It is the 1st click\n---------------')
        db_format = self.get_db_format()
        self.clear_qrt_dict()        
        self.main.update_current_conn(db_format)
        if db_format=='RFDB':
            self.conn   = self.main.rfdb_conn
        elif db_format=='UDBX':
            self.conn   = self.main.customer_conn
        elif db_format=='UDBX3':
            self.conn   = self.main.customer_conn
        
        if self.radioSign.isChecked():
            try:
                self.n_samples = int(self.sampleField.text())
            except:
                self.n_samples = 10
        
            super_type = self.suptField.currentText()
            type_ = self.typeField.currentText()
            # only super type is selected
            if type_ == '' and super_type != '':
                type_ = self.get_sign_types_by_super_type(super_type)

            value = self.valueField.currentText()
            if value != '':
                value = int(value)
            shape = self.shapeField.currentText()
            is_digital = self.digitalField.currentText()
            is_hanging = self.hangingField.currentText()
            subcountry = self.subcField.currentText()
            self.sign_id_list = self.query_sign_samples(n_samples=self.n_samples, type_=string2array(type_),
                                                        value=string2array(value), shape=string2array(shape),
                                                        is_digital=string2array(is_digital),
                                                        is_hanging=string2array(is_hanging),
                                                        subcountry=string2array(subcountry))
            
        else:
            subcountry = self.subcField.currentText()
            type_ = self.pmField.currentText()
            self.n_samples = int(self.sampleField.text())
            self.pm_id_list = self.query_pm_samples(n_samples=self.n_samples, type_=string2array(type_),
                                                    subcountry=string2array(subcountry))

    def query_pm_samples(self, n_samples=10, type_=None, subcountry=None):
        pm_id_list = []
        self.pm_dict.clear()
        self.pm_lane_mapping_dict.clear()
        db_format = self.get_db_format()

        type_option = ''
        subcountry_option = ''

        params = []

        if type_ is not None:
            if db_format == 'RFDB':
                type_option = 'and type_name = any(%s)'
            elif db_format == 'UDBX':
                # convert name list to id list
                type_ = udbx_sign_pm_type_name_list_to_id_list(type_, feature='pm')
                type_option = 'where marking_type = any(%s)'
            params.append(type_)

        if subcountry is not None:
            subcountry_option = 'and subcountry = any(%s)'
            params.append(subcountry)

        if len(params) == 0:
            params = None

        if db_format == 'RFDB':
            query = f'''with pm_sample as (select road_objects.id as road_object_id, type_name, location, envelope
                        from road_object.road_objects
                        join work_units.associated_road_objects 
                            on associated_road_objects.road_object_id = road_objects.id
                        join work_units.work_unit on work_unit.id = associated_road_objects.wu_id
                        where type_name like 'RO_PM_%%'
                        {type_option}
                        {subcountry_option}
                        order by random()
                        limit {n_samples})
                        select pm_sample.road_object_id, type_name, st_astext(location) as loc, st_astext(envelope) as envelope, 
                        st_astext(st_envelope(st_buffer(envelope::geometry, 0.0001))) 
                        from pm_sample                       
                        '''
        elif db_format == 'UDBX':
            query = f'''with pm_sample as (select pm.pavement_marking_id, marking_type as type, centroid_position, 
                        st_polygon(st_linefrommultipoint(
                        st_collect(array[bottom_left_corner_position, top_left_corner_position, 
                                         top_right_corner_position, bottom_right_corner_position, 
                                         bottom_left_corner_position])), 4326) as pm_geom
                        from ushr_format.pavement_markings pm     
                        {type_option}                          
                        order by random()
                        limit {n_samples}
                   ), 
                   pm_lm as (
                   select pm_sample.pavement_marking_id, type, centroid_position, st_astext(pm_geom) as geom, 
                   st_astext(st_envelope(st_buffer(pm_geom, 0.0001))) as buffer_geom, road_segment_id, lane_number     
                   from pm_sample
                   join ushr_format.pavement_marking_lane_mapping pm_lane_mapping 
                        on pm_lane_mapping.pavement_marking_id = pm_sample.pavement_marking_id                                     
                   group by pm_sample.pavement_marking_id, type, centroid_position, pm_geom, road_segment_id, lane_number   
                      )
                    select pavement_marking_id, type, st_astext(centroid_position) as centroid,
                    geom, buffer_geom, array_agg(pm_lm.road_segment_id order by pm_lm.lane_number) as road_segment_ids, 
                    array_agg(pm_lm.lane_number order by pm_lm.lane_number) as lane_numbers,                    
                    array_agg(st_astext(st_makeline(centroid_position, lane_center_points.position)) order by pm_lm.lane_number)
                    from pm_lm
                    join ushr_format.lane_center_points on lane_center_points.road_segment_id = pm_lm.road_segment_id
                   and lane_center_points.lane_number = pm_lm.lane_number
                   and lane_center_points.lane_point_sequence_index = 0
                   group by pavement_marking_id, type, centroid_position, geom, buffer_geom'''
        else:
            return

        response = make_query(self.conn, query, params)
        for row in response:
            pm_id = row[0]
            pm_id_list.append(pm_id)
            type_ = row[1]
            centroid = row[2]
            geom = row[3]
            buffer_geom_extent = row[4]
            if db_format == 'UDBX':
                type_ = udbx_pm_type_df[udbx_pm_type_df['id'] == type_]['type'].values[0]
                # lane mapping
                segment_id_list = row[5]
                lane_number_list = row[6]
                geom_list = row[7]
                self.pm_lane_mapping_dict[pm_id] = {}
                for i in range(len(segment_id_list)):
                    self.pm_lane_mapping_dict[pm_id][i] = {'segment_id': segment_id_list[i],
                                                         'lane_number': lane_number_list[i],
                                                         'geom': geom_list[i]}

                lane_mapping_feature_dict = {}
                segment_feature_dict = {}
                for lane_mapping_ind in self.pm_lane_mapping_dict[pm_id]:
                    segment_id = self.pm_lane_mapping_dict[pm_id][lane_mapping_ind]['segment_id']
                    lane_number = self.pm_lane_mapping_dict[pm_id][lane_mapping_ind]['lane_number']
                    geom = self.pm_lane_mapping_dict[pm_id][lane_mapping_ind]['geom']
                    attribute_list = [pm_id, segment_id, lane_number]
                    lane_mapping_feature_dict[lane_mapping_ind] = {}
                    lane_mapping_feature_dict[lane_mapping_ind]['attribute_list'] = attribute_list
                    lane_mapping_feature_dict[lane_mapping_ind]['geom'] = geom
                    segment_feature_dict[lane_mapping_ind] = {}
                    segment_feature_dict[lane_mapping_ind]['attribute_list'] = attribute_list
                    segment_dict = query_segment(self.conn, segment_id)
                    geom = segment_dict[segment_id]['geom']
                    segment_feature_dict[lane_mapping_ind]['geom'] = geom
                qgs_fields = [QgsField('pm_id', QVariant.Int), QgsField('segment_id', QVariant.Int),
                              QgsField('lane_number', QVariant.Int)]


                lane_mapping_layer = create_layer(lane_mapping_feature_dict, qgs_fields, geom_type='LinestringZ',layer_name=f'pm_{pm_id}_lane_mapping')
                segment_layer      = create_layer(segment_feature_dict, qgs_fields, geom_type='PolygonZ',layer_name=f'pm_{pm_id}_segment_mapping')
                
                to_file(lane_mapping_layer,'%s_lane_mapping'%pm_id,format=1, ws=os.path.join(self.main.ws,'data'))
                to_file(segment_layer,'%s_segment'%pm_id,format=1, ws=os.path.join(self.main.ws,'data'))

            self.pm_dict[pm_id] = {'type': type_, 'centroid': centroid, 'geom': geom,
                                 'buffer_geom_extent': buffer_geom_extent}
        df = pd.DataFrame.from_dict(self.pm_dict,orient='index')
        df.columns = ['type','centroid','geometry','buffer_ext']
        now             = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        df.to_csv(os.path.join(self.main.ws,'pm_samples_%s.csv'%now),index=False)
        return pm_id_list



    def query_sign_samples(self, n_samples=10, type_=None, value=None, shape=None, is_digital=None, is_hanging=None,
                           subcountry=None):

        db_format = self.get_db_format()

        type_option = ''
        value_option = ''
        shape_option = ''
        is_digital_option = ''
        is_hanging_option = ''
        subcountry_option = ''

        params = []
        colNames = ['rfdb_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']

        if type_ is not None:
            if db_format == 'RFDB':
                type_option = 'and sign_types.name = any(%s)'
            elif db_format == 'UDBX':
                # convert name list to id list
                type_ = udbx_sign_pm_type_name_list_to_id_list(type_, feature='sign')
                type_option = 'and type = any(%s)'
            params.append(type_)
        if value is not None:
            value_option = 'and value = any(%s)'
            params.append(value)
        if shape is not None:
            if db_format == 'RFDB':
                shape_option = 'and sign_shapes.name = any(%s)'
            elif db_format == 'UDBX':
                shape = udbx_sign_shape_name_list_to_id_list(shape)
                shape_option = 'and shape = any(%s)'
            params.append(shape)
        if is_digital is not None:
            is_digital_option = 'and is_digital = any(%s)'
            is_digital = string_list2bool_list(is_digital)
            params.append(is_digital)
        if is_hanging is not None:
            is_hanging_option = 'and is_hanging = any(%s)'
            params.append(is_hanging)
        if subcountry is not None:
            subcountry_option = 'and subcountry = any(%s)'
            params.append(subcountry)

        if db_format == 'RFDB':
            query = f'''select signs.id
                        from signs.signs
                        join signs.sign_types on sign_types.id = type_id
                        join signs.sign_shapes on sign_shapes.id = shape_id                 
                        join road_object.road_object_signs on road_object_signs.sign_id = signs.id
                        join work_units.associated_road_objects 
                             on associated_road_objects.road_object_id = road_object_signs.road_object_id
                        join work_units.work_unit on work_unit.id = associated_road_objects.wu_id
                        where camera_imagery_id is not NULL
                        {type_option}
                        {value_option}
                        {shape_option}
                        {is_digital_option}
                        {is_hanging_option}
                        {subcountry_option}       
                        order by random()
                        limit {n_samples}                                
                    '''
        elif db_format == 'UDBX':           
            query = f'''with sign_sample as (select sign_id, centroid_position, type
                        from ushr_format.signs 
                        where sign_id <= 1000000000
                        {type_option}
                        {shape_option}
                        {is_digital_option}
                        order by random()
                        limit {n_samples})
                        select sign_sample.sign_id / 9 as rfdb_sid, 
                        array_agg(sign_lane_mapping.road_segment_id order by sign_lane_mapping.lane_number), 
                        array_agg(sign_lane_mapping.lane_number order by sign_lane_mapping.lane_number), 
                        array_agg(sign_lane_mapping.lane_point_sequence_index order by sign_lane_mapping.lane_number),
                        array_agg(st_astext(st_makeline(centroid_position, position)) order by sign_lane_mapping.lane_number) as lane_mapping
                        from sign_sample
                        join ushr_format.sign_lane_mapping on sign_lane_mapping.sign_id = sign_sample.sign_id       
                        join ushr_format.lane_center_points on lane_center_points.road_segment_id = sign_lane_mapping.road_segment_id
                        where ((type > 13 and lane_center_points.lane_number = sign_lane_mapping.lane_number + 1) or 
                            (type <= 13 and lane_center_points.lane_number = sign_lane_mapping.lane_number))
                        and lane_center_points.lane_point_sequence_index = sign_lane_mapping.lane_point_sequence_index                                                
                        group by sign_sample.sign_id
                        '''
            colNames = ['udbx_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']
        elif db_format == 'UDBX3': 
            sign_super_type = self.typeField.currentText()
            sign_type_constraint = 'where type = any(%s)'  
            if sign_super_type:
                sign_types = udbx_sign_types_df[udbx_sign_types_df['super_type'] == sign_super_type]['id'].unique().tolist()
            else:
                sign_types = None            
            query = f'''with sign as (
                        select sign_id, type, centroid_position
                        from ushr_format.signs       
                        {sign_type_constraint}
                        order by random()
                        limit {n_samples}
                    ), 
                    sign_lane_mapping as (
                    select sign.sign_id, type, sign_lane_mapping.road_segment_id, sign_lane_mapping.lane_number, 
                    sign_lane_mapping.lane_point_sequence_index,                     
                    centroid_position, st_astext(st_makeline(centroid_position, applied_position)) as rtd_apply
                    from sign 
                    left join ushr_format.sign_lane_mapping on sign_lane_mapping.sign_id = sign.sign_id
                    left join ushr_format.rtd_apply_position 
                        on rtd_apply_position.road_segment_id = sign_lane_mapping.road_segment_id
                        and rtd_apply_position.lane_number = sign_lane_mapping.lane_number
                        and rtd_apply_position.lane_point_sequence_index = sign_lane_mapping.lane_point_sequence_index
                    )
                    select sign_id, type, sign_lane_mapping.road_segment_id, sign_lane_mapping.lane_number, 
                    sign_lane_mapping.lane_point_sequence_index, st_astext(centroid_position), rtd_apply,
                    st_astext(st_makeline(centroid_position, position)) as lane_mapping
                    from sign_lane_mapping
                    join ushr_format.lane_center_points on lane_center_points.road_segment_id = sign_lane_mapping.road_segment_id
                    where ((type > 13 and type < 196 and lane_center_points.lane_number = sign_lane_mapping.lane_number + 1) or 
                    ((type <= 13 or type >= 196) and lane_center_points.lane_number = sign_lane_mapping.lane_number))
                        and lane_center_points.lane_point_sequence_index = sign_lane_mapping.lane_point_sequence_index                                                                      
                    '''
            colNames = ['udbx3_sid','captured_at','type','value','shape','is_digital','is_hanging','image_url','geom_wkt']
      
        else:
            return

        if self.siloc is None:
            self.siloc = Siloc(self.main)
            self.siloc.conn = self.conn

        response = make_query(self.conn, query, params)
        sign_id_list = []
        rst          = []
        sign_count   = 0
        for row in response:
            id_ = row[0]
            sign_id_list.append(id_)
            sign_count += 1
            try:                
                captured_at, lidar_at, lidar_image, image, lidar_bbox, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid = self.siloc.get_sign_image(id_)
                if image is not None:
                    image_url = draw_sign_image(id_, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
                else:
                    with open(self.main.no_image_path, 'rb') as f:
                        image = f.read()
                    image_url = draw_sign_image(id_, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.main.ws,'data'),save=True)
            except:
                image_url = "ERROR OCCURED"
                print("POWWEF")
            
            if db_format == 'UDBX':
                segment_id_list = row[1]
                lane_number_list = row[2]
                lane_pt_seq_index_list = row[3]
                geom_list = row[4]
                self.sign_lane_mapping_dict[id_] = {}
                for i in range(len(segment_id_list)):
                    self.sign_lane_mapping_dict[id_][i] = {'segment_id': segment_id_list[i],
                                                           'lane_number': lane_number_list[i],
                                                           'lane_pt_seq_index': lane_pt_seq_index_list[i],
                                                           'geom': geom_list[i]}
                
                sign_id = id_
                id_ *=  9
                lane_mapping_feature_dict = {}
                segment_feature_dict = {}
                for lane_mapping_ind in self.sign_lane_mapping_dict[sign_id]:
                    segment_id = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['segment_id']
                    lane_number = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['lane_number']
                    lane_pt_seq_index = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['lane_pt_seq_index']
                    geom = self.sign_lane_mapping_dict[sign_id][lane_mapping_ind]['geom']
                    attribute_list = [sign_id * 9, segment_id, lane_number, lane_pt_seq_index]
                    lane_mapping_feature_dict[lane_mapping_ind] = {}
                    lane_mapping_feature_dict[lane_mapping_ind]['attribute_list'] = attribute_list
                    lane_mapping_feature_dict[lane_mapping_ind]['geom'] = geom
                    segment_feature_dict[lane_mapping_ind] = {}
                    segment_feature_dict[lane_mapping_ind]['attribute_list'] = attribute_list
                    segment_dict = query_segment(self.conn, segment_id)
                    geom = segment_dict[segment_id]['geom']
                    segment_feature_dict[lane_mapping_ind]['geom'] = geom
                qgs_fields = [QgsField('sign_id', QVariant.Int), QgsField('segment_id', QVariant.Int),
                              QgsField('lane_number', QVariant.Int), QgsField('lane_pt_seq_index', QVariant.Int)]

                lane_mapping_layer = create_layer(lane_mapping_feature_dict, qgs_fields, geom_type='LinestringZ',layer_name='lane_mapping_%s'%id_)
                segment_layer      = create_layer(segment_feature_dict, qgs_fields, geom_type='PolygonZ',layer_name='segment_%s'%id_)
                to_file(lane_mapping_layer,'%s_lane_mapping'%id_,format=1, ws=os.path.join(self.main.ws,'data'))
                to_file(segment_layer,'%s_segment'%id_,format=1, ws=os.path.join(self.main.ws,'data'))

                rst.append([id_, str(captured_at), type_, value, shape, is_digital, is_hanging, image_url, centroid])

        if len(response) == 0:
            self.main.push_message('No sign found for this category!')
        now             = datetime.now().strftime("%Y_%m_%d_%H_%M_%S")
        df = pd.DataFrame(rst)
        df.columns = colNames
        df.to_csv(os.path.join(self.main.ws,'sign_samples_%s.csv'%now),index=False)
        print('Finished')
        return sign_id_list


