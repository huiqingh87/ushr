#!/usr/bin/python3
# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import QSize, Qt, QDateTime
from qgis.PyQt.QtGui import QBrush, QColor, QIcon
from qgis.PyQt.QtPrintSupport import QPrintDialog, QPrinter
from qgis.PyQt.QtWidgets import *
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from .resources import *
import geopandas as gpd
import pandas as pd
import os
import math
import numpy as np
import pytz
import webbrowser
from .encrypt import *

from datetime import datetime
import shutil
import smtplib
from pathlib import Path
from email.mime.multipart import MIMEMultipart
from email.mime.base import MIMEBase
from email.mime.text import MIMEText
from email.utils import COMMASPACE, formatdate
from email import encoders
from .rules import *
from matplotlib.ticker import MaxNLocator
import matplotlib.ticker as ticker
from .steps import FieldChoseWin


class FieldWin(QDialog):
    def __init__(self,mainwin=None):
        super().__init__()
        self.main = mainwin
        # Set the window size to 200x200 pixels
        self.setFixedSize(200, 300)
        self.setWindowTitle('Popup Window')

        # Create a form layout
        layout = QFormLayout()
        # Add a label and combobox to the first 3 rows of the form
        label1 = QLabel('Unique Field')
        self.uniqueFieldCbox = QComboBox()
        layout.addRow(label1, self.uniqueFieldCbox)

        label2 = QLabel('ANSI Field')
        self.ansiFieldCbox = QComboBox()
        layout.addRow(label2, self.ansiFieldCbox)

        label3 = QLabel('ANSI Notes')
        self.notesFieldCbox = QComboBox()
        layout.addRow(label3, self.notesFieldCbox)

        label4 = QLabel('Technician')
        self.techFieldCbox = QComboBox()
        layout.addRow(label4, self.techFieldCbox)

        label5 = QLabel('ANSI Date')
        self.dateFieldCbox = QComboBox()
        layout.addRow(label5, self.dateFieldCbox)
        # Add a reset button and save button to the 4th row of the form
        self.reset_button = QPushButton('Reset')
        self.save_button = QPushButton('Save')

        layout.addRow(self.reset_button, self.save_button)
        self.resetSettings()

        self.reset_button.clicked.connect(self.resetSettings)
        self.save_button.clicked.connect(self.saveSettings) 
        # Set the layout of the main window to the form layout
        self.setLayout(layout)
        self.show()
    def saveSettings(self):
        self.main.unique_field = self.uniqueFieldCbox.currentText().strip()
        self.main.ansi_field   = self.ansiFieldCbox.currentText().strip()
        self.main.ansi_notes   = self.notesFieldCbox.currentText().strip()
        self.main.ansi_date    = self.dateFieldCbox.currentText().strip()
        self.main.ansi_tech    = self.techFieldCbox.currentText().strip()
        self.accept()



    def resetSettings(self):
        field_names = self.main.data.keys()
        for cbox in (self.uniqueFieldCbox,self.ansiFieldCbox,self.notesFieldCbox,self.dateFieldCbox,self.techFieldCbox):
            cbox.addItems(field_names)

        for f in field_names:            
            if f.lower().find('id')!=-1 or f.lower().find('road_segme') !=-1:
                self.uniqueFieldCbox.setCurrentText(f)
                break
        for f in field_names: 
            if f.lower().find('notes')!=-1 or f.lower().find('comment') !=-1:
                self.notesFieldCbox.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('overall')!=-1 or f.lower().find('pass/fail') !=-1:
                self.ansiFieldCbox.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('lst_updat')!=-1 or f.lower().find('date') !=-1:
                self.dateFieldCbox.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('technician')!=-1:
                self.techFieldCbox.setCurrentText(f)
                break

def groupSum(data, group_field,  unique_field):
    data_agg = data.groupby(group_field,as_index=False).agg({unique_field:'count'}).sort_values(group_field)
    #print(data_agg.head())
    if isinstance(group_field,str):
        data_agg.columns = [group_field,'CompletedSegments']
    elif isinstance(group_field,list):
        data_agg.columns = group_field + ['CompletedSegments']
    return data_agg

def calPass(r,cols):
    #print(cols)
    tmp = r[cols].sum()
    #print(tmp)
    if isinstance(tmp,str):
        if tmp.lower().find('fail')!=-1:
            return 'fail'
        else:
            return 'pass'
    else:
        if tmp == len(cols)-2:
            return 'fail'
        else:
            return 'pass'
class AddEngineer(QDialog):
    def __init__(self,mainwin=None):
        super().__init__()
        self.main = mainwin
        # Set window title and layout
        self.setWindowTitle("Add Engineer")
        layout = QVBoxLayout(self)

        # Add name label and text input
        name_label = QLabel("Name:")
        self.name_input = QLineEdit()
        layout.addWidget(name_label)
        layout.addWidget(self.name_input)

        # Add email label and text input
        email_label = QLabel("Email:")
        self.email_input = QLineEdit()
        layout.addWidget(email_label)
        layout.addWidget(self.email_input)

        # Add admin checkbox
        admin_label = QLabel("Admin:")
        self.admin_checkbox = QCheckBox()
        layout.addWidget(admin_label)
        layout.addWidget(self.admin_checkbox)

        # Add submit button
        submit_button = QPushButton("Add")
        submit_button.clicked.connect(self.accept)
        layout.addWidget(submit_button)
        self.show()

    def get_inputs(self):
        # Return the user's inputs as a tuple
        name = self.name_input.text()
        email = self.email_input.text()
        is_admin = self.admin_checkbox.isChecked()
        return name, email, is_admin




class ManageEngineer(QMainWindow):
    def __init__(self,mainwin=None):
        super().__init__()
        self.main = mainwin.main
        self.conn    = None
        self.setWindowTitle('Engineers Management')
        self.resize(800, 600)

        self.central_widget = QWidget()
        self.layout = QVBoxLayout()
        self.central_widget.setLayout(self.layout)
        self.setCentralWidget(self.central_widget)

        self.table_view = QTableView()
        self.layout.addWidget(self.table_view)

        self.proxy_model = QSortFilterProxyModel()
        self.proxy_model.setDynamicSortFilter(True)

        self.table_view.setSortingEnabled(True)
        self.table_view.setModel(self.proxy_model)

        self.refresh_button = QPushButton('Refresh')
        self.refresh_button.clicked.connect(self.refresh_data)
        self.layout.addWidget(self.refresh_button)

        self.delete_button = QPushButton('Delete Selected')
        self.delete_button.clicked.connect(self.delete_selected)
        self.layout.addWidget(self.delete_button)

        self.load_data()
        self.show()
    def load_data(self):
        if not self.conn:
            self.conn = connect_to_db_rule(self.main.config['Rules']['host'], self.main.config['Rules']['username'], self.main.config['Rules']['password'], self.main.config['Rules']['db'],self.main.config['Rules']['port'])
        cursor = self.conn.cursor()
        cursor.execute('SELECT * FROM engineers')
        data = cursor.fetchall()
        cursor.close()

        header = [desc[0] for desc in cursor.description]
        model = QStandardItemModel(len(data), len(header))
        model.setHorizontalHeaderLabels(header)

        for row in range(len(data)):
            for column in range(len(header)):
                item = QStandardItem(str(data[row][column]))
                item.setTextAlignment(Qt.AlignCenter)
                model.setItem(row, column, item)

        self.proxy_model.setSourceModel(model)
        self.table_view.setModel(self.proxy_model)
        
    def refresh_data(self):
        self.load_data()

    def delete_selected(self):
        if not self.conn:
            self.conn = connect_to_db_rule(self.main.config['Rules']['host'], self.main.config['Rules']['username'], self.main.config['Rules']['password'], self.main.config['Rules']['db'],self.main.config['Rules']['port'])
        cursor = self.conn.cursor()
        selected_indexes = self.table_view.selectionModel().selectedRows()
        if selected_indexes:
            reply = QMessageBox.question(self, 'Delete Confirmation', 'Are you sure you want to delete the selected row(s)?',
                                         QMessageBox.Yes | QMessageBox.No, QMessageBox.No)
            if reply == QMessageBox.Yes:
                for index in selected_indexes:
                    row = index.row()
                    engineer_id = self.table_view.model().index(row, 0).data()
                    cursor.execute(f'DELETE FROM engineers WHERE id = {engineer_id}')
                self.conn.commit()
                cursor.close()
                self.load_data()
        else:
            QMessageBox.information(self, 'No Rows Selected', 'Please select row(s) to delete.')

    def closeEvent(self, event):
        self.close()






def modification_date(filename):
    t = os.path.getmtime(filename)
    return datetime.datetime.fromtimestamp(t)

def send_mail(send_from, send_to, subject, message, files=[],
              server="localhost", port=587, username='', password='',
              use_tls=True):
    """Compose and send email with provided info and attachments.

    Args:
        send_from (str): from name
        send_to (list[str]): to name(s)
        subject (str): message title
        message (str): message body
        files (list[str]): list of file paths to be attached to email
        server (str): mail server host name
        port (int): port number
        username (str): server auth username
        password (str): server auth password
        use_tls (bool): use TLS mode
    """
    msg = MIMEMultipart()
    msg['From'] = send_from
    msg['To'] = COMMASPACE.join(send_to)
    msg['Date'] = formatdate(localtime=True)
    msg['Subject'] = subject

    msg.attach(MIMEText(message,'html'))

    for path in files:
        part = MIMEBase('application', "octet-stream")
        with open(path, 'rb') as file:
            part.set_payload(file.read())
        encoders.encode_base64(part)
        part.add_header('Content-Disposition',
                        'attachment; filename={}'.format(Path(path).name))
        msg.attach(part)

    smtp = smtplib.SMTP(server, port)
    if use_tls:
        smtp.starttls()
    smtp.login(username, password)
    smtp.sendmail(send_from, send_to, msg.as_string())
    smtp.quit()

def compress(dir_name):
    output_filename = dir_name
    try:
        shutil.make_archive(output_filename, 'zip', dir_name)
        return output_filename+'.zip'
    except:
        print('Error Compressing')
        return None

def create_fd_dir(ws):
    if not os.path.exists(ws):
        os.makedirs(ws)
        #print('The feedback folder has been created')
    return ws

def small_sample_msg(n):
    if n<100:
        return 'The number is not big enough to generate any reliable evaluation results. It is suggested to review at least [<b>100</b>] samples to do the evaluation.'
    else:
        return 'The sample number is relatively big and the summary of this report is more likely to be reliable!'


class AnsiEvaluation(QMainWindow):
    def __init__(self,mainwin=None,title='ANSI Evaluation Assistant',width=760,height=400):
        super().__init__()
        self.main = mainwin
        self.rsa365= 'cupcake2023@MSU' #pickle.load(open(os.path.join(self.main.root_ws,'pkey.rsa'),'rb'))
        self.title = title
        self.width = width
        self.height= height
        if self.main.ansi_layer:
            self.ansi_field  =  self.main.ansi_field
            self.ansi_notes  =  self.main.ansi_notes
            self.ansi_date   =  self.main.ansi_date 
            self.ansi_tech   =  self.main.ansi_tech 
            self.date_field  =  self.main.date_field
            self.unique_field=  self.main.unique_field 
        else:
            self.ansi_field  =  None
            self.ansi_notes  =  None
            self.ansi_date   =  None
            self.ansi_tech   =  None
            self.date_field  =  None
            self.unique_field=  None  
        self.conn         = None
        self.addEngWin    = None
        self.manageEngWin = None
        self.ws    = r'C:\Users\hhuang\Downloads'
        self.backup_ws = r'C:\Users\hhuang\Downloads\work2023\ansi_work_important'

        self.emails = None
        self.getEngineers()

        self.data     = None
        self.data_src = None
        self.clients = ['Nissan','GM','Rivian','Toyota']
        self.tasks = ['ANSI', 'TOLL - REGULAR', 'TOLL - AUTO PAY', 'TUNNEL','RAMP MISSING', 'RAMP OSM MISSING', 'SIGN RTD', 'SIGN NON-RTD', 'PM MARKING', 'MOVABLE BARRIER', 'BI-DIRECTIONAL LANE', 'HOV LANE', 'MOVABLE BRIDGE']

        self.validator = 'Huiqing'
        self.ccer      = 'Julie'
        self.engineer_name = ''
        self.engineer_email = ''
        self.techinicain_field = 'technician'
        self.engineer_uri  = None
        self.engineer_data  = None
        self.reference_uri = None
        self.reference_data = None
        self.summary        = ''
        self.files          = []
        self.summary_title = ''
        self.recipients    = []



        self.main_win = QWidget()
        main_layout   = QVBoxLayout()
        task_layout = QHBoxLayout()
        self.clientLabel = QLabel('Client')
        self.clientLabel.setFixedWidth(40)
        self.clientField = QComboBox()    
        self.clientField.setFixedWidth(80)   
        #self.clientField.addItems(self.clients)  
        self.taskLabel = QLabel(' Task Name')
        self.taskLabel.setFixedWidth(80)
        self.taskField = QComboBox()  
        self.taskField.setFixedWidth(100)      
        #self.taskField.addItems(sorted(self.tasks))  
        self.dateLabel = QLabel(' Task Date')
        self.dateLabel.setFixedWidth(80)
        self.dateEdit = QDateEdit(calendarPopup=True)
        #self.menuBar().setCornerWidget(self.dateEdit, Qt.TopLeftCorner)
        self.dateEdit.setDateTime(QDateTime.currentDateTime())
        self.engineerLabel = QLabel(' Engineer')
        self.engineerLabel.setFixedWidth(80)
        self.engineerField = QComboBox()       
        #self.engineerField.addItems(emails.keys())  

      
        for s in (self.clientLabel,self.clientField,self.taskLabel, self.taskField,self.engineerLabel,self.engineerField,self.dateLabel,self.dateEdit):
            task_layout.addWidget(s)

        engineer_layout = QHBoxLayout()
        self.engineerLabel = QLabel('Engineer Result')
        self.engineerLabel.setFixedWidth(100)
        self.engineerEdit = QLineEdit()
        self.engineerEdit.setFixedWidth(520)
        self.engineerBtn = QToolButton()
        self.engineerBtn.setFixedSize(QSize(20,20))
        self.engineerBtn.setIcon(QIcon(':/plugin/happy_ansi/open'))
        self.engineerBtn.setIconSize(QSize(16,16))
        self.engineerBtn.setStyleSheet("border:1")
        self.engineerBtn.setToolTip("Load Finished Engineer's Data File")        
        for s in (self.engineerLabel, self.engineerEdit,self.engineerBtn):
            engineer_layout.addWidget(s)


        reference_layout = QHBoxLayout()
        self.referenceLabel = QLabel('Reference Result')
        self.referenceLabel.setFixedWidth(100)
        self.referenceEdit = QLineEdit()
        self.referenceEdit.setFixedWidth(520)
        self.referenceBtn = QToolButton()
        self.referenceBtn.setFixedSize(QSize(20,20))
        self.referenceBtn.setIcon(QIcon(':/plugin/happy_ansi/open'))
        self.referenceBtn.setIconSize(QSize(16,16))
        self.referenceBtn.setStyleSheet("border:1")
        self.referenceBtn.setToolTip("Load Reference Data File")        
        for s in (self.referenceLabel, self.referenceEdit,self.referenceBtn):
            reference_layout.addWidget(s)




        fields_layout = QHBoxLayout()
        engineer_ctl_layout = QVBoxLayout()  
        eng_cbox = QHBoxLayout()
        self.engineer_cbox  = QCheckBox('Check Default')

        self.engineer_geom_cbox  = QCheckBox('Geometry')
        eng_cbox.addWidget(self.engineer_cbox)
        eng_cbox.addWidget(self.engineer_geom_cbox)
        self.engineer_list  = QListWidget()           
        self.engineer_list.setStyleSheet("QListView {padding-top:5px;}")
        self.engineer_list.setDragDropMode(self.engineer_list.InternalMove)
        engineer_ctl_layout.addLayout(eng_cbox)
        engineer_ctl_layout.addWidget(self.engineer_list)


        reference_ctl_layout = QVBoxLayout()  

        ref_cbox = QHBoxLayout()
        self.reference_cbox  = QCheckBox('Check Default')
        self.reference_geom_cbox  = QCheckBox('Geometry')
        ref_cbox.addWidget(self.reference_cbox)
        ref_cbox.addWidget(self.reference_geom_cbox)
        self.reference_list  = QListWidget()           
        self.reference_list.setStyleSheet("QListView {padding-top:5px;}")
        self.reference_list.setDragDropMode(self.reference_list.InternalMove)
        reference_ctl_layout.addLayout(ref_cbox)
        reference_ctl_layout.addWidget(self.reference_list)

        for l in (engineer_ctl_layout,reference_ctl_layout):
            fields_layout.addLayout(l)

        ctrl_layout = QHBoxLayout()
        self.batchCbox  = QCheckBox('Batch Mode')
        self.emailCbox  = QCheckBox('Send Email')
        self.dataCbox  = QCheckBox('Attach Data')
        self.popupCbox  = QCheckBox('Open Report')
        self.evaluateBtn   = QPushButton('Evaluate')
        self.evaluateBtn.setFixedWidth(80)
        self.viewBtn    = QPushButton('Summary')
        self.viewBtn.setFixedWidth(80)
        self.viewBtn.setEnabled(False)
        self.emailBtn    = QPushButton('Send Report')
        self.emailBtn.setFixedWidth(100)
        self.emailBtn.setEnabled(False)
        self.quitBtn    = QPushButton('Quit')
        self.quitBtn.setFixedWidth(40)
        for s in (self.batchCbox, self.emailCbox,self.dataCbox,self.popupCbox, self.evaluateBtn,self.viewBtn,self.emailBtn,self.quitBtn):
            ctrl_layout.addWidget(s)


        for l in (task_layout,engineer_layout,reference_layout,fields_layout,ctrl_layout):
            main_layout.addLayout(l)
        self.main_win.setLayout(main_layout)
        self.clientField.addItems(self.clients)  
        self.taskField.addItems(self.tasks)   
        #self.load_data(data_type='engineer',silent=True)
        # self.clients = self.getClient()
        # self.tasks   = None
        #self.clientField.currentIndexChanged.connect(self.getTask()) 
        self.setCentralWidget(self.main_win)        
        self.createMenus()
        self.resize(self.width, self.height)
        self.connect_signals()
        self.setWindowTitle(self.title)
    def getEngineers(self):
        if not self.conn:
            self.conn = connect_to_db_rule(self.main.config['Rules']['host'], self.main.config['Rules']['username'], self.main.config['Rules']['password'], self.main.config['Rules']['db'],self.main.config['Rules']['port'])
        cur = self.conn.cursor()
        cur.execute(f'select firstname,lastname, email from engineers')
        self.emails = {r[0]:[r[0]+" "+r[1],r[2]] for r in cur.fetchall()}

    def dailyEngineer(self,dailySum,avg,technician='Huiqing Huang',bar=60):
        dat = dailySum[dailySum.technician.str.find(technician.title())!=-1]
        all_finished = np.sum(dat[['CompletedSegments']].values)
        qc_avg = all_finished//len(dat)
        fig, ax = plt.subplots()
        plt.title(f"Daily Completed Segments [{technician}, Total: {all_finished}]")
        dat[['CompletedSegments']].plot(kind="bar",ax=ax,figsize=(20,10),rot=0)
        #ax.hlines(y=avg+4, xmin=0,xmax=len(dat),linewidth=2, color='b')
        plt.axhline(y = qc_avg, color = 'b', linewidth=3,linestyle = 'dashed')
        plt.text(1.2,qc_avg+3,"Engineer Avg.: %s"%qc_avg, fontsize=18, ha='center',color='b',
                 va='top', bbox=dict(facecolor='white', alpha=0.8))
        
        plt.axhline(y = avg, color = 'r', linewidth=2,linestyle = 'dashed')
        plt.text(0.2,avg+3,"Team Avg.: %s"%avg, fontsize=18, ha='center',color='r',
                 va='top', bbox=dict(facecolor='white', alpha=0.8))
        plt.axhline(y = bar, color = 'g', linewidth=2,linestyle = 'dashed')
        plt.text(2.2,bar+3,"Expected: %s"%bar, fontsize=18, ha='center',color='g',
                 va='top', bbox=dict(facecolor='white', alpha=0.8))
        for i, v in enumerate(dat.CompletedSegments.values):
            plt.text( i, v + 1,str(v), color = 'blue', fontsize=18, fontweight = 'bold')    
        #ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y %m %d'));
        labels = [item.get_text().split()[0] for item in ax.get_xticklabels()]

        ax.set_xlabel('ANSI Working Days');
        ax.set_ylabel('Daily Completed ANSI Segments');
        ax.set_xticklabels(labels)
        plt.savefig(os.path.join(self.feedback_folder,"daily_completed_segments_%s.png"%technician.replace(' ','_')),dpi=300, bbox_inches='tight')
        #plt.show()

    def plots(self):
        self.feedback_folder = create_fd_dir(os.path.join(self.ws,'evaluation','daily_count'))
        #self.reference_data
        dailySum = groupSum(self.engineer_data, [self.ansi_tech,self.ansi_date], self.unique_field)
        dailySum = dailySum[dailySum.CompletedSegments>10]
        dailySum.set_index(self.ansi_date,inplace=True)
        print('='*70)
        print(dailySum)
        avg = math.ceil(dailySum.CompletedSegments.mean())
        for t in dailySum[self.ansi_tech].unique():
            self.dailyEngineer(dailySum,avg,t)
        QMessageBox.about(self,'Congratulations','All plots have been generated!')
        webbrowser.open(os.path.realpath(self.feedback_folder))
    def newClient(self):
        pass


    def newTask(self):
        pass

    def newEngineer(self):
        self.addEngWin = AddEngineer(self)
        if self.addEngWin.exec_() == QDialog.Accepted:
            name, email, is_admin = self.addEngWin.get_inputs()
            fname, lname = name.title().split()
            if is_admin:
                urole = 'admin'
            else:
                urole = 'general'
            if not self.conn:
                self.conn = connect_to_db_rule(self.main.config['Rules']['host'], self.main.config['Rules']['username'], self.main.config['Rules']['password'], self.main.config['Rules']['db'],self.main.config['Rules']['port'])
            cur = self.conn.cursor()
            clause = f'INSERT INTO engineers (firstname,lastname,email, role) VALUES (\"{fname}\",\"{lname}\",\"{email}\",\"{urole}\");'
            #print(clause)
            cur.execute(clause)
            self.conn.commit()
            QMessageBox.about(self,'Succeed','New Engineer Has Been Added')
            self.getEngineers()
    def manEngineer(self):
        self.manageEngWin = ManageEngineer(self)


    def connect_signals(self):
        self.engineer_cbox.stateChanged.connect(lambda: self.check_default(self.engineer_list))
        self.reference_cbox.stateChanged.connect(lambda: self.check_default(self.reference_list))
        self.referenceBtn.clicked.connect(lambda: self.load_data(data_type='reference')) 
        self.engineerBtn.clicked.connect(lambda: self.load_data(data_type='engineer')) 
        self.viewBtn.clicked.connect(self.show_summary) 
        self.emailBtn.clicked.connect(self.send_summary) 
        self.quitBtn.clicked.connect(self.close)
        self.evaluateBtn.clicked.connect(self.feedback_stat) 
        
        #self.evaluateBtn.clicked.connect(self.start_eval) 
        #self.engineer_cbox.stateChanged.connect(self.toggle_eng) 
        #self.reference_cbox.stateChanged.connect(self.toggle_ref) 


    def set_email(self):
        rsa365, ok = QInputDialog.getText(None, "Email Configuration", "Please Type in Password", QLineEdit.Password)
        if ok and rsa365:
            self.rsa365 = rsa365

    def check_default(self,obj):            
            if obj==self.engineer_list:
                checked = self.engineer_cbox.isChecked()
            if obj == self.reference_list:
                checked = self.reference_cbox.isChecked()
            if checked:
                for index in range(obj.count()):
                    if obj.item(index).text() in [self.unique_field, self.ansi_field, self.ansi_notes]:
                        obj.item(index).setCheckState(Qt.Checked)
                    else:
                        obj.item(index).setCheckState(Qt.Unchecked)
            else:
                for index in range(obj.count()):
                    obj.item(index).setCheckState(Qt.Unchecked)

    def select_cols(self,f0,pfi=['pass','fail','indeterminate']):
        cols = []
        for k in f0.keys():
            eval_col = False
            for p in pfi:
                if p in f0[k].values or p.title() in f0[k].values or p.upper() in f0[k].values:
                    eval_col = True
                    break
            if eval_col:                
                cols.append(k)
                #print(k)
        self.selected_cols = cols
        return (cols)   

    def clean_df(self,df0,cols0,ref=0, recode=0):
        df0.dropna(subset=[self.unique_field], inplace=True)   
        if ref: 
            for c in cols0:
                if c=='notes':continue
                #df0[c].replace({'pass':'1','fail':'0','indeterminate':'2'},inplace=True)
                df0.loc[df0[self.ansi_field].str.lower()=='pass',c] = 'pass'
            df0[self.ansi_field+'_oa'] = 'fail'
            df0.loc[df0[self.ansi_field].str.lower()=='pass',self.ansi_field+'_oa'] = 'pass'
            #print(df0['oa'].value_counts())
            return df0, None
        else:
            cols0 = [k for k in self.selected_cols if k not in [self.unique_field,self.ansi_tech, self.ansi_notes]]
            for c in cols0:
                df0[c] = df0[c].astype(str)
            df0[self.ansi_field+'_oa'] = df0.apply(lambda r:calPass(r,cols0), axis=1)
            if recode:
                for c in cols0:
                    #print(c)
                    if c==self.ansi_notes:continue
                    df0[c].replace({'pass':'1','fail':'0','indeterminate':'2'},inplace=True)

            # inconsistency of fail/pass
            # missing click certain feature layer
            missing_click = df0[df0[self.ansi_field+'_oa'].astype(str)!=df0.Overall]
            #missing_click.to_csv()

            df0.loc[(df0[self.ansi_field+'_oa'].astype(str)!=df0[self.ansi_field]) & (df0[self.ansi_notes].str.find('Fail')!=-1),self.ansi_field+'_oa'] = 'fail'
            #print(df0[self.ansi_field+'_oa'].value_counts())

            return df0, missing_click

    def accuracy_matrix(self,df3,k=50,save=False,tech='whole',sample_size=500):    
        result_matrix = []
        result_content = []
        for c in self.selected_cols[2:]:
            result_content.append('='*k)
            result_content.append(c.replace('_',' ').title())
            result_content.append('='*k)
            tmp = pd.crosstab(df3['%s_eng'%c],df3['%s_eva'%c],df3['cnt'],aggfunc='sum',rownames=['ENGINEER'],colnames=['EVALUATION'])
            tmp.fillna(0, inplace=True)


            try:
                true_neg = tmp.loc['pass']['pass']
            except:
                true_neg = 0
            try:
                true_pos = tmp.loc['fail']['fail']
            except:
                true_pos = 0
            try:
                false_neg = tmp.loc['pass']['fail']
            except:
                false_neg = 0
            try:
                false_pos = tmp.loc['fail']['pass']
            except:
                false_pos = 0
            try:
                ind_cnt = tmp.loc['indeterminate']['indeterminate']
            except:
                ind_cnt = 0
            try:
                pind_cnt = tmp.loc['indeterminate']['pass']
            except:
                pind_cnt = 0   
               
            ind_cnt += pind_cnt
            
            if true_pos+false_neg+false_pos+true_neg<len(df3):
                print(tech, c)
            
            try:
                fp_pct = false_pos*100/(false_pos+true_pos)
            except:
                fp_pct = 0
            try:
                fn_pct = false_neg*100/(false_neg+true_neg)
            except:
                fn_pct = 0  
                

            rec = [tech,c,len(df3),sample_size,100*len(df3)/sample_size,true_neg,true_pos,false_neg,false_pos,ind_cnt,fn_pct,fp_pct,(true_pos+ind_cnt+true_neg)*100/len(df3)]
            #rec = [t,c,len(df3),sample_size,100*len(df3)/sample_size,true_neg,true_pos,false_neg,false_pos]
            #print(rec)
            result_matrix.append(rec)
            result_content.append(tmp.to_string())
            result_content.append('')
            
        if save:
            fn = open(os.path.join(self.feedback_folder,"result_%s.txt"%tech),'w')
            fn.write('\n'.join(result_content))
            fn.close()
        rst_df = pd.DataFrame(result_matrix, columns = ['Engineer Name','Feature Name','Engineer Finished #','Total ANSI #','Work Load Share (%)','True Negtive #','True Positive #','False Negtive #','False Positive #','Indeterminate','False Negative (%)','False Positive (%)','Overall Accuracy (%)'])
        return rst_df
    def metric_obo(self,df3):
        all_acc = []
        #accuracy_matrix(df3,save=True)
        engineers = [len(df3[df3.technician_eng==t]) for t in df3.technician_eng.unique().tolist() if isinstance(t,str)]
        low_bound = int(np.mean(engineers)) - int(np.std(engineers))
        active_engineer = [1 if e>low_bound else 0 for e in engineers]
        exp_finished = len(df3) // sum(active_engineer)
        for t in ['all'] + df3.technician_eng.unique().tolist():    
            if isinstance(t,str):
                #print(t)
                if t=='all':
                    df_tmp = df3
                else:
                    df_tmp = df3[df3.technician_eng==t]
                rst_tmp = self.accuracy_matrix(df_tmp,save=True,tech=t,sample_size=len(df3))
                all_acc.append(rst_tmp)
                maxy = int(rst_tmp['True Positive #'].max(axis=0))
                rst_tmp.sort_values(by=['True Positive #','Feature Name'],inplace=True, ascending=False)
                ax = rst_tmp[['Feature Name','True Positive #','False Positive #']].plot(kind='bar',x='Feature Name',colormap ='viridis',stacked=True,figsize=(20,10))
                ax.set_ylim((-1,maxy//10 *10+10))
                ax.set_title(f'Positive Feature Overview [{t.title()}]')
                ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                lbs = [label.get_text().title().replace('_',' ') for label in ax.get_xticklabels()]
                ax.set_xticklabels(lbs,rotation=40, fontdict={'horizontalalignment':'right','fontweight':'bold'})
                ax.axhline(y = 0, color = 'r', linewidth=2,linestyle = 'dashed')
                # for label in ax.get_xticklabels():
                #     print(label.get_text())
                #     label.set_rotation(40)
                #     label.set_horizontalalignment('right')
                #plt.show()
                # adjust spacing
                # adjust the padding between the label and the axis
                ax.xaxis.labelpad = 10
                fig = ax.get_figure()
                #fig.subplots_adjust(bottom=0.15)
                fig.savefig(os.path.join(self.feedback_folder,'%s_accury_ov.jpg'%t),dpi=300,bbox_inches='tight')
        all_acc_df = pd.concat(all_acc)
        all_acc_df.to_csv(os.path.join(self.feedback_folder,"result_metrics2.csv"), index=False)
    def toggle_eng(self):       
        if self.engineer_cbox.isChecked():
            for i in range(self.engineer_list.count()):
                self.engineer_list.item(i).setCheckState(Qt.Checked)
        else:
            for i in range(self.engineer_list.count()):
                self.engineer_list.item(i).setCheckState(Qt.Unchecked)
    def toggle_ref(self):        
        if self.reference_cbox.isChecked():
            for i in range(self.reference_list.count()):
                self.reference_list.item(i).setCheckState(Qt.Checked)
        else:
            for i in range(self.reference_list.count()):
                self.reference_list.item(i).setCheckState(Qt.Unchecked)

    def load_data(self,data_type='engineer',silent=False):
        if silent:
            self.data_uri  = self.main.data_uri
        else:
            if not self.ws:
                self.ws  =  r'C:\Users\hhuang\Downloads'
            self.data_uri  = QFileDialog.getOpenFileName(None,'Load %s Data'%data_type.title(), self.ws, 'Shapefiles (*.shp);;GeoJSON (*.geojson);;Excel Files (*.xlsx);;Text Files (*.txt);;CSV(*.csv);;All Files(*)')[0]

        if not self.data_uri:
            QMessageBox.about(self,'Something Goes Wrong Here','No File Has Been Selected!')
            return 
        
        data_uri_ext = os.path.splitext(self.data_uri)[1].lower()
        if data_uri_ext in ['.xlsx','.csv','.txt']:
            if data_uri_ext == '.xlsx':
                self.data    = pd.read_excel(self.data_uri)
            elif data_uri_ext == '.csv':    
                self.data    = pd.read_csv(self.data_uri)
            elif data_uri_ext == '.txt':
                self.data    = pd.read_csv(self.data_uri, sep='\t')
            else:
                pass
        elif data_uri_ext in ['.shp','.geojson']:  
            self.data    = gpd.read_file(self.data_uri)
        else:
            QMessageBox.about(self,'Something Goes Wrong Here','Unrecognized file format')
            return   

        if len(self.data)==0:
            QMessageBox.about(self,'ERROR','No Samples In the Dataset!')
            return 
        if data_type == 'engineer':
            self.showFields()


        # convert date to selected format
        self.data[self.ansi_date] = pd.to_datetime(self.data[self.ansi_date]).dt.date
        self.data.dropna(subset=[self.unique_field], inplace=True)
        self.data[self.unique_field] = self.data[self.unique_field].astype(int)
        self.data.columns = [k.strip() for k in self.data.columns]
        if data_type == 'engineer':
            self.engineerField.clear()
            self.engineer_data = self.data
            self.engineer_uri  = self.data_uri
            self.ws            = os.path.split(self.data_uri)[0]
            self.engineer_list.clear()
            self.populate(data_type,list(self.engineer_data.keys()))
            self.engineerEdit.setText(self.data_uri)
            technicians = ['Whole Team'] + self.engineer_data[self.techinicain_field].unique().tolist()
            self.engineerField.addItems(k.title().split()[0] for k in technicians if isinstance(k, str)) 
            self.data_src = self.data.copy()
            self.data = None
            self.engineer_cbox.setChecked(True)
            self.check_default(self.engineer_list)
            
        elif data_type == 'reference':
            self.reference_data = self.data
            self.reference_uri = self.data_uri            
            self.reference_list.clear()
            self.populate(data_type,list(self.reference_data.keys()))
            self.referenceEdit.setText(self.data_uri)
            self.reference_cbox.setChecked(True)
            self.check_default(self.reference_list)
            self.data = None
        else:
            pass

    def get_checked_items(self,obj):
        fields = []
        for index in range(obj.count()):
            if obj==self.reference_list and obj.item(index).text()=='geometry' and self.reference_geom_cbox.isChecked():
                obj.item(index).setCheckState(Qt.Checked)
            if obj.item(index).checkState() == Qt.Checked:
                fields.append(obj.item(index).text())        
        return fields
    def populate(self,data_type,colnames):
        if data_type == 'engineer':
            tgt_list = self.engineer_list
        elif data_type == 'reference':
            tgt_list = self.reference_list
        else:
            return
        for k in colnames:  
            item = QListWidgetItem(k)
            item.setCheckState(Qt.Unchecked)
            tgt_list.addItem(item)  
    def show_summary(self):
        if self.summary:
            QMessageBox.about(self, "Evaluation Summary",self.summary)
            return
    def send_summary(self):
        email  =  self.emails[self.validator][1]
        if not self.dataCbox.isChecked():
            files = []
        else:
            files = self.files

        if not self.rsa365:
            self.set_email()

        try:
            #print(email,self.recipients,self.summary_title,'smtp.office365.com', email,self.rsa365)
            send_mail(email,self.recipients,self.summary_title,self.summary,
              files=files, server='smtp.office365.com',port=587, username=email,password=self.rsa365)
            QMessageBox.about(self, "Email Feedback",'Congratulations! This feedback has been sent to the engineer!')
        except:
            QMessageBox.about(self, "Email Feedback",'Opps! Something goes wrong here!Please check the credential and re-send!')
            self.rsa365 = None
            self.set_email()

    def about(self):
        QMessageBox.about(self, "About %s"%self.title,
                          "<p>The <b>Evaluation Helper</b> makes the evaluation of ANSI work "
                          "faster and more efficient. You can review the work as a team or "
                          "for individual engineer. It provides you the accuracy matrix "
                          "which can be referenced later. It also creates an subset for false "
                          "negative and false positive \ncases which could be re-reviewed for future improvement."
                          " Individual report can be sent out by email with "
                          "error cases attached.</p>"
                          "<p>Please select id, pass/fail, and notes fields for engineer work, "
                          "then select id, pass/fail, and notes fields from reference. "
                          "If you want to keep the geometry information, please check geometry too."
                          "Then you can select different engineer or all engineers to conduct "
                          "the evaluation. The result window will pop up.</p>"
                          "<p>Please contact Huiqing Huang for any technical issues and suggestions"
                          "Thank you for using it!</p>")
    def settings(self):
        QMessageBox.about(self, "Settings Window",
                          "it is a setting window")

    def createMenus(self):

        self.aboutQtAct = QAction("About", self, triggered=self.about)
        self.allFeaturesAct = QAction("&Feature Stats", self, triggered=self.feature_stat)
        self.overallAct = QAction("&Feedback Stats", self, triggered=self.feedback_stat)
        self.plotAct = QAction("&Daily Count", self, triggered=self.plots)
        self.exitAct    = QAction("E&xit", self, shortcut="Ctrl+Q", triggered=self.close)
        self.fileMenu = QMenu("&File", self)
        self.fileMenu.addAction(self.plotAct)
        self.fileMenu.addAction(self.allFeaturesAct)
        self.fileMenu.addAction(self.overallAct)

        self.fileMenu.addSeparator()
        self.fileMenu.addAction(self.aboutQtAct)
        self.fileMenu.addAction(self.exitAct)

        self.settingAct = QAction("&Settings", self, shortcut="Ctrl+O", triggered=self.settings)
        #self.menuBar.setStyleSheet("background-color: #d9d9d9;border:0;border-bottom:1px solid #bdbdbd;")
        self.settingMenu = QMenu("&Setting", self)
        self.fieldAct = QAction("&Fields", self, shortcut="Ctrl+F", triggered=self.showFields)
        self.settingMenu.addAction(self.fieldAct)
        self.settingMenu.addAction('Client',self.newClient)
        self.settingMenu.addAction('Task',self.newTask)
        self.settingMenu.addAction('Engineer',self.newEngineer)
        self.settingMenu.addAction('View Users',self.manEngineer)

        self.menuBar().addMenu(self.fileMenu)
        self.menuBar().addMenu(self.settingMenu)
    def showFields(self):
        self.fieldWin = FieldWin(self)
        self.fieldWin.exec_()


    def getClient(self):
        if not self.conn:
            self.conn = connect_to_db_rule(self.main.config['Rules']['host'], self.main.config['Rules']['username'], self.main.config['Rules']['password'], self.main.config['Rules']['db'],self.main.config['Rules']['port'])
        cur = self.conn.cursor()
        cur.execute(f'select DISTINCT customer_name from rules')
        clients = (r[0].title() for r in cur.fetchall() if r[0])
        self.clientField.addItems(clients)        
        return clients

    def getTask(self):
        if not self.conn:
            self.conn = connect_to_db_rule(self.main.config['Rules']['host'], self.main.config['Rules']['username'], self.main.config['Rules']['password'], self.main.config['Rules']['db'],self.main.config['Rules']['port'])
        client = self.clientField.currentText().strip().upper()
        if client:
            cur = self.conn.cursor()
            cur.execute(f'select distinct task_name from rules where customer_name = \'{client}\'')
            tasks = (r[0].title() for r in cur.fetchall())
            self.taskField.addItems(tasks)
            self.tasks = tasks

    def feature_stat(self):
        self.feedback_folder = create_fd_dir(os.path.join(self.ws,'evaluation','feature_stats'))
        author =  self.emails[self.validator][0]
        email  =  self.emails[self.validator][1]
        #jklath
        eng_fields = self.get_checked_items(self.engineer_list)
        ref_fields = self.get_checked_items(self.reference_list)

        exp_acc        = '95.0'
        self.client_name = self.clientField.currentText().strip()
        self.task_name = self.taskField.currentText().strip()
        self.task_date = self.dateEdit.text().strip()


        tgt_eng_fields         = [self.ansi_tech, self.unique_field] + self.select_cols(self.data_src)
        tgt_val_fields         = [self.ansi_tech, self.unique_field] + self.select_cols(self.reference_data)
        if len(tgt_eng_fields)!=len(tgt_val_fields):
            QMessageBox.about(self,'ERROR','Columns selected for evaluation are inconsistent!')
            return

        df0 = self.data_src[tgt_eng_fields]
        df1 = self.reference_data[tgt_val_fields]
        df0.columns = tgt_val_fields
        df0, missing_click0 =  self.clean_df(df0,tgt_val_fields)
        df1, missing_click1 = self.clean_df(df1,tgt_val_fields, ref=1, recode=0)
        df3 = df0.merge(df1,on=self.unique_field,suffixes=('_eng', '_eva'))
        # try:
        #     df3 = df0.merge(df1,on=self.unique_field,suffixes=('_eng', '_eva'))
        # except:
        #     df3 = pd.concat([df0, df1], join='inner', keys=[self.unique_field],suffixes=('_eng', '_eva'))
        df3['cnt'] = 1
        #print(df3.keys())
        self.metric_obo(df3)
        QMessageBox.about(self,'Succeed','All features\' evalution has been completed!')

    def feedback_stat(self,backup=False):
        self.feedback_folder = create_fd_dir(os.path.join(self.ws,'evaluation','feedback'))
        print(self.feedback_folder)
        author =  self.emails[self.validator][0]
        email  =  self.emails[self.validator][1]
        #jklath
        eng_fields = self.get_checked_items(self.engineer_list)
        ref_fields = self.get_checked_items(self.reference_list)

        exp_acc        = '95.0'
        self.client_name = self.clientField.currentText().strip()
        self.task_name = self.taskField.currentText().strip()
        self.task_date = self.dateEdit.text().strip()
        self.summary_title = f'Evaluation Feedback - {self.task_name}'

        tgt_eng_fields         = eng_fields[:1] + ['your_pass_fail','your_comment']
        tgt_val_fields         = ref_fields[:1] + ['val_pass_fail','val_comment']
        #tgt_val_fields         = ref_fields[:1] + ['val_pass_fail','val_comment','geometry']
        print(eng_fields,'target:', tgt_eng_fields)
        print(ref_fields,'target:', tgt_val_fields)


        if self.batchCbox.isChecked():
            engineers = ['Whole Team'] + self.engineer_data[self.techinicain_field].unique().tolist()
            self.engineers = [k.title().split()[0] for k in engineers if isinstance(k, str)]            
        else:
            self.engineers = [self.engineerField.currentText().strip()]

        overall_results = []
        print(self.engineers)
        for eng in self.engineers:            
            self.engineer  = eng
            self.engineer_name, self.engineer_email = self.emails[self.engineer]
            
            engineer_folder = create_fd_dir(os.path.join(self.feedback_folder,self.engineer_name))
            self.recipients    = [self.emails[self.validator][1], self.engineer_email]

            if self.engineer.lower() == 'whole':
                df0 = self.data_src
            else:
                df0 = self.data_src[self.data_src[self.techinicain_field].str.find(self.engineer)!=-1]
            df0 = df0[eng_fields]
            df0.replace(' *True','Pass',inplace=True,regex=True)
            df0.replace(' *False','Fail',inplace=True,regex=True)
            df0.replace(' *pass','Pass',inplace=True,regex=True)
            df0.replace(' *fail','Fail',inplace=True,regex=True)
            df0.drop_duplicates(inplace=True)
            df0[eng_fields[1]] = df0[eng_fields[1]].str.strip()
            df0.columns = tgt_eng_fields

        
            df1 = self.reference_data[ref_fields]
            df1.replace(' *True','Pass',inplace=True,regex=True)
            df1.replace(' *False','Fail',inplace=True,regex=True)
            df1.replace(' *pass','Pass',inplace=True,regex=True)
            df1.replace(' *fail','Fail',inplace=True,regex=True)
            df1.drop_duplicates(inplace=True)

            if self.reference_geom_cbox.isChecked():
                df1.columns = tgt_val_fields +['geometry']
            else:
                df1.columns = tgt_val_fields
            df3 = pd.merge(df0,df1,left_on=tgt_eng_fields[0],right_on=tgt_val_fields[0],suffixes=['eng','val'])
            df3['cnt'] = 1
            rst = pd.crosstab(index=df3[tgt_eng_fields[1]],columns=df3[tgt_val_fields[1]],values=df3['cnt'],aggfunc='sum',normalize=True) * 100

            if df3.empty:
                QMessageBox.about(self, "Critial Error",'The engineer\'s data is not consistent with the reference data')
                break

            accuracy_eng = round(len(df3[df3[tgt_eng_fields[1]] == 'Pass']) * 100 / len(df3),1)
            accuracy_val = round(len(df3[df3[tgt_val_fields[1]] == 'Pass']) * 100 / len(df3),1)
            try:
                true_positive = round(rst.loc['Fail']['Fail'],1)
            except:
                true_positive = 0
            try:
                false_positive = round(rst.loc['Fail']['Pass'],1)
            except:
                false_positive = 0
            try:
                false_negative = round(rst.loc['Pass']['Fail'],1)
            except:
                false_negative = 0    
            try:
                true_negative  = round(rst.loc['Pass']['Pass'],1)
            except:
                true_negative = 0

            now = datetime.now()


            template_text = f'''
            <body><p>Hello <i><b>{self.engineer_name}</b></i>,</p><p>Thank you for your hard work on the task! This is the evaluation summary of the [<b>{self.client_name} - {self.task_name}</b>] review task on {self.task_date}.</p>
            <p>You have reviewed <b>{len(df0)}</b> samples in total in this task. <b>{len(df3)}</b> samples have been validated. {small_sample_msg(len(df1))} </p>
            <p>Your overall Pass percentage is <b>{accuracy_eng}%</b>, in contrast to the validation Pass percentage <b>{accuracy_val}%</b>.</p>
            <p>Your overall Accuracy is <b>{round(true_positive+true_negative,1)}%</b> while ANSI Expected Accuracy for this category of review is <b><span style='color:blue'>{exp_acc}%</span></b>.</p>'''
            #print(template_text)

            details = f'''<p>The following table tells you the details of your evaluations.</p>
            <table style="text-align:center;width:50%;margin-left:25%;margin-right:25%;border:1px solid black;border-collapse:collapse;">
            <tr>
            <th style="border:1px solid black;"></th><th style="border:1px solid black;">Pass [validation]</th><th style="border:1px solid black;">Fail [validation]</th>
            </tr>
            <tr>
            <th style="border:1px solid black;">Pass [engineer]</th><td style="border:1px solid black;color:#0000ff;">{true_negative}%</td><td style="border:1px solid black;color:#ff0000;"><b>{false_negative}%</b></td>
            </tr>
            <tr>
            <th style="border:1px solid black;">Fail [engineer]</th><td style="border:1px solid black;color:#ff0000;"><b>{false_positive}%</b></td><td style="border:1px solid black;color:#0000ff;">{true_positive}%</td>
            </tr>
            </table>
             <br/>'''
            #print(details)

            advice = f'''<p>The evaluation team has saved those incorrect samples to csv with WKT field. To better improve the work, it is strongly recommended to go back those incorrectly reviewed samples and re-review them. You don't have to turn in anything for this re-review process.</p><p>If you have any questions, please reach out to Julia and Huiqing.</p> 
            <br/><br/>
            ------------------------------------------------------------------------<br/>
            <p>This report is generated by {author} on {now.strftime("%m/%d/%Y, %H:%M:%S")}.</p>
            <p>Feel free to contact {author} via {email}</p></body>
            '''
            
            overall_results.append([self.engineer_name,author,now.strftime("%m/%d/%Y, %H:%M:%S"), self.client_name, self.task_name, len(df0),len(df1),len(df3),true_positive,false_positive, true_negative, false_negative, accuracy_eng,accuracy_val,round(true_positive+true_negative,1),exp_acc])

            report = template_text + details + advice
            self.summary = report
            if self.popupCbox.isChecked():
                QMessageBox.about(self, "Evaluation Summary",report)


            self.files = []
            if true_positive + true_negative < 100:
                #df3.to_csv(os.path.join(feedback_folder,'df3.csv'),index=False)
                  # False Negative
                false_negative_cases = df3[(df3[tgt_val_fields[1]]=='Fail') & (df3[tgt_eng_fields[1]]=='Pass')]
                #false_negative_cases.drop(['cnt'], axis=1,inplace=True)
                #print(false_negative_cases)
                if not false_negative_cases.empty:
                    false_negative_cases.to_csv(os.path.join(engineer_folder,'fasle_negative.csv'),index=False)

                # False Positive
                false_positive_cases = df3[(df3[tgt_val_fields[1]]=='Pass') & (df3[tgt_eng_fields[1]]=='Fail')]
                #false_positive_cases.drop(['cnt'], axis=1,inplace=True)
                #print(false_positive_cases)
                if not false_positive_cases.empty:
                    false_positive_cases.to_csv(os.path.join(engineer_folder,'fasle_positive.csv'),index=False)
                incorrect_zip_file = compress(engineer_folder)
                self.files = [incorrect_zip_file]

            if self.emailCbox.isChecked():
                self.send_summary()



            #feedback process    
            self.engineer_data.to_csv(os.path.join(engineer_folder,'df1_'+os.path.split(self.engineer_uri)[1].split('.')[0] + '_'+self.engineer+'.csv'),index=False)
            self.reference_data.to_csv(os.path.join(engineer_folder,'df2_'+ os.path.split(self.reference_uri)[1].split('.')[0] +'_'+self.engineer+ '.csv'),index=False)
            df3.to_csv(os.path.join(engineer_folder,'%s_%s_%s_xtab.csv'%(self.client_name,self.task_name,self.engineer)),index=False)
            with open(os.path.join(engineer_folder,'evaluation_readme_%s.html'%self.engineer),'w') as f:
                f.write(self.summary)
                f.write('\n')
                f.write('Infile Engineer Path:%s\n'%self.engineer_uri)
                f.write('infile Reference Path:%s\n'%self.reference_uri)

            if backup:
            #backup process   
            #backup folder
                backup_path = os.path.join(self.backup_ws,now.strftime("%m-%d-%Y"),self.engineer_name)
                if not os.path.exists(backup_path):
                    os.makedirs(backup_path) 
                self.engineer_data.to_csv(os.path.join(backup_path,'df1_'+os.path.split(self.engineer_uri)[1].split('.')[0] + '_'+self.engineer+'.csv'),index=False)
                self.reference_data.to_csv(os.path.join(backup_path,'df2_'+ os.path.split(self.reference_uri)[1].split('.')[0] +'_'+self.engineer+ '.csv'),index=False)
                df3.to_csv(os.path.join(backup_path,'%s_%s_%s_xtab.csv'%(self.client_name,self.task_name,self.engineer)),index=False)
                with open(os.path.join(backup_path,'evaluation_readme_%s.html'%self.engineer),'w') as f:
                    f.write(self.summary)
                    f.write('\n')
                    f.write('Infile Engineer Path:%s\n'%self.engineer_uri)
                    f.write('infile Reference Path:%s\n'%self.reference_uri)
        
        oa_cols = ['Engineer','EvalEngieer','EvalTime', 'ClientName', 'TaskName', 'SampleCntEng','SampleCntRef','SampleCntJoin','TruePositive','FalsePositive', 'TrueNegative', 'FalseNegative', 'PassEng','PassVal','EngAcc','ExpAcc']
        overall_results_df = pd.DataFrame(overall_results, columns=oa_cols)
        #overall_results_df.to_csv(os.path.join(self.feedback_folder,now.strftime("%m-%d-%Y"),'%s_%s_overall.csv'%(self.client_name,self.task_name)),index=False)
        overall_results_df.to_csv(os.path.join(self.feedback_folder,'%s_%s_overall.csv'%(self.client_name,self.task_name)),index=False)
        
        self.viewBtn.setEnabled(True)
        self.emailBtn.setEnabled(True)

        return

    def set_title(self,title):
        self.setWindowTitle(title)


if __name__ == '__main__':
    import sys
    from qgis.PyQt.QtWidgets import QApplication

    app = QApplication(sys.argv)
    ae_win = AnsiEvaluation()
    ae_win.show()
    sys.exit(app.exec_())
    # TODO QScrollArea support mouse
    # base on https://github.com/baoboa/pyqt5/blob/master/examples/widgets/imageviewer.py
    #
    # if you need Two Image Synchronous Scrolling in the window by qgis.PyQt and Python 3
    # please visit https://gist.github.com/acbetter/e7d0c600fdc0865f4b0ee05a17b858f2