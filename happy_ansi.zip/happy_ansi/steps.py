from PyQt5 import QtCore
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QFont, QColor, QIcon, QKeySequence, QBrush, QPixmap
from PyQt5.QtWidgets import *
from qgis.core import *
import geopandas as gpd
import pandas as pd
import os
from .ansi_win import load_xyz
from .map_data.utils import *
from .render import *
from datetime import datetime
import pytz
from shapely.wkt import loads
from .map_data.db_conn import *

def s2t(row,date_field):
    if row[date_field]:      
        #print(row[date_field]) 
        s = datetime.strptime(row[date_field]+'00', "%Y-%m-%d %H:%M:%S.%f%z")   
        return s.date().strftime("%Y-%m-%d"), s.hour
    return None, None

steps = {
    'pipeline_mode':False,
    'database':'RFDB',
    'required_layers':['rfdb_wu', 'rfdb_road_segment','rfdb_path','rfdb_delin',  'rfdb_crossing', 'rfdb_sign'],
    'steps':[
            ['step1','self.step1'],
            ['step2','self.step2'],
            ['step3','self.step3'],
            ['step4','self.step4'],
            ['step5','self.step5'],
            ['step6','self.step6'],
    ]
}


tolls = {
    'pipeline_mode':False,
    'database':'RFDB',
    'required_layers':['rfdb_road_segment','rfdb_path', 'rfdb_crossing', 'rfdb_sign'],
    'steps':[
            ['step1','self.step1'],
            ['step2','self.step2'],
            ['step3','self.step3'],
            ['step4','self.step4'],
            ['step5','self.step5'],
            ['step6','self.step6'],
    ]
}

class Welcome(QWidget):

    def __init__(self,main=None):
        super().__init__()
        self.main = main
        self.initUI()


    def initUI(self):
        qmsg = QLabel('Please Select the Task in the Menu.')
        # qbtn = QPushButton('Quit', self)
        # qbtn.clicked.connect(QApplication.instance().quit)
        # qbtn.resize(qbtn.sizeHint())
        # qbtn.move(50, 50)

        # self.setGeometry(300, 300, 350, 250)
        # self.setWindowTitle('Quit button')
        # self.show()
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)

class GMTollStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.client_list.count()):
            item = self.main.client_db_win.client_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):        
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['gm_crossing','gm_lane_speed_limit','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        set_ansi_style(self.main.layers['gm_lane_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['gm_lane_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.canvas.zoomScale(1000)
        self.main.canvas.refresh()
    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['gm_lane','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['gm_lane'],fn='type',size=12, c='red',fontsize=12,bg='white',clause=None,minimumScale=50000,maximumScale=50) 
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(2000)
        self.main.canvas.refresh()
    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['gm_lane_speed_limit','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        set_ansi_style(self.main.layers['gm_lane_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['gm_lane_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.layers['gm_lane_speed_limit'].triggerRepaint()
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(500)
        self.main.canvas.refresh()
        self.main.open_gsv_page()









class RFDBTollStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.rfdb_list.count()):
            item = self.main.client_db_win.rfdb_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):        
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_road_segment','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        show_label(self.main.layers['rfdb_road_segment'],fn='road_type',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.canvas.zoomScale(1000)
        self.main.canvas.refresh()
    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_path_type','rfdb_path','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(500)
        self.main.canvas.refresh()
    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_crossing','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['rfdb_crossing'],fn='crossing_type',size=12, c='red',fontsize=12,bg='white',clause=None,minimumScale=50000,maximumScale=50) 
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(2000)
        self.main.canvas.refresh()
        self.main.open_gsv_page()









class NissanMovBarrierStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.client_list.count()):
            item = self.main.client_db_win.client_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout  = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):        
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_edge','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        set_ansi_style(self.main.layers['udbx_edge'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['udbx_edge'],fn='road_edge_type',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=5000,maximumScale=50) 
        self.main.canvas.zoomScale(1000)
        self.main.canvas.refresh()



class JPIntersectionStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers['RFDB'][lyr] for lyr in steps['required_layers']}
        self.main.update_layers()  
        if not self.main.ansi_layer:
            self.main.ansi_layer = self.main.layers['JPN_Intersection_800_Sample_Review']

        for i in range(self.main.client_db_win.rfdb_list.count()):
            item = self.main.client_db_win.rfdb_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_road_segment','rfdb_osm_way','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['rfdb_road_segment'],fn='wu_project',size=12, c='red',fontsize=12,bg='white',clause=None,minimumScale=0,maximumScale=0) 
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(2000)
        self.main.canvas.refresh()

    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_wu','rfdb_intersection','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['rfdb_wu'],fn='wu_id',size=16,position=-1,scaleVisibility = False, c='yellow',fontsize=18,bg='blue',clause=None,minimumScale=0,maximumScale=20000) 
        #display_label(self.main.layers['rfdb_wu'],'"wu_id"',scaleVisibility = True, min_scale=0, max_scale=0)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(2000)
        self.main.canvas.refresh()

    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_crossing','rfdb_crossing_path','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        #set_ansi_style(self.main.layers['rfdb_crossing'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['rfdb_crossing'],fn='crossing_type',position=4, scaleVisibility = False,size=16, c='blue',fontsize=18,bg='white',clause=None,minimumScale=0,maximumScale=20000) 

        #display_label(self.main.layers['rfdb_crossing'],'"crossing_type"',scaleVisibility = True, min_scale=0, max_scale=0)

        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(500)
        self.main.canvas.refresh()
        self.main.open_gsv_page()

    def step4(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['rfdb_sign','rfdb_sign_path_association','rfdb_road_object_polygon','rfdb_road_object_path_association','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        set_ansi_style(self.main.layers['rfdb_sign'],'supertype', colors=['#ff0000','#0000ff'],values=['Right of Way',None], width = '1', style='no') 
       #set_ansi_style(self.main.layers['rfdb_intersection'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['rfdb_sign'],fn='supertype',scaleVisibility = False,position=4, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=0,maximumScale=20000) 
        #display_label(self.main.layers['rfdb_sign'],'"supertype"',scaleVisibility = True, min_scale=0, max_scale=0)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(500)
        self.main.canvas.refresh()


class NissanTollStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.client_list.count()):
            item = self.main.client_db_win.client_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):        
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_lane_att_crossing_type','udbx_functional_authority','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        #set_ansi_style(self.main.layers['udbx_lane_att_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        #show_label(self.main.layers['udbx_lane_att_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.canvas.zoomScale(1000)
        self.main.canvas.refresh()
    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_lane','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['udbx_lane'],fn='lane_type',size=12, c='red',fontsize=12,bg='white',clause=None,minimumScale=50000,maximumScale=50) 
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(2000)
        self.main.canvas.refresh()
    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_lane_att_speed_limit','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        set_ansi_style(self.main.layers['udbx_lane_att_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['udbx_lane_att_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.layers['udbx_lane_att_speed_limit'].triggerRepaint()
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(500)
        self.main.canvas.refresh()
        if self.main.auto_gsv.isChecked():
            self.open_gsv_page()


class NissanBidirectionStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.client_list.count()):
            item = self.main.client_db_win.client_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):        
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_lane_att_crossing_type','udbx_lane_att_speed_limit','udbx_functional_authority','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        set_ansi_style(self.main.layers['udbx_lane_att_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['udbx_lane_att_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.canvas.zoomScale(1000)
        self.main.canvas.refresh()
    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_lane','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['udbx_lane'],fn='lane_type',size=12, c='red',fontsize=12,bg='white',clause=None,minimumScale=50000,maximumScale=50) 
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(2000)
        self.main.canvas.refresh()
    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_lane_att_speed_limit','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        set_ansi_style(self.main.layers['udbx_lane_att_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['udbx_lane_att_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        self.main.layers['udbx_lane_att_speed_limit'].triggerRepaint()
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(500)
        self.main.canvas.refresh()
        self.main.open_gsv_page()



class NissanAnsiStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main    = main
        self.current = None
        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.client_list.count()):
            item = self.main.client_db_win.client_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        vl.addLayout(layout)
        self.setLayout(vl)
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)

    def step1(self):        
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_sign','udbx_road_segment','udbx_lane_att_speed_limit','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        show_label(self.main.layers['udbx_road_segment'],fn='road_type',size=10, c='red',fontsize=12,bg='white',clause=None,minimumScale=5000,maximumScale=50) 
        set_ansi_style(self.main.layers['udbx_lane_att_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['udbx_lane_att_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 

        self.main.canvas.zoomScale(1500)
        self.main.canvas.refresh()

    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_sign','udbx_lane_att_speed_limit','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        rules = (('Maximum Speed Limit', "type like 'Maximum Speed Limit %'", 'solid', 'red', 1), ('Other Signs', "type not like 'Maximum Speed Limit %'", 'solid', 'orange', 1))
        self.main.layers['udbx_sign'] = apply_rule_based_symbol(rules, self.main.layers['udbx_sign'])
        set_ansi_style(self.main.layers['udbx_lane_att_speed_limit'],'segment_id', colors=['#00ff00','#0000ff'],values=[self.current,None], width = '1', style='no')
        show_label(self.main.layers['udbx_lane_att_speed_limit'],fn='speed_limit',position=2, size=14, c='blue',fontsize=14,bg='white',clause=None,minimumScale=10000,maximumScale=50) 
        lyr = self.main.layers['udbx_sign']
        #lyr.setSubsetString("type like 'Maximum Speed Limit %'")
        #show_label(lyr,fn='type',size=18, c='red',fontsize=18,bg='white',clause=None,minimumScale=100000,maximumScale=50)   
        show_label(lyr,size=18, c='red',fontsize=18,bg='white',minimumScale=100000,maximumScale=50,clause='''replace("type",'Maximum Speed Limit','')''')
        # #Configure label settings
        # settings = QgsPalLayerSettings()
        # settings.fieldName = 'speed_limit'
        # textFormat = QgsTextFormat()
        # textFormat.setSize(10)
        # settings.setFormat(textFormat)
        # #create and append a new rule
        # root = QgsRuleBasedLabeling.Rule(QgsPalLayerSettings())
        # rule = QgsRuleBasedLabeling.Rule(settings)
        # rule.setDescription('speed_limit')
        # rule.setFilterExpression("segment_id=%s"%self.current)
        # root.appendChild(rule)
        # #Apply label configuration
        # rules = QgsRuleBasedLabeling(root)
        # self.main.layers['udbx_lane_att_speed_limit'].setLabeling(rules)
        # self.main.layers['udbx_lane_att_speed_limit'].triggerRepaint()


        self.main.layers['udbx_lane_att_speed_limit'].triggerRepaint()
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(15000)
        self.main.canvas.refresh()

    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['udbx_sign','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        show_label(self.main.layers['udbx_sign'],fn='type',size=12, c='red',fontsize=12,bg='white',clause=None,minimumScale=50000,maximumScale=50) 
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.open_gsv_page()

class AnsiStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main = main
        
        for i in range(self.main.client_db_win.rfdb_list.count()):
            item = self.main.client_db_win.rfdb_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        # for a in range(10):
        #     button = QPushButton(str(a))
        #     button.clicked.connect(lambda checked, a=a, obj=button: self.button_clicked(obj,a))
        #     layout.addWidget(button)

        vl.addLayout(layout)
        self.setLayout(vl)

    # def button_clicked(self,obj, n):
    #     print('button %s: Text(%s)'%(n,obj.text())) 
        # if self.main.ansi_ongoing:
        #     self.main.fetch_data()
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        sids = [f[self.main.unique_field] for f in self.main.ansi_layer.selectedFeatures()]
        self.current =str(sids[0])
        print('[steps] sids:',sids)
    def step1(self):        
        for k, v in self.main.qgs_project_instance.mapLayers().items():
            if k.startswith('Google_Satellite') or v.name()=='rfdb_road_segment':
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(True)
            else:
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(False)

    def step2(self):
        for k, v in self.main.qgs_project_instance.mapLayers().items():
            if k.startswith('Google_Satellite') or v.name()=='rfdb_delin':
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(True)
            else:
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(False)

        lyr = self.main.get_layer_by_name('rfdb_delin')[0]
        show_label(lyr,fn='type',size=10, c='red',fontsize=12,bg='white',clause=None,minimumScale=5000,maximumScale=50)        
        if self.pipeline_mode:
            self.step3()
    def step3(self):
        print('step3')
        if self.pipeline_mode:
            self.step4()
    def step4(self):
        print('step4')
        if self.pipeline_mode:
            self.step5()
    def step5(self):
        print('step5')
        if self.pipeline_mode:
            self.step6()
    def step6(self):
        print('step6')
        print('finished')  

steps = {
    'pipeline_mode':False,
    'database':'RFDB',
    'required_layers':['rfdb_crossing', 'rfdb_sign'],
    'steps':[
            ['1.BD','self.step1'],
            ['2.RU','self.step2'],
            ['3.DL','self.step3'],
            ['4.PA','self.step4'],
            ['5.SP','self.step5'],
            ['6.RO','self.step6'],
    ]
}

class RFDBAnsiStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main = main

        if not self.main.layers:
            self.main.update_layers()

        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.rfdb_list.count()):
            item = self.main.client_db_win.rfdb_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        # for a in range(10):
        #     button = QPushButton(str(a))
        #     button.clicked.connect(lambda checked, a=a, obj=button: self.button_clicked(obj,a))
        #     layout.addWidget(button)

        vl.addLayout(layout)
        self.setLayout(vl)

    # def button_clicked(self,obj, n):
    #     print('button %s: Text(%s)'%(n,obj.text())) 
        # if self.main.ansi_ongoing:
        #     self.main.fetch_data()
    def step0(self):
        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)

    def step1(self):   
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['Boundary Points','Boundary Planes','Work Units']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        vname ='2D LiDAR'
        group = self.main.qgs_project_instance.layerTreeRoot().findGroup(vname)
        if group:
            for lyr in group.findLayers():
                self.main.qgs_project_instance.layerTreeRoot().findLayer(lyr.layer().id()).setItemVisibilityChecked(True)   
            group.setItemVisibilityChecked(True)

        self.main.ansi_layer.setOpacity(0.5)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])

    def step2(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['Road Unit Segment','Google Satellite'] + [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.ansi_layer.setOpacity(0.5)
        lyr = self.main.layers[lyrs[0]]
        #lyr.setSubsetString('segment_id=3439288')
        clause = ''' "segment_id"  ||  '\nname:'  ||  "road_name"  ||  '\ntype:'  || "road_type"'''
        show_label(lyr,size=12, c='red',fontsize=10,bg='white',clause=clause,minimumScale=5000,maximumScale=50)  
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])

    def step3(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['Delineator Types']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.ansi_layer.setOpacity(0.5)
        vname ='2D LiDAR'
        group = self.main.qgs_project_instance.layerTreeRoot().findGroup(vname)
        if group:
            for lyr in group.findLayers():
                self.main.qgs_project_instance.layerTreeRoot().findLayer(lyr.layer().id()).setItemVisibilityChecked(True)   
            group.setItemVisibilityChecked(True) 
        group.setItemVisibilityChecked(True)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])

    def step4(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['Path Crossing Regions','Path Types','Crossings Paths Association','Path Speed Limits',]+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.ansi_layer.setOpacity(0.5)
        vname ='2D LiDAR'
        group = self.main.qgs_project_instance.layerTreeRoot().findGroup(vname)
        if group:
            for lyr in group.findLayers():
                self.main.qgs_project_instance.layerTreeRoot().findLayer(lyr.layer().id()).setItemVisibilityChecked(True)   
            group.setItemVisibilityChecked(True)
        group.setItemVisibilityChecked(True)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])

    def step5(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['Path Speed Limits','rfdb_sign','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)

        vname ='2D LiDAR'
        group = self.main.qgs_project_instance.layerTreeRoot().findGroup(vname)
        if group:
            group.setItemVisibilityChecked(True)

        self.main.ansi_layer.setOpacity(0.5)
        lyr = self.main.layers['rfdb_sign']
        lyr.setSubsetString("type='Maximum Speed Limit'")
        show_label(lyr,fn='value',size=14, c='red',fontsize=12,bg='white',clause=None,minimumScale=50000,maximumScale=50)   
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        self.main.canvas.zoomScale(15000)
        self.main.canvas.refresh()

    def step6(self):
        self.main.update_layers()     
        self.main.hide_all_layers()
        lyrs = ['Road Objects','Road Objects Paths Association','Google Satellite']+ [self.main.ansi_layer.name()]
        self.main.set_visibility(lyrs)
        self.main.ansi_layer.setOpacity(0.5)
        self.main.canvas.zoomToSelected(self.main.ansi_layer)
        self.main.iface.setActiveLayer(self.main.layers[lyrs[0]])
        #self.main.canvas.zoomScale(self.main.canvas.scale()*1.5)
        self.main.canvas.refresh()
        # lyr = self.main.layers['rfdb_sign']
        # lyr.setSubsetString("type='Maximum Speed Limit'")
        # show_label(lyr,fn='value',size=14, c='red',fontsize=12,bg='white',clause=None) 



class NissanRampStepWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main = main

        if not self.main.layers:
            self.main.update_layers()

        self.main.client_layers = {lyr:client_layers[self.main.ansi_database][lyr] for lyr in steps['required_layers']}
        for i in range(self.main.client_db_win.client_list.count()):
            item = self.main.client_db_win.client_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1

        vl.addLayout(layout)
        self.setLayout(vl)

    def step0(self):
        self.main.ansi_layer.setOpacity(0.8)        
        self.main.canvas.zoomToSelected(self.main.ansi_layer)

    def step1(self):   
        pass


class TollReviewWindow(QWidget):
    def __init__(self,steps,main=None):
        super().__init__()
        self.main = main
        
        for i in range(self.main.client_db_win.rfdb_list.count()):
            item = self.main.client_db_win.rfdb_list.item(i)
            if item.text() in steps['required_layers']:
                item.setCheckState(Qt.Checked)
            else:
                item.setCheckState(Qt.Unchecked)

        self.pipeline_mode = steps['pipeline_mode']

        vl      = QVBoxLayout()
        layout = QHBoxLayout()
        i  = 1
        for k, v in steps['steps']:
            s = QPushButton(k)
            print(v)
            s.clicked.connect(eval('self.step%s'%i))
            layout.addWidget(s)
            i+=1
        # for a in range(10):
        #     button = QPushButton(str(a))
        #     button.clicked.connect(lambda checked, a=a, obj=button: self.button_clicked(obj,a))
        #     layout.addWidget(button)

        vl.addLayout(layout)
        self.setLayout(vl)

    # def button_clicked(self,obj, n):
    #     print('button %s: Text(%s)'%(n,obj.text())) 
        # if self.main.ansi_ongoing:
        #     self.main.fetch_data()

    def step1(self):        
        for k, v in self.main.qgs_project_instance.mapLayers().items():
            if k.startswith('Google_Satellite') or v.name()=='rfdb_road_segment':
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(True)
            else:
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(False)

    def step2(self):
        for k, v in self.main.qgs_project_instance.mapLayers().items():
            if k.startswith('Google_Satellite') or v.name()=='rfdb_delin':
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(True)
            else:
                self.main.qgs_project_instance.layerTreeRoot().findLayer(k).setItemVisibilityChecked(False)

        lyr = self.main.get_layer_by_name('rfdb_delin')[0]
        show_label(lyr,fn='type',size=10, c='red',fontsize=12,bg='white',clause=None)        
        if self.pipeline_mode:
            self.step3()
    def step3(self):
        print('step3')
        if self.pipeline_mode:
            self.step4()
    def step4(self):
        print('step4')
        if self.pipeline_mode:
            self.step5()
    def step5(self):
        print('step5')
        if self.pipeline_mode:
            self.step6()
    def step6(self):
        print('step6')
        print('finished')  



class FieldChoseWin(QMainWindow):
    def __init__(self,mainwin=None,main_ansi_exist = True,ws=r"C:\Users\hhuang\Downloads"):
        super().__init__()
        self.setWindowTitle("Review Field Setting")
        self.setWindowIcon(QIcon(":/plugin/happy_ansi/db.png"))
        self.main = mainwin
        self.main_ansi_exist = main_ansi_exist
        self.ws = ws
        form = QFormLayout()
        form.setLabelAlignment(Qt.AlignLeft)
        form.setFormAlignment(Qt.AlignRight)
        form.setContentsMargins(15,10,15,10)
       
        
        self.layer = QComboBox()  
        layers = [lyr.name() for lyr in self.main.qgs_project_instance.mapLayers().values() if isinstance(lyr,QgsVectorLayer)]
        self.layer.addItems(layers)
        self.id_field = QComboBox()        
        self.fields = QComboBox()
        self.note = QComboBox()
        self.group = QComboBox()
        self.date = QComboBox()

        self.layer_label  = QLabel("Layer")
        self.id_label  = QLabel("Unique ID")
        self.fields_label  = QLabel("ANSI Field")
        self.note_label      = QLabel("ANSI Note")
        self.group_label    = QLabel("Region")
        self.date_label    = QLabel("Date")

        self.hasGeomLabel = QLabel('Has Geometry')
        self.hasGeomCbox = QCheckBox()       
        self.hasGeomCbox.setChecked(True)
        self.wktLabel = QLabel('Geometry Field')
        self.wktField = QComboBox()       
        self.set_geom0= QPushButton('Set Geom')   
        self.set_geom     = QPushButton('Set Geom')
        self.hasGeomCbox.setChecked(True)        


        form.addRow(self.layer_label, self.layer)
        form.addRow(self.id_label, self.id_field)
        form.addRow(self.fields_label, self.fields)
        form.addRow(self.note_label, self.note)
        form.addRow(self.group_label, self.group)
        form.addRow(self.date_label, self.date)
        form.addRow(self.hasGeomLabel, self.hasGeomCbox)
        
        self.geomRow0 = QFormLayout()
        self.geomRow0.addRow(self.wktLabel, self.wktField)
        self.geomRow0.addRow(None, self.set_geom0)
        self.wktFrame = QFrame()
        self.wktFrame.setLayout(self.geomRow0)
        form.addWidget(self.wktFrame)

        self.geomRow = QFormLayout()
        self.dbLabel = QLabel('Database')
        self.dbCbox = QComboBox()       
        self.dbCbox.addItems(['RFDB','JPRFDB','UDBX','GM'])
        self.dbCbox.setCurrentText('RFDB')
        self.featLabel = QLabel('Feature')
        self.featCbox = QComboBox()       
        self.featCbox.addItems(['segment','path','crossing','road_object','WU','subcountry'])
        self.featCbox.setCurrentText('segment')
        self.searchLabel = QLabel('Search Field')
        self.searchCbox  = QComboBox()       
          
        self.geomRow.addRow(self.dbLabel, self.dbCbox)
        self.geomRow.addRow(self.featLabel, self.featCbox)
        self.geomRow.addRow(self.searchLabel, self.searchCbox)
        self.geomRow.addRow(None,self.set_geom)
        self.geomFrame = QFrame()
        self.geomFrame.setLayout(self.geomRow)
        form.addWidget(self.geomFrame)



        self.load_data_btn     = QPushButton('LOAD')
        self.reset_btn   = QPushButton('RESET')

        buttonRow = QHBoxLayout()
        
        buttonRow.addStretch()
        buttonRow.addWidget(self.load_data_btn)
        buttonRow.addStretch()
        buttonRow.addWidget(self.reset_btn)    
        buttonRow.addStretch()
        form.addRow(buttonRow)

        #self.setMinimumSize(QSize(300, 200))
        self.setFixedSize(QSize(400, 500))

        widget = QWidget()
        widget.setLayout(form)
        #self.setStyleSheet('QLabel {margin-left:2px; };')
        self.setCentralWidget(widget)

        if self.main_ansi_exist:            
            self.data_uri = self.main.ansi_layer.source()

        

        
        self.refreshForm()

        
        self.toggle_geometry()
        self.reset_btn.clicked.connect(self.refreshForm)
        self.load_data_btn.clicked.connect(self.saveSetting)
        self.layer.currentIndexChanged.connect(self.update_field)
        self.set_geom.clicked.connect(self.set_geometry)
        self.set_geom0.clicked.connect(self.set_geometry)
        self.hasGeomCbox.toggled.connect(self.toggle_geometry)

    def init_data(self):
        self.data_uri  = QFileDialog.getOpenFileName(None,'Open On', self.ws, 'Shapefiles (*.shp);;GeoJSON (*.geojson);;ANSI Project Files (*.ansi);;Excel Files (*.xlsx);;Text Files (*.txt);;CSV(*.csv);;All Files(*)')[0]
        if not self.data_uri:
            return 
        self.main.ws          = os.path.split(self.data_uri)[0]
        data_uri_ext = os.path.splitext(self.data_uri)[1].lower()
        if data_uri_ext in ['.xlsx','.csv','.txt']:
            if data_uri_ext == '.xlsx':
                self.data_all    = pd.read_excel(self.data_uri)
            elif data_uri_ext == '.csv':    
                self.data_all    = pd.read_csv(self.data_uri)
            elif data_uri_ext == '.txt':
                self.data_all    = pd.read_csv(self.data_uri, sep='\t')
            else:
                pass
            self.data_all.columns = [k.strip() for k in self.data_all.keys()]
            for k in self.main.std_ansi_fields+[self.main.date_field]:
                if k not in self.data_all.keys():
                    self.data_all[k] = None  
            self.hasGeomCbox.setDisabled(False)
        elif data_uri_ext == '.ansi':        
            self.data_all    = gpd.read_file(self.data_uri)   
            self.hasGeomCbox.setDisabled(True)    
            self.wktFrame.hide()
            self.geomFrame.hide()
            self.setFixedSize(QSize(400, 260))
        elif data_uri_ext in ['.shp','.geojson']:  
            print(' ------------------------- ERROR CODE 1 ------------------------- ')
            self.data_all    = gpd.read_file(self.data_uri) 
            #self.data_all    = gpd.GeoDataFrame.from_file(self.data_uri)      

            for k in self.main.std_ansi_fields+[self.main.date_field]:
                if k not in self.data_all.keys():
                    self.data_all[k] = None   
            self.hasGeomCbox.setDisabled(True)
            self.wktFrame.hide()
            self.geomFrame.hide()
            self.setFixedSize(QSize(400, 260))
            print(' ------------------------- ERROR CODE 2 ------------------------- ')
        else:
            QMessageBox.about(self,'Something Goes Wrong Here','Unrecognized file format')
            return   

    def toggle_geometry(self):
        if not self.hasGeomCbox.isEnabled():
            self.wktFrame.hide()
            self.geomFrame.hide()
            self.load_data_btn.setDisabled(0)
            self.setFixedSize(QSize(400, 260))
        elif self.hasGeomCbox.isChecked():
            self.wktFrame.show()
            self.geomFrame.hide()
            self.load_data_btn.setDisabled(0)
            self.setFixedSize(QSize(400, 330))

        else:
            self.wktFrame.hide()
            self.geomFrame.show()
            self.load_data_btn.setDisabled(True)
            self.setFixedSize(QSize(400, 380))

            #self.wktLabel.setDisabled(True)
            #self.wktField.setDisabled(True)
    def refreshForm(self):
        field_names = ['test1','test2']
        if self.main_ansi_exist:   
            self.layer.setCurrentText(self.main.ansi_layer.name())
            self.data_uri = self.main.ansi_layer.source()
            field_names = [f.name() for f in self.main.ansi_layer.fields()] 
            self.id_field.addItems(field_names)
            self.fields.addItems(field_names)        
            self.note.addItems(field_names)        
            self.group.addItems(field_names)        
            self.date.addItems(field_names)
            self.id_field.setCurrentText(self.main.unique_field)
            self.fields.setCurrentText(self.main.ansi_field)
            self.note.setCurrentText(self.main.ansi_notes)
            self.group.setCurrentText(self.main.group_field)
            self.date.setCurrentText(self.main.date_field)  
            self.wktField.addItems(field_names) 
            self.hasGeomCbox.setDisabled(True)                              
        else:
            self.layer.addItems(["New ANSI Layer"])
            try:
                self.init_data()

            
                field_names = [f for f in self.data_all.keys()] 
                self.id_field.addItems(field_names)
                self.fields.addItems(field_names)        
                self.note.addItems(field_names)        
                self.group.addItems(field_names)        
                self.date.addItems(field_names)
                self.wktField.addItems(field_names)  
                for f in field_names:
                    if f.lower().find('id')!=-1 or f.lower().find('road_segme') !=-1:
                        self.id_field.setCurrentText(f)
                        break
                for f in field_names: 
                    if f.lower().find('notes')!=-1 or f.lower().find('comment') !=-1:
                        self.note.setCurrentText(f)
                        break
                for f in field_names:
                    if f.lower().find('overall')!=-1 or f.lower().find('pass/fail') !=-1:
                        self.fields.setCurrentText(f)
                        break
                for f in field_names:
                    if f.lower().find('region')!=-1 or f.lower().find('subcountry') !=-1 or f.lower().find('state') !=-1:
                        self.group.setCurrentText(f)
                        break
                for f in field_names:
                    if f.lower().find('lst_updat')!=-1 or f.lower().find('date') !=-1:
                        self.date.setCurrentText(f)
                        break
                for f in field_names:
                    if f.lower().find('wkt')!=-1 or f.lower().find('geometry') !=-1:
                        self.wktField.setCurrentText(f)
                        break
            except Exception as e:
                print("An error occurred:", str(e))   
                return  
        self.searchCbox.addItems(field_names) 
    def saveSetting(self,verbal=False):        
        self.main.ansi_field       = self.fields.currentText()
        self.main.ansi_notes       = self.note.currentText()
        self.main.group_field      = self.group.currentText()
        self.main.date_field       = self.date.currentText()
        self.main.unique_field     = self.id_field.currentText()
        self.main.std_ansi_fields  = [self.main.ansi_field,self.main.ansi_notes,'ansi_date','ansi_hour','technician']
        self.main.data_uri         = self.data_uri #self.ansi_layer.source() #dataProvider().dataSourceUri()
        self.main.ws               = os.path.split(self.main.data_uri)[0]
        self.main.load_spatial_lyr()
        #self.ansi_layer            = self.main.get_layer_by_name(self.layer.currentText())[0]
        self.hide()
        self.main.go_next()

    def update_field(self):
        self.ansi_layer = self.main.get_layer_by_name(self.layer.currentText())[0]
        field_names = [f.name() for f in self.ansi_layer.fields()]
        self.id_field.addItems(field_names)
        self.fields.addItems(field_names)        
        self.note.addItems(field_names)        
        self.group.addItems(field_names)        
        self.date.addItems(field_names)
        self.wktField.addItems(field_names)  
        for f in field_names:
            if f.lower().find('id')!=-1 or f.lower().find('road_segme') !=-1:
                self.id_field.setCurrentText(f)
                break
        for f in field_names: 
            if f.lower().find('notes')!=-1 or f.lower().find('comment') !=-1:
                self.note.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('overall')!=-1 or f.lower().find('pass/fail') !=-1:
                self.fields.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('region')!=-1 or f.lower().find('subcountry') !=-1 or f.lower().find('state') !=-1:
                self.group.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('lst_updat')!=-1 or f.lower().find('date') !=-1:
                self.date.setCurrentText(f)
                break
        for f in field_names:
            if f.lower().find('wkt')!=-1 or f.lower().find('geometry') !=-1:
                self.wktField.setCurrentText(f)
                break
        self.searchCbox.addItems(field_names) 


        for w in (self.fields,self.note,self.group,self.id_field):
            w.clear()
            w.addItems(field_names)
    def query_segments(self,segment_ids,client='RFDB',feature='segment',search_field=None):
        if client=='GM':
            self.main.update_current_conn('GM')
            query = f'''with seg_geom as (
                        select segment_id, ST_ConvexHull(st_collect(geom)) as geom
                        from csav3.point 
                        where segment_id in %s
                        group by segment_id
                    )
                    select segment_id,st_astext(geom)
                    from seg_geom'''
            self.conn = self.main.customer_conn
            colnames = ['gm_segment_id','geometry']
        elif client=='UDBX':
            self.main.update_current_conn('UDBX')            
            query = f'''with left_edge as (
                                select road_segment.road_segment_id, road_type, number_of_lanes,
                                st_makeline(array_agg(left_edge_pts.position order by road_edge_point_sequence_index)) as left_edge_line,
                                max(road_edge_point_sequence_index) as max_index
                                from ushr_format.road_segment 
                                join ushr_format.road_edge_points left_edge_pts on left_edge_pts.road_segment_id = road_segment.road_segment_id 
                                where road_segment.road_segment_id in %s
                                and left_edge_pts.road_edge_side = false                                        
                                group by road_segment.road_segment_id
                            ),
                            road_edge as (                                  
                            select left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line,
                            st_makeline(array_agg(right_edge_pts.position order by road_edge_point_sequence_index desc)) as right_edge_line
                            from left_edge
                            join ushr_format.road_edge_points right_edge_pts on right_edge_pts.road_segment_id = left_edge.road_segment_id
                            where right_edge_pts.road_edge_side = true
                            group by left_edge.road_segment_id, road_type, number_of_lanes, max_index, left_edge_line
                            ),
                            segment_boundary_lines as (                                 
                            select *, 
                            st_makeline(array[ST_PointN(right_edge_line, -1), ST_PointN(left_edge_line, 1)]) as start_boundary_line, 
                            st_makeline(array[ST_PointN(left_edge_line, -1), ST_PointN(right_edge_line, 1)]) as end_boundary_line 
                            from road_edge
                            )
                            select road_segment_id,st_astext(st_makepolygon(st_makeline(array[left_edge_line, end_boundary_line, right_edge_line, start_boundary_line]))) as boundary_line
                            from segment_boundary_lines
                            '''
            self.conn = self.main.customer_conn
            colnames = ['udbx_segment_id','geometry']
        else:
            self.main.update_current_conn(client)
            if feature == 'segment':
                query = f'''select segment_id,st_astext(st_union(paths.envelope::geometry))
                            from road_unit.segment_paths
                            join path.paths on paths.id = segment_paths.id
                            where segment_id in %s
                            group by segment_id'''
                colnames = ['rfdb_segment_id','geometry']            
            elif feature == 'path':
                query = f'''select paths.id as pa_id, st_astext(paths.envelope)
                            from path.paths
                            where paths.id in %s
                            '''
                colnames = ['rfdb_path_id','geometry']    
            elif feature == 'crossing':
                query = f'''select crossings.id as cr_id,st_astext(st_collect(start_line::geometry, end_line::geometry))
                            from crossing.crossings
                            where crossings.id in %s
                            '''
                colnames = ['rfdb_crossing_id','geometry']   
            elif feature == 'road_object':
                query = f'''select road_objects.id as ro_id, st_astext(location)
                            from road_object.road_objects
                            where road_objects.id in %s'''
                colnames = ['rfdb_road_object_id','geometry']       
            elif feature == 'WU':
                query = f'''select work_unit.id as wu_id,st_astext(geom)
                            from work_units.work_unit
                            where work_unit.id in %s'''
                colnames = ['rfdb_wu_id','geometry']             
            elif feature == 'subcountry':
                query = f'''select work_unit.subcountry as sub_id,st_astext(geom)
                            from work_units.work_unit
                            where work_unit.subcountry in %s'''
                colnames = ['rfdb_subcountry','geometry']             
            else:
                self.main.push_status_message('Not a valid query clause')
                return 
            self.conn = self.main.rfdb_conn

        #print(query)
        #print(segment_ids)   
        response = make_query(self.conn, query, [tuple(segment_ids)])

        if len(response) == 0:
            return 1    
        
        id_geom = {}
        for row in response:
            sid = row[0]
            try:
                g = loads(row[1])
            except:
                g = None
            id_geom[sid] = g
         
        geom_list = []
        geom_fail = []
        for sid in self.data_all[search_field]:
            try:
                g = id_geom[sid]
            except:
                geom_fail.append(str(sid))
                g = None
            geom_list.append(g)
        #print(geom_list)
        gdf  = gpd.GeoDataFrame(data=self.data_all,geometry=geom_list,crs='EPSG:4326')
        #gdf.columns = self.main.data_all
        fn_out      = self.data_uri.split('.')[0]+'.shp'
        #fn_out      = self.main.data_uri.split('.')[0]+'.geojson'
        try:
            gdf.to_file(fn_out)
            #gdf.to_file(fn_out,driver='GeoJSON')
            self.main.data_uri = fn_out
            clipboard.copy(','.join(geom_fail))
            return 1
        except:
            self.main.push_status_message('Data Query Error')
            return 0

    def set_geometry(self,verbal=False):
        if self.hasGeomCbox.isChecked():
            wkt_field                 = self.wktField.currentText()
            geom                      = [] #[loads(g) for g in self.main.data_all[wkt_field]]
            for g in self.data_all[wkt_field]:

                try:
                    eg = loads(g)
                except:
                    eg = None
                geom.append(eg)

            columns                   = [k for k in self.data_all.columns if k != wkt_field]
            self.main.ansi_field       = self.fields.currentText()[:10]
            self.main.ansi_notes        = self.note.currentText()[:10]
            self.main.group_field      = self.group.currentText()[:10]
            self.main.date_field       = self.date.currentText()[:10]
            self.main.unique_field     = self.id_field.currentText()[:10]

            self.data_all        = gpd.GeoDataFrame(data=self.data_all[columns],geometry=geom, crs="EPSG:4326")   
            self.main.data_uri        = self.data_uri.split('.')[0]+'.shp'     
            self.data_all.to_file(self.main.data_uri)
            self.main.load_spatial_lyr()
            self.hide()
        else:
            self.main.ansi_field       = self.fields.currentText()[:10]
            self.main.ansi_notes       = self.note.currentText()[:10]
            self.main.group_field      = self.group.currentText()[:10]
            self.main.date_field       = self.date.currentText()[:10]
            self.main.unique_field     = self.id_field.currentText()[:10]
            client       = self.dbCbox.currentText()
            feature      = self.featCbox.currentText()
            search_field = self.searchCbox.currentText()
            segment_ids  = self.data_all[search_field].unique().tolist()
            segment_ids  = [v for v in segment_ids if str(v).strip()]
            #segment_ids  = [366,873,924,930]
            response     = self.query_segments(segment_ids,client,feature,search_field)
            if response:
                self.main.load_spatial_lyr()
                self.hide()
            else:
                self.main.push_status_message('Load Query Data Failed')

if __name__ == "__main__":
    import sys

    app = QApplication(sys.argv)
    w = QMainWindow()
    widget = AnsiStepWindow(steps)
    widget.pipeline_mode = True
    w.setCentralWidget(widget)
    w.show()

    sys.exit(app.exec_())