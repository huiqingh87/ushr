#!/usr/bin/python3
# -*- coding: utf-8 -*-

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtGui import QImage, QPixmap, QPalette, QPainter
from qgis.PyQt.QtPrintSupport import QPrintDialog, QPrinter
from qgis.PyQt.QtWidgets import QLabel, QSizePolicy, QScrollArea, QMessageBox, QMainWindow, QMenu, QAction, \
    qApp, QFileDialog, QInputDialog, QWidget, QGridLayout, QLineEdit,QComboBox,QPushButton
from .map_data.siloc import *
from .map_data.udbx3_data import *
from .map_data.gm_data import *
from .map_data.udbx_data import *
from .map_data.utils import *
#from .map_data.udbx3_data import *
#from .map_data.dmp_gen1_data import *
from .map_data.rfdb_data import *
from .sign_pm import draw_sign_image, create_layer

class gotoWin(QWidget):
    def __init__(self,mainWin=None):
        super().__init__()
        self.ws = r'C:\Users\hhuang\Downloads\temp'
        if mainWin:
            self.mainWin = mainWin
            if self.mainWin and self.mainWin.main.ws:
                self.ws = self.mainWin.main.ws
        self.initUI()
    def initUI(self):

        self.dbLabel = QLabel('Database')
        self.dbLabel.setFixedWidth(80)

        self.dbField = QComboBox()  
        self.dbField.addItems(['RFDB','UDBX','UDBX3'])

        self.sidLabel = QLabel('Sign ID')
        self.sidText = QLineEdit(self)
        # 添加确定和取消按钮
        self.goButton = QPushButton('GO')
        self.abortButton = QPushButton('Abort')
        # 设置布局
        self.goButton.setFixedSize(100, 50)
        self.abortButton.setFixedSize(100, 50)
        # Create grid layout
        grid = QGridLayout()
        grid.addWidget(self.dbLabel, 0, 0)
        grid.addWidget(self.dbField, 0, 1)
        grid.addWidget(self.sidLabel, 1, 0)
        grid.addWidget(self.sidText, 1, 1)
        grid.addWidget(self.goButton, 2, 0)
        grid.addWidget(self.abortButton, 2, 1)

        # Set layout
        self.setLayout(grid)

        # Set window properties
        self.setGeometry(300, 300, 300, 200)
        self.setWindowTitle('Siloc Sign Retriver')
        #self.show()
        self.connect_signals()
    def findSign(self):
        client = self.dbField.currentText().strip()
        print('current client: ', client)
        self.mainWin.siloc = Siloc(self.mainWin.main, client=client)
        try:
            sid = int(self.sidText.text().strip())
        except:
            QMessageBox.about(self,'ERROR','Sign ID is not a NUMBER')
            return
        if client=='UDBX':
            sid = int(sid//9)

        captured_at, lidar_at, lidar_image, image, lidar_bbox, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid = self.mainWin.siloc.get_sign_image(sid)
        print(captured_at, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid)
        image_url = draw_sign_image(sid, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.ws,'data'),save=True)
        lidar_url = draw_sign_image(sid, lidar_image, str(captured_at), lidar_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.ws,'data'),save=True,is_lidar=True,is_ushr_image=True)
        
        if self.mainWin:
            self.mainWin.open(image_url)
        QMessageBox.about(self,'ERROR',image_url)

        return image_url
        # try:
        #     captured_at, lidar_at, lidar_image, image, lidar_bbox, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid = self.mainWin.siloc.get_sign_image(sid)
        #     print(captured_at, camera_bbox, type_, value, shape, is_digital, is_hanging, centroid)
        #     image_url = draw_sign_image(sid, image, str(captured_at), camera_bbox,type_, value, shape, is_digital, is_hanging,ws=os.path.join(self.mainWin.ws,'data'),save=True)
        #     if self.mainWin:
        #         self.mainWin.open(image_url)
        #     return image_url
        # except:
        #     QMessageBox.about(self,'ERROR','Could\'t find the sign or sign id is incorrect!')
        #     return None

            
    def connect_signals(self):
        self.goButton.clicked.connect(self.findSign) 
        self.abortButton.clicked.connect(self.close) 


class QImageViewer(QMainWindow):
    def __init__(self,title='Image Viewer',width=1200,height=800,mainwin=None):
        super().__init__()
        self.title = title
        self.width = width
        self.height= height
        self.main  = mainwin
        self.siloc = None
        self.gotoWin = gotoWin(self)
        self.printer = QPrinter()
        self.scaleFactor = 0.0

        self.imageLabel = QLabel()
        self.imageLabel.setBackgroundRole(QPalette.Base)
        self.imageLabel.setSizePolicy(QSizePolicy.Ignored, QSizePolicy.Ignored)
        self.imageLabel.setScaledContents(True)

        self.scrollArea = QScrollArea()
        self.scrollArea.setBackgroundRole(QPalette.Dark)
        self.scrollArea.setWidget(self.imageLabel)
        self.scrollArea.setVisible(False)

        self.setCentralWidget(self.scrollArea)

        self.createActions()
        self.createMenus()

        self.setWindowTitle(self.title)
        self.resize(self.width, self.height)
        #self.fitToWindowAct.trigger()
    
        # Connect the mouse wheel event to the zoom function
        self.imageLabel.wheelEvent = self.zoom
        
    def zoom(self, event):
        # Get the current size of the image
        current_width = self.imageLabel.pixmap().width()
        current_height = self.imageLabel.pixmap().height()
        
        # Calculate the new size of the image based on the mouse wheel delta
        delta = event.angleDelta().y()
        if delta > 0:
            #new_width = current_width * 1.1
            #new_height = current_height * 1.1
            self.zoomIn()
        else:
            #new_width = current_width * 0.9
            #new_height = current_height * 0.9
            self.zoomOut()
            
        # Resize the image and update the label's pixmap
        #self.image = self.image.scaled(new_width, new_height, Qt.KeepAspectRatio)
        #self.imageLabel.setPixmap(self.image)


    def set_title(self,title):
        self.setWindowTitle(title)
    def open(self,fileName=None):
        if not fileName:
            options = QFileDialog.Options()
            # fileName = QFileDialog.getOpenFileName(self, "Open File", QDir.currentPath())
            fileName, _ = QFileDialog.getOpenFileName(self, 'QFileDialog.getOpenFileName()', '',
                                                      'Images (*.png *.jpeg *.jpg *.bmp *.gif)', options=options)

        image = QImage(fileName)
        if image.isNull():
            QMessageBox.information(self, self.title, "Cannot load %s." % fileName)
            return
        self.image = QPixmap.fromImage(image)
        self.imageLabel.setPixmap(self.image)
        self.scaleFactor = 1.0

        self.scrollArea.setVisible(True)
        self.printAct.setEnabled(True)
        self.fitToWindowAct.setEnabled(True)
        self.updateActions()
        self.imageLabel.adjustSize()        
        current_width = self.imageLabel.pixmap().width()
        current_height = self.imageLabel.pixmap().height()
        self.resize(current_width, current_height)
        # if not self.fitToWindowAct.isChecked():
        #     self.imageLabel.adjustSize()
        self.show()
    def print_(self):
        dialog = QPrintDialog(self.printer, self)
        if dialog.exec_():
            painter = QPainter(self.printer)
            rect = painter.viewport()
            size = self.imageLabel.pixmap().size()
            size.scale(rect.size(), Qt.KeepAspectRatio)
            painter.setViewport(rect.x(), rect.y(), size.width(), size.height())
            painter.setWindow(self.imageLabel.pixmap().rect())
            painter.drawPixmap(0, 0, self.imageLabel.pixmap())
    def goto(self):
        if self.gotoWin:
            self.gotoWin = gotoWin(self)
        self.gotoWin.show()
    def zoomIn(self):
        self.scaleImage(1.25)

    def zoomOut(self):
        self.scaleImage(0.8)

    def normalSize(self):
        self.imageLabel.adjustSize()
        self.scaleFactor = 1.0

    def fitToWindow(self):
        fitToWindow = self.fitToWindowAct.isChecked()
        self.scrollArea.setWidgetResizable(fitToWindow)
        if not fitToWindow:
            self.normalSize()

        self.updateActions()

    def about(self):
        QMessageBox.about(self, "About %s"%self.title,
                          "<p>The <b>Image Viewer</b> example shows how to combine "
                          "QLabel and QScrollArea to display an image. QLabel is "
                          "typically used for displaying text, but it can also display "
                          "an image. QScrollArea provides a scrolling view around "
                          "another widget. If the child widget exceeds the size of the "
                          "frame, QScrollArea automatically provides scroll bars.</p>"
                          "<p>The example demonstrates how QLabel's ability to scale "
                          "its contents (QLabel.scaledContents), and QScrollArea's "
                          "ability to automatically resize its contents "
                          "(QScrollArea.widgetResizable), can be used to implement "
                          "zooming and scaling features.</p>"
                          "<p>In addition the example shows how to use QPainter to "
                          "print an image.</p>")

    def createActions(self):
        self.openAct = QAction("&Open...", self, shortcut="Ctrl+O", triggered=self.open)
        self.gotoAct = QAction("Go To", self, shortcut="Ctrl+F", enabled=True, triggered=self.goto)
        self.printAct = QAction("&Print...", self, shortcut="Ctrl+P", enabled=False, triggered=self.print_)
        self.exitAct = QAction("E&xit", self, shortcut="Ctrl+Q", triggered=self.close)
        
        self.zoomInAct = QAction("Zoom &In (25%)", self, shortcut="Ctrl++", enabled=False, triggered=self.zoomIn)
        self.zoomOutAct = QAction("Zoom &Out (25%)", self, shortcut="Ctrl+-", enabled=False, triggered=self.zoomOut)
        self.normalSizeAct = QAction("&Normal Size", self, shortcut="Ctrl+S", enabled=False, triggered=self.normalSize)
        self.fitToWindowAct = QAction("&Fit to Window", self, enabled=False, checkable=True, shortcut="Ctrl+F",
                                      triggered=self.fitToWindow)
        self.aboutAct = QAction("&About", self, triggered=self.about)
        self.aboutQtAct = QAction("About &Qt", self, triggered=qApp.aboutQt)

    def createMenus(self):
        self.fileMenu = QMenu("&File", self)
        self.fileMenu.addAction(self.openAct)
        self.fileMenu.addAction(self.gotoAct)
        self.fileMenu.addAction(self.printAct)
        self.fileMenu.addSeparator()
        self.fileMenu.addAction(self.exitAct)

        self.viewMenu = QMenu("&View", self)
        self.viewMenu.addAction(self.zoomInAct)
        self.viewMenu.addAction(self.zoomOutAct)
        self.viewMenu.addAction(self.normalSizeAct)
        self.viewMenu.addSeparator()
        self.viewMenu.addAction(self.fitToWindowAct)

        self.helpMenu = QMenu("&Help", self)
        self.helpMenu.addAction(self.aboutAct)
        self.helpMenu.addAction(self.aboutQtAct)

        self.menuBar().addMenu(self.fileMenu)
        self.menuBar().addMenu(self.viewMenu)
        self.menuBar().addMenu(self.helpMenu)

    def updateActions(self):
        self.zoomInAct.setEnabled(not self.fitToWindowAct.isChecked())
        self.zoomOutAct.setEnabled(not self.fitToWindowAct.isChecked())
        self.normalSizeAct.setEnabled(not self.fitToWindowAct.isChecked())

    def scaleImage(self, factor):
        self.scaleFactor *= factor
        self.imageLabel.resize(self.scaleFactor * self.imageLabel.pixmap().size())

        self.adjustScrollBar(self.scrollArea.horizontalScrollBar(), factor)
        self.adjustScrollBar(self.scrollArea.verticalScrollBar(), factor)

        self.zoomInAct.setEnabled(self.scaleFactor < 3.0)
        self.zoomOutAct.setEnabled(self.scaleFactor > 0.333)

    def adjustScrollBar(self, scrollBar, factor):
        scrollBar.setValue(int(factor * scrollBar.value()
                               + ((factor - 1) * scrollBar.pageStep() / 2)))


if __name__ == '__main__':
    import sys
    from qgis.PyQt.QtWidgets import QApplication

    app = QApplication(sys.argv)
    imageViewer = QImageViewer()
    imageViewer.show()
    sys.exit(app.exec_())
    # TODO QScrollArea support mouse
    # base on https://github.com/baoboa/pyqt5/blob/master/examples/widgets/imageviewer.py
    #
    # if you need Two Image Synchronous Scrolling in the window by qgis.PyQt and Python 3
    # please visit https://gist.github.com/acbetter/e7d0c600fdc0865f4b0ee05a17b858f2