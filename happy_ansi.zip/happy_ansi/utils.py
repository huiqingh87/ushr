from .map_data.db_conn import *

conn = pg2.connect(host=url,port=port,dbname=db,user=user,password=pwd)
sids = ['4908265','266895']
records = make_query(conn,'select segment_id, ST_ConvexHull(st_collect(geom)) as geom from csav3.point where segment_id in %s group by segment_id',[tuple(sids)])
for record in records:
	print(record)


# get segments by id for RFDB, GM and NISSAN

def query_gm_segments(segment_ids,client='RFDB'):
	if client=='GM':
		query = f'''select segment_id, ST_ConvexHull(st_collect(geom)) as geom
						from csav3.point 
						where segment_id in (%s)
						group by segment_id'''
	elif client=='':
		query = f'''select segment_id, ST_ConvexHull(st_collect(geom)) as geom
						from csav3.point 
						where segment_id in (%s)
						group by segment_id'''
	else:

        if self.rfdb_map_data is None:
            self.rfdb_map_data = RFDBMapData(self)

        self.rfdb_map_data.conn = self.rfdb_conn
        
	response = make_query(self.conn, query, (tuple(segment_ids),))
	if len(response) == 0:
		return
	return response