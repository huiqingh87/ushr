from PyQt5 import QtCore, uic
from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QApplication, QWidget, QAbstractItemView,QMainWindow
from PyQt5.QtGui import QBrush, QColor
import os, sys
import pyperclip as clipboard




class PandasModel(QtCore.QAbstractTableModel):
    """
    Class to populate a table view with a pandas dataframe
    """
    def __init__(self, data, parent=None):
        QtCore.QAbstractTableModel.__init__(self, parent)
        self._data = data
        self.prefix = {0:'USHR HHQ Notes - WU Should Be On Hold - ',1:'USHR HHQ Notes - WU Should Not Be On Hold - '}
        
    def to_csv(self,ws=r'C:\Users\hhuang\Downloads\kryan',kind=0):
        now = datetime.now().strftime('%Y_%m%d')
        if not kind:
            fn = os.path.join(ws,'all_onhold_wu_list_%s.csv'%now)
            self._data.to_csv(fn,index=False)
        else:
            fn               = os.path.join(ws,'not_onhold_wu_list_%s.csv'%now)            
            data             = self._data[self._data['Observation and solution'].str.find(self.prefix[1])!=-1]
            data['Wu Index'] = data.index
            data.to_csv(fn,index=False)
            QMessageBox.about(None,'Summary Not On Hold',f'There are {len(data)} WUs should\n not be On-Hold Status in Total')

    def rowCount(self, parent=None):
        return self._data.shape[0]

    def columnCount(self, parent=None):
        return self._data.shape[1]

    def finishCount(self,parent=None):
        tmp = self._data[self._data['Cross-check']!=""]
        return len(tmp)-1
    def data(self, index, role=QtCore.Qt.DisplayRole):
        if index.isValid():
            if role == Qt.DisplayRole or role == Qt.EditRole:
                return str(self._data.iloc[index.row(), index.column()])
            elif role == Qt.BackgroundRole:
                if  index.sibling(index.row(),3).data():
                    return QBrush(QColor(199,233,192))#Qt.white)
                else:
                    return QBrush(Qt.white)
        return None

    def setData(self, index, value, role=Qt.EditRole):
        #["Work Unit #", "On Hold Reasons","Observation and solution","Cross-check","Reviewed Date", "Project Code","State name"]
        if not index.isValid():
            return False
        if role==Qt.EditRole:
            #self._data[index.row()][3].setText(value)
            #self._data[index.row()][4].setText('Huang')
            self._data.iloc[index.row(), 2] = value.replace('Rfdb','RFDB').replace('Csav','CSAV').replace('Wu','WU').strip('\n')
            self._data.iloc[index.row(), 3] = 'Huiqing'
            self._data.iloc[index.row(), 4] = datetime.now().strftime('%m/%d/%Y')
            self.dataChanged.emit(index,index)
            return True

    # def headerData(self, col, orientation, role):
    #     if orientation == QtCore.Qt.Horizontal and role == QtCore.Qt.DisplayRole:
    #         return self._data.columns[col]

    def headerData(self, section, orientation, role=QtCore.Qt.DisplayRole):
        if role != QtCore.Qt.DisplayRole:
            return QtCore.QVariant()

        if orientation == QtCore.Qt.Horizontal:
            try:
                return self._data.columns.tolist()[section]
            except (IndexError, ):
                return QtCore.QVariant()
        elif orientation == QtCore.Qt.Vertical:
            try:
                # return self.df.index.tolist()
                return self._data.index.tolist()[section]
            except (IndexError, ):
                return QtCore.QVariant()    
                   
        return None
    def sort(self, column, order):
        colname = self._df.columns.tolist()[column]
        self.layoutAboutToBeChanged.emit()
        self._df.sort_values(colname, ascending= order == QtCore.Qt.AscendingOrder, inplace=True)
        self._df.reset_index(inplace=True, drop=True)
        self.layoutChanged.emit()

    def flags(self, index):
        return Qt.ItemIsSelectable|Qt.ItemIsEnabled|Qt.ItemIsEditable

# class TableModel(QtCore.QAbstractTableModel):
#     def __init__(self, data):
#         super(TableModel, self).__init__()
#         self._data = data

#     def data(self, index, role):
#         if role == Qt.DisplayRole:
#             # See below for the nested-list data structure.
#             # .row() indexes into the outer list,
#             # .column() indexes into the sub-list
#             return self._data[index.row()][index.column()]

#     def rowCount(self, index):
#         # The length of the outer list.
#         return len(self._data)

#     def columnCount(self, index):
#         # The following takes the first sub-list, and returns
#         # the length (only works if all rows are an equal length)
#         return len(self._data[0])



class data_view_manager(QMainWindow):
    def __init__(self,mainwin):
        super(data_view_manager, self).__init__()        
        self.ui = None        
        self.task_on = False
        self.ws   = os.path.dirname(__file__)
        self.main = mainwin
        if not self.main or not self.main.ws:
            self.ws = os.path.dirname(__file__)
        self.load_ui()

        self.ui.setWindowTitle("On Hold Data Viwer")
        self.ui.move(1000, 250)
        #self.setCentralWidget(self.ui.tableView_onhold)
        self.all_data = None
        self.index = 0
        self.ui.tableView_onhold.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.ui.tableView_onhold.clicked.connect(self.getCurWU)
        
    #     self.ui.tableView_onhold.clicked.connect(self.selectRow)

    # def selectRow(self,index):

    #     print('Current index: %s'%index.row())  # test
    #     index = self.ui.tableView_onhold.currentIndex()
    #     print('Now index: %s'%index.row())  # test
    #     self.ui.tableView_onhold.selectRow(index.row())
    def getCurWU(self,item):
        cellContent = item.data()
        print('Current @ %s'%cellContent)  # test
        sf = "You clicked on {}".format(cellContent)
        # display in title bar for convenience
        clipboard.copy(cellContent)
        index = self.ui.tableView_onhold.currentIndex()
        self.ui.tableView_onhold.selectRow(index.row())
    def getNextWU(self):
        index = self.ui.tableView_onhold.currentIndex()
        self.index = index.row() + 1
        if self.index == self.ui.tableView_onhold.model().rowCount():
            QMessageBox.about(None, "Congratulations", 'All Samples Have Been Reviwed Successfully')
            return
        self.ui.tableView_onhold.selectRow(self.index)
    def update_data(self,data):
        self.all_data = data
        self.index    = 0
        self.model    = PandasModel(data)
        self.ui.tableView_onhold.setModel(self.model)  
        stylesheet    = "::section{Background-color:rgb(217,217,217);font-weight:bold;}" #border-radius:14px;
        self.ui.tableView_onhold.horizontalHeader().setStyleSheet(stylesheet)
        self.ui.tableView_onhold.selectRow(self.index)
        #self.ui.show()
    def load_ui(self):
        # loader = QUiLoader()
        # path = os.fspath(Path(__file__).resolve().parent / "form.ui")
        # ui_file = QFile(path)
        # ui_file.open(QFile.ReadOnly)
        # self.ui = loader.load(ui_file, self)
        # ui_file.close()
        self.ui =uic.loadUi(os.path.join(os.path.dirname(__file__), "data_view.ui"))

if __name__ == "__main__":
    app = QApplication([])

    widget = data_view_manager(None)
    widget.show()
    sys.exit(app.exec_())
