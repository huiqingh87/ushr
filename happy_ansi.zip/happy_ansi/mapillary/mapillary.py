import requests
import json
from qgis.core import QgsGeometry, QgsField, QgsFeature, QgsPointXY
from qgis.PyQt.QtCore import QVariant
from ..map_data.utils import *
import logging
from datetime import datetime


class Mapillary:
    def __init__(self):
        self.access_token = 'MLY|4481596778573798|c401e5256a6c7bb4085c2bff4dae46f2'
        self.extent = None
        self.sequence_dict = {}
        self.img_dict = {}
        self.sequence_key = None
        self.sequence_index = None

        self.traffic_sign_key = None
        self.traffic_sign_index = None
        self.traffic_sign_name = None

        self.traffic_sign_dict = {}

    def query_sequence(self):
        self.sequence_dict = {}
        url = f"https://a.mapillary.com/v3/sequences?bbox={self.extent.x_min},{self.extent.y_min}," \
              f"{self.extent.x_max},{self.extent.y_max}&access_token={self.access_token}"
        response = requests.get(url=url)
        response_json = json.loads(response.text)

        # todo: exclude the coordinates that are too far away from the extent
        for feature in response_json['features']:
            key = feature['properties']['key']  # Unique identifier of the sequence.
            # if key in
            coordinates = feature['geometry']['coordinates']
            image_keys = feature['properties']['coordinateProperties']['image_keys']
            cas = feature['properties']['coordinateProperties']['cas']  # Camera angles either in [0, 360) degrees, or -1 which indicates the corresponding CA is missing.
            captured_at = feature['properties']['captured_at']
            year = captured_at.split('-')[0]
            month = captured_at.split('-')[1]
            year_month = f'{year}/{month}'
            camera_make = feature['properties']['camera_make']
            self.sequence_dict[key] = {'coordinates': coordinates, 'image_keys': image_keys, 'cas': cas,
                                       'captured_at': captured_at, 'camera_make': camera_make, 'year_month': year_month}

    def query_image(self, image_key):
        s = requests.Session()
        r = s.get(f'https://www.mapillary.com/embed?image_key={image_key}')
        image_id = r.url.split('=')[-1]
        if image_id == image_key:
            return None, None
        r = s.get(f'https://graph.mapillary.com/{image_id}?access_token={self.access_token}&fields=id,captured_at,thumb_1024_url')
        r_json = json.loads(r.content)
        captured_at = r_json['captured_at']
        captured_at = str(datetime.fromtimestamp(captured_at / 1e3))
        image_url = r_json['thumb_1024_url']
        image = s.get(image_url)
        return captured_at, image.content

    def query_traffic_sign(self):
        self.traffic_sign_dict = {}
        url = f'https://a.mapillary.com/v3/map_features?layers=trafficsigns' \
              f'&bbox={self.extent.x_min},{self.extent.y_min},{self.extent.x_max},{self.extent.y_max}' \
              f'&per_page=200&client_id={self.access_token}'
        response = requests.get(url=url)
        response_json = json.loads(response.text)

        if 'features' not in response_json.keys():
            return
        for feature in response_json['features']:
            properties = feature['properties']
            key = properties['key']
            first_seen_at = properties['first_seen_at']
            first_seen_date = first_seen_at.split('T')[0]
            last_seen_at = properties['last_seen_at']
            last_seen_date = last_seen_at.split('T')[0]
            value = properties['value']     # ex. "general--traffic-sign--g1"
            category = value.split('--')[0]
            if self.traffic_sign_name == 'speed-limit':
                if self.traffic_sign_name not in value:
                    continue
            name = value.split('--')[1]
            appearance_group = value.split('--')[2]
            coordinates = feature['geometry']['coordinates']

            detections = properties['detections']
            image_keys = []
            for detection in detections:
                image_key = detection['image_key']
                image_keys.append(image_key)

            self.traffic_sign_dict[key] = {'category': category, 'name': name, 'seen_at': f'{first_seen_date}~{last_seen_date}',
                                           'coordinates': coordinates, 'image_keys': image_keys}

    def build_sequence_layer(self):

        qgs_fields = [QgsField('sequence_key', QVariant.String), QgsField('index', QVariant.Int),
                      QgsField('image_key', QVariant.String), QgsField('captured_at', QVariant.String),
                      QgsField('year_month', QVariant.String)]
        feature_list = []
        year_month_list = []
        for key in self.sequence_dict:
            coords = self.sequence_dict[key]['coordinates']
            captured_at = self.sequence_dict[key]['captured_at']
            year_month = self.sequence_dict[key]['year_month']
            image_keys = self.sequence_dict[key]['image_keys']
            if year_month not in year_month_list:
                year_month_list.append(year_month)
            for i, coord in enumerate(coords):
                point = QgsPointXY(coord[0], coord[1])
                geom = QgsGeometry.fromPointXY(point)
                f = QgsFeature()
                f.setGeometry(geom)
                f.setAttributes([key, i, image_keys[i], captured_at, year_month])
                feature_list.append(f)

        v_layer = buildQgsVectorLayer('Point?crs=epsg:4326', 'sequence',
                                      feature_list, qgs_fields)
        feature_dict = {}
        # sign_color_selector = ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'purple']
        for i, year_month in enumerate(year_month_list):
            # if i > 6:
            #     index = i % 6
            # else:
            #     index = i
            # color = sign_color_selector[index]
            h, s, v, a = 130 + i * 10, 255, 255, 255
            color = QColor.fromHsv(h, s, v, a)
            feature_dict[f'{year_month}'] = (color, f'{year_month}')

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='year_month', point=True)

        return v_layer

    def build_traffic_sign_layer(self):

        qgs_fields = [QgsField('key', QVariant.String),
                      QgsField('category', QVariant.String), QgsField('name', QVariant.String),
                      QgsField('seen_at', QVariant.String), QgsField('image_keys', QVariant.String)]
        feature_list = []
        name_list = []
        for key in self.traffic_sign_dict:
            category = self.traffic_sign_dict[key]['category']
            name = self.traffic_sign_dict[key]['name']
            seen_at = self.traffic_sign_dict[key]['seen_at']
            coords = self.traffic_sign_dict[key]['coordinates']
            image_keys = self.traffic_sign_dict[key]['image_keys']

            if name not in name_list:
                name_list.append(name)
            point = QgsPointXY(coords[0], coords[1])
            geom = QgsGeometry.fromPointXY(point)
            f = QgsFeature()
            f.setGeometry(geom)
            f.setAttributes([key, category, name, seen_at, f'{image_keys}'])
            feature_list.append(f)

        v_layer = buildQgsVectorLayer('Point?crs=epsg:4326', 'traffic_sign',
                                      feature_list, qgs_fields)
        feature_dict = {}
        sign_color_selector = ['red', 'orange', 'yellow', 'green', 'blue', 'magenta', 'purple']
        for i, name in enumerate(name_list):
            if i > 6:
                index = i % 6
            else:
                index = i
            color = sign_color_selector[index]
            feature_dict[f'{name}'] = (color, f'{name}')

        v_layer = apply_categorized_symbol(feature_dict, v_layer, field='name', point=True)
        return v_layer


if __name__ == '__main__':
    extent = '-83.061344, 42.490348, -83.059902, 42.491870'
    mapillary = Mapillary()
    image_id = 'BXWXb-cpwB8r2Q4RKL2YHA'
    captured_at, image = mapillary.query_image(image_id)
    print(captured_at)
    with open('D:/test_image.png', 'wb') as f:
        f.write(image)





