import os
from PyQt5 import uic
from qgis.PyQt.QtGui import QPixmap, QPainter, QPen
from qgis.PyQt.QtCore import Qt, QRect


class SilocCameraImageDialog:
    def __init__(self):
        self.ui = uic.loadUi(os.path.join(os.path.dirname(__file__), 'siloc_camera_image_dialog.ui'))

        self.captured_at = None
        self.image = None
        self.bbox = None

        self.n_slide_pos = 4

        self.ui.horizontalSlider_siloc_image.sliderReleased.connect(
            self.on_horizontalSlider_siloc_image_released)

    def on_horizontalSlider_siloc_image_released(self):
        self.load_image()

    def load_image(self):
        cols = self.bbox.strip('[]').split(',')
        x_min = min(float(cols[0]), float(cols[2]))
        x_max = max(float(cols[0]), float(cols[2]))
        y_min = min(float(cols[1]), float(cols[3]))
        y_max = max(float(cols[1]), float(cols[3]))
        self.ui.label_siloc_camera_image_date.setText(self.captured_at)
        pixmap = QPixmap()
        pixmap.loadFromData(self.image)

        image_width = pixmap.width()
        image_height = pixmap.height()

        left_space_length = x_min
        right_space_length = image_width - x_max
        up_space_length = y_min
        down_space_length = image_height - y_max
        min_space_length = min(left_space_length, right_space_length, up_space_length, down_space_length)
        step_length = min_space_length / self.n_slide_pos

        image_label = self.ui.label_siloc_camera_image

        slider_pos = self.ui.horizontalSlider_siloc_image.sliderPosition()

        # different zoom levels
        if slider_pos not in (0, self.n_slide_pos):
            space_length = (4 - slider_pos) * step_length
            rect = QRect(x_min - space_length, y_min - space_length,
                         x_max - x_min + space_length * 2, y_max - y_min + space_length * 2)
            pixmap = pixmap.copy(rect)
        # full size image
        elif slider_pos == 0:
            pixmap.scaled(image_label.width(), image_label.height(), Qt.KeepAspectRatio, Qt.SmoothTransformation)
            # bbox of the sign
            painter = QPainter(pixmap)
            pen = QPen(Qt.yellow, 3)
            painter.setPen(pen)
            painter.drawRect(x_min, y_min, x_max - x_min, y_max - y_min)
            painter.end()
        # only display the sign
        else:
            rect = QRect(x_min, y_min, x_max - x_min, y_max - y_min)
            pixmap = pixmap.copy(rect)

        painter = QPainter(pixmap)
        pen = QPen(Qt.yellow, 3)
        painter.setPen(pen)
        painter.drawRect(x_min, y_min, x_max - x_min, y_max - y_min)
        painter.end()

        # scaled = pixmap.scaled(640, 640, Qt.KeepAspectRatio, Qt.SmoothTransformation)
        image_label.setPixmap(pixmap)
