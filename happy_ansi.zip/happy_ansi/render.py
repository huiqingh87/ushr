from PyQt5 import QtCore
from PyQt5.QtCore import QSize, Qt
from PyQt5.QtGui import QFont, QColor, QIcon, QKeySequence, QBrush, QPixmap
from PyQt5.QtWidgets import *
from qgis.core import *
import geopandas as gpd
import os
from .ansi_win import load_xyz
from .map_data.utils import *

def display_label(layer, label_expression, font_size=18, scaleVisibility = True, font_color='red', background_color='white', min_scale=50, max_scale=15000):
    # create a label settings object
    layer_settings = QgsPalLayerSettings()
    layer_settings.drawBackground = True
    
    # set the text format parameters
    text_format = QgsTextFormat()
    text_format.setFont(QFont("Arial", font_size))    
    #text_format.setSize(font_size)
    text_format.setColor(QColor(font_color))



    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(1)
    buffer_settings.setColor(QColor(background_color))
    text_format.setBuffer(buffer_settings)


    # set the label settings
    layer_settings.setFormat(text_format)
    layer_settings.fieldName = label_expression
    layer_settings.placement = 2
    
    # set the scale-based visibility
    layer_settings.scaleVisibility = scaleVisibility
    if layer_settings.scaleVisibility:
        layer_settings.minimumScale = min_scale
        layer_settings.maximumScale = max_scale
    
    # create a vector layer labeling object and set it as active
    vector_layer_labeling = QgsVectorLayerSimpleLabeling(layer_settings)
    layer.setLabelsEnabled(True)
    layer.setLabeling(vector_layer_labeling)

    # trigger refresh for the changes to take effect
    layer.triggerRepaint()




def set_ansi_style(vlayer,field, colors=['#00ff00','#ff0000','#0000ff'],values=['Pass','Fail',None], width = '1', style='no'):
    #symbols  = [QgsRendererCategory(v,
    #QgsFillSymbol.createSimple({'color':'','outline_color':c,'width_border':width,'style':style}),v, True)
    #for c, v in zip(colors,values)]
    symbols  = []

    geom_type = vlayer.wkbType()
    if geom_type in (3006,1006,2006,6,3,1003,2003,3003):    
        for c, v in zip(colors,values):
            if v:
                category = QgsRendererCategory(v,QgsFillSymbol.createSimple({'color':'','outline_color':c,'width_border':width,'style':style}),v, True)
            else:
                category = QgsRendererCategory(v,QgsFillSymbol.createSimple({'color':'','outline_color':c,'width_border':width,'style':style}),'Others', True)
            symbols.append(category)
        
    elif geom_type in (1,1001,2001,3001, 4, 1004, 2004, 3004):
        for c, v in zip(colors,values):
            if v:
                category = QgsRendererCategory(v,QgsMarkerSymbol.createSimple({'color':c,'size':'4','width_border':width,'style':style}),v, True)
            else:
                category = QgsRendererCategory(v,QgsMarkerSymbol.createSimple({'color':c,'size':'4','width_border':width,'style':style}),'Others', True)
            symbols.append(category)

        # categorized symbology
        # category = QgsCategorizedSymbolRenderer("attr", [QgsRendererCategory(1, QgsMarkerSymbol.createSimple({"color": "255,0,0"}), "red"),
        #                                           QgsRendererCategory(2, QgsMarkerSymbol.createSimple({"color": "0,0,255"}), "blue")])
    elif geom_type in (2,1002,2002,3002):
        for c, v in zip(colors,values):
            if v:
                category = QgsRendererCategory(v,QgsLineSymbol.createSimple({'color':c,'width':width, 'customdash': '3;10', 'use_custom_dash': '1'}),v, True)
            else:
                category = QgsRendererCategory(v,QgsLineSymbol.createSimple({'color':c,'width':width, 'customdash': '3;10', 'use_custom_dash': '1'}),'Others', True)
            symbols.append(category)
    else:
        pass
    renderer = QgsCategorizedSymbolRenderer(field,symbols)
    vlayer.setRenderer(renderer)
    vlayer.triggerRepaint() 

def show_label(my_layer,fn='segment_id',size=10, c='red',position=9,scaleVisibility = True, fontsize=12,bg='white',clause=None,minimumScale=5000,maximumScale=500):
    layer_settings  = QgsPalLayerSettings()
    text_format = QgsTextFormat()
    text_format.setFont(QFont("Arial", fontsize))
    text_format.setSize(size)
    text_format.setColor(QColor(c))
    buffer_settings = QgsTextBufferSettings()
    buffer_settings.setEnabled(True)
    buffer_settings.setSize(1)
    buffer_settings.setColor(QColor(bg))
    text_format.setBuffer(buffer_settings)
    layer_settings.setFormat(text_format)
    if clause:
        layer_settings.isExpression = True
        layer_settings.fieldName = clause
    else:
        layer_settings.fieldName = fn

    if position==-1:
        layer_settings.placement = QgsPalLayerSettings.Line
    else:
        layer_settings.placement = position
    layer_settings.enabled = True
    layer_settings.scaleVisibility = scaleVisibility
    if layer_settings.scaleVisibility:
        layer_settings.minimumScale = minimumScale # -> 1:5.000
        layer_settings.maximumScale = maximumScale # -> 1:5.000
    else:
        layer_settings.minimumScale = 0 # -> 1:5.000
        layer_settings.maximumScale = 0 # -> 1:5.000
    layer_settings = QgsVectorLayerSimpleLabeling(layer_settings)
    my_layer.setLabelsEnabled(True)
    my_layer.setLabeling(layer_settings)
    my_layer.triggerRepaint()

client_layers = {"RFDB":
                    {

                    'work_unit': ['rfdb_wu'],
                    'wu_connection': ['udbx3_wu_connection'],
                    'segment':['rfdb_road_segment'],
                    'intersection': ['rfdb_intersection'],
                    'path': ['rfdb_path_type','rfdb_path'],
                    'delineator':['rfdb_delin'],
                    'delineator_control_pts':['rfdb_delin'],
                    'crossing':['rfdb_crossing','rfdb_crossing_path'],
                    'sign':['rfdb_sign','rfdb_sign_centroid','rfdb_sign_path_association','rfdb_sign_face_azimuth'],
                    'ottonomo_sign': ['ottonomo_sign'],
                    'road_object': ['rfdb_road_object_path_association','rfdb_road_object_linestring','rfdb_road_object_polygon'],
                    'osm':['rfdb_osm_way'],
                    'change_management':['rfdb_change_tracking']},


                    "UDBX":{'road_segment':['udbx_road_segment'],
                    'lane_center_line':['udbx_lane'],
                    'lane_connection_nodes':['udbx_lane_connection','udbx_lane_connection_node'],
                    'lane_marker_line':['udbx_lane_line'],
                    'road_edge':['udbx_edge'],
                    'crossing':['udbx_lane_att_crossing_type'],
                    'speed_limit':['udbx_lane_att_speed_limit'],
                    'lane_change_allowed':['udbx_lane_att_left_change_allowed','udbx_lane_att_right_change_allowed'],
                    'functional_authority':['udbx_functional_authority'],
                    'sign':['udbx_sign','udbx_sign_lane_mapping'],
                    'pavement_marking':['udbx_pavement_marking','udbx_pavement_marking_lane_mapping'],
                    'osm':['udbx_osm_data'],
                    'reflective_markings':['udbx_line_attr_reflective_markings'],
                    'pavement_striping_present':['udbx_line_attr_pavement_striping_present'],
                    'lane_geom_feat':['udbx_lane_geom_feat']},

                    "GM":{'lane':['gm_lane','gm_lane_stacking'],
                    'edge':['gm_edge'],
                    'barrier':['gm_barrier'],
                    'crossing':['gm_crossing'],
                    'sign':['gm_sign','gm_sign_to_lane'],
                    'gmfa':[],
                    'marker':['gm_marker'],
                    'lane_connection':['gm_lane_connection'],
                    'lane_boundary':['gm_lane_end_point','gm_lane_start_point'],
                    'curvature, heading':['gm_point_curvature_direction'],
                    'speed_limit':['gm_lane_speed_limit'],
                    'lane_width':['gm_lane_width']},      
                    "UDBX3":{"coverage":['udbx3_coverage'],
                    'functional_authority':['udbx3_functional_authority'],
                            "road_segment":['udbx3_road_segment'],
                            "lane_center_line":['udbx3_lane'],
                            "lane_connection":['udbx3_lane_connection','udbx3_lane_connection_node'],
                            "lane_line":["udbx3_lane_line"],
                            "road edge":["udbx3_road_edge"],
                            "intersection":['udbx3_intersection_centroid', 'udbx3_intersection_geom'],
                            "speed_limit":['udbx3_lane_att_speed_limit_attribute'],
                            "crossing":['udbx3_lane_att_crossing_type_attribute'],
                            "lane_add_remove":['udbx3_lane_add_remove_type'],
                            "lane_change_allowed":['udbx3_lane_att_lane_change_allowed'],
                            "obstructed_shoulder":["udbx3_obstructed_shoulder"],
                            "rtd_lane_assignment":['udbx3_lane_att_regulatory_traffic_device_attribute'],
                            "rtd_apply_position":['udbx3_rtd_apply_position'],
                            "sign":['udbx3_sign_centroid','udbx3_sign','udbx3_sign_lane_mapping','udbx3_sign_face_azimuth'],
                            "pavement_marking":['udbx3_pavement_marking'],
                            "reflective_marking":['udbx3_line_attr_REFLECTIVE_MARKINGS_ATTRIBUTE'],
                            "pavement_striping_present":['udbx3_line_attr_PAVEMENT_STRIPING_PRESENT_ATTRIBUTE'],
                            "deceleration_marking_present":['udbx3_line_attr_DECELERATION_MARKING_PRESENT'],
                            "lane_line_geometry_centered":['udbx3_line_attr_LANE_LINE_GEOMETRY_CENTERED'],
                            "lane_center_points":['udbx3_lane_center_points'],
                            "lane_line_points":['udbx3_lane_line_points'],
                            "road_edge_points":['udbx3_road_edge_points']}             
                    }






# client_layers = {"RFDB":
#                     {'work_unit':['rfdb_wu'],
#                     'wu_connection':['udbx3_wu_connection'],
#                     'segment':['rfdb_road_segment'],
#                     'path':['rfdb_path_type','rfdb_path'],
#                     'delineator':['rfdb_delin'],
#                     'delineator_control_pts':['rfdb_delin'],
#                     'crossing':['rfdb_crossing','rfdb_crossing_path'],
#                     'sign':['rfdb_sign','rfdb_sign_centroid','rfdb_sign_path_association','rfdb_sign_face_azimuth'],
#                     'road_object':['rfdb_road_object_path_association','rfdb_road_object_polygon'],
#                     'osm':['rfdb_osm_way']},

#                     "UDBX":{'road_segment':['udbx_road_segment'],
#                     'lane_center_line':['udbx_lane'],
#                     'lane_connection':['udbx_lane_connection','udbx_lane_connection_node'],
#                     'lane_marker_line':['udbx_lane_line'],
#                     'road_edge':['udbx_edge'],
#                     'crossing':['udbx_lane_att_crossing_type'],
#                     'speed_limit':['udbx_lane_att_speed_limit'],
#                     'lane_change_allowed':['udbx_lane_att_left_change_allowed','udbx_lane_att_right_change_allowed'],
#                     'functional_authority':['udbx_functional_authority'],
#                     'sign':['udbx_sign','udbx_sign_lane_mapping'],
#                     'pavement_marking':['udbx_pavement_marking','udbx_pavement_marking_lane_mapping'],
#                     'osm':['udbx_osm_data'],
#                     'reflective_markings':['udbx_line_attr_reflective_markings'],
#                     'pavement_striping_present':['udbx_line_attr_pavement_striping_present'],
#                     'lane_geom_feat':['udbx_lane_geom_feat']},

#                     "GM":{'lane':['gm_lane','gm_lane_stacking'],
#                     'edge':['gm_edge'],
#                     'barrier':['gm_barrier'],
#                     'crossing':['gm_crossing'],
#                     'sign':['gm_sign','gm_sign_to_lane'],
#                     'gmfa':[],
#                     'marker':['gm_marker'],
#                     'lane_connection':['gm_lane_connection'],
#                     'lane_boundary':['gm_lane_end_point','gm_lane_start_point'],
#                     'curvature, heading':['gm_point_curvature_direction'],
#                     'speed_limit':['gm_lane_speed_limit'],
#                     'lane_width':['gm_lane_width']}
#                     }








