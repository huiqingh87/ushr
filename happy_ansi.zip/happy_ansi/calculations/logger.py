import os
import datetime


class Logger:
    def __init__(self, out_dir, out_file, fmt='csv', header=''):
        out_file_path = out_dir + '/' + f'{out_file}.{fmt}'
        if not os.path.exists(out_dir):
            os.makedirs(out_dir)
        if not os.path.exists(out_file_path):
            new_file = True
        else:
            new_file = False
        self.f = open(out_file_path, 'a')
        if new_file and header != '':
            self.f.write(f'{header}\n')

    def log(self, txt):
        self.f.write(txt)

    def close(self):
        self.f.close()


