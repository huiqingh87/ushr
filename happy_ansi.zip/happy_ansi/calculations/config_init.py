import configparser
import os


class ConfigInit:
    def __init__(self, filepath):
        self.filepath = filepath
        self.config = configparser.ConfigParser()

        if not os.path.exists(filepath):
            self.config['RFDB'] = {}
            self.config['UDBX'] = {}
            self.config['GM'] = {}
            self.config['AWS'] = {}
            self.config['LAZ'] = {}
            self.config['2D_LiDAR'] = {}
            self.config['Technician'] = {}
            self.config['Rules'] = {}
            with open(filepath, 'w') as configfile:
                self.config.write(configfile)
        else:
            self.config.read(filepath)

    def update_section(self, section, option, value):
        self.config.set(section, option, value)
        with open(self.filepath, 'w') as configfile:
            self.config.write(configfile)

    # if section not exist, create one
    def update_whole_section(self, section, dict_):
        if section not in self.config.sections():
            self.config.add_section(section)
        for key in dict_:
            value = dict_[key]
            self.config.set(section, key, value)

        with open(self.filepath, 'w') as configfile:
            self.config.write(configfile)

