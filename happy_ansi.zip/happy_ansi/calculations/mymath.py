import itertools
import numpy as np
import shapely.wkt
from shapely.geometry import LineString, Polygon
from calculations.projection import project_wgs84_utm


def convert_point_array_to_line(point_array):
    point_list = []
    for point in point_array:
        point_list.append(shapely.wkt.loads(point))
    return project_wgs84_utm(LineString(point_list))


def convert_wkt_to_utm_shapely(wkt_geom):
    geom = shapely.wkt.loads(wkt_geom)
    geom = project_wgs84_utm(geom)
    return geom


def convert_wkt_to_utm_np_array(wkt_geom):
    geom = convert_wkt_to_utm_shapely(wkt_geom)
    return np.array(geom)


def get_value_combi(iterable):
    value_combi_set = set([])
    for i in range(1, len(iterable) + 1):
        combi_list = itertools.combinations(iterable, i)
        for j in combi_list:
            sum_ = sum(list(j))
            value_combi_set.add(sum_)
    return list(value_combi_set)


def determine_point_left_right(heading, pt1, pt2):
    if np.array_equal(pt1, pt2):
        return 0
    if np.cross(pt2 - pt1, heading)[2] > 0:
        return -1
    else:
        return 1


def unit_vector(v):
    ret = v
    length = np.linalg.norm(v)
    try:
        ret = v / length
    except RuntimeWarning as e:
        print(f'unit_vector warning: {v}, {e}')
    return ret


def get_point_list_overall_vec(point_list):
    overall_vec = np.array(point_list[-1].coords[0]) - np.array(point_list[0].coords[0])
    return overall_vec


def angle(v1, v2):
    v1_u = unit_vector(v1)
    v2_u = unit_vector(v2)
    return np.arccos(np.dot(v1_u, v2_u))


def angle_rowwise(A, B):
    p1 = np.einsum('ij,ij->i', A, B)
    p2 = np.einsum('ij,ij->i', A, A)
    p3 = np.einsum('ij,ij->i', B, B)
    p4 = p1 / np.sqrt(p2*p3)
    return np.arccos(np.clip(p4, -1.0, 1.0))


# 1->[1], 12-> [1, 2]
def integer2list(int_):
    list_ = []
    while 1:
        list_.insert(0, int_ % 10)
        int_ = int_ // 10
        if int_ == 0:
            break
    return list_


def get_polygon_corner_pts(polygon_point_list, thold):
    polygon_point_list.pop()
    polygon_corner_pts = []
    polygon_corner_pt_inds = []
    for i in range(-1, len(polygon_point_list) - 1):
        ind_0, ind_1, ind_2 = i, i + 1, i + 2
        if ind_2 == len(polygon_point_list):
            ind_2 = 0
        v1 = np.array(polygon_point_list[ind_1].coords[0]) - np.asarray(polygon_point_list[ind_0].coords[0])
        v2 = np.array(polygon_point_list[ind_2].coords[0]) - np.asarray(polygon_point_list[ind_1].coords[0])
        angle_ = angle(v1, v2)
        if angle_ > thold:
            polygon_corner_pts.append(polygon_point_list[i + 1])
            polygon_corner_pt_inds.append(i + 1)
    polygon_corner_pts.append(polygon_corner_pts[0])
    return polygon_corner_pt_inds, polygon_corner_pts


if __name__ == '__main__':
    a = 121
    print(integer2list(a))

