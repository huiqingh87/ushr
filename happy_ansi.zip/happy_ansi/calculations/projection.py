from shapely.ops import transform
import pyproj
import numpy as np


wgs84 = pyproj.CRS('EPSG:4326')
utm = pyproj.CRS('EPSG:32618')
projection_wgs84_utm = pyproj.Transformer.from_crs(wgs84, utm, always_xy=True).transform
projection_utm_wgs84 = pyproj.Transformer.from_crs(utm, wgs84, always_xy=True).transform


def project_wgs84_utm(wgs84_geom):
    utm_geom = transform(projection_wgs84_utm, wgs84_geom)
    return utm_geom


def project_utm_wgs84(utm_geom):
    wgs84_geom = transform(projection_utm_wgs84, utm_geom)
    return wgs84_geom


def lla_to_enu(lla, origin, degrees=True):
    ecef = lla_to_ecef(lla, degrees)
    return ecef_to_enu(ecef, origin, degrees)


def lla_to_ecef(lla, degrees=True):
    lla_mat = check_array_pos(lla)
    ecef = pyproj.Proj(proj='geocent', ellps='WGS84', datum='WGS84')
    lla = pyproj.Proj(proj='latlong', ellps='WGS84', datum='WGS84')

    X, Y, Z = pyproj.transform(lla, ecef, lla_mat[:, 1], lla_mat[:, 0], lla_mat[:, 2], radians=(not degrees))
    return np.column_stack((X, Y, Z)).squeeze()


def ecef_to_enu(ecef, origin, degrees=True):
    ecef_mat = check_array_pos(ecef)

    # invert the model matrix to go from ECEF to ENU
    M_ECEF_ENU = get_ENU_ECEF(origin, degrees)
    return homogeneous_transform(ecef_mat, M_ECEF_ENU)


def get_ENU_ECEF(origin, degrees=True):
    def R_enu2ecef(lat, lon, degrees=True):
        if degrees:
            # Need radians for cos and sin
            lat = np.deg2rad(lat)
            lon = np.deg2rad(lon)

        phi = lat
        lam = lon
        R = np.array([[-np.sin(lam), np.cos(lam), 0.0],
                      [-np.sin(phi) * np.cos(lam), -np.sin(phi) * np.sin(lam), np.cos(phi)],
                      [np.cos(phi) * np.cos(lam), np.cos(phi) * np.sin(lam), np.sin(phi)]])
        return np.transpose(R)

    t = lla_to_ecef(origin, degrees)
    R = R_enu2ecef(origin[0], origin[1], degrees)

    X, Y, Z = R.T
    return basis_to_model_matrix(X, Y, Z, t)


def homogeneous_transform(X, M):
    # ensure its a np.array of the correct shape
    X = np.array(X)

    # perform the dot product optimally depending on what was passed in
    if X.shape[-1] == 4:
        return np.dot(X, M.T)
    elif X.shape[-1] == 3:
        return np.dot(X, M[:3, :3].T) + np.squeeze(M[:3, 3:])
    else:
        raise ValueError('Unsupported array shape for homogeneous transformation ' + str(X.shape))


def basis_to_model_matrix(X, Y, Z, origin):
    assert np.allclose(np.cross(X, Y), Z), 'Basis vectors must be right-handed'
    assert np.allclose([np.dot(X, Y), np.dot(X, Z), np.dot(Y, Z)], [0, 0, 0]), 'Basis vectors must be orthogonal'

    def pad(vect, val):
        return np.pad(np.array(vect), (0, 4 - np.array(vect).shape[0]),
                      'constant', constant_values=val).astype(np.float64)

    return np.column_stack((pad(X, 0.), pad(Y, 0.), pad(Z, 0.), pad(origin, 1.)))


def check_array_pos(X):

    if isinstance(X, list) or isinstance(X, tuple):
        assert len(X) == 3, 'if X is a tuple or a list it should contain 3 elements'
        X = pack(X)

    X = np.atleast_2d(X)

    assert len(X.shape) == 2 and X.shape[1] == 3, 'X should be [n x 3]'

    return X


def pack(x):
    assert isinstance(x, list) or isinstance(x, tuple)

    y = list(map(lambda u: np.array(u).ravel(), x))

    X = np.column_stack(y)

    return X
