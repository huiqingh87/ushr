# -*- coding: utf-8 -*-

import sys

from PyQt5.QtWidgets import *
import matplotlib.pyplot as plt
from matplotlib.figure import Figure

from matplotlib.backends.backend_qt5agg import (
    FigureCanvasQTAgg as FigureCanvas)

class MplCanvas(FigureCanvas):
    """Class to represent the FigureCanvas widget"""
    def __init__(self):
        plt.gcf().subplots_adjust(left=0.75)
        # Setup Matplotlib Figure and Axis
        self.fig = Figure(facecolor="white")
        self.axes = self.fig.add_subplot(111)

        # Initialization of the canvas
        super(MplCanvas, self).__init__(self.fig)

        # Define the widget as expandable
        FigureCanvas.setSizePolicy(self,
                                   QSizePolicy.Expanding,
                                   QSizePolicy.Expanding)

        # Notify the system of updated policy
        FigureCanvas.updateGeometry(self)

        # Call tight_layout on resize
        #self.mpl_connect('resize_event', self.fig.tight_layout)

class MplWidget(QWidget):
    """Widget defined in Qt Designer"""
    def __init__(self, parent = None):

        super(MplWidget, self).__init__(parent)

        # Set canvas and navigation toolbar
        self.canvas = MplCanvas()

        # Layout as vertical box
        self.vbl = QVBoxLayout()
        self.vbl.addWidget(self.canvas)
        self.setLayout(self.vbl)


if __name__ == "__main__":

    app = QApplication(sys.argv)

    W = MplWidget()

    W.canvas.axes.cla()

    values = [0.2, 0.5, 0.3]
    labels = ['label',
              'looooooog label',
              'very loooooooooooooooooooooooog label'
             ]

    W.canvas.axes.pie(values, labels=labels)
    W.canvas.axes.axis('equal')

    W.canvas.fig.tight_layout()
    W.canvas.draw()
    W.show()

    sys.exit(app.exec_())